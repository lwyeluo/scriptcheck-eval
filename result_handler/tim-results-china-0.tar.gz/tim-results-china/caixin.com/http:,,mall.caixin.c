[0713/011555.532768:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/011555.533017:INFO:switcher_clone.cc(787)] backtrace rip is 7f837f5a4891
[0713/011556.089408:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/011556.089655:INFO:switcher_clone.cc(787)] backtrace rip is 7f9841d3f891
[1:1:0713/011556.093455:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0713/011556.093624:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0713/011556.096439:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[0713/011556.924540:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/011556.924825:INFO:switcher_clone.cc(787)] backtrace rip is 7efd3e80d891
[6898:6898:0713/011556.978917:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/90c45ac7-32cc-4edf-8b9a-2028852ab66f
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[6931:6931:0713/011557.071114:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=6931
[6944:6944:0713/011557.071699:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=6944
[6898:6898:0713/011557.221549:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[6898:6929:0713/011557.222026:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0713/011557.222156:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0713/011557.222344:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0713/011557.222664:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0713/011557.222792:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0713/011557.224506:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x2b86bdd8, 1
[1:1:0713/011557.224744:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x1e2e5884, 0
[1:1:0713/011557.224843:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x17241c48, 3
[1:1:0713/011557.224899:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0xd519beb, 2
[1:1:0713/011557.224968:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffff84582e1e ffffffd8ffffffbdffffff862b ffffffebffffff9b510d 481c2417 , 10104, 4
[1:1:0713/011557.225666:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[6898:6929:0713/011557.225790:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�X.ؽ�+�QH$�Ϯ
[6898:6929:0713/011557.225840:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �X.ؽ�+�QH$��Ϯ
[1:1:0713/011557.225782:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f983ff790a0, 3
[1:1:0713/011557.225919:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f9840105080, 2
[6898:6929:0713/011557.226011:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[6898:6929:0713/011557.226062:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 6952, 4, 84582e1e d8bd862b eb9b510d 481c2417 
[1:1:0713/011557.226019:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f9829dc7d20, -2
[1:1:0713/011557.233783:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0713/011557.234223:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal d519beb
[1:1:0713/011557.234673:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal d519beb
[1:1:0713/011557.235430:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal d519beb
[1:1:0713/011557.235975:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal d519beb
[1:1:0713/011557.236104:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal d519beb
[1:1:0713/011557.236207:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal d519beb
[1:1:0713/011557.236307:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal d519beb
[1:1:0713/011557.236558:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal d519beb
[1:1:0713/011557.236675:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f9841d3f7ba
[1:1:0713/011557.236731:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f9841d36def, 7f9841d3f77a, 7f9841d410cf
[1:1:0713/011557.238477:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal d519beb
[1:1:0713/011557.238665:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal d519beb
[1:1:0713/011557.238990:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal d519beb
[1:1:0713/011557.239878:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal d519beb
[1:1:0713/011557.239995:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal d519beb
[1:1:0713/011557.240102:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal d519beb
[1:1:0713/011557.240230:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal d519beb
[1:1:0713/011557.241138:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal d519beb
[1:1:0713/011557.241350:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f9841d3f7ba
[1:1:0713/011557.241469:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f9841d36def, 7f9841d3f77a, 7f9841d410cf
[1:1:0713/011557.244131:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0713/011557.244391:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0713/011557.244498:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffd3c3088a8, 0x7ffd3c308828)
[1:1:0713/011557.251182:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0713/011557.253808:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[6898:6898:0713/011557.672742:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[6898:6898:0713/011557.673290:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[6898:6898:0713/011557.681511:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[6898:6898:0713/011557.681578:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[6898:6898:0713/011557.681651:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,6952, 4
[6898:6910:0713/011557.690811:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[6898:6910:0713/011557.690876:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[1:7:0713/011557.692193:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/011557.748985:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x3ae32c39220
[1:1:0713/011557.749240:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[6898:6921:0713/011557.753165:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0713/011557.954653:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0713/011558.679510:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/011558.681266:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[6898:6898:0713/011559.010286:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[6898:6898:0713/011559.010400:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0713/011559.174662:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/011559.261891:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 142db20a1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0713/011559.262094:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/011559.272208:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 142db20a1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0713/011559.272367:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/011559.305072:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/011559.305271:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/011559.449861:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 357, "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/011559.452321:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 142db20a1f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0713/011559.452466:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/011559.464308:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 358, "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/011559.467297:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 142db20a1f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0713/011559.467435:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/011559.471228:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[6898:6898:0713/011559.471920:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0713/011559.473008:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x3ae32c37e20
[1:1:0713/011559.473136:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[6898:6898:0713/011559.474365:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[6898:6898:0713/011559.485828:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[6898:6898:0713/011559.485908:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0713/011559.506202:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/011559.805345:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 418 0x7f982b9a22e0 0x3ae32e78ee0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/011559.805983:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 142db20a1f78, , , var configData = {"googleBaseUrl":"https://www.google.com.hk/","isAccessibleBrowser":false,"isGoogle
[1:1:0713/011559.806128:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/011559.806690:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[6898:6898:0713/011559.831427:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0713/011559.832509:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x3ae32c38820
[1:1:0713/011559.832667:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[6898:6898:0713/011559.833833:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0713/011559.839552:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0713/011559.839720:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[6898:6898:0713/011559.840730:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[6898:6898:0713/011559.844833:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[6898:6898:0713/011559.845282:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[6898:6910:0713/011559.849708:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[6898:6910:0713/011559.849759:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[6898:6898:0713/011559.849781:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[6898:6898:0713/011559.849820:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[6898:6898:0713/011559.849879:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,6952, 4
[1:7:0713/011559.851488:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/011600.126846:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0713/011600.318052:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 472 0x7f982b9a22e0 0x3ae32e702e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/011600.318719:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 142db20a1f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0713/011600.318879:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/011600.319289:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[6898:6898:0713/011600.423424:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[6898:6898:0713/011600.423491:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0713/011600.435600:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[6898:6898:0713/011600.532812:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[6898:6929:0713/011600.533096:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0713/011600.533223:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0713/011600.533355:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0713/011600.533539:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0713/011600.533618:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0713/011600.536105:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x58f00ad, 1
[1:1:0713/011600.536332:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x2c8893cf, 0
[1:1:0713/011600.536451:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x322bf5e5, 3
[1:1:0713/011600.536590:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x1dc0cb91, 2
[1:1:0713/011600.536710:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffcfffffff93ffffff882c ffffffad00ffffff8f05 ffffff91ffffffcbffffffc01d ffffffe5fffffff52b32 , 10104, 5
[1:1:0713/011600.537443:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[6898:6929:0713/011600.537628:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGϓ�,�
[6898:6929:0713/011600.537670:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ϓ�,�
[6898:6929:0713/011600.537821:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 6996, 5, cf93882c ad008f05 91cbc01d e5f52b32 
[1:1:0713/011600.537617:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f983ff790a0, 3
[1:1:0713/011600.538082:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f9840105080, 2
[1:1:0713/011600.538192:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f9829dc7d20, -2
[1:1:0713/011600.547648:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0713/011600.547872:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1dc0cb91
[1:1:0713/011600.548054:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1dc0cb91
[1:1:0713/011600.548393:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1dc0cb91
[1:1:0713/011600.548902:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1dc0cb91
[1:1:0713/011600.549001:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1dc0cb91
[1:1:0713/011600.549121:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1dc0cb91
[1:1:0713/011600.549215:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1dc0cb91
[1:1:0713/011600.549473:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1dc0cb91
[1:1:0713/011600.549600:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f9841d3f7ba
[1:1:0713/011600.549675:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f9841d36def, 7f9841d3f77a, 7f9841d410cf
[1:1:0713/011600.551355:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1dc0cb91
[1:1:0713/011600.551545:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1dc0cb91
[1:1:0713/011600.551864:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1dc0cb91
[1:1:0713/011600.552632:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1dc0cb91
[1:1:0713/011600.552739:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1dc0cb91
[1:1:0713/011600.552813:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1dc0cb91
[1:1:0713/011600.552891:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1dc0cb91
[1:1:0713/011600.553399:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1dc0cb91
[1:1:0713/011600.553570:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f9841d3f7ba
[1:1:0713/011600.553634:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f9841d36def, 7f9841d3f77a, 7f9841d410cf
[1:1:0713/011600.556184:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0713/011600.556416:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0713/011600.556529:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffd3c3088a8, 0x7ffd3c308828)
[1:1:0713/011600.562784:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0713/011600.564693:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0713/011600.570882:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/011600.666546:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x3ae32bc1220
[1:1:0713/011600.666710:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0713/011600.842732:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/011600.842913:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/011600.983723:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 540, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/011600.985581:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 142db21ce5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0713/011600.985770:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/011600.988551:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[6898:6898:0713/011600.990017:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[6898:6898:0713/011600.991949:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[6898:6910:0713/011601.011384:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[6898:6910:0713/011601.011451:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[6898:6898:0713/011601.011579:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://mall.caixin.com/
[6898:6898:0713/011601.011624:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://mall.caixin.com/, http://mall.caixin.com/mall/web/index/index.html, 1
[6898:6898:0713/011601.011694:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://mall.caixin.com/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 17:12:36 GMT Content-Type: text/html; charset=UTF-8 Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Content-Encoding: gzip  ,6996, 5
[1:7:0713/011601.015792:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/011601.027821:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://mall.caixin.com/
[1:1:0713/011601.044755:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/011601.045168:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 142db20a1f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0713/011601.045276:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[6898:6898:0713/011601.087503:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://mall.caixin.com/, http://mall.caixin.com/, 1
[6898:6898:0713/011601.087569:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://mall.caixin.com/, http://mall.caixin.com
[1:1:0713/011601.096768:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/011601.137257:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/011601.156500:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/011601.157332:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0713/011601.157481:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 142db21ce5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0713/011601.157635:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/011601.168803:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/011601.168987:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011601.186511:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 123 0x7f9829a7a070 0x3ae32ce10e0 , "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011601.187491:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mall.caixin.com/, 074a61d22860, , , 
        (function(){
            var vua=navigator.userAgent.toLowerCase();
            var isMob=(
[1:1:0713/011601.187656:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mall.caixin.com/mall/web/index/index.html", "mall.caixin.com", 3, 1, , , 0
[1:1:0713/011601.224869:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/011601.225453:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0713/011601.225561:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 142db21ce5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0713/011601.225690:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/011601.450748:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 156 0x7f9829a7a070 0x3ae32d478e0 , "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011601.462404:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mall.caixin.com/, 074a61d22860, , , /*

*设置cookie值

*/

function SetCookieValue(_Name,_Value,_Expires,_Type){

  var _LargeExpDate
[1:1:0713/011601.462576:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mall.caixin.com/mall/web/index/index.html", "mall.caixin.com", 3, 1, , , 0
[1:1:0713/011601.485013:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 156 0x7f9829a7a070 0x3ae32d478e0 , "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011601.534688:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/011601.569571:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.105769, 471, 1
[1:1:0713/011601.569743:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/011601.696309:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/011601.696509:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011601.697850:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 190 0x7f9829a7a070 0x3ae32d910e0 , "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011601.698926:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mall.caixin.com/, 074a61d22860, , , function getCCTailString(){
 var myDate = new Date();
 var mySecond = myDate.getSeconds();
 var myCY
[1:1:0713/011601.699065:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mall.caixin.com/mall/web/index/index.html", "mall.caixin.com", 3, 1, , , 0
[1:1:0713/011601.719998:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/011601.796592:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 210 0x7f9829de2bd0 0x3ae32cd8d58 , "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011601.802490:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mall.caixin.com/, 074a61d22860, , , !function(e){"use strict";function t(e){return e=e.slice(),function(t){t&&l(t),i(e,function(e){for(t
[1:1:0713/011601.802698:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mall.caixin.com/mall/web/index/index.html", "mall.caixin.com", 3, 1, , , 0
		remove user.e_b60eaaf0 -> 0
[1:1:0713/011601.911895:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 210 0x7f9829de2bd0 0x3ae32cd8d58 , "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011605.918003:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[6898:6910:0713/011620.365715:ERROR:ssl_client_socket_impl.cc(1046)] handshake failed; returned -1, SSL error code 1, net_error -101
[6898:6898:0713/011620.386916:INFO:CONSOLE(127)] "Uncaught ReferenceError: $ is not defined", source: http://file.caixin.com/webjs/comment/count_comment.js (127)
[3:3:0713/011620.395971:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0713/011620.503442:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x35882d3829c8, 0x3ae327de9a0
[1:1:0713/011620.503668:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mall.caixin.com/mall/web/index/index.html", 15000
[1:1:0713/011620.503957:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mall.caixin.com/, 270
[1:1:0713/011620.504115:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 270 0x7f9829a7a070 0x3ae32fc1760 , 5:3_http://mall.caixin.com/, 1, -5:3_http://mall.caixin.com/, 210 0x7f9829de2bd0 0x3ae32cd8d58 
[1:1:0713/011620.507201:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 18.5959, 0, 0
[1:1:0713/011620.507395:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/011620.681441:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mall.caixin.com/, 074a61d22860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0713/011620.681669:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mall.caixin.com/mall/web/index/index.html", "mall.caixin.com", 3, 1, , , 0
[1:1:0713/011620.842063:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/011620.842245:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011620.843889:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 271 0x7f9829a7a070 0x3ae32fa17e0 , "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011620.845768:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mall.caixin.com/, 074a61d22860, , , var urp = new Array();                                        
var urpv = new Array();              
[1:1:0713/011620.845915:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mall.caixin.com/mall/web/index/index.html", "mall.caixin.com", 3, 1, , , 0
[1:1:0713/011620.889605:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 271 0x7f9829a7a070 0x3ae32fa17e0 , "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011620.898210:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 271 0x7f9829a7a070 0x3ae32fa17e0 , "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011620.902159:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 271 0x7f9829a7a070 0x3ae32fa17e0 , "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011620.912317:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 271 0x7f9829a7a070 0x3ae32fa17e0 , "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011620.917361:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011620.919004:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011622.018595:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mall.caixin.com/, 074a61d22860, , , document.readyState
[1:1:0713/011622.018759:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mall.caixin.com/mall/web/index/index.html", "mall.caixin.com", 3, 1, , , 0
[1:1:0713/011622.325008:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 409 0x7f982b9a22e0 0x3ae32e447e0 , "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011622.327285:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mall.caixin.com/, 074a61d22860, , , 
// Copyright 2012 Google Inc. All rights reserved.
(function(){

var data = {
"resource": {
  "vers
[1:1:0713/011622.327413:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mall.caixin.com/mall/web/index/index.html", "mall.caixin.com", 3, 1, , , 0
[1:1:0713/011622.336727:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x35882d3829c8, 0x3ae327de990
[1:1:0713/011622.336859:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mall.caixin.com/mall/web/index/index.html", 0
[1:1:0713/011622.337068:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mall.caixin.com/, 458
[1:1:0713/011622.337177:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 458 0x7f9829a7a070 0x3ae32e44a60 , 5:3_http://mall.caixin.com/, 1, -5:3_http://mall.caixin.com/, 409 0x7f982b9a22e0 0x3ae32e447e0 
[1:1:0713/011622.337568:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x35882d3829c8, 0x3ae327de990
[1:1:0713/011622.337660:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mall.caixin.com/mall/web/index/index.html", 0
[1:1:0713/011622.337816:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mall.caixin.com/, 459
[1:1:0713/011622.337918:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 459 0x7f9829a7a070 0x3ae32cd69e0 , 5:3_http://mall.caixin.com/, 1, -5:3_http://mall.caixin.com/, 409 0x7f982b9a22e0 0x3ae32e447e0 
[1:1:0713/011622.346189:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 410 0x7f982b9a22e0 0x3ae3314cd60 , "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011622.347650:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mall.caixin.com/, 074a61d22860, , , !function(t,e){function i(t){for(var e;e=t.shift();)e()}function n(){p.loading=1;var n,o="";try{n=t.
[1:1:0713/011622.347822:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mall.caixin.com/mall/web/index/index.html", "mall.caixin.com", 3, 1, , , 0
[1:1:0713/011622.398999:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 414 0x7f982b9a22e0 0x3ae32ddf0e0 , "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011622.401055:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mall.caixin.com/, 074a61d22860, , , (function(){var k=this||self,l=function(a,b){a=a.split(".");var c=k;a[0]in c||"undefined"==typeof c.
[1:1:0713/011622.401263:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mall.caixin.com/mall/web/index/index.html", "mall.caixin.com", 3, 1, , , 0
[1:1:0713/011622.652478:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 415 0x7f982b9a22e0 0x3ae32cd3a60 , "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011622.655724:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mall.caixin.com/, 074a61d22860, , , !function t(e,r,i){function n(s,a){if(!r[s]){if(!e[s]){var u="function"==typeof require&&require;if(
[1:1:0713/011622.655895:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mall.caixin.com/mall/web/index/index.html", "mall.caixin.com", 3, 1, , , 0
[1:1:0713/011622.839414:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1500, 0x35882d3829c8, 0x3ae327dea80
[1:1:0713/011622.839607:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mall.caixin.com/mall/web/index/index.html", 1500
[1:1:0713/011622.839874:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mall.caixin.com/, 516
[1:1:0713/011622.840019:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 516 0x7f9829a7a070 0x3ae33d7bf60 , 5:3_http://mall.caixin.com/, 1, -5:3_http://mall.caixin.com/, 415 0x7f982b9a22e0 0x3ae32cd3a60 
[1:1:0713/011622.934546:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mall.caixin.com/, 074a61d22860, , , document.readyState
[1:1:0713/011622.934728:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mall.caixin.com/mall/web/index/index.html", "mall.caixin.com", 3, 1, , , 0
[1:1:0713/011623.210123:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 449 0x7f982b9a22e0 0x3ae3319f3e0 , "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011623.222038:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mall.caixin.com/, 074a61d22860, , , require.defineCSS('mallPC/1.8.24/c-layer/c-layer.css', "*html{background-image:url(about:blank);back
[1:1:0713/011623.222200:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mall.caixin.com/mall/web/index/index.html", "mall.caixin.com", 3, 1, , , 0
[1:1:0713/011623.261786:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011623.661152:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x35882d3829c8, 0x3ae327dea10
[1:1:0713/011623.661399:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mall.caixin.com/mall/web/index/index.html", 3000
[1:1:0713/011623.661719:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mall.caixin.com/, 568
[1:1:0713/011623.661883:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 568 0x7f9829a7a070 0x3ae34199f60 , 5:3_http://mall.caixin.com/, 1, -5:3_http://mall.caixin.com/, 449 0x7f982b9a22e0 0x3ae3319f3e0 
[1:1:0713/011623.677712:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x35882d3829c8, 0x3ae327dea10
[1:1:0713/011623.677903:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mall.caixin.com/mall/web/index/index.html", 3000
[1:1:0713/011623.678157:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mall.caixin.com/, 569
[1:1:0713/011623.678318:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 569 0x7f9829a7a070 0x3ae34275be0 , 5:3_http://mall.caixin.com/, 1, -5:3_http://mall.caixin.com/, 449 0x7f982b9a22e0 0x3ae3319f3e0 
[1:1:0713/011623.719589:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x35882d3829c8, 0x3ae327dea10
[1:1:0713/011623.719744:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mall.caixin.com/mall/web/index/index.html", 0
[1:1:0713/011623.719943:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mall.caixin.com/, 570
[1:1:0713/011623.720044:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 570 0x7f9829a7a070 0x3ae342d1ae0 , 5:3_http://mall.caixin.com/, 1, -5:3_http://mall.caixin.com/, 449 0x7f982b9a22e0 0x3ae3319f3e0 
[1:1:0713/011623.742214:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mall.caixin.com/mall/web/index/index.html", 13
[1:1:0713/011623.742472:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mall.caixin.com/, 571
[1:1:0713/011623.742595:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 571 0x7f9829a7a070 0x3ae342e7ae0 , 5:3_http://mall.caixin.com/, 1, -5:3_http://mall.caixin.com/, 449 0x7f982b9a22e0 0x3ae3319f3e0 
[1:1:0713/011623.802916:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mall.caixin.com/, 458, 7f982c3bf881
[1:1:0713/011623.811243:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"074a61d22860","ptid":"409 0x7f982b9a22e0 0x3ae32e447e0 ","rf":"5:3_http://mall.caixin.com/"}
[1:1:0713/011623.811439:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://mall.caixin.com/","ptid":"409 0x7f982b9a22e0 0x3ae32e447e0 ","rf":"5:3_http://mall.caixin.com/"}
[1:1:0713/011623.811694:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011623.812059:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mall.caixin.com/, 074a61d22860, , of, (){var a=nf();try{var b=yc.h,c=v["dataLayer"].hide;if(c&&void 0!==c[b]&&c.end){c[b]=!1;var d=!0,e;fo
[1:1:0713/011623.812188:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mall.caixin.com/mall/web/index/index.html", "mall.caixin.com", 3, 1, , , 0
[1:1:0713/011623.851749:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 458 0x7f9829a7a070 0x3ae32e44a60 , "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011623.858756:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mall.caixin.com/, 459, 7f982c3bf881
[1:1:0713/011623.868615:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"074a61d22860","ptid":"409 0x7f982b9a22e0 0x3ae32e447e0 ","rf":"5:3_http://mall.caixin.com/"}
[1:1:0713/011623.868799:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://mall.caixin.com/","ptid":"409 0x7f982b9a22e0 0x3ae32e447e0 ","rf":"5:3_http://mall.caixin.com/"}
[1:1:0713/011623.869003:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011623.869315:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mall.caixin.com/, 074a61d22860, , , (){b.gtmDom||(b.gtmDom=!0,a.push({event:"gtm.dom"}))}
[1:1:0713/011623.869421:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mall.caixin.com/mall/web/index/index.html", "mall.caixin.com", 3, 1, , , 0
[1:1:0713/011624.536054:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011624.536455:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mall.caixin.com/, 074a61d22860, , i.onreadystatechange, (){return 4===i.readyState?"function"==typeof e?e(i):void 0:"function"==typeof r?r(i):void 0}
[1:1:0713/011624.536574:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mall.caixin.com/mall/web/index/index.html", "mall.caixin.com", 3, 1, , , 0
[1:1:0713/011624.536959:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011624.538132:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011624.556631:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011624.557117:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mall.caixin.com/, 074a61d22860, , , (){return 4===u.readyState&&(""!==o&&(t.sendVisitTimeout-=300),t.removeAjax(u),window.grWaitTime=+Da
[1:1:0713/011624.557264:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mall.caixin.com/mall/web/index/index.html", "mall.caixin.com", 3, 1, , , 0
[1:1:0713/011624.557740:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011624.570128:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mall.caixin.com/, 074a61d22860, , , document.readyState
[1:1:0713/011624.570301:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mall.caixin.com/mall/web/index/index.html", "mall.caixin.com", 3, 1, , , 0
[1:1:0713/011624.802215:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011624.802637:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mall.caixin.com/, 074a61d22860, , r, (e,o){var s,l,c,f;try{if(r&&(o||4===u.readyState))if(r=t,a&&(u.onreadystatechange=ut.noop,Kn&&delete
[1:1:0713/011624.802780:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mall.caixin.com/mall/web/index/index.html", "mall.caixin.com", 3, 1, , , 0
[1:1:0713/011624.803384:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011624.804708:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011624.805123:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x2c93517b3bf8
[1:1:0713/011625.189260:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mall.caixin.com/, 570, 7f982c3bf881
[1:1:0713/011625.199598:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"074a61d22860","ptid":"449 0x7f982b9a22e0 0x3ae3319f3e0 ","rf":"5:3_http://mall.caixin.com/"}
[1:1:0713/011625.199798:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://mall.caixin.com/","ptid":"449 0x7f982b9a22e0 0x3ae3319f3e0 ","rf":"5:3_http://mall.caixin.com/"}
[1:1:0713/011625.200036:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011625.200373:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mall.caixin.com/, 074a61d22860, , , (){Zn=t}
[1:1:0713/011625.200509:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mall.caixin.com/mall/web/index/index.html", "mall.caixin.com", 3, 1, , , 0
[1:1:0713/011625.225758:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mall.caixin.com/, 571, 7f982c3bf8db
[1:1:0713/011625.236803:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"074a61d22860","ptid":"449 0x7f982b9a22e0 0x3ae3319f3e0 ","rf":"5:3_http://mall.caixin.com/"}
[1:1:0713/011625.236988:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://mall.caixin.com/","ptid":"449 0x7f982b9a22e0 0x3ae3319f3e0 ","rf":"5:3_http://mall.caixin.com/"}
[1:1:0713/011625.237229:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mall.caixin.com/, 625
[1:1:0713/011625.237315:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 625 0x7f9829a7a070 0x3ae33146360 , 5:3_http://mall.caixin.com/, 0, , 571 0x7f9829a7a070 0x3ae342e7ae0 
[1:1:0713/011625.237473:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011625.237767:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mall.caixin.com/, 074a61d22860, , ut.fx.tick, (){var e,n=ut.timers,r=0;for(Zn=ut.now();r<n.length;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.leng
[1:1:0713/011625.237871:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mall.caixin.com/mall/web/index/index.html", "mall.caixin.com", 3, 1, , , 0
[1:1:0713/011625.295928:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011625.296338:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mall.caixin.com/, 074a61d22860, , r, (e,o){var s,l,c,f;try{if(r&&(o||4===u.readyState))if(r=t,a&&(u.onreadystatechange=ut.noop,Kn&&delete
[1:1:0713/011625.296465:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mall.caixin.com/mall/web/index/index.html", "mall.caixin.com", 3, 1, , , 0
[1:1:0713/011625.297549:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011625.299735:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011625.300116:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x2c93517b3bf8
[1:1:0713/011625.737739:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x35882d3829c8, 0x3ae327dea10
[1:1:0713/011625.737938:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mall.caixin.com/mall/web/index/index.html", 100
[1:1:0713/011625.738173:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mall.caixin.com/, 634
[1:1:0713/011625.738300:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 634 0x7f9829a7a070 0x3ae3471b2e0 , 5:3_http://mall.caixin.com/, 1, -5:3_http://mall.caixin.com/, 581
[1:1:0713/011625.794496:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 200, 0x35882d3829c8, 0x3ae327dea10
[1:1:0713/011625.794655:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mall.caixin.com/mall/web/index/index.html", 200
[1:1:0713/011625.794847:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mall.caixin.com/, 635
[1:1:0713/011625.794958:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 635 0x7f9829a7a070 0x3ae3483ac60 , 5:3_http://mall.caixin.com/, 1, -5:3_http://mall.caixin.com/, 581
[1:1:0713/011625.821836:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: the server responded with a status of 502 (Bad Gateway)","https://www.qipus.cn/cmp/cmp.api?r=&s=5004&u=http%3A%2F%2Fmall.caixin.com%2Fmall%2Fweb%2Findex%2Findex.html"
[1:1:0713/011625.857676:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 584 0x7f982b9a22e0 0x3ae3438c960 , "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011625.858216:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mall.caixin.com/, 074a61d22860, , , _4IFRD('CLAnatI5Al0pHgsbR1XsgQA')
[1:1:0713/011625.858367:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mall.caixin.com/mall/web/index/index.html", "mall.caixin.com", 3, 1, , , 0
[1:1:0713/011625.893635:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mall.caixin.com/, 516, 7f982c3bf881
[1:1:0713/011625.904780:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"074a61d22860","ptid":"415 0x7f982b9a22e0 0x3ae32cd3a60 ","rf":"5:3_http://mall.caixin.com/"}
[1:1:0713/011625.904960:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://mall.caixin.com/","ptid":"415 0x7f982b9a22e0 0x3ae32cd3a60 ","rf":"5:3_http://mall.caixin.com/"}
[1:1:0713/011625.905187:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011625.905492:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mall.caixin.com/, 074a61d22860, , , (){return t.registerDomObserver()}
[1:1:0713/011625.905602:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mall.caixin.com/mall/web/index/index.html", "mall.caixin.com", 3, 1, , , 0
[1:1:0713/011625.976848:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mall.caixin.com/, 074a61d22860, , , document.readyState
[1:1:0713/011625.977016:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mall.caixin.com/mall/web/index/index.html", "mall.caixin.com", 3, 1, , , 0
[1:1:0713/011626.717941:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mall.caixin.com/, 634, 7f982c3bf881
[1:1:0713/011626.728441:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"074a61d22860","ptid":"581","rf":"5:3_http://mall.caixin.com/"}
[1:1:0713/011626.728658:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://mall.caixin.com/","ptid":"581","rf":"5:3_http://mall.caixin.com/"}
[1:1:0713/011626.728890:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011626.729306:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mall.caixin.com/, 074a61d22860, , , (){$("img.lazy").trigger("sporty")}
[1:1:0713/011626.729485:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mall.caixin.com/mall/web/index/index.html", "mall.caixin.com", 3, 1, , , 0
[1:1:0713/011627.162570:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011627.163079:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mall.caixin.com/, 074a61d22860, , d.onload.d.onerror, (){d.onload=null;d.onerror=null;c()}
[1:1:0713/011627.163253:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mall.caixin.com/mall/web/index/index.html", "mall.caixin.com", 3, 1, , , 0
[1:1:0713/011627.176465:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mall.caixin.com/, 074a61d22860, , , document.readyState
[1:1:0713/011627.176689:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mall.caixin.com/mall/web/index/index.html", "mall.caixin.com", 3, 1, , , 0
[1:1:0713/011627.178083:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mall.caixin.com/, 635, 7f982c3bf881
[1:1:0713/011627.190040:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"074a61d22860","ptid":"581","rf":"5:3_http://mall.caixin.com/"}
[1:1:0713/011627.190203:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://mall.caixin.com/","ptid":"581","rf":"5:3_http://mall.caixin.com/"}
[1:1:0713/011627.190429:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011627.190748:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mall.caixin.com/, 074a61d22860, , , (){f()}
[1:1:0713/011627.190872:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mall.caixin.com/mall/web/index/index.html", "mall.caixin.com", 3, 1, , , 0
[1:1:0713/011627.424508:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mall.caixin.com/, 569, 7f982c3bf881
[1:1:0713/011627.436544:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"074a61d22860","ptid":"449 0x7f982b9a22e0 0x3ae3319f3e0 ","rf":"5:3_http://mall.caixin.com/"}
[1:1:0713/011627.436758:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://mall.caixin.com/","ptid":"449 0x7f982b9a22e0 0x3ae3319f3e0 ","rf":"5:3_http://mall.caixin.com/"}
[1:1:0713/011627.436975:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011627.437287:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mall.caixin.com/, 074a61d22860, , , (){i.next()}
[1:1:0713/011627.437404:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mall.caixin.com/mall/web/index/index.html", "mall.caixin.com", 3, 1, , , 0
[1:1:0713/011627.438440:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x35882d3829c8, 0x3ae327de950
[1:1:0713/011627.438568:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mall.caixin.com/mall/web/index/index.html", 3000
[1:1:0713/011627.438771:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mall.caixin.com/, 717
[1:1:0713/011627.438881:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 717 0x7f9829a7a070 0x3ae3293c2e0 , 5:3_http://mall.caixin.com/, 1, -5:3_http://mall.caixin.com/, 569 0x7f9829a7a070 0x3ae34275be0 
[1:1:0713/011627.474428:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x35882d3829c8, 0x3ae327de950
[1:1:0713/011627.474577:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mall.caixin.com/mall/web/index/index.html", 0
[1:1:0713/011627.474764:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mall.caixin.com/, 719
[1:1:0713/011627.474945:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 719 0x7f9829a7a070 0x3ae34db59e0 , 5:3_http://mall.caixin.com/, 1, -5:3_http://mall.caixin.com/, 569 0x7f9829a7a070 0x3ae34275be0 
[1:1:0713/011627.484418:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mall.caixin.com/mall/web/index/index.html", 13
[1:1:0713/011627.484680:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mall.caixin.com/, 721
[1:1:0713/011627.484777:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 721 0x7f9829a7a070 0x3ae34db8ae0 , 5:3_http://mall.caixin.com/, 1, -5:3_http://mall.caixin.com/, 569 0x7f9829a7a070 0x3ae34275be0 
[1:1:0713/011627.502519:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011627.502993:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mall.caixin.com/, 074a61d22860, , y.handle, (e){return typeof ut===J||e&&ut.event.triggered===e.type?t:ut.event.dispatch.apply(f.elem,arguments)
[1:1:0713/011627.503126:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mall.caixin.com/mall/web/index/index.html", "mall.caixin.com", 3, 1, , , 0
[1:1:0713/011627.539135:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011627.539523:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mall.caixin.com/, 074a61d22860, , y.handle, (e){return typeof ut===J||e&&ut.event.triggered===e.type?t:ut.event.dispatch.apply(f.elem,arguments)
[1:1:0713/011627.539653:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mall.caixin.com/mall/web/index/index.html", "mall.caixin.com", 3, 1, , , 0
[1:1:0713/011627.561243:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011627.561698:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mall.caixin.com/, 074a61d22860, , y.handle, (e){return typeof ut===J||e&&ut.event.triggered===e.type?t:ut.event.dispatch.apply(f.elem,arguments)
[1:1:0713/011627.561839:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mall.caixin.com/mall/web/index/index.html", "mall.caixin.com", 3, 1, , , 0
[1:1:0713/011627.584382:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011627.584815:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mall.caixin.com/, 074a61d22860, , y.handle, (e){return typeof ut===J||e&&ut.event.triggered===e.type?t:ut.event.dispatch.apply(f.elem,arguments)
[1:1:0713/011627.584924:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mall.caixin.com/mall/web/index/index.html", "mall.caixin.com", 3, 1, , , 0
[1:1:0713/011627.607732:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011627.608121:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mall.caixin.com/, 074a61d22860, , y.handle, (e){return typeof ut===J||e&&ut.event.triggered===e.type?t:ut.event.dispatch.apply(f.elem,arguments)
[1:1:0713/011627.608214:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mall.caixin.com/mall/web/index/index.html", "mall.caixin.com", 3, 1, , , 0
[1:1:0713/011627.644705:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011627.645166:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mall.caixin.com/, 074a61d22860, , y.handle, (e){return typeof ut===J||e&&ut.event.triggered===e.type?t:ut.event.dispatch.apply(f.elem,arguments)
[1:1:0713/011627.645310:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mall.caixin.com/mall/web/index/index.html", "mall.caixin.com", 3, 1, , , 0
[1:1:0713/011627.976781:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mall.caixin.com/, 074a61d22860, , , document.readyState
[1:1:0713/011627.976961:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mall.caixin.com/mall/web/index/index.html", "mall.caixin.com", 3, 1, , , 0
[1:1:0713/011628.118269:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mall.caixin.com/, 719, 7f982c3bf881
[1:1:0713/011628.131754:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"074a61d22860","ptid":"569 0x7f9829a7a070 0x3ae34275be0 ","rf":"5:3_http://mall.caixin.com/"}
[1:1:0713/011628.131961:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://mall.caixin.com/","ptid":"569 0x7f9829a7a070 0x3ae34275be0 ","rf":"5:3_http://mall.caixin.com/"}
[1:1:0713/011628.132189:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011628.132565:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mall.caixin.com/, 074a61d22860, , , (){Zn=t}
[1:1:0713/011628.132705:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mall.caixin.com/mall/web/index/index.html", "mall.caixin.com", 3, 1, , , 0
[1:1:0713/011628.165978:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mall.caixin.com/, 721, 7f982c3bf8db
[1:1:0713/011628.179037:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"074a61d22860","ptid":"569 0x7f9829a7a070 0x3ae34275be0 ","rf":"5:3_http://mall.caixin.com/"}
[1:1:0713/011628.179227:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://mall.caixin.com/","ptid":"569 0x7f9829a7a070 0x3ae34275be0 ","rf":"5:3_http://mall.caixin.com/"}
[1:1:0713/011628.179478:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mall.caixin.com/, 755
[1:1:0713/011628.179614:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 755 0x7f9829a7a070 0x3ae34e93d60 , 5:3_http://mall.caixin.com/, 0, , 721 0x7f9829a7a070 0x3ae34db8ae0 
[1:1:0713/011628.179776:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011628.180083:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mall.caixin.com/, 074a61d22860, , ut.fx.tick, (){var e,n=ut.timers,r=0;for(Zn=ut.now();r<n.length;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.leng
[1:1:0713/011628.180181:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mall.caixin.com/mall/web/index/index.html", "mall.caixin.com", 3, 1, , , 0
[1:1:0713/011628.382496:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mall.caixin.com/, 074a61d22860, , , document.readyState
[1:1:0713/011628.382789:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mall.caixin.com/mall/web/index/index.html", "mall.caixin.com", 3, 1, , , 0
[1:1:0713/011628.424967:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011628.425425:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mall.caixin.com/, 074a61d22860, , y.handle, (e){return typeof ut===J||e&&ut.event.triggered===e.type?t:ut.event.dispatch.apply(f.elem,arguments)
[1:1:0713/011628.425558:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mall.caixin.com/mall/web/index/index.html", "mall.caixin.com", 3, 1, , , 0
[1:1:0713/011628.666178:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mall.caixin.com/, 755, 7f982c3bf8db
[1:1:0713/011628.680530:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"721 0x7f9829a7a070 0x3ae34db8ae0 ","rf":"5:3_http://mall.caixin.com/"}
[1:1:0713/011628.680705:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"721 0x7f9829a7a070 0x3ae34db8ae0 ","rf":"5:3_http://mall.caixin.com/"}
[1:1:0713/011628.680912:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mall.caixin.com/, 789
[1:1:0713/011628.681003:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 789 0x7f9829a7a070 0x3ae34f8a9e0 , 5:3_http://mall.caixin.com/, 0, , 755 0x7f9829a7a070 0x3ae34e93d60 
[1:1:0713/011628.681154:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011628.681432:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mall.caixin.com/, 074a61d22860, , ut.fx.tick, (){var e,n=ut.timers,r=0;for(Zn=ut.now();r<n.length;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.leng
[1:1:0713/011628.681551:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mall.caixin.com/mall/web/index/index.html", "mall.caixin.com", 3, 1, , , 0
[1:1:0713/011628.780216:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011628.780784:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mall.caixin.com/, 074a61d22860, , y.handle, (e){return typeof ut===J||e&&ut.event.triggered===e.type?t:ut.event.dispatch.apply(f.elem,arguments)
[1:1:0713/011628.780932:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mall.caixin.com/mall/web/index/index.html", "mall.caixin.com", 3, 1, , , 0
[1:1:0713/011628.804889:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mall.caixin.com/, 074a61d22860, , , document.readyState
[1:1:0713/011628.805074:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mall.caixin.com/mall/web/index/index.html", "mall.caixin.com", 3, 1, , , 0
[1:1:0713/011629.201859:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011629.202484:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mall.caixin.com/, 074a61d22860, , y.handle, (e){return typeof ut===J||e&&ut.event.triggered===e.type?t:ut.event.dispatch.apply(f.elem,arguments)
[1:1:0713/011629.202618:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mall.caixin.com/mall/web/index/index.html", "mall.caixin.com", 3, 1, , , 0
[1:1:0713/011629.309966:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mall.caixin.com/, 074a61d22860, , , document.readyState
[1:1:0713/011629.310143:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mall.caixin.com/mall/web/index/index.html", "mall.caixin.com", 3, 1, , , 0
[1:1:0713/011629.354856:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011629.355252:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mall.caixin.com/, 074a61d22860, , y.handle, (e){return typeof ut===J||e&&ut.event.triggered===e.type?t:ut.event.dispatch.apply(f.elem,arguments)
[1:1:0713/011629.355382:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mall.caixin.com/mall/web/index/index.html", "mall.caixin.com", 3, 1, , , 0
[1:1:0713/011629.393342:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011629.393741:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mall.caixin.com/, 074a61d22860, , y.handle, (e){return typeof ut===J||e&&ut.event.triggered===e.type?t:ut.event.dispatch.apply(f.elem,arguments)
[1:1:0713/011629.393866:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mall.caixin.com/mall/web/index/index.html", "mall.caixin.com", 3, 1, , , 0
[1:1:0713/011629.444620:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011629.445145:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mall.caixin.com/, 074a61d22860, , y.handle, (e){return typeof ut===J||e&&ut.event.triggered===e.type?t:ut.event.dispatch.apply(f.elem,arguments)
[1:1:0713/011629.445307:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mall.caixin.com/mall/web/index/index.html", "mall.caixin.com", 3, 1, , , 0
[1:1:0713/011629.482506:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011629.482949:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mall.caixin.com/, 074a61d22860, , y.handle, (e){return typeof ut===J||e&&ut.event.triggered===e.type?t:ut.event.dispatch.apply(f.elem,arguments)
[1:1:0713/011629.483109:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mall.caixin.com/mall/web/index/index.html", "mall.caixin.com", 3, 1, , , 0
[1:1:0713/011629.569390:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011629.569872:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mall.caixin.com/, 074a61d22860, , y.handle, (e){return typeof ut===J||e&&ut.event.triggered===e.type?t:ut.event.dispatch.apply(f.elem,arguments)
[1:1:0713/011629.570021:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mall.caixin.com/mall/web/index/index.html", "mall.caixin.com", 3, 1, , , 0
[1:1:0713/011629.883233:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mall.caixin.com/, 074a61d22860, , , document.readyState
[1:1:0713/011629.883427:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mall.caixin.com/mall/web/index/index.html", "mall.caixin.com", 3, 1, , , 0
[1:1:0713/011630.094457:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011630.094927:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mall.caixin.com/, 074a61d22860, , y.handle, (e){return typeof ut===J||e&&ut.event.triggered===e.type?t:ut.event.dispatch.apply(f.elem,arguments)
[1:1:0713/011630.095097:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mall.caixin.com/mall/web/index/index.html", "mall.caixin.com", 3, 1, , , 0
[1:1:0713/011630.506376:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mall.caixin.com/, 074a61d22860, , , document.readyState
[1:1:0713/011630.506541:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mall.caixin.com/mall/web/index/index.html", "mall.caixin.com", 3, 1, , , 0
[1:1:0713/011630.816051:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011630.816550:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mall.caixin.com/, 074a61d22860, , y.handle, (e){return typeof ut===J||e&&ut.event.triggered===e.type?t:ut.event.dispatch.apply(f.elem,arguments)
[1:1:0713/011630.816692:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mall.caixin.com/mall/web/index/index.html", "mall.caixin.com", 3, 1, , , 0
[1:1:0713/011630.840575:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mall.caixin.com/, 717, 7f982c3bf881
[1:1:0713/011630.855353:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"074a61d22860","ptid":"569 0x7f9829a7a070 0x3ae34275be0 ","rf":"5:3_http://mall.caixin.com/"}
[1:1:0713/011630.855582:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://mall.caixin.com/","ptid":"569 0x7f9829a7a070 0x3ae34275be0 ","rf":"5:3_http://mall.caixin.com/"}
[1:1:0713/011630.855846:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011630.856193:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mall.caixin.com/, 074a61d22860, , , (){i.next()}
[1:1:0713/011630.856329:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mall.caixin.com/mall/web/index/index.html", "mall.caixin.com", 3, 1, , , 0
[1:1:0713/011630.857074:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x35882d3829c8, 0x3ae327de950
[1:1:0713/011630.857199:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mall.caixin.com/mall/web/index/index.html", 3000
[1:1:0713/011630.857388:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mall.caixin.com/, 927
[1:1:0713/011630.857508:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 927 0x7f9829a7a070 0x3ae352d6c60 , 5:3_http://mall.caixin.com/, 1, -5:3_http://mall.caixin.com/, 717 0x7f9829a7a070 0x3ae3293c2e0 
[1:1:0713/011630.890634:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x35882d3829c8, 0x3ae327de950
[1:1:0713/011630.890797:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mall.caixin.com/mall/web/index/index.html", 0
[1:1:0713/011630.890987:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mall.caixin.com/, 928
[1:1:0713/011630.891103:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 928 0x7f9829a7a070 0x3ae353a2260 , 5:3_http://mall.caixin.com/, 1, -5:3_http://mall.caixin.com/, 717 0x7f9829a7a070 0x3ae3293c2e0 
[1:1:0713/011630.910827:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mall.caixin.com/mall/web/index/index.html", 13
[1:1:0713/011630.911071:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mall.caixin.com/, 930
[1:1:0713/011630.911187:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 930 0x7f9829a7a070 0x3ae353a65e0 , 5:3_http://mall.caixin.com/, 1, -5:3_http://mall.caixin.com/, 717 0x7f9829a7a070 0x3ae3293c2e0 
[1:1:0713/011630.931517:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mall.caixin.com/, 074a61d22860, , , document.readyState
[1:1:0713/011630.931691:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mall.caixin.com/mall/web/index/index.html", "mall.caixin.com", 3, 1, , , 0
[1:1:0713/011630.991132:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011630.991520:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mall.caixin.com/, 074a61d22860, , y.handle, (e){return typeof ut===J||e&&ut.event.triggered===e.type?t:ut.event.dispatch.apply(f.elem,arguments)
[1:1:0713/011630.991635:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mall.caixin.com/mall/web/index/index.html", "mall.caixin.com", 3, 1, , , 0
[1:1:0713/011631.116707:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011631.117152:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mall.caixin.com/, 074a61d22860, , y.handle, (e){return typeof ut===J||e&&ut.event.triggered===e.type?t:ut.event.dispatch.apply(f.elem,arguments)
[1:1:0713/011631.117269:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mall.caixin.com/mall/web/index/index.html", "mall.caixin.com", 3, 1, , , 0
[1:1:0713/011631.238835:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011631.239239:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mall.caixin.com/, 074a61d22860, , y.handle, (e){return typeof ut===J||e&&ut.event.triggered===e.type?t:ut.event.dispatch.apply(f.elem,arguments)
[1:1:0713/011631.239359:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mall.caixin.com/mall/web/index/index.html", "mall.caixin.com", 3, 1, , , 0
[1:1:0713/011631.381698:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011631.382122:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mall.caixin.com/, 074a61d22860, , y.handle, (e){return typeof ut===J||e&&ut.event.triggered===e.type?t:ut.event.dispatch.apply(f.elem,arguments)
[1:1:0713/011631.382229:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mall.caixin.com/mall/web/index/index.html", "mall.caixin.com", 3, 1, , , 0
[1:1:0713/011631.405495:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mall.caixin.com/, 928, 7f982c3bf881
[1:1:0713/011631.419199:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"074a61d22860","ptid":"717 0x7f9829a7a070 0x3ae3293c2e0 ","rf":"5:3_http://mall.caixin.com/"}
[1:1:0713/011631.419360:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://mall.caixin.com/","ptid":"717 0x7f9829a7a070 0x3ae3293c2e0 ","rf":"5:3_http://mall.caixin.com/"}
[1:1:0713/011631.419551:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011631.419829:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mall.caixin.com/, 074a61d22860, , , (){Zn=t}
[1:1:0713/011631.419939:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mall.caixin.com/mall/web/index/index.html", "mall.caixin.com", 3, 1, , , 0
[1:1:0713/011631.462746:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mall.caixin.com/, 074a61d22860, , , document.readyState
[1:1:0713/011631.462923:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mall.caixin.com/mall/web/index/index.html", "mall.caixin.com", 3, 1, , , 0
[1:1:0713/011631.479367:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mall.caixin.com/, 930, 7f982c3bf8db
[1:1:0713/011631.493804:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"074a61d22860","ptid":"717 0x7f9829a7a070 0x3ae3293c2e0 ","rf":"5:3_http://mall.caixin.com/"}
[1:1:0713/011631.493982:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://mall.caixin.com/","ptid":"717 0x7f9829a7a070 0x3ae3293c2e0 ","rf":"5:3_http://mall.caixin.com/"}
[1:1:0713/011631.494187:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mall.caixin.com/, 959
[1:1:0713/011631.494320:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 959 0x7f9829a7a070 0x3ae34d12f60 , 5:3_http://mall.caixin.com/, 0, , 930 0x7f9829a7a070 0x3ae353a65e0 
[1:1:0713/011631.494482:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011631.494796:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mall.caixin.com/, 074a61d22860, , ut.fx.tick, (){var e,n=ut.timers,r=0;for(Zn=ut.now();r<n.length;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.leng
[1:1:0713/011631.494918:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mall.caixin.com/mall/web/index/index.html", "mall.caixin.com", 3, 1, , , 0
[1:1:0713/011631.825254:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mall.caixin.com/, 074a61d22860, , , document.readyState
[1:1:0713/011631.825420:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mall.caixin.com/mall/web/index/index.html", "mall.caixin.com", 3, 1, , , 0
[1:1:0713/011631.826844:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mall.caixin.com/, 959, 7f982c3bf8db
[1:1:0713/011631.844361:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"930 0x7f9829a7a070 0x3ae353a65e0 ","rf":"5:3_http://mall.caixin.com/"}
[1:1:0713/011631.844543:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"930 0x7f9829a7a070 0x3ae353a65e0 ","rf":"5:3_http://mall.caixin.com/"}
[1:1:0713/011631.844760:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mall.caixin.com/, 972
[1:1:0713/011631.844856:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 972 0x7f9829a7a070 0x3ae3451bb60 , 5:3_http://mall.caixin.com/, 0, , 959 0x7f9829a7a070 0x3ae34d12f60 
[1:1:0713/011631.844988:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011631.845288:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mall.caixin.com/, 074a61d22860, , ut.fx.tick, (){var e,n=ut.timers,r=0;for(Zn=ut.now();r<n.length;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.leng
[1:1:0713/011631.845373:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mall.caixin.com/mall/web/index/index.html", "mall.caixin.com", 3, 1, , , 0
[1:1:0713/011631.907783:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011631.908229:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mall.caixin.com/, 074a61d22860, , y.handle, (e){return typeof ut===J||e&&ut.event.triggered===e.type?t:ut.event.dispatch.apply(f.elem,arguments)
[1:1:0713/011631.908381:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mall.caixin.com/mall/web/index/index.html", "mall.caixin.com", 3, 1, , , 0
[1:1:0713/011632.023042:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mall.caixin.com/, 074a61d22860, , , document.readyState
[1:1:0713/011632.023204:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mall.caixin.com/mall/web/index/index.html", "mall.caixin.com", 3, 1, , , 0
[1:1:0713/011632.181141:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011632.181641:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mall.caixin.com/, 074a61d22860, , ef, (){if(!cf){cf=!0;for(var a=0;a<df.length;a++)D(df[a])}}
[1:1:0713/011632.181820:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mall.caixin.com/mall/web/index/index.html", "mall.caixin.com", 3, 1, , , 0
[1:1:0713/011632.182420:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x35882d3829c8, 0x3ae327dea20
[1:1:0713/011632.182579:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mall.caixin.com/mall/web/index/index.html", 0
[1:1:0713/011632.182863:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mall.caixin.com/, 987
[1:1:0713/011632.183026:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 987 0x7f9829a7a070 0x3ae353bc4e0 , 5:3_http://mall.caixin.com/, 1, -5:3_http://mall.caixin.com/, 978 0x7f9829a7a070 0x3ae35452ce0 
[1:1:0713/011632.183271:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011632.228871:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mall.caixin.com/, 074a61d22860, , , document.readyState
[1:1:0713/011632.229069:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mall.caixin.com/mall/web/index/index.html", "mall.caixin.com", 3, 1, , , 0
[1:1:0713/011632.353124:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mall.caixin.com/, 987, 7f982c3bf881
[1:1:0713/011632.365430:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"074a61d22860","ptid":"978 0x7f9829a7a070 0x3ae35452ce0 ","rf":"5:3_http://mall.caixin.com/"}
[1:1:0713/011632.365583:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://mall.caixin.com/","ptid":"978 0x7f9829a7a070 0x3ae35452ce0 ","rf":"5:3_http://mall.caixin.com/"}
[1:1:0713/011632.365772:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011632.366082:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mall.caixin.com/, 074a61d22860, , , (){b.gtmLoad||(b.gtmLoad=!0,a.push({event:"gtm.load"}))}
[1:1:0713/011632.366195:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mall.caixin.com/mall/web/index/index.html", "mall.caixin.com", 3, 1, , , 0
[1:1:0713/011632.685140:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/011632.686719:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/011633.899644:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mall.caixin.com/, 927, 7f982c3bf881
[1:1:0713/011633.928086:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"074a61d22860","ptid":"717 0x7f9829a7a070 0x3ae3293c2e0 ","rf":"5:3_http://mall.caixin.com/"}
[1:1:0713/011633.928389:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://mall.caixin.com/","ptid":"717 0x7f9829a7a070 0x3ae3293c2e0 ","rf":"5:3_http://mall.caixin.com/"}
[1:1:0713/011633.928766:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011633.929263:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mall.caixin.com/, 074a61d22860, , , (){i.next()}
[1:1:0713/011633.929500:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mall.caixin.com/mall/web/index/index.html", "mall.caixin.com", 3, 1, , , 0
[1:1:0713/011633.932560:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x35882d3829c8, 0x3ae327de950
[1:1:0713/011633.932814:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mall.caixin.com/mall/web/index/index.html", 3000
[1:1:0713/011633.934834:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mall.caixin.com/, 1030
[1:1:0713/011633.935071:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1030 0x7f9829a7a070 0x3ae3438ffe0 , 5:3_http://mall.caixin.com/, 1, -5:3_http://mall.caixin.com/, 927 0x7f9829a7a070 0x3ae352d6c60 
[1:1:0713/011633.976984:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x35882d3829c8, 0x3ae327de950
[1:1:0713/011633.977169:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mall.caixin.com/mall/web/index/index.html", 0
[1:1:0713/011633.977355:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mall.caixin.com/, 1032
[1:1:0713/011633.977473:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1032 0x7f9829a7a070 0x3ae354bd160 , 5:3_http://mall.caixin.com/, 1, -5:3_http://mall.caixin.com/, 927 0x7f9829a7a070 0x3ae352d6c60 
[1:1:0713/011633.994978:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mall.caixin.com/mall/web/index/index.html", 13
[1:1:0713/011633.996108:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mall.caixin.com/, 1034
[1:1:0713/011633.996231:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1034 0x7f9829a7a070 0x3ae354c0960 , 5:3_http://mall.caixin.com/, 1, -5:3_http://mall.caixin.com/, 927 0x7f9829a7a070 0x3ae352d6c60 
[1:1:0713/011634.038775:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mall.caixin.com/, 1032, 7f982c3bf881
[1:1:0713/011634.057123:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"074a61d22860","ptid":"927 0x7f9829a7a070 0x3ae352d6c60 ","rf":"5:3_http://mall.caixin.com/"}
[1:1:0713/011634.057318:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://mall.caixin.com/","ptid":"927 0x7f9829a7a070 0x3ae352d6c60 ","rf":"5:3_http://mall.caixin.com/"}
[1:1:0713/011634.057520:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011634.057797:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mall.caixin.com/, 074a61d22860, , , (){Zn=t}
[1:1:0713/011634.057897:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mall.caixin.com/mall/web/index/index.html", "mall.caixin.com", 3, 1, , , 0
[1:1:0713/011634.086467:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mall.caixin.com/, 1034, 7f982c3bf8db
[1:1:0713/011634.099467:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"074a61d22860","ptid":"927 0x7f9829a7a070 0x3ae352d6c60 ","rf":"5:3_http://mall.caixin.com/"}
[1:1:0713/011634.099615:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://mall.caixin.com/","ptid":"927 0x7f9829a7a070 0x3ae352d6c60 ","rf":"5:3_http://mall.caixin.com/"}
[1:1:0713/011634.099822:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mall.caixin.com/, 1041
[1:1:0713/011634.099948:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1041 0x7f9829a7a070 0x3ae327619e0 , 5:3_http://mall.caixin.com/, 0, , 1034 0x7f9829a7a070 0x3ae354c0960 
[1:1:0713/011634.100126:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011634.100380:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mall.caixin.com/, 074a61d22860, , ut.fx.tick, (){var e,n=ut.timers,r=0;for(Zn=ut.now();r<n.length;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.leng
[1:1:0713/011634.100518:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mall.caixin.com/mall/web/index/index.html", "mall.caixin.com", 3, 1, , , 0
[1:1:0713/011634.130153:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mall.caixin.com/, 1041, 7f982c3bf8db
[1:1:0713/011634.143620:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1034 0x7f9829a7a070 0x3ae354c0960 ","rf":"5:3_http://mall.caixin.com/"}
[1:1:0713/011634.143780:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1034 0x7f9829a7a070 0x3ae354c0960 ","rf":"5:3_http://mall.caixin.com/"}
[1:1:0713/011634.143992:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mall.caixin.com/, 1044
[1:1:0713/011634.144111:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1044 0x7f9829a7a070 0x3ae354d3660 , 5:3_http://mall.caixin.com/, 0, , 1041 0x7f9829a7a070 0x3ae327619e0 
[1:1:0713/011634.144298:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011634.144570:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mall.caixin.com/, 074a61d22860, , ut.fx.tick, (){var e,n=ut.timers,r=0;for(Zn=ut.now();r<n.length;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.leng
[1:1:0713/011634.144672:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mall.caixin.com/mall/web/index/index.html", "mall.caixin.com", 3, 1, , , 0
[1:1:0713/011634.199709:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mall.caixin.com/, 1044, 7f982c3bf8db
[1:1:0713/011634.218456:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1041 0x7f9829a7a070 0x3ae327619e0 ","rf":"5:3_http://mall.caixin.com/"}
[1:1:0713/011634.218663:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1041 0x7f9829a7a070 0x3ae327619e0 ","rf":"5:3_http://mall.caixin.com/"}
[1:1:0713/011634.218969:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mall.caixin.com/, 1046
[1:1:0713/011634.219134:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1046 0x7f9829a7a070 0x3ae34062260 , 5:3_http://mall.caixin.com/, 0, , 1044 0x7f9829a7a070 0x3ae354d3660 
[1:1:0713/011634.219398:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011634.219747:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mall.caixin.com/, 074a61d22860, , ut.fx.tick, (){var e,n=ut.timers,r=0;for(Zn=ut.now();r<n.length;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.leng
[1:1:0713/011634.219895:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mall.caixin.com/mall/web/index/index.html", "mall.caixin.com", 3, 1, , , 0
[1:1:0713/011634.322631:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mall.caixin.com/, 1046, 7f982c3bf8db
[1:1:0713/011634.339522:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1044 0x7f9829a7a070 0x3ae354d3660 ","rf":"5:3_http://mall.caixin.com/"}
[1:1:0713/011634.339740:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1044 0x7f9829a7a070 0x3ae354d3660 ","rf":"5:3_http://mall.caixin.com/"}
[1:1:0713/011634.340005:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mall.caixin.com/, 1054
[1:1:0713/011634.340151:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1054 0x7f9829a7a070 0x3ae355247e0 , 5:3_http://mall.caixin.com/, 0, , 1046 0x7f9829a7a070 0x3ae34062260 
[1:1:0713/011634.340386:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011634.340691:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mall.caixin.com/, 074a61d22860, , ut.fx.tick, (){var e,n=ut.timers,r=0;for(Zn=ut.now();r<n.length;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.leng
[1:1:0713/011634.340794:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mall.caixin.com/mall/web/index/index.html", "mall.caixin.com", 3, 1, , , 0
[1:1:0713/011634.457172:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mall.caixin.com/, 1054, 7f982c3bf8db
[1:1:0713/011634.472957:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1046 0x7f9829a7a070 0x3ae34062260 ","rf":"5:3_http://mall.caixin.com/"}
[1:1:0713/011634.473184:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1046 0x7f9829a7a070 0x3ae34062260 ","rf":"5:3_http://mall.caixin.com/"}
[1:1:0713/011634.473393:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mall.caixin.com/, 1059
[1:1:0713/011634.473537:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1059 0x7f9829a7a070 0x3ae35568060 , 5:3_http://mall.caixin.com/, 0, , 1054 0x7f9829a7a070 0x3ae355247e0 
[1:1:0713/011634.473732:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011634.474006:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mall.caixin.com/, 074a61d22860, , ut.fx.tick, (){var e,n=ut.timers,r=0;for(Zn=ut.now();r<n.length;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.leng
[1:1:0713/011634.474106:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mall.caixin.com/mall/web/index/index.html", "mall.caixin.com", 3, 1, , , 0
[1:1:0713/011634.564199:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mall.caixin.com/, 1059, 7f982c3bf8db
[1:1:0713/011634.582019:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1054 0x7f9829a7a070 0x3ae355247e0 ","rf":"5:3_http://mall.caixin.com/"}
[1:1:0713/011634.582238:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1054 0x7f9829a7a070 0x3ae355247e0 ","rf":"5:3_http://mall.caixin.com/"}
[1:1:0713/011634.582505:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mall.caixin.com/, 1064
[1:1:0713/011634.582687:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1064 0x7f9829a7a070 0x3ae3557dc60 , 5:3_http://mall.caixin.com/, 0, , 1059 0x7f9829a7a070 0x3ae35568060 
[1:1:0713/011634.582951:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011634.583273:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mall.caixin.com/, 074a61d22860, , ut.fx.tick, (){var e,n=ut.timers,r=0;for(Zn=ut.now();r<n.length;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.leng
[1:1:0713/011634.583412:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mall.caixin.com/mall/web/index/index.html", "mall.caixin.com", 3, 1, , , 0
[1:1:0713/011634.676853:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mall.caixin.com/, 1064, 7f982c3bf8db
[1:1:0713/011634.694032:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1059 0x7f9829a7a070 0x3ae35568060 ","rf":"5:3_http://mall.caixin.com/"}
[1:1:0713/011634.694179:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1059 0x7f9829a7a070 0x3ae35568060 ","rf":"5:3_http://mall.caixin.com/"}
[1:1:0713/011634.694391:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mall.caixin.com/, 1070
[1:1:0713/011634.694503:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1070 0x7f9829a7a070 0x3ae354cabe0 , 5:3_http://mall.caixin.com/, 0, , 1064 0x7f9829a7a070 0x3ae3557dc60 
[1:1:0713/011634.694699:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011634.694982:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mall.caixin.com/, 074a61d22860, , ut.fx.tick, (){var e,n=ut.timers,r=0;for(Zn=ut.now();r<n.length;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.leng
[1:1:0713/011634.695087:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mall.caixin.com/mall/web/index/index.html", "mall.caixin.com", 3, 1, , , 0
[1:1:0713/011634.797094:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mall.caixin.com/, 1070, 7f982c3bf8db
[1:1:0713/011634.817097:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1064 0x7f9829a7a070 0x3ae3557dc60 ","rf":"5:3_http://mall.caixin.com/"}
[1:1:0713/011634.817296:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1064 0x7f9829a7a070 0x3ae3557dc60 ","rf":"5:3_http://mall.caixin.com/"}
[1:1:0713/011634.817538:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mall.caixin.com/, 1076
[1:1:0713/011634.817666:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1076 0x7f9829a7a070 0x3ae32761a60 , 5:3_http://mall.caixin.com/, 0, , 1070 0x7f9829a7a070 0x3ae354cabe0 
[1:1:0713/011634.817866:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011634.818172:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mall.caixin.com/, 074a61d22860, , ut.fx.tick, (){var e,n=ut.timers,r=0;for(Zn=ut.now();r<n.length;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.leng
[1:1:0713/011634.818291:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mall.caixin.com/mall/web/index/index.html", "mall.caixin.com", 3, 1, , , 0
[1:1:0713/011636.956397:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mall.caixin.com/, 1030, 7f982c3bf881
[1:1:0713/011636.972202:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"074a61d22860","ptid":"927 0x7f9829a7a070 0x3ae352d6c60 ","rf":"5:3_http://mall.caixin.com/"}
[1:1:0713/011636.972394:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://mall.caixin.com/","ptid":"927 0x7f9829a7a070 0x3ae352d6c60 ","rf":"5:3_http://mall.caixin.com/"}
[1:1:0713/011636.972656:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011636.972959:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mall.caixin.com/, 074a61d22860, , , (){i.next()}
[1:1:0713/011636.973091:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mall.caixin.com/mall/web/index/index.html", "mall.caixin.com", 3, 1, , , 0
[1:1:0713/011636.973739:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x35882d3829c8, 0x3ae327de950
[1:1:0713/011636.973884:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mall.caixin.com/mall/web/index/index.html", 3000
[1:1:0713/011636.974113:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mall.caixin.com/, 1085
[1:1:0713/011636.974269:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1085 0x7f9829a7a070 0x3ae354cfb60 , 5:3_http://mall.caixin.com/, 1, -5:3_http://mall.caixin.com/, 1030 0x7f9829a7a070 0x3ae3438ffe0 
[1:1:0713/011637.005636:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x35882d3829c8, 0x3ae327de950
[1:1:0713/011637.005786:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mall.caixin.com/mall/web/index/index.html", 0
[1:1:0713/011637.005977:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mall.caixin.com/, 1087
[1:1:0713/011637.006093:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1087 0x7f9829a7a070 0x3ae355fab60 , 5:3_http://mall.caixin.com/, 1, -5:3_http://mall.caixin.com/, 1030 0x7f9829a7a070 0x3ae3438ffe0 
[1:1:0713/011637.022562:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mall.caixin.com/mall/web/index/index.html", 13
[1:1:0713/011637.022800:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mall.caixin.com/, 1089
[1:1:0713/011637.022921:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1089 0x7f9829a7a070 0x3ae32ef4d60 , 5:3_http://mall.caixin.com/, 1, -5:3_http://mall.caixin.com/, 1030 0x7f9829a7a070 0x3ae3438ffe0 
[1:1:0713/011637.065973:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mall.caixin.com/, 1087, 7f982c3bf881
[1:1:0713/011637.085285:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"074a61d22860","ptid":"1030 0x7f9829a7a070 0x3ae3438ffe0 ","rf":"5:3_http://mall.caixin.com/"}
[1:1:0713/011637.085469:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://mall.caixin.com/","ptid":"1030 0x7f9829a7a070 0x3ae3438ffe0 ","rf":"5:3_http://mall.caixin.com/"}
[1:1:0713/011637.085667:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011637.085966:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mall.caixin.com/, 074a61d22860, , , (){Zn=t}
[1:1:0713/011637.086065:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mall.caixin.com/mall/web/index/index.html", "mall.caixin.com", 3, 1, , , 0
[1:1:0713/011637.115864:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mall.caixin.com/, 1089, 7f982c3bf8db
[1:1:0713/011637.129588:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"074a61d22860","ptid":"1030 0x7f9829a7a070 0x3ae3438ffe0 ","rf":"5:3_http://mall.caixin.com/"}
[1:1:0713/011637.129740:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://mall.caixin.com/","ptid":"1030 0x7f9829a7a070 0x3ae3438ffe0 ","rf":"5:3_http://mall.caixin.com/"}
[1:1:0713/011637.129942:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mall.caixin.com/, 1096
[1:1:0713/011637.130056:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1096 0x7f9829a7a070 0x3ae35568ce0 , 5:3_http://mall.caixin.com/, 0, , 1089 0x7f9829a7a070 0x3ae32ef4d60 
[1:1:0713/011637.130242:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mall.caixin.com/mall/web/index/index.html"
[1:1:0713/011637.130523:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mall.caixin.com/, 074a61d22860, , ut.fx.tick, (){var e,n=ut.timers,r=0;for(Zn=ut.now();r<n.length;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.leng
[1:1:0713/011637.130629:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mall.caixin.com/mall/web/index/index.html", "mall.caixin.com", 3, 1, , , 0
[1:1:0713/011637.221154:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mall.caixin.com/, 1096, 7f982c3bf8db
