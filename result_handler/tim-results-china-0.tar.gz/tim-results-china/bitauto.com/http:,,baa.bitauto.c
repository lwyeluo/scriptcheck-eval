[0712/103619.154190:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/103619.154444:INFO:switcher_clone.cc(787)] backtrace rip is 7f0127c77891
[0712/103619.735490:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/103619.735774:INFO:switcher_clone.cc(787)] backtrace rip is 7f71e11cc891
[1:1:0712/103619.739748:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/103619.739924:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/103619.742905:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[28709:28709:0712/103620.624366:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/faf0998a-2e98-4cb3-a498-93315a4ae74e
[0712/103620.692291:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/103620.692531:INFO:switcher_clone.cc(787)] backtrace rip is 7f93b1d9e891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[28741:28741:0712/103620.866311:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=28741
[28754:28754:0712/103620.873631:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=28754
[28709:28709:0712/103620.902265:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[28709:28739:0712/103620.902687:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/103620.902812:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/103620.902975:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/103620.903292:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/103620.903427:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/103620.905155:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x2bfb998f, 1
[1:1:0712/103620.905358:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x2fcf329a, 0
[1:1:0712/103620.905450:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x206943a2, 3
[1:1:0712/103620.905530:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x173940d0, 2
[1:1:0712/103620.905617:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffff9a32ffffffcf2f ffffff8fffffff99fffffffb2b ffffffd0403917 ffffffa2436920 , 10104, 4
[1:1:0712/103620.906302:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[28709:28739:0712/103620.906413:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�2�/���+�@9�Ci {�F=
[28709:28739:0712/103620.906452:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �2�/���+�@9�Ci �Q{�F=
[1:1:0712/103620.906509:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f71df4060a0, 3
[28709:28739:0712/103620.906598:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0712/103620.906598:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f71df592080, 2
[28709:28739:0712/103620.906636:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 28762, 4, 9a32cf2f 8f99fb2b d0403917 a2436920 
[1:1:0712/103620.906680:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f71c9254d20, -2
[1:1:0712/103620.914289:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/103620.914746:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 173940d0
[1:1:0712/103620.915231:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 173940d0
[1:1:0712/103620.916025:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 173940d0
[1:1:0712/103620.916572:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 173940d0
[1:1:0712/103620.916674:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 173940d0
[1:1:0712/103620.916765:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 173940d0
[1:1:0712/103620.916856:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 173940d0
[1:1:0712/103620.917123:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 173940d0
[1:1:0712/103620.917262:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f71e11cc7ba
[1:1:0712/103620.917376:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f71e11c3def, 7f71e11cc77a, 7f71e11ce0cf
[1:1:0712/103620.919084:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 173940d0
[1:1:0712/103620.919253:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 173940d0
[1:1:0712/103620.919554:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 173940d0
[1:1:0712/103620.920327:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 173940d0
[1:1:0712/103620.920422:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 173940d0
[1:1:0712/103620.920515:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 173940d0
[1:1:0712/103620.920607:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 173940d0
[1:1:0712/103620.921110:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 173940d0
[1:1:0712/103620.921272:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f71e11cc7ba
[1:1:0712/103620.921347:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f71e11c3def, 7f71e11cc77a, 7f71e11ce0cf
[1:1:0712/103620.923931:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/103620.924184:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/103620.924321:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffd33f4bcd8, 0x7ffd33f4bc58)
[1:1:0712/103620.930734:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/103620.933404:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/103621.374123:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x2a83cddf6220
[1:1:0712/103621.374325:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[28709:28709:0712/103621.376543:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[28709:28709:0712/103621.376977:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[28709:28720:0712/103621.384924:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[28709:28720:0712/103621.384986:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[28709:28709:0712/103621.385007:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[28709:28709:0712/103621.385075:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[28709:28709:0712/103621.385150:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,28762, 4
[1:7:0712/103621.386148:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[28709:28732:0712/103621.427257:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/103621.663610:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[28709:28709:0712/103622.333735:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[28709:28709:0712/103622.333821:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/103622.350695:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/103622.352211:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/103622.805655:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/103622.851485:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3a55eb6c1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/103622.851663:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/103622.857775:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3a55eb6c1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/103622.857934:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/103622.942323:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/103622.942465:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/103623.089958:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 361, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/103623.092653:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3a55eb6c1f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/103623.092813:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/103623.106356:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 362, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/103623.109538:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3a55eb6c1f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/103623.109653:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/103623.113539:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[28709:28709:0712/103623.114200:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/103623.115202:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x2a83cddf4e20
[1:1:0712/103623.115350:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[28709:28709:0712/103623.116671:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[28709:28709:0712/103623.127898:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[28709:28709:0712/103623.127988:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/103623.147927:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/103623.459794:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 421 0x7f71cae2f2e0 0x2a83ce0a8360 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/103623.460522:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3a55eb6c1f78, , , var configData = {"googleBaseUrl":"https://www.google.com.hk/","isAccessibleBrowser":false,"isGoogle
[1:1:0712/103623.460678:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/103623.461338:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[28709:28709:0712/103623.489689:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/103623.490808:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x2a83cddf5820
[28709:28709:0712/103623.491945:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/103623.491879:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[1:1:0712/103623.500501:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/103623.500623:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[28709:28709:0712/103623.501939:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[28709:28709:0712/103623.505920:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[28709:28709:0712/103623.506349:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[28709:28720:0712/103623.511090:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[28709:28720:0712/103623.511155:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[28709:28709:0712/103623.511170:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[28709:28709:0712/103623.511214:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[28709:28709:0712/103623.511279:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,28762, 4
[1:7:0712/103623.512913:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/103623.807835:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/103623.929832:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 470 0x7f71cae2f2e0 0x2a83ce1bebe0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/103623.930488:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3a55eb6c1f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/103623.930621:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/103623.930964:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[28709:28709:0712/103624.114946:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[28709:28709:0712/103624.115036:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/103624.129572:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[28709:28709:0712/103624.225711:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[28709:28739:0712/103624.226023:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/103624.226684:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/103624.229521:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/103624.229709:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/103624.229783:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/103624.232262:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x30ac4fe1, 1
[1:1:0712/103624.232513:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x22063fa5, 0
[1:1:0712/103624.232641:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x2fa40d12, 3
[1:1:0712/103624.232741:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x2fbc6ebc, 2
[1:1:0712/103624.232836:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffa53f0622 ffffffe14fffffffac30 ffffffbc6effffffbc2f 120dffffffa42f , 10104, 5
[1:1:0712/103624.233540:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[28709:28739:0712/103624.233765:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�?"�O�0�n�/�/ߚF=
[28709:28739:0712/103624.233810:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �?"�O�0�n�/�/�xߚF=
[1:1:0712/103624.233755:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f71df4060a0, 3
[1:1:0712/103624.233854:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f71df592080, 2
[28709:28739:0712/103624.233953:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 28806, 5, a53f0622 e14fac30 bc6ebc2f 120da42f 
[1:1:0712/103624.233949:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f71c9254d20, -2
[1:1:0712/103624.242935:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/103624.243122:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2fbc6ebc
[1:1:0712/103624.243318:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2fbc6ebc
[1:1:0712/103624.243568:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2fbc6ebc
[1:1:0712/103624.244127:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2fbc6ebc
[1:1:0712/103624.244223:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2fbc6ebc
[1:1:0712/103624.244322:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2fbc6ebc
[1:1:0712/103624.244410:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2fbc6ebc
[1:1:0712/103624.244697:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2fbc6ebc
[1:1:0712/103624.244823:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f71e11cc7ba
[1:1:0712/103624.244894:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f71e11c3def, 7f71e11cc77a, 7f71e11ce0cf
[1:1:0712/103624.246642:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2fbc6ebc
[1:1:0712/103624.246841:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2fbc6ebc
[1:1:0712/103624.247145:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2fbc6ebc
[1:1:0712/103624.247955:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2fbc6ebc
[1:1:0712/103624.248093:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2fbc6ebc
[1:1:0712/103624.248213:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2fbc6ebc
[1:1:0712/103624.248325:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2fbc6ebc
[1:1:0712/103624.248844:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2fbc6ebc
[1:1:0712/103624.249002:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f71e11cc7ba
[1:1:0712/103624.249084:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f71e11c3def, 7f71e11cc77a, 7f71e11ce0cf
[1:1:0712/103624.251676:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/103624.251911:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/103624.251991:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffd33f4bcd8, 0x7ffd33f4bc58)
[1:1:0712/103624.257965:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/103624.259920:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/103624.286714:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/103624.355064:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x2a83cddc2220
[1:1:0712/103624.356085:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/103624.598732:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/103624.598926:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[28709:28709:0712/103624.616147:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[28709:28709:0712/103624.619589:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[28709:28709:0712/103624.629829:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://baa.bitauto.com/
[28709:28709:0712/103624.629889:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://baa.bitauto.com/, http://baa.bitauto.com/cs55/thread-15796781.html, 1
[28709:28709:0712/103624.629954:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://baa.bitauto.com/, HTTP/1.1 200 OK Server: nginx/1.12.1 Date: Fri, 12 Jul 2019 02:36:23 GMT Content-Type: text/html; charset=utf-8 Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Cache-Control: public Expires: Fri, 12 Jul 2019 03:03:07 GMT Vary: *,Accept-Encoding X-Powered-Load: 6.188 X-Cached-From: HIT X-Cached-Store: BYPASS X-Key: baa.bitauto.com/cs55/thread-15796781.html Content-Encoding: gzip  ,28806, 5
[28709:28720:0712/103624.635879:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[28709:28720:0712/103624.635947:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[1:7:0712/103624.637363:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/103624.659507:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://baa.bitauto.com/
[28709:28709:0712/103624.714513:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://baa.bitauto.com/, http://baa.bitauto.com/, 1
[28709:28709:0712/103624.714576:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://baa.bitauto.com/, http://baa.bitauto.com
[1:1:0712/103624.728590:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/103624.763518:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/103624.765819:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 549, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/103624.767476:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3a55eb7ee5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/103624.767616:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/103624.770548:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/103624.782627:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/103624.796062:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/103624.796601:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103624.843905:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0483968, 232, 1
[1:1:0712/103624.845182:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/103624.896131:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/103624.967269:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/103624.967450:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103625.778887:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 254 0x7f71c8f07070 0x2a83cdea4360 , "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103625.782180:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , , (function(E){var F={templateSettings:{TemplateRegQueue:[{reg:/^\s*|\s$/g,func:""},{reg:/\r|\n|\t|\/\
[1:1:0712/103625.782359:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "baa.bitauto.com", 3, 1, , , 0
[1:1:0712/103625.784967:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/103625.796249:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 254 0x7f71c8f07070 0x2a83cdea4360 , "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103625.812585:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 254 0x7f71c8f07070 0x2a83cdea4360 , "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103625.819364:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0236812, 105, 1
[1:1:0712/103625.819560:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/103625.866844:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/103625.867033:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103625.867559:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 265 0x7f71c8f07070 0x2a83cdea0260 , "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103625.867993:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , , 
    //setTimeout("document.getElementById('imgAppQCode').src = '/Ajax/GetQCode.ashx?para=http://baa
[1:1:0712/103625.868108:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "baa.bitauto.com", 3, 1, , , 0
[1:1:0712/103625.962172:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.095088, 1818, 1
[1:1:0712/103625.962378:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/103626.200090:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/103626.200289:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103626.200741:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 305 0x7f71c8f07070 0x2a83ce07d360 , "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103626.201274:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , , 
function goPage(pageindex)
{
    var pageCount = 2;
    if(pageindex==''||isNaN(pageindex)||pageind
[1:1:0712/103626.201361:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "baa.bitauto.com", 3, 1, , , 0
[1:1:0712/103626.211721:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.01143, 108, 1
[1:1:0712/103626.211892:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/103626.257300:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/103626.257454:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103626.257930:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 317 0x7f71c8f07070 0x2a83cde844e0 , "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103626.258482:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , , 
    function onAgreementChange(sender) {
        sender = $(sender);
        var button = sender.up
[1:1:0712/103626.258589:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "baa.bitauto.com", 3, 1, , , 0
[1:1:0712/103626.259817:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 317 0x7f71c8f07070 0x2a83cde844e0 , "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103626.262866:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 317 0x7f71c8f07070 0x2a83cde844e0 , "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103626.279789:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0223, 340, 1
[1:1:0712/103626.279945:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/103626.332377:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/103626.332531:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103626.336087:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 326 0x7f71c8f07070 0x2a83cdfaff60 , "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103626.349215:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , , /*! jQuery v1.11.0 | (c) 2005, 2014 jQuery Foundation, Inc. | jquery.org/license */
!function(a,b){"
[1:1:0712/103626.349389:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "baa.bitauto.com", 3, 1, , , 0
[1:1:0712/103626.475444:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 326 0x7f71c8f07070 0x2a83cdfaff60 , "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103626.480784:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 326 0x7f71c8f07070 0x2a83cdfaff60 , "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103626.482129:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 326 0x7f71c8f07070 0x2a83cdfaff60 , "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103626.483701:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 326 0x7f71c8f07070 0x2a83cdfaff60 , "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103626.484784:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 326 0x7f71c8f07070 0x2a83cdfaff60 , "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103626.488901:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.156309, 92, 1
[1:1:0712/103626.489018:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/103626.495269:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103626.496602:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , onerror, this.onerror=null;this.src='http://pic.baa.bitautotech.com/newavatar/120.jpg';
[1:1:0712/103626.496718:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "baa.bitauto.com", 3, 1, , , 0
[1:1:0712/103626.595611:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/103626.595788:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103626.596410:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 343 0x7f71c8f07070 0x2a83ce426360 , "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103626.597221:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , , 
       

        (function(global) {
            var extend = function(target, extendObj) {
       
[1:1:0712/103626.597331:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "baa.bitauto.com", 3, 1, , , 0
[1:1:0712/103626.604389:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 343 0x7f71c8f07070 0x2a83ce426360 , "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103626.638167:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 343 0x7f71c8f07070 0x2a83ce426360 , "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103626.640199:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 343 0x7f71c8f07070 0x2a83ce426360 , "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103626.642873:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 343 0x7f71c8f07070 0x2a83ce426360 , "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103626.672730:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 343 0x7f71c8f07070 0x2a83ce426360 , "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103626.857234:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/103627.031773:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 385, "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103627.032367:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , , sspCallBackSenseNew.handleJson([])
[1:1:0712/103627.032519:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "baa.bitauto.com", 3, 1, , , 0
[1:1:0712/103627.036803:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 385, "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103627.051282:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 385, "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103627.063481:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 385, "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103627.071665:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 385, "http://baa.bitauto.com/cs55/thread-15796781.html"
		remove user.e_4762ae44 -> 0
[1:1:0712/103628.470129:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 1.43385, 0, 0
[1:1:0712/103628.470346:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/103628.494526:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 387 0x7f71cae2f2e0 0x2a83ce40ff60 , "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103628.495701:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , , (function(C){var B,A,D;A=("Bitauto" in C&&C.Bitauto&&"DomainManager" in C.Bitauto);if(A){D=C.DomainM
[1:1:0712/103628.495873:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "baa.bitauto.com", 3, 1, , , 0
[1:1:0712/103628.496811:INFO:document.cc(5190)] >>> Document::setDomain. [old, new] = "baa.bitauto.com", "bitauto.com"
[1:1:0712/103628.543857:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103628.558251:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 388 0x7f71cae2f2e0 0x2a83ce3977e0 , "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103628.558798:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , , var bit_IpRegion = '218.241.135.34:北京市;201,北京,beijing';
var bit_locationInfo = {cityId:'2
[1:1:0712/103628.558894:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103628.603172:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103628.603582:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , eventHander, (e){
            var elem = e.target;
            if(elem.tagName.toLowerCase() === 'script' && elem
[1:1:0712/103628.603738:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103628.622060:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 398 0x7f71cae2f2e0 0x2a83ce392260 , "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103628.622443:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , , var bit_IpRegion = '218.241.135.34:北京市;201,北京,beijing';
var bit_locationInfo = {cityId:'2
[1:1:0712/103628.622596:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103628.629079:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 399 0x7f71cae2f2e0 0x2a83ce3f4560 , "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103628.629406:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , , 
var Bitauto = Bitauto || {};
Bitauto.location = {
  "ip": "218.241.135.34",
  "regionId": "1101
[1:1:0712/103628.629522:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103628.629840:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103628.639953:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 400 0x7f71cae2f2e0 0x2a83ce400e60 , "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103628.644339:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , , City_Select._$JSON_callback.$JSON([{"cityId":"201","regionId":"110100","cityName":"北京","regionNa
[1:1:0712/103628.644478:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103628.774498:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da988
[1:1:0712/103628.774725:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103628.774977:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 471
[1:1:0712/103628.775111:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 471 0x7f71c8f07070 0x2a83cea92360 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 400 0x7f71cae2f2e0 0x2a83ce400e60 
[1:1:0712/103629.107310:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/103629.107505:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103629.108106:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 436 0x7f71c8f07070 0x2a83ce9fe5e0 , "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103629.108640:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , , 
        document.observe('dom:loaded', function() {
            
            Bitauto.Login.isNeedRe
[1:1:0712/103629.108759:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103629.114107:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 436 0x7f71c8f07070 0x2a83ce9fe5e0 , "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103629.131880:INFO:document.cc(5190)] >>> Document::setDomain. [old, new] = "bitauto.com", "bitauto.com"
[1:1:0712/103629.270468:INFO:document.cc(5190)] >>> Document::setDomain. [old, new] = "bitauto.com", "bitauto.com"
[1:1:0712/103629.271782:INFO:document.cc(5190)] >>> Document::setDomain. [old, new] = "bitauto.com", "bitauto.com"
[1:1:0712/103629.273377:INFO:document.cc(5190)] >>> Document::setDomain. [old, new] = "bitauto.com", "bitauto.com"
[1:1:0712/103629.318444:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0x3092138629c8, 0x2a83cd9dabe0
[1:1:0712/103629.318607:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 10
[1:1:0712/103629.318803:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 497
[1:1:0712/103629.318923:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 497 0x7f71c8f07070 0x2a83cec702e0 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 436 0x7f71c8f07070 0x2a83ce9fe5e0 
[1:1:0712/103629.338035:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 436 0x7f71c8f07070 0x2a83ce9fe5e0 , "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103629.361696:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 436 0x7f71c8f07070 0x2a83ce9fe5e0 , "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103629.517571:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/103629.689814:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 471, 7f71cb84c881
[1:1:0712/103629.697473:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"400 0x7f71cae2f2e0 0x2a83ce400e60 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103629.697653:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"400 0x7f71cae2f2e0 0x2a83ce400e60 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103629.697870:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103629.698169:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , , () {
                    delete City_Select._$JSON_callback[fun.id];
                    script.pa
[1:1:0712/103629.698263:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103629.956796:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 497, 7f71cb84c881
[1:1:0712/103629.963461:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"436 0x7f71c8f07070 0x2a83ce9fe5e0 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103629.963602:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"436 0x7f71c8f07070 0x2a83ce9fe5e0 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103629.963793:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103629.964072:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , , (){return N.apply(N,O)}
[1:1:0712/103629.964186:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103630.027211:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 514 0x7f71cae2f2e0 0x2a83cec3a460 , "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103630.027777:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , , var bit_IpRegion = '218.241.135.34:北京市;201,北京,beijing';
var bit_locationInfo = {cityId:'2
[1:1:0712/103630.027865:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103630.028156:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103630.184692:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 519, "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103630.186242:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , , (function(){var h={},mt={},c={id:"8f7b0f02f06be2d533aa2273ea6f7028",dm:["baa.bitauto.com"],js:"tongj
[1:1:0712/103630.186403:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103630.198390:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da9a8
[1:1:0712/103630.198577:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103630.198832:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 528
[1:1:0712/103630.198998:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 528 0x7f71c8f07070 0x2a83ced6c0e0 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 519
[28709:28709:0712/103632.095304:INFO:CONSOLE(357)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://ptyw.yiche.com/ssp/echo/v1.0/en?pid=e6a4ac06-8a66-4016-b0d7-71708ad31dba&cs=UTF-8&ord=9480&areaId=201&brandId=0&modelId=0&keywordId=&CIGDCID=679337e5b4574824b79081654821b830&callback=sspCallBackSenseNew.handleJson, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://d2.yiche.com/js/senseNew.js (357)
[28709:28709:0712/103632.096220:INFO:CONSOLE(357)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://ptyw.yiche.com/ssp/echo/v1.0/en?pid=e6a4ac06-8a66-4016-b0d7-71708ad31dba&cs=UTF-8&ord=9480&areaId=201&brandId=0&modelId=0&keywordId=&CIGDCID=679337e5b4574824b79081654821b830&callback=sspCallBackSenseNew.handleJson, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://d2.yiche.com/js/senseNew.js (357)
[28709:28709:0712/103632.119290:INFO:CONSOLE(3363)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://hm.baidu.com/h.js?8f7b0f02f06be2d533aa2273ea6f7028, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://baa.bitauto.com/cs55/thread-15796781.html (3363)
[28709:28709:0712/103632.120113:INFO:CONSOLE(3363)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://hm.baidu.com/h.js?8f7b0f02f06be2d533aa2273ea6f7028, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://baa.bitauto.com/cs55/thread-15796781.html (3363)
[1:1:0712/103632.254996:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 519, "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103632.366782:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 519, "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103632.369316:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 519, "http://baa.bitauto.com/cs55/thread-15796781.html"
		remove user.e_b4a91bea -> 0
[1:1:0712/103632.382823:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 519, "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103632.384080:INFO:document.cc(5190)] >>> Document::setDomain. [old, new] = "bitauto.com", "bitauto.com"
[1:1:0712/103632.385795:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 519, "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103632.406239:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 519, "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103632.407418:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 519, "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103632.412175:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 519, "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103632.417733:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 519, "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103632.425669:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 0
[1:1:0712/103632.425941:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 594
[1:1:0712/103632.426093:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 594 0x7f71c8f07070 0x2a83cf151ae0 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 519
[1:1:0712/103632.512452:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 519, "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103632.515810:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 519, "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103632.529454:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da998
[1:1:0712/103632.529640:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103632.529897:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 604
[1:1:0712/103632.530063:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 604 0x7f71c8f07070 0x2a83ceec2be0 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 519
[1:1:0712/103632.535131:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103632.586353:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103632.588661:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "dataavailable", "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103632.593320:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "dataavailable", "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103632.597732:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "dataavailable", "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103632.602367:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "dataavailable", "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103632.603315:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "dataavailable", "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103632.610948:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "dataavailable", "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103632.613508:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "dataavailable", "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103632.620231:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103632.620508:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baa.bitauto.com/, 609
[1:1:0712/103632.620632:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 609 0x7f71c8f07070 0x2a83cf0d2d60 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 519
[1:1:0712/103632.622262:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103632.622473:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baa.bitauto.com/, 610
[1:1:0712/103632.622601:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 610 0x7f71c8f07070 0x2a83cf0dcde0 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 519
[1:1:0712/103632.623992:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103632.624153:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baa.bitauto.com/, 611
[1:1:0712/103632.624231:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 611 0x7f71c8f07070 0x2a83cf0e5ae0 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 519
[1:1:0712/103632.625667:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103632.625884:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baa.bitauto.com/, 612
[1:1:0712/103632.626006:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 612 0x7f71c8f07070 0x2a83cf0eb060 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 519
[1:1:0712/103632.627310:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103632.627505:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baa.bitauto.com/, 613
[1:1:0712/103632.627612:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 613 0x7f71c8f07070 0x2a83cf0f35e0 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 519
[1:1:0712/103632.628892:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103632.629084:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baa.bitauto.com/, 614
[1:1:0712/103632.629281:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 614 0x7f71c8f07070 0x2a83cf0f7b60 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 519
[1:1:0712/103632.630657:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103632.630867:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baa.bitauto.com/, 615
[1:1:0712/103632.630988:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 615 0x7f71c8f07070 0x2a83cf0f9960 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 519
[1:1:0712/103632.632274:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103632.632491:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baa.bitauto.com/, 616
[1:1:0712/103632.632605:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 616 0x7f71c8f07070 0x2a83cf0fc760 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 519
[1:1:0712/103632.633911:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103632.634106:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baa.bitauto.com/, 617
[1:1:0712/103632.634232:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 617 0x7f71c8f07070 0x2a83cf100560 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 519
[1:1:0712/103632.635521:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103632.635710:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baa.bitauto.com/, 618
[1:1:0712/103632.635817:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 618 0x7f71c8f07070 0x2a83cf107360 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 519
[1:1:0712/103632.637113:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103632.637305:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baa.bitauto.com/, 619
[1:1:0712/103632.637424:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 619 0x7f71c8f07070 0x2a83cf10a160 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 519
[1:1:0712/103632.638748:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103632.638939:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baa.bitauto.com/, 620
[1:1:0712/103632.639052:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 620 0x7f71c8f07070 0x2a83cf10af60 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 519
[1:1:0712/103632.640352:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103632.640594:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baa.bitauto.com/, 621
[1:1:0712/103632.640692:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 621 0x7f71c8f07070 0x2a83cf10ed60 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 519
[1:1:0712/103632.642092:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103632.642288:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baa.bitauto.com/, 622
[1:1:0712/103632.642405:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 622 0x7f71c8f07070 0x2a83cf111b60 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 519
[1:1:0712/103632.643681:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103632.643863:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baa.bitauto.com/, 623
[1:1:0712/103632.643967:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 623 0x7f71c8f07070 0x2a83cf115960 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 519
[3:3:0712/103632.690066:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[28709:28709:0712/103632.734173:INFO:CONSOLE(3570)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://hm.baidu.com/h.js?8f7b0f02f06be2d533aa2273ea6f7028, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://baa.bitauto.com/cs55/thread-15796781.html (3570)
[28709:28709:0712/103632.735091:INFO:CONSOLE(3570)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://hm.baidu.com/h.js?8f7b0f02f06be2d533aa2273ea6f7028, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://baa.bitauto.com/cs55/thread-15796781.html (3570)
[1:1:0712/103632.737748:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0x3092138629c8, 0x2a83cd9daad8
[1:1:0712/103632.737936:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 10
[1:1:0712/103632.738139:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 635
[1:1:0712/103632.738248:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 635 0x7f71c8f07070 0x2a83cef472e0 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 519
[1:1:0712/103632.746022:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0x3092138629c8, 0x2a83cd9daad8
[1:1:0712/103632.746172:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 10
[1:1:0712/103632.746358:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 637
[1:1:0712/103632.746469:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 637 0x7f71c8f07070 0x2a83cf00ac60 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 519
[1:1:0712/103632.754102:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103632.754993:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103632.786921:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103632.962526:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/103632.962767:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103633.831946:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103633.832382:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , onStateChange, (){var A=this.transport.readyState;if(A>1&&!((A==4)&&this._complete)){this.respondToReadyState(this.
[1:1:0712/103633.832499:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103633.834079:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103633.843576:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x330d50a18e0
[1:1:0712/103633.872179:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103633.872599:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , onStateChange, (){var A=this.transport.readyState;if(A>1&&!((A==4)&&this._complete)){this.respondToReadyState(this.
[1:1:0712/103633.872719:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103633.873899:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103633.876426:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103633.906005:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x330d50a18e0
[1:1:0712/103633.920154:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 528, 7f71cb84c881
[1:1:0712/103633.931055:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"519","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103633.931216:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"519","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103633.931410:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103633.931696:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/103633.931783:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103633.932126:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da950
[1:1:0712/103633.932204:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103633.932388:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 712
[1:1:0712/103633.932531:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 712 0x7f71c8f07070 0x2a83cf009060 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 528 0x7f71c8f07070 0x2a83ced6c0e0 
[1:1:0712/103633.932978:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 594, 7f71cb84c881
[1:1:0712/103633.942901:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"519","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103633.943101:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"519","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103633.943649:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103633.944144:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , , gJsWtid.src="http://Webtrends.yccdn.com/dcs0shdj3ltq36hp3m47ucd9v_9i5v/wtid.js"
[1:1:0712/103633.944279:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103633.958731:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 604, 7f71cb84c881
[1:1:0712/103633.969139:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"519","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103633.969398:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"519","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103633.969738:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103633.970059:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/103633.970183:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103633.970603:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da950
[1:1:0712/103633.970724:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103633.970891:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 715
[1:1:0712/103633.971008:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 715 0x7f71c8f07070 0x2a83cf24a160 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 604 0x7f71c8f07070 0x2a83ceec2be0 
[1:1:0712/103633.986658:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baa.bitauto.com/, 609, 7f71cb84c8db
[1:1:0712/103633.997422:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"519","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103633.997808:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"519","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103633.998029:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baa.bitauto.com/, 720
[1:1:0712/103633.998150:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 720 0x7f71c8f07070 0x2a83cdea0760 , 5:3_http://baa.bitauto.com/, 0, , 609 0x7f71c8f07070 0x2a83cf0d2d60 
[1:1:0712/103633.998304:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103633.998587:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , onTimerEvent, (){if(!this.currentlyExecuting){try{this.currentlyExecuting=true;this.execute();this.currentlyExecut
[1:1:0712/103633.998702:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103634.020348:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baa.bitauto.com/, 610, 7f71cb84c8db
[1:1:0712/103634.033300:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"519","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103634.033478:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"519","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103634.033689:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baa.bitauto.com/, 722
[1:1:0712/103634.033825:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 722 0x7f71c8f07070 0x2a83cf242d60 , 5:3_http://baa.bitauto.com/, 0, , 610 0x7f71c8f07070 0x2a83cf0dcde0 
[1:1:0712/103634.033969:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103634.034258:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , onTimerEvent, (){if(!this.currentlyExecuting){try{this.currentlyExecuting=true;this.execute();this.currentlyExecut
[1:1:0712/103634.034362:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103634.054483:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baa.bitauto.com/, 611, 7f71cb84c8db
[1:1:0712/103634.066869:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"519","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103634.067141:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"519","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103634.067377:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baa.bitauto.com/, 725
[1:1:0712/103634.067491:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 725 0x7f71c8f07070 0x2a83cf242ee0 , 5:3_http://baa.bitauto.com/, 0, , 611 0x7f71c8f07070 0x2a83cf0e5ae0 
[1:1:0712/103634.067636:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103634.067928:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , onTimerEvent, (){if(!this.currentlyExecuting){try{this.currentlyExecuting=true;this.execute();this.currentlyExecut
[1:1:0712/103634.068040:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103634.090739:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baa.bitauto.com/, 612, 7f71cb84c8db
[1:1:0712/103634.102144:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"519","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103634.102340:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"519","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103634.102582:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baa.bitauto.com/, 728
[1:1:0712/103634.102708:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 728 0x7f71c8f07070 0x2a83cf29e0e0 , 5:3_http://baa.bitauto.com/, 0, , 612 0x7f71c8f07070 0x2a83cf0eb060 
[1:1:0712/103634.102879:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103634.103184:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , onTimerEvent, (){if(!this.currentlyExecuting){try{this.currentlyExecuting=true;this.execute();this.currentlyExecut
[1:1:0712/103634.103302:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103634.109733:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baa.bitauto.com/, 613, 7f71cb84c8db
[1:1:0712/103634.121209:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"519","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103634.121368:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"519","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103634.121570:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baa.bitauto.com/, 730
[1:1:0712/103634.121671:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 730 0x7f71c8f07070 0x2a83cf2916e0 , 5:3_http://baa.bitauto.com/, 0, , 613 0x7f71c8f07070 0x2a83cf0f35e0 
[1:1:0712/103634.121802:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103634.122070:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , onTimerEvent, (){if(!this.currentlyExecuting){try{this.currentlyExecuting=true;this.execute();this.currentlyExecut
[1:1:0712/103634.122166:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103634.140808:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baa.bitauto.com/, 614, 7f71cb84c8db
[1:1:0712/103634.151989:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"519","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103634.152152:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"519","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103634.152363:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baa.bitauto.com/, 733
[1:1:0712/103634.152455:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 733 0x7f71c8f07070 0x2a83cf274ce0 , 5:3_http://baa.bitauto.com/, 0, , 614 0x7f71c8f07070 0x2a83cf0f7b60 
[1:1:0712/103634.152574:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103634.152820:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , onTimerEvent, (){if(!this.currentlyExecuting){try{this.currentlyExecuting=true;this.execute();this.currentlyExecut
[1:1:0712/103634.152890:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103634.172199:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 670 0x7f71cae2f2e0 0x2a83cec835e0 , "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103634.174612:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , , Date.prototype.format = function (format) {
    var o = { "M+": this.getMonth() + 1, "d+": this.get
[1:1:0712/103634.174724:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103634.196979:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103634.202681:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baa.bitauto.com/, 615, 7f71cb84c8db
[1:1:0712/103634.214623:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"519","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103634.214794:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"519","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103634.215020:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baa.bitauto.com/, 738
[1:1:0712/103634.215145:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 738 0x7f71c8f07070 0x2a83cf2b2060 , 5:3_http://baa.bitauto.com/, 0, , 615 0x7f71c8f07070 0x2a83cf0f9960 
[1:1:0712/103634.215284:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103634.215560:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , onTimerEvent, (){if(!this.currentlyExecuting){try{this.currentlyExecuting=true;this.execute();this.currentlyExecut
[1:1:0712/103634.215664:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103634.225184:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baa.bitauto.com/, 616, 7f71cb84c8db
[1:1:0712/103634.237874:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"519","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103634.238068:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"519","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103634.238329:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baa.bitauto.com/, 740
[1:1:0712/103634.238472:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 740 0x7f71c8f07070 0x2a83cf291960 , 5:3_http://baa.bitauto.com/, 0, , 616 0x7f71c8f07070 0x2a83cf0fc760 
[1:1:0712/103634.238648:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103634.238924:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , onTimerEvent, (){if(!this.currentlyExecuting){try{this.currentlyExecuting=true;this.execute();this.currentlyExecut
[1:1:0712/103634.239011:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103634.261314:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baa.bitauto.com/, 617, 7f71cb84c8db
[1:1:0712/103634.273670:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"519","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103634.273863:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"519","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103634.274107:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baa.bitauto.com/, 742
[1:1:0712/103634.274231:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 742 0x7f71c8f07070 0x2a83cf31bae0 , 5:3_http://baa.bitauto.com/, 0, , 617 0x7f71c8f07070 0x2a83cf100560 
[1:1:0712/103634.274402:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103634.274701:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , onTimerEvent, (){if(!this.currentlyExecuting){try{this.currentlyExecuting=true;this.execute();this.currentlyExecut
[1:1:0712/103634.274819:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103634.294499:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 671 0x7f71cae2f2e0 0x2a83cf17b760 , "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103634.295269:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , , !function(t,e){function i(t){for(var e;e=t.shift();)e()}function n(){p.loading=1;var n,o="";try{n=t.
[1:1:0712/103634.295418:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103634.303025:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baa.bitauto.com/, 618, 7f71cb84c8db
[1:1:0712/103634.316563:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"519","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103634.317690:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"519","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103634.317946:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baa.bitauto.com/, 745
[1:1:0712/103634.318074:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 745 0x7f71c8f07070 0x2a83cf2def60 , 5:3_http://baa.bitauto.com/, 0, , 618 0x7f71c8f07070 0x2a83cf107360 
[1:1:0712/103634.318239:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103634.318770:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , onTimerEvent, (){if(!this.currentlyExecuting){try{this.currentlyExecuting=true;this.execute();this.currentlyExecut
[1:1:0712/103634.318891:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103634.328622:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baa.bitauto.com/, 619, 7f71cb84c8db
[1:1:0712/103634.340272:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"519","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103634.340452:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"519","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103634.340668:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baa.bitauto.com/, 747
[1:1:0712/103634.340765:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 747 0x7f71c8f07070 0x2a83cf2c4960 , 5:3_http://baa.bitauto.com/, 0, , 619 0x7f71c8f07070 0x2a83cf10a160 
[1:1:0712/103634.340875:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103634.341201:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , onTimerEvent, (){if(!this.currentlyExecuting){try{this.currentlyExecuting=true;this.execute();this.currentlyExecut
[1:1:0712/103634.341340:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103634.360219:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baa.bitauto.com/, 620, 7f71cb84c8db
[1:1:0712/103634.370833:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"519","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103634.371000:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"519","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103634.371217:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baa.bitauto.com/, 750
[1:1:0712/103634.371335:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 750 0x7f71c8f07070 0x2a83cf359260 , 5:3_http://baa.bitauto.com/, 0, , 620 0x7f71c8f07070 0x2a83cf10af60 
[1:1:0712/103634.371500:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103634.371815:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , onTimerEvent, (){if(!this.currentlyExecuting){try{this.currentlyExecuting=true;this.execute();this.currentlyExecut
[1:1:0712/103634.371935:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103634.390764:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , , document.readyState
[1:1:0712/103634.390936:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103634.392275:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baa.bitauto.com/, 621, 7f71cb84c8db
[1:1:0712/103634.404308:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"519","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103634.404487:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"519","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103634.404722:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baa.bitauto.com/, 754
[1:1:0712/103634.404830:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 754 0x7f71c8f07070 0x2a83cf200260 , 5:3_http://baa.bitauto.com/, 0, , 621 0x7f71c8f07070 0x2a83cf10ed60 
[1:1:0712/103634.404983:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103634.405436:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , onTimerEvent, (){if(!this.currentlyExecuting){try{this.currentlyExecuting=true;this.execute();this.currentlyExecut
[1:1:0712/103634.405582:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103634.411785:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baa.bitauto.com/, 622, 7f71cb84c8db
[1:1:0712/103634.423510:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"519","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103634.423715:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"519","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103634.423931:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baa.bitauto.com/, 756
[1:1:0712/103634.424047:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 756 0x7f71c8f07070 0x2a83cf3362e0 , 5:3_http://baa.bitauto.com/, 0, , 622 0x7f71c8f07070 0x2a83cf111b60 
[1:1:0712/103634.424180:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103634.424454:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , onTimerEvent, (){if(!this.currentlyExecuting){try{this.currentlyExecuting=true;this.execute();this.currentlyExecut
[1:1:0712/103634.424544:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103634.442395:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baa.bitauto.com/, 623, 7f71cb84c8db
[1:1:0712/103634.452619:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"519","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103634.452769:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"519","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103634.452962:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baa.bitauto.com/, 758
[1:1:0712/103634.453098:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 758 0x7f71c8f07070 0x2a83cf361660 , 5:3_http://baa.bitauto.com/, 0, , 623 0x7f71c8f07070 0x2a83cf115960 
[1:1:0712/103634.453247:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103634.453523:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , onTimerEvent, (){if(!this.currentlyExecuting){try{this.currentlyExecuting=true;this.execute();this.currentlyExecut
[1:1:0712/103634.453644:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103634.643766:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 635, 7f71cb84c881
[1:1:0712/103634.656221:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"519","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103634.656421:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"519","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103634.656653:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103634.656936:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , , (){return N.apply(N,O)}
[1:1:0712/103634.657035:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103634.659052:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 637, 7f71cb84c881
[1:1:0712/103634.670748:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"519","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103634.670908:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"519","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103634.671119:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103634.671424:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , , (){return N.apply(N,O)}
[1:1:0712/103634.671514:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103634.851034:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 679 0x7f71cae2f2e0 0x2a83cefb8360 , "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103634.853746:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , , //0.042
//0.041
//CIG DC
var _dc_cm_time = 432000;//5days 432000 500days 43200000
var _dc_pc_kg 
[1:1:0712/103634.853955:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103634.881776:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 6000
[1:1:0712/103634.882070:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 797
[1:1:0712/103634.882249:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 797 0x7f71c8f07070 0x2a83cf0c9160 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 679 0x7f71cae2f2e0 0x2a83cefb8360 
[1:1:0712/103634.910012:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 680 0x7f71cae2f2e0 0x2a83cdabafe0 , "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103634.910688:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , , success_jsonpCallback1([{"Id":1048100,"Name":"张一帆","JobLvl":2,"ImgUrl":"https://epbf.bitautoim
[1:1:0712/103634.910840:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103634.912525:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103635.438555:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 712, 7f71cb84c881
[1:1:0712/103635.452622:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"528 0x7f71c8f07070 0x2a83ced6c0e0 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103635.452807:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"528 0x7f71c8f07070 0x2a83ced6c0e0 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103635.453051:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103635.453367:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/103635.453476:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103635.454013:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da950
[1:1:0712/103635.454128:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103635.454321:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 814
[1:1:0712/103635.454436:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 814 0x7f71c8f07070 0x2a83ce9a21e0 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 712 0x7f71c8f07070 0x2a83cf009060 
[1:1:0712/103635.454944:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 715, 7f71cb84c881
[1:1:0712/103635.469156:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"604 0x7f71c8f07070 0x2a83ceec2be0 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103635.469354:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"604 0x7f71c8f07070 0x2a83ceec2be0 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103635.469571:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103635.469939:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/103635.470059:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103635.470581:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da950
[1:1:0712/103635.470693:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103635.470896:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 815
[1:1:0712/103635.471022:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 815 0x7f71c8f07070 0x2a83cf14d3e0 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 715 0x7f71c8f07070 0x2a83cf24a160 
[1:1:0712/103635.761621:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , , document.readyState
[1:1:0712/103635.761798:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103636.886877:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103636.887288:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , f.onload, (){f.onload=u;f=window[d]=u;a&&a(b)}
[1:1:0712/103636.887401:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103636.963713:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 810 0x7f71cae2f2e0 0x2a83cf3599e0 , "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103636.964687:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , , <!-- 
gWtId="139.207.78.31-2425217536.30750809";  
gWtAccountRollup=1; 
 
// -->

[1:1:0712/103636.964814:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103636.978411:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 811 0x7f71cae2f2e0 0x2a83cf377960 , "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103636.978945:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , , _29WLM('CLAnatI5Al0pHgsbR1XsgQA')
[1:1:0712/103636.979033:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103637.115525:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 814, 7f71cb84c881
[1:1:0712/103637.129296:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"712 0x7f71c8f07070 0x2a83cf009060 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103637.129466:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"712 0x7f71c8f07070 0x2a83cf009060 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103637.129667:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103637.129960:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103637.130075:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103637.130890:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da950
[1:1:0712/103637.131257:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103637.131437:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 882
[1:1:0712/103637.131533:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 882 0x7f71c8f07070 0x2a83cf32aa60 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 814 0x7f71c8f07070 0x2a83ce9a21e0 
[1:1:0712/103637.131997:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 815, 7f71cb84c881
[1:1:0712/103637.146266:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"715 0x7f71c8f07070 0x2a83cf24a160 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103637.146450:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"715 0x7f71c8f07070 0x2a83cf24a160 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103637.146738:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103637.147074:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103637.147468:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103637.148078:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da950
[1:1:0712/103637.148173:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103637.148362:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 883
[1:1:0712/103637.148489:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 883 0x7f71c8f07070 0x2a83cf3da260 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 815 0x7f71c8f07070 0x2a83cf14d3e0 
[1:1:0712/103637.242963:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , , document.readyState
[1:1:0712/103637.243156:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103638.241928:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , , document.readyState
[1:1:0712/103638.242108:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103638.243505:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 882, 7f71cb84c881
[1:1:0712/103638.259081:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"814 0x7f71c8f07070 0x2a83ce9a21e0 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103638.259249:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"814 0x7f71c8f07070 0x2a83ce9a21e0 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103638.259443:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103638.259717:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103638.259804:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103638.260340:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da950
[1:1:0712/103638.260421:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103638.260605:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 951
[1:1:0712/103638.260700:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 951 0x7f71c8f07070 0x2a83cfd98360 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 882 0x7f71c8f07070 0x2a83cf32aa60 
[1:1:0712/103638.261194:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 883, 7f71cb84c881
[1:1:0712/103638.276114:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"815 0x7f71c8f07070 0x2a83cf14d3e0 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103638.276323:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"815 0x7f71c8f07070 0x2a83cf14d3e0 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103638.276553:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103638.276922:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103638.277009:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103638.277561:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da950
[1:1:0712/103638.277667:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103638.277861:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 952
[1:1:0712/103638.277980:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 952 0x7f71c8f07070 0x2a83cefb4660 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 883 0x7f71c8f07070 0x2a83cf3da260 
[1:1:0712/103639.078046:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , , document.readyState
[1:1:0712/103639.078218:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103639.305619:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 951, 7f71cb84c881
[1:1:0712/103639.321993:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"882 0x7f71c8f07070 0x2a83cf32aa60 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103639.322184:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"882 0x7f71c8f07070 0x2a83cf32aa60 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103639.322417:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103639.322768:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103639.322896:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103639.323485:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da950
[1:1:0712/103639.323566:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103639.323726:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1002
[1:1:0712/103639.323823:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1002 0x7f71c8f07070 0x2a83cfd95d60 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 951 0x7f71c8f07070 0x2a83cfd98360 
[1:1:0712/103639.324312:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 952, 7f71cb84c881
[1:1:0712/103639.339779:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"883 0x7f71c8f07070 0x2a83cf3da260 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103639.339949:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"883 0x7f71c8f07070 0x2a83cf3da260 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103639.340148:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103639.340426:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103639.340523:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103639.341104:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da950
[1:1:0712/103639.341185:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103639.341349:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1003
[1:1:0712/103639.341439:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1003 0x7f71c8f07070 0x2a83cff594e0 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 952 0x7f71c8f07070 0x2a83cefb4660 
[1:1:0712/103639.488072:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 973 0x7f71cae2f2e0 0x2a83cfd862e0 , "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103639.489170:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , , try{
	    	//3c ok
	    	_dcv.push(['_set3C', 1]);
    		_dcv.push(['_setUid','fdc9cca86eca5c662ea3a
[1:1:0712/103639.489318:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103640.145574:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , , document.readyState
[1:1:0712/103640.145734:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103640.218268:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1002, 7f71cb84c881
[1:1:0712/103640.235189:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"951 0x7f71c8f07070 0x2a83cfd98360 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103640.235576:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"951 0x7f71c8f07070 0x2a83cfd98360 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103640.235876:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103640.236419:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103640.236545:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103640.237173:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da950
[1:1:0712/103640.237275:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103640.237475:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1077
[1:1:0712/103640.237614:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1077 0x7f71c8f07070 0x2a83ce000d60 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 1002 0x7f71c8f07070 0x2a83cfd95d60 
[1:1:0712/103640.238150:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1003, 7f71cb84c881
[1:1:0712/103640.255676:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"952 0x7f71c8f07070 0x2a83cefb4660 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103640.255844:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"952 0x7f71c8f07070 0x2a83cefb4660 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103640.256044:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103640.256326:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103640.256413:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103640.256925:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da950
[1:1:0712/103640.257006:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103640.257206:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1078
[1:1:0712/103640.257324:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1078 0x7f71c8f07070 0x2a83cf9f2160 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 1003 0x7f71c8f07070 0x2a83cff594e0 
[1:1:0712/103641.584561:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , , document.readyState
[1:1:0712/103641.589182:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103641.649984:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1077, 7f71cb84c881
[1:1:0712/103641.668920:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"1002 0x7f71c8f07070 0x2a83cfd95d60 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103641.669133:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"1002 0x7f71c8f07070 0x2a83cfd95d60 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103641.669412:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103641.669805:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103641.669977:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103641.670622:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da950
[1:1:0712/103641.670778:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103641.670979:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1106
[1:1:0712/103641.671093:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1106 0x7f71c8f07070 0x2a83cf68b760 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 1077 0x7f71c8f07070 0x2a83ce000d60 
[1:1:0712/103641.671624:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1078, 7f71cb84c881
[1:1:0712/103641.700717:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"1003 0x7f71c8f07070 0x2a83cff594e0 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103641.700914:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"1003 0x7f71c8f07070 0x2a83cff594e0 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103641.701143:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103641.701467:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103641.701604:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103641.702201:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da950
[1:1:0712/103641.702354:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103641.702557:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1107
[1:1:0712/103641.702677:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1107 0x7f71c8f07070 0x2a83cda372e0 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 1078 0x7f71c8f07070 0x2a83cf9f2160 
[28709:28739:0712/103641.791727:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 6
[3:3:0712/103641.791906:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/103641.792039:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/103641.792211:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/103641.792321:INFO:zygote_linux.cc(633)] 		cid is 6
[1:1:0712/103641.814482:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x3d9d15d5, 1
[1:1:0712/103641.814716:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0xe929abc, 0
[1:1:0712/103641.814883:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x3cf0e330, 3
[1:1:0712/103641.815022:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x1fb50041, 2
[1:1:0712/103641.815158:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffbcffffff9affffff920e ffffffd515ffffff9d3d 4100ffffffb51f 30ffffffe3fffffff03c , 10104, 6
[1:1:0712/103641.815912:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[28709:28739:0712/103641.816068:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�����=A
[28709:28739:0712/103641.816116:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �����=A
[1:1:0712/103641.816063:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f71df4060a0, 3
[1:1:0712/103641.816159:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f71df592080, 2
[28709:28739:0712/103641.816241:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 28824, 6, bc9a920e d5159d3d 4100b51f 30e3f03c 
[1:1:0712/103641.816247:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f71c9254d20, -2
[1:1:0712/103641.824071:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/103641.824453:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1fb50041
[1:1:0712/103641.824887:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1fb50041
[1:1:0712/103641.825850:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1fb50041
[1:1:0712/103641.826395:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1fb50041
[1:1:0712/103641.826512:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1fb50041
[1:1:0712/103641.826628:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1fb50041
[1:1:0712/103641.826742:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1fb50041
[1:1:0712/103641.826970:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1fb50041
[1:1:0712/103641.827123:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f71e11cc7ba
[1:1:0712/103641.827221:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f71e11c3def, 7f71e11cc77a, 7f71e11ce0cf
[1:1:0712/103641.828843:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1fb50041
[1:1:0712/103641.829000:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1fb50041
[1:1:0712/103641.829296:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1fb50041
[1:1:0712/103641.829999:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1fb50041
[1:1:0712/103641.830108:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1fb50041
[1:1:0712/103641.830201:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1fb50041
[1:1:0712/103641.830293:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1fb50041
[1:1:0712/103641.830690:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1fb50041
[1:1:0712/103641.830852:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f71e11cc7ba
[1:1:0712/103641.830933:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f71e11c3def, 7f71e11cc77a, 7f71e11ce0cf
[1:1:0712/103641.833358:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/103641.833635:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/103641.833745:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffd33f4c568, 0x7ffd33f4c4e8)
[1:1:0712/103641.841940:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1088 0x7f71cae2f2e0 0x2a83ce000fe0 , "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103641.843329:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , , ep_jsondata_ep_union_112 = {status:1, html:'<ul class="jxs-list">            <li>        <div class=
[1:1:0712/103641.843483:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103641.844236:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/103641.844016:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103642.014721:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 797, 7f71cb84c881
[1:1:0712/103642.032527:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"679 0x7f71cae2f2e0 0x2a83cefb8360 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103642.032721:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"679 0x7f71cae2f2e0 0x2a83cefb8360 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103642.032946:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103642.033647:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , , _psc_kanli_kuai_im_dcjs()
[1:1:0712/103642.033765:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103642.133328:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103642.139734:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , c.onload.c.onerror, () {
            window[n] = null
        }
[1:1:0712/103642.139882:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103642.216548:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , , document.readyState
[1:1:0712/103642.216684:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103642.309526:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103642.310022:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , c.onload.c.onerror, () {
            window[n] = null
        }
[1:1:0712/103642.310189:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103642.311089:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1106, 7f71cb84c881
[1:1:0712/103642.330417:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"1077 0x7f71c8f07070 0x2a83ce000d60 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103642.330615:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"1077 0x7f71c8f07070 0x2a83ce000d60 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103642.330865:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103642.331177:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103642.331295:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103642.331871:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da950
[1:1:0712/103642.331982:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103642.332227:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1137
[1:1:0712/103642.332328:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1137 0x7f71c8f07070 0x2a83cfa0c960 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 1106 0x7f71c8f07070 0x2a83cf68b760 
[1:1:0712/103642.401159:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1107, 7f71cb84c881
[1:1:0712/103642.420450:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"1078 0x7f71c8f07070 0x2a83cf9f2160 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103642.420645:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"1078 0x7f71c8f07070 0x2a83cf9f2160 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103642.420848:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103642.421170:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103642.421285:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103642.421859:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da950
[1:1:0712/103642.421954:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103642.422132:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1142
[1:1:0712/103642.422238:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1142 0x7f71c8f07070 0x2a83d00f10e0 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 1107 0x7f71c8f07070 0x2a83cda372e0 
[1:1:0712/103642.779804:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1129 0x7f71cae2f2e0 0x2a83cf68ab60 , "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103642.781540:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , , 
[1:1:0712/103642.781674:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103642.802042:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1130 0x7f71cae2f2e0 0x2a83cda95260 , "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103642.802662:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , , 
[1:1:0712/103642.802795:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103642.803032:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103642.865066:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , , document.readyState
[1:1:0712/103642.865281:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103642.973210:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1137, 7f71cb84c881
[1:1:0712/103642.989778:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"1106 0x7f71c8f07070 0x2a83cf68b760 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103642.989997:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"1106 0x7f71c8f07070 0x2a83cf68b760 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103642.990252:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103642.990591:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103642.990733:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103642.991307:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da950
[1:1:0712/103642.991415:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103642.991605:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1164
[1:1:0712/103642.991723:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1164 0x7f71c8f07070 0x2a83cfd986e0 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 1137 0x7f71c8f07070 0x2a83cfa0c960 
[1:1:0712/103643.011285:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1142, 7f71cb84c881
[1:1:0712/103643.030933:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"1107 0x7f71c8f07070 0x2a83cda372e0 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103643.031108:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"1107 0x7f71c8f07070 0x2a83cda372e0 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103643.031612:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103643.031932:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103643.032049:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103643.032635:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da950
[1:1:0712/103643.032865:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103643.033052:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1165
[1:1:0712/103643.033350:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1165 0x7f71c8f07070 0x2a83cda954e0 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 1142 0x7f71c8f07070 0x2a83d00f10e0 
[1:1:0712/103643.381861:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103643.382287:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , c.onload.c.onerror, () {
        window[n] = null
    }
[1:1:0712/103643.382385:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103643.419409:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , , document.readyState
[1:1:0712/103643.419567:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103643.454993:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1164, 7f71cb84c881
[1:1:0712/103643.475521:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"1137 0x7f71c8f07070 0x2a83cfa0c960 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103643.475712:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"1137 0x7f71c8f07070 0x2a83cfa0c960 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103643.475928:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103643.476243:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103643.476349:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103643.476931:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da950
[1:1:0712/103643.477022:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103643.477231:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1177
[1:1:0712/103643.477352:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1177 0x7f71c8f07070 0x2a83cf5e2c60 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 1164 0x7f71c8f07070 0x2a83cfd986e0 
[1:1:0712/103643.500498:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1165, 7f71cb84c881
[1:1:0712/103643.520137:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"1142 0x7f71c8f07070 0x2a83d00f10e0 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103643.520343:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"1142 0x7f71c8f07070 0x2a83d00f10e0 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103643.520563:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103643.520860:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103643.520956:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103643.521526:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da950
[1:1:0712/103643.521639:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103643.521841:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1178
[1:1:0712/103643.521964:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1178 0x7f71c8f07070 0x2a83d00fa1e0 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 1165 0x7f71c8f07070 0x2a83cda954e0 
[1:1:0712/103643.630277:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , , document.readyState
[1:1:0712/103643.630472:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103643.631978:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1177, 7f71cb84c881
[1:1:0712/103643.649546:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"1164 0x7f71c8f07070 0x2a83cfd986e0 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103643.649719:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"1164 0x7f71c8f07070 0x2a83cfd986e0 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103643.649926:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103643.650219:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103643.650331:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103643.650864:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da950
[1:1:0712/103643.650977:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103643.651164:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1187
[1:1:0712/103643.651283:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1187 0x7f71c8f07070 0x2a83cf68b960 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 1177 0x7f71c8f07070 0x2a83cf5e2c60 
[1:1:0712/103643.688549:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1178, 7f71cb84c881
[1:1:0712/103643.711084:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"1165 0x7f71c8f07070 0x2a83cda954e0 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103643.711303:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"1165 0x7f71c8f07070 0x2a83cda954e0 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103643.711553:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103643.711864:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103643.711968:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103643.712545:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da950
[1:1:0712/103643.712627:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103643.712825:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1190
[1:1:0712/103643.712922:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1190 0x7f71c8f07070 0x2a83d0176560 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 1178 0x7f71c8f07070 0x2a83d00fa1e0 
[1:1:0712/103643.733940:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , , document.readyState
[1:1:0712/103643.734109:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103643.775245:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , , document.readyState
[1:1:0712/103643.775399:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103643.812428:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1187, 7f71cb84c881
[1:1:0712/103643.830632:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"1177 0x7f71c8f07070 0x2a83cf5e2c60 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103643.830839:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"1177 0x7f71c8f07070 0x2a83cf5e2c60 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103643.831045:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103643.831320:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103643.831416:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103643.831950:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da950
[1:1:0712/103643.832029:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103643.832211:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1199
[1:1:0712/103643.832315:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1199 0x7f71c8f07070 0x2a83cfa3fb60 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 1187 0x7f71c8f07070 0x2a83cf68b960 
[1:1:0712/103643.867797:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , , document.readyState
[1:1:0712/103643.867961:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103643.887852:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1190, 7f71cb84c881
[1:1:0712/103643.905372:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"1178 0x7f71c8f07070 0x2a83d00fa1e0 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103643.905796:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"1178 0x7f71c8f07070 0x2a83d00fa1e0 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103643.906026:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103643.906337:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103643.906513:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103643.907205:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da950
[1:1:0712/103643.907341:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103643.907917:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1204
[1:1:0712/103643.908057:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1204 0x7f71c8f07070 0x2a83d0171260 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 1190 0x7f71c8f07070 0x2a83d0176560 
[1:1:0712/103643.929759:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , , document.readyState
[1:1:0712/103643.929939:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103643.972807:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , , document.readyState
[1:1:0712/103643.980459:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103644.018834:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1199, 7f71cb84c881
[1:1:0712/103644.036790:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"1187 0x7f71c8f07070 0x2a83cf68b960 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103644.036984:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"1187 0x7f71c8f07070 0x2a83cf68b960 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103644.037298:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103644.037639:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103644.037757:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103644.038404:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da950
[1:1:0712/103644.038535:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103644.038732:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1214
[1:1:0712/103644.038854:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1214 0x7f71c8f07070 0x2a83d00f1fe0 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 1199 0x7f71c8f07070 0x2a83cfa3fb60 
[1:1:0712/103644.075106:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , , document.readyState
[1:1:0712/103644.075251:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103644.094768:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1204, 7f71cb84c881
[1:1:0712/103644.111662:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"1190 0x7f71c8f07070 0x2a83d0176560 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103644.111829:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"1190 0x7f71c8f07070 0x2a83d0176560 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103644.112047:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103644.112352:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103644.112473:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103644.112999:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da950
[1:1:0712/103644.113112:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103644.113288:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1218
[1:1:0712/103644.113424:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1218 0x7f71c8f07070 0x2a83cf9e86e0 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 1204 0x7f71c8f07070 0x2a83d0171260 
[1:1:0712/103644.133546:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , , document.readyState
[1:1:0712/103644.133694:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103644.176346:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , , document.readyState
[1:1:0712/103644.176542:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103644.217617:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1214, 7f71cb84c881
[1:1:0712/103644.235792:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"1199 0x7f71c8f07070 0x2a83cfa3fb60 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103644.235962:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"1199 0x7f71c8f07070 0x2a83cfa3fb60 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103644.236160:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103644.236436:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103644.236535:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103644.237087:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da950
[1:1:0712/103644.237186:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103644.237406:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1228
[1:1:0712/103644.237511:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1228 0x7f71c8f07070 0x2a83cfd8a8e0 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 1214 0x7f71c8f07070 0x2a83d00f1fe0 
[1:1:0712/103644.273819:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , , document.readyState
[1:1:0712/103644.273977:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103644.294124:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1218, 7f71cb84c881
[1:1:0712/103644.311842:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"1204 0x7f71c8f07070 0x2a83d0171260 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103644.312022:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"1204 0x7f71c8f07070 0x2a83d0171260 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103644.312236:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103644.312526:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103644.312627:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103644.313205:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da950
[1:1:0712/103644.313301:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103644.313480:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1232
[1:1:0712/103644.313577:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1232 0x7f71c8f07070 0x2a83cf377760 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 1218 0x7f71c8f07070 0x2a83cf9e86e0 
[1:1:0712/103644.331017:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , , document.readyState
[1:1:0712/103644.331165:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103644.373918:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , , document.readyState
[1:1:0712/103644.374090:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103644.416340:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1228, 7f71cb84c881
[1:1:0712/103644.435850:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"1214 0x7f71c8f07070 0x2a83d00f1fe0 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103644.436031:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"1214 0x7f71c8f07070 0x2a83d00f1fe0 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103644.436237:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103644.436537:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103644.436626:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103644.437197:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da950
[1:1:0712/103644.437292:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103644.437471:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1241
[1:1:0712/103644.437576:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1241 0x7f71c8f07070 0x2a83cda351e0 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 1228 0x7f71c8f07070 0x2a83cfd8a8e0 
[1:1:0712/103644.474124:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , , document.readyState
[1:1:0712/103644.474269:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103644.494225:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1232, 7f71cb84c881
[1:1:0712/103644.511938:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"1218 0x7f71c8f07070 0x2a83cf9e86e0 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103644.512107:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"1218 0x7f71c8f07070 0x2a83cf9e86e0 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103644.512304:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103644.512565:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103644.512668:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103644.513256:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da950
[1:1:0712/103644.513345:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103644.513520:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1245
[1:1:0712/103644.513628:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1245 0x7f71c8f07070 0x2a83d00fa060 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 1232 0x7f71c8f07070 0x2a83cf377760 
[1:1:0712/103644.532362:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , , document.readyState
[1:1:0712/103644.532518:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103644.571901:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , , document.readyState
[1:1:0712/103644.572052:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103644.615764:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1241, 7f71cb84c881
[1:1:0712/103644.636795:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"1228 0x7f71c8f07070 0x2a83cfd8a8e0 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103644.636974:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"1228 0x7f71c8f07070 0x2a83cfd8a8e0 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103644.637190:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103644.637499:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103644.637595:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103644.638146:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da950
[1:1:0712/103644.638223:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103644.638387:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1256
[1:1:0712/103644.638470:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1256 0x7f71c8f07070 0x2a83cf3168e0 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 1241 0x7f71c8f07070 0x2a83cda351e0 
[1:1:0712/103644.676801:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , , document.readyState
[1:1:0712/103644.676968:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103644.697721:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1245, 7f71cb84c881
[1:1:0712/103644.716196:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"1232 0x7f71c8f07070 0x2a83cf377760 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103644.716370:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"1232 0x7f71c8f07070 0x2a83cf377760 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103644.716556:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103644.716817:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103644.716904:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103644.717458:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da950
[1:1:0712/103644.717547:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103644.717721:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1263
[1:1:0712/103644.717823:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1263 0x7f71c8f07070 0x2a83cf39b760 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 1245 0x7f71c8f07070 0x2a83d00fa060 
[1:1:0712/103644.848952:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , , document.readyState
[1:1:0712/103644.849156:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103644.913370:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1256, 7f71cb84c881
[1:1:0712/103644.933223:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"1241 0x7f71c8f07070 0x2a83cda351e0 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103644.933382:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"1241 0x7f71c8f07070 0x2a83cda351e0 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103644.933576:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103644.933848:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103644.933944:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103644.934475:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da950
[1:1:0712/103644.934564:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103644.934736:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1286
[1:1:0712/103644.934837:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1286 0x7f71c8f07070 0x2a83d00fd0e0 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 1256 0x7f71c8f07070 0x2a83cf3168e0 
[1:1:0712/103644.973917:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1263, 7f71cb84c881
[1:1:0712/103644.992841:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"1245 0x7f71c8f07070 0x2a83d00fa060 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103644.993014:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"1245 0x7f71c8f07070 0x2a83d00fa060 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103644.993235:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103644.993543:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103644.993656:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103644.994205:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da950
[1:1:0712/103644.994313:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103644.994504:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1292
[1:1:0712/103644.994625:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1292 0x7f71c8f07070 0x2a83cf3945e0 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 1263 0x7f71c8f07070 0x2a83cf39b760 
[1:1:0712/103645.037530:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , , document.readyState
[1:1:0712/103645.037701:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103645.170267:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1286, 7f71cb84c881
[1:1:0712/103645.189506:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"1256 0x7f71c8f07070 0x2a83cf3168e0 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103645.189675:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"1256 0x7f71c8f07070 0x2a83cf3168e0 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103645.189875:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103645.190180:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103645.190299:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103645.190866:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da950
[1:1:0712/103645.190976:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103645.191197:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1316
[1:1:0712/103645.191618:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1316 0x7f71c8f07070 0x2a83cff5e7e0 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 1286 0x7f71c8f07070 0x2a83d00fd0e0 
[1:1:0712/103645.210708:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , , document.readyState
[1:1:0712/103645.210876:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103645.276085:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1299 0x7f71cae2f2e0 0x2a83cff9f2e0 , "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103645.276648:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , , 
[1:1:0712/103645.276754:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103645.298633:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1300 0x7f71cae2f2e0 0x2a83cec01760 , "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103645.299233:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , , 
[1:1:0712/103645.299355:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103645.397303:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1292, 7f71cb84c881
[1:1:0712/103645.415826:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"1263 0x7f71c8f07070 0x2a83cf39b760 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103645.415998:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"1263 0x7f71c8f07070 0x2a83cf39b760 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103645.416206:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103645.416497:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103645.416608:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103645.417178:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da950
[1:1:0712/103645.417300:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103645.417482:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1324
[1:1:0712/103645.417599:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1324 0x7f71c8f07070 0x2a83cfd9a1e0 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 1292 0x7f71c8f07070 0x2a83cf3945e0 
[1:1:0712/103645.480110:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103645.480520:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , eventHander, (e){
            var elem = e.target;
            if(elem.tagName.toLowerCase() === 'script' && elem
[1:1:0712/103645.480627:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103645.482175:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103645.487714:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103645.488446:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103645.488731:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103645.489593:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "pageshow", "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103645.490469:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9daaf0
[1:1:0712/103645.490569:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103645.490738:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1328
[1:1:0712/103645.490832:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1328 0x7f71c8f07070 0x2a83ceee8260 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 1313 0x7f71c8f07070 0x2a83cf3287e0 
[1:1:0712/103645.491057:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "pageshow", "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103645.491646:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da9f0
[1:1:0712/103645.491767:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103645.492011:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1329
[1:1:0712/103645.492126:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1329 0x7f71c8f07070 0x2a83d00fa1e0 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 1313 0x7f71c8f07070 0x2a83cf3287e0 
[1:1:0712/103645.566969:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , , document.readyState
[1:1:0712/103645.567107:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103645.812776:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1328, 7f71cb84c881
[1:1:0712/103645.831203:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"1313 0x7f71c8f07070 0x2a83cf3287e0 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103645.831386:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"1313 0x7f71c8f07070 0x2a83cf3287e0 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103645.831599:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103645.831899:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103645.832015:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103645.832553:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da950
[1:1:0712/103645.832663:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103645.832845:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1352
[1:1:0712/103645.832942:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1352 0x7f71c8f07070 0x2a83cde63760 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 1328 0x7f71c8f07070 0x2a83ceee8260 
[1:1:0712/103645.833415:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1329, 7f71cb84c881
[1:1:0712/103645.851253:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"1313 0x7f71c8f07070 0x2a83cf3287e0 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103645.851409:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"1313 0x7f71c8f07070 0x2a83cf3287e0 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103645.851606:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103645.851873:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103645.852009:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103645.852535:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da950
[1:1:0712/103645.852620:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103645.852784:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1353
[1:1:0712/103645.852871:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1353 0x7f71c8f07070 0x2a83cf9d8360 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 1329 0x7f71c8f07070 0x2a83d00fa1e0 
[1:1:0712/103645.937940:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1346 0x7f71cae2f2e0 0x2a83cf361ce0 , "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103645.938682:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , , VideoAd.Callback([{"VideoId":"346808","Title":"【阿蛮评车】10万级爆款SUV来袭 趣评长�
[1:1:0712/103645.938813:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103646.105926:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1352, 7f71cb84c881
[1:1:0712/103646.126743:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"1328 0x7f71c8f07070 0x2a83ceee8260 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103646.126967:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"1328 0x7f71c8f07070 0x2a83ceee8260 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103646.127236:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103646.127615:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103646.127736:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103646.128441:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da950
[1:1:0712/103646.128565:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103646.128774:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1375
[1:1:0712/103646.128861:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1375 0x7f71c8f07070 0x2a83cfd98c60 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 1352 0x7f71c8f07070 0x2a83cde63760 
[1:1:0712/103646.435865:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1353, 7f71cb84c881
[1:1:0712/103646.459296:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"1329 0x7f71c8f07070 0x2a83d00fa1e0 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103646.459461:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"1329 0x7f71c8f07070 0x2a83d00fa1e0 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103646.459664:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103646.459950:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103646.460049:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103646.460581:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da950
[1:1:0712/103646.460660:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103646.460831:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1393
[1:1:0712/103646.460921:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1393 0x7f71c8f07070 0x2a83d0230560 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 1353 0x7f71c8f07070 0x2a83cf9d8360 
[1:1:0712/103646.636042:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1375, 7f71cb84c881
[1:1:0712/103646.656147:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"1352 0x7f71c8f07070 0x2a83cde63760 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103646.656296:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"1352 0x7f71c8f07070 0x2a83cde63760 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103646.656473:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103646.656733:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103646.656814:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103646.657398:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da950
[1:1:0712/103646.657506:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103646.657693:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1404
[1:1:0712/103646.657811:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1404 0x7f71c8f07070 0x2a83cf1b90e0 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 1375 0x7f71c8f07070 0x2a83cfd98c60 
[3:3:0712/103646.868463:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 2
[1:1:0712/103647.099911:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1393, 7f71cb84c881
[1:1:0712/103647.118183:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"1353 0x7f71c8f07070 0x2a83cf9d8360 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103647.118351:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"1353 0x7f71c8f07070 0x2a83cf9d8360 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103647.118562:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103647.118843:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103647.118951:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103647.119494:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da950
[1:1:0712/103647.119586:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103647.119767:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1425
[1:1:0712/103647.119871:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1425 0x7f71c8f07070 0x2a83cf68b860 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 1393 0x7f71c8f07070 0x2a83d0230560 
[1:1:0712/103647.190477:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1404, 7f71cb84c881
[1:1:0712/103647.208142:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"1375 0x7f71c8f07070 0x2a83cfd98c60 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103647.208303:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"1375 0x7f71c8f07070 0x2a83cfd98c60 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103647.208502:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103647.208785:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103647.208885:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103647.209422:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da950
[1:1:0712/103647.209528:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103647.209714:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1428
[1:1:0712/103647.209830:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1428 0x7f71c8f07070 0x2a83d01eb960 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 1404 0x7f71c8f07070 0x2a83cf1b90e0 
[1:1:0712/103647.479006:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1425, 7f71cb84c881
[1:1:0712/103647.499539:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"1393 0x7f71c8f07070 0x2a83d0230560 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103647.499723:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"1393 0x7f71c8f07070 0x2a83d0230560 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103647.499913:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103647.500187:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103647.500273:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103647.500838:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da950
[1:1:0712/103647.500925:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103647.501127:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1436
[1:1:0712/103647.501240:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1436 0x7f71c8f07070 0x2a83d02a9be0 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 1425 0x7f71c8f07070 0x2a83cf68b860 
[1:1:0712/103647.501782:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1428, 7f71cb84c881
[1:1:0712/103647.522833:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"1404 0x7f71c8f07070 0x2a83cf1b90e0 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103647.523017:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"1404 0x7f71c8f07070 0x2a83cf1b90e0 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103647.523223:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103647.523501:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103647.523600:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103647.524132:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da950
[1:1:0712/103647.524225:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103647.524393:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1437
[1:1:0712/103647.524502:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1437 0x7f71c8f07070 0x2a83cde645e0 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 1428 0x7f71c8f07070 0x2a83d01eb960 
[1:1:0712/103647.712121:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1436, 7f71cb84c881
[1:1:0712/103647.734718:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"1425 0x7f71c8f07070 0x2a83cf68b860 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103647.734885:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"1425 0x7f71c8f07070 0x2a83cf68b860 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103647.735082:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103647.735362:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103647.735464:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103647.735997:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da950
[1:1:0712/103647.736091:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103647.736284:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1456
[1:1:0712/103647.736375:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1456 0x7f71c8f07070 0x2a83d0228de0 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 1436 0x7f71c8f07070 0x2a83d02a9be0 
[1:1:0712/103647.736839:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1437, 7f71cb84c881
[1:1:0712/103647.756441:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"1428 0x7f71c8f07070 0x2a83d01eb960 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103647.756589:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"1428 0x7f71c8f07070 0x2a83d01eb960 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103647.756765:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103647.757013:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103647.757112:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103647.757637:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da950
[1:1:0712/103647.757728:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103647.757897:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1457
[1:1:0712/103647.757997:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1457 0x7f71c8f07070 0x2a83cff5b860 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 1437 0x7f71c8f07070 0x2a83cde645e0 
[1:1:0712/103647.946805:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1456, 7f71cb84c881
[1:1:0712/103647.966399:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"1436 0x7f71c8f07070 0x2a83d02a9be0 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103647.966570:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"1436 0x7f71c8f07070 0x2a83d02a9be0 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103647.966780:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103647.967055:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103647.967147:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103647.967661:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da950
[1:1:0712/103647.967769:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103647.967980:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1465
[1:1:0712/103647.968092:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1465 0x7f71c8f07070 0x2a83d01f11e0 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 1456 0x7f71c8f07070 0x2a83d0228de0 
[1:1:0712/103647.968534:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1457, 7f71cb84c881
[1:1:0712/103647.987829:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"1437 0x7f71c8f07070 0x2a83cde645e0 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103647.988005:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"1437 0x7f71c8f07070 0x2a83cde645e0 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103647.988225:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103647.988502:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103647.988613:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103647.989172:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da950
[1:1:0712/103647.989266:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103647.989439:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1467
[1:1:0712/103647.989544:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1467 0x7f71c8f07070 0x2a83cff9fd60 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 1457 0x7f71c8f07070 0x2a83cff5b860 
[1:1:0712/103648.110671:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1465, 7f71cb84c881
[1:1:0712/103648.132148:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"1456 0x7f71c8f07070 0x2a83d0228de0 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103648.132338:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"1456 0x7f71c8f07070 0x2a83d0228de0 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103648.132532:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103648.132806:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103648.132883:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103648.133498:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da950
[1:1:0712/103648.133576:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103648.133745:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1476
[1:1:0712/103648.133837:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1476 0x7f71c8f07070 0x2a83cf5e2de0 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 1465 0x7f71c8f07070 0x2a83d01f11e0 
[1:1:0712/103648.211689:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1467, 7f71cb84c881
[1:1:0712/103648.229395:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"1457 0x7f71c8f07070 0x2a83cff5b860 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103648.229565:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"1457 0x7f71c8f07070 0x2a83cff5b860 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103648.229750:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103648.230016:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103648.230112:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103648.230633:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da950
[1:1:0712/103648.230738:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103648.230918:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1482
[1:1:0712/103648.231031:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1482 0x7f71c8f07070 0x2a83cda97be0 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 1467 0x7f71c8f07070 0x2a83cff9fd60 
[1:1:0712/103648.330023:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1476, 7f71cb84c881
[1:1:0712/103648.351823:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"1465 0x7f71c8f07070 0x2a83d01f11e0 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103648.352036:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"1465 0x7f71c8f07070 0x2a83d01f11e0 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103648.352254:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103648.352579:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103648.352719:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103648.353313:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da950
[1:1:0712/103648.353428:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103648.353633:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1489
[1:1:0712/103648.353754:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1489 0x7f71c8f07070 0x2a83cdee5e60 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 1476 0x7f71c8f07070 0x2a83cf5e2de0 
[1:1:0712/103648.354458:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1482, 7f71cb84c881
[1:1:0712/103648.374474:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"1467 0x7f71c8f07070 0x2a83cff9fd60 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103648.374656:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"1467 0x7f71c8f07070 0x2a83cff9fd60 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103648.374855:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103648.375127:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103648.375224:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103648.375739:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da950
[1:1:0712/103648.375827:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103648.376003:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1492
[1:1:0712/103648.376092:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1492 0x7f71c8f07070 0x2a83cddeabe0 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 1482 0x7f71c8f07070 0x2a83cda97be0 
[1:1:0712/103648.492502:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1489, 7f71cb84c881
[1:1:0712/103648.515888:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"1476 0x7f71c8f07070 0x2a83cf5e2de0 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103648.516089:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"1476 0x7f71c8f07070 0x2a83cf5e2de0 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103648.516298:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103648.516579:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103648.516679:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103648.518507:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da950
[1:1:0712/103648.518619:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103648.518815:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1501
[1:1:0712/103648.518934:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1501 0x7f71c8f07070 0x2a83d023a560 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 1489 0x7f71c8f07070 0x2a83cdee5e60 
[1:1:0712/103648.540263:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1492, 7f71cb84c881
[1:1:0712/103648.562499:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"1482 0x7f71c8f07070 0x2a83cda97be0 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103648.562707:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"1482 0x7f71c8f07070 0x2a83cda97be0 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103648.562951:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103648.563354:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103648.563467:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103648.564056:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da950
[1:1:0712/103648.564155:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103648.564347:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1504
[1:1:0712/103648.564458:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1504 0x7f71c8f07070 0x2a83d0240960 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 1492 0x7f71c8f07070 0x2a83cddeabe0 
[1:1:0712/103648.622978:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1501, 7f71cb84c881
[1:1:0712/103648.641217:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"1489 0x7f71c8f07070 0x2a83cdee5e60 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103648.641372:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"1489 0x7f71c8f07070 0x2a83cdee5e60 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103648.641561:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103648.641833:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103648.641929:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103648.642479:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da950
[1:1:0712/103648.642582:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103648.642764:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1510
[1:1:0712/103648.642877:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1510 0x7f71c8f07070 0x2a83cf394560 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 1501 0x7f71c8f07070 0x2a83d023a560 
[1:1:0712/103648.681006:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1504, 7f71cb84c881
[1:1:0712/103648.701235:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"1492 0x7f71c8f07070 0x2a83cddeabe0 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103648.701412:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"1492 0x7f71c8f07070 0x2a83cddeabe0 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103648.701631:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103648.701924:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103648.702037:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103648.702601:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da950
[1:1:0712/103648.702709:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103648.702899:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1514
[1:1:0712/103648.703017:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1514 0x7f71c8f07070 0x2a83cfd8ace0 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 1504 0x7f71c8f07070 0x2a83d0240960 
[1:1:0712/103648.787738:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1510, 7f71cb84c881
[1:1:0712/103648.808529:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"1501 0x7f71c8f07070 0x2a83d023a560 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103648.808696:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"1501 0x7f71c8f07070 0x2a83d023a560 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103648.808890:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103648.809202:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103648.809302:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103648.809866:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da950
[1:1:0712/103648.809956:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103648.810130:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1521
[1:1:0712/103648.810232:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1521 0x7f71c8f07070 0x2a83cfe233e0 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 1510 0x7f71c8f07070 0x2a83cf394560 
[1:1:0712/103648.810863:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1514, 7f71cb84c881
[1:1:0712/103648.830643:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"1504 0x7f71c8f07070 0x2a83d0240960 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103648.830792:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"1504 0x7f71c8f07070 0x2a83d0240960 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103648.830990:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103648.831249:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103648.831346:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103648.831866:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da950
[1:1:0712/103648.831958:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103648.832117:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1524
[1:1:0712/103648.832205:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1524 0x7f71c8f07070 0x2a83cfa21be0 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 1514 0x7f71c8f07070 0x2a83cfd8ace0 
[1:1:0712/103648.916914:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1521, 7f71cb84c881
[1:1:0712/103648.940572:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"1510 0x7f71c8f07070 0x2a83cf394560 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103648.940774:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"1510 0x7f71c8f07070 0x2a83cf394560 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103648.940963:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103648.941270:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103648.941385:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103648.941939:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da950
[1:1:0712/103648.942047:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103648.942242:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1529
[1:1:0712/103648.942361:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1529 0x7f71c8f07070 0x2a83ced99260 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 1521 0x7f71c8f07070 0x2a83cfe233e0 
[1:1:0712/103648.942893:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1524, 7f71cb84c881
[1:1:0712/103648.964047:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"1514 0x7f71c8f07070 0x2a83cfd8ace0 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103648.964258:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"1514 0x7f71c8f07070 0x2a83cfd8ace0 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103648.964471:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103648.964763:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103648.964857:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103648.965419:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da950
[1:1:0712/103648.965515:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103648.965692:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1531
[1:1:0712/103648.965797:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1531 0x7f71c8f07070 0x2a83cf58b560 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 1524 0x7f71c8f07070 0x2a83cfa21be0 
[1:1:0712/103649.063284:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1529, 7f71cb84c881
[1:1:0712/103649.081477:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"1521 0x7f71c8f07070 0x2a83cfe233e0 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103649.081686:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"1521 0x7f71c8f07070 0x2a83cfe233e0 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103649.081938:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103649.082277:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103649.082429:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103649.083022:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da950
[1:1:0712/103649.083137:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103649.083367:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1533
[1:1:0712/103649.083487:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1533 0x7f71c8f07070 0x2a83cd986de0 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 1529 0x7f71c8f07070 0x2a83ced99260 
[1:1:0712/103649.083984:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1531, 7f71cb84c881
[1:1:0712/103649.103604:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"1524 0x7f71c8f07070 0x2a83cfa21be0 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103649.103770:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"1524 0x7f71c8f07070 0x2a83cfa21be0 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103649.103973:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103649.104260:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103649.104388:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103649.104915:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da950
[1:1:0712/103649.104999:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103649.105164:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1535
[1:1:0712/103649.105282:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1535 0x7f71c8f07070 0x2a83cdde5ae0 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 1531 0x7f71c8f07070 0x2a83cf58b560 
[1:1:0712/103649.205273:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1533, 7f71cb84c881
[1:1:0712/103649.224327:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"1529 0x7f71c8f07070 0x2a83ced99260 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103649.224515:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"1529 0x7f71c8f07070 0x2a83ced99260 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103649.224723:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103649.224974:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103649.225055:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103649.225637:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da950
[1:1:0712/103649.225776:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103649.226024:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1537
[1:1:0712/103649.226178:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1537 0x7f71c8f07070 0x2a83d02286e0 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 1533 0x7f71c8f07070 0x2a83cd986de0 
[1:1:0712/103649.226709:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1535, 7f71cb84c881
[1:1:0712/103649.245386:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"1531 0x7f71c8f07070 0x2a83cf58b560 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103649.245578:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"1531 0x7f71c8f07070 0x2a83cf58b560 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103649.245775:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103649.246059:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103649.246168:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103649.246802:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da950
[1:1:0712/103649.246903:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103649.247084:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1539
[1:1:0712/103649.247193:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1539 0x7f71c8f07070 0x2a83d01eb360 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 1535 0x7f71c8f07070 0x2a83cdde5ae0 
[1:1:0712/103649.350006:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1537, 7f71cb84c881
[1:1:0712/103649.371285:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"1533 0x7f71c8f07070 0x2a83cd986de0 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103649.371531:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"1533 0x7f71c8f07070 0x2a83cd986de0 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103649.371797:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103649.372139:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103649.372284:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103649.372858:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da950
[1:1:0712/103649.372944:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103649.373147:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1542
[1:1:0712/103649.373268:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1542 0x7f71c8f07070 0x2a83ced4c560 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 1537 0x7f71c8f07070 0x2a83d02286e0 
[1:1:0712/103649.373777:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1539, 7f71cb84c881
[1:1:0712/103649.396391:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"1535 0x7f71c8f07070 0x2a83cdde5ae0 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103649.396584:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"1535 0x7f71c8f07070 0x2a83cdde5ae0 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103649.396782:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103649.397079:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103649.397207:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103649.397789:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da950
[1:1:0712/103649.397901:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103649.398104:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1543
[1:1:0712/103649.398229:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1543 0x7f71c8f07070 0x2a83cde28860 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 1539 0x7f71c8f07070 0x2a83d01eb360 
[1:1:0712/103649.494280:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1542, 7f71cb84c881
[1:1:0712/103649.513693:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"1537 0x7f71c8f07070 0x2a83d02286e0 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103649.513902:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"1537 0x7f71c8f07070 0x2a83d02286e0 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103649.514156:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103649.514499:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103649.514656:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103649.515265:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da950
[1:1:0712/103649.515374:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103649.515566:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1545
[1:1:0712/103649.515673:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1545 0x7f71c8f07070 0x2a83cfa267e0 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 1542 0x7f71c8f07070 0x2a83ced4c560 
[1:1:0712/103649.516150:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1543, 7f71cb84c881
[1:1:0712/103649.535944:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"1539 0x7f71c8f07070 0x2a83d01eb360 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103649.536106:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"1539 0x7f71c8f07070 0x2a83d01eb360 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103649.536330:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103649.536600:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103649.536707:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103649.537264:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da950
[1:1:0712/103649.537368:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103649.537554:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1547
[1:1:0712/103649.537671:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1547 0x7f71c8f07070 0x2a83cfd63160 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 1543 0x7f71c8f07070 0x2a83cde28860 
[1:1:0712/103649.636214:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1545, 7f71cb84c881
[1:1:0712/103649.654771:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"1542 0x7f71c8f07070 0x2a83ced4c560 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103649.654969:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"1542 0x7f71c8f07070 0x2a83ced4c560 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103649.655213:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103649.655540:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103649.655687:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103649.656238:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da950
[1:1:0712/103649.656341:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103649.656525:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1550
[1:1:0712/103649.656627:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1550 0x7f71c8f07070 0x2a83d02a94e0 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 1545 0x7f71c8f07070 0x2a83cfa267e0 
[1:1:0712/103649.657139:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1547, 7f71cb84c881
[1:1:0712/103649.676229:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"1543 0x7f71c8f07070 0x2a83cde28860 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103649.676392:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"1543 0x7f71c8f07070 0x2a83cde28860 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103649.676585:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103649.676833:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103649.676923:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103649.677437:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da950
[1:1:0712/103649.677539:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103649.677716:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1552
[1:1:0712/103649.677828:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1552 0x7f71c8f07070 0x2a83cf9e3f60 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 1547 0x7f71c8f07070 0x2a83cfd63160 
[1:1:0712/103649.779759:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1550, 7f71cb84c881
[1:1:0712/103649.801800:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"1545 0x7f71c8f07070 0x2a83cfa267e0 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103649.802074:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"1545 0x7f71c8f07070 0x2a83cfa267e0 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103649.802352:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103649.802700:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103649.802858:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103649.803511:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da950
[1:1:0712/103649.803621:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103649.803820:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1555
[1:1:0712/103649.803944:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1555 0x7f71c8f07070 0x2a83cf17bae0 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 1550 0x7f71c8f07070 0x2a83d02a94e0 
[1:1:0712/103649.804432:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1552, 7f71cb84c881
[1:1:0712/103649.827183:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"1547 0x7f71c8f07070 0x2a83cfd63160 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103649.827379:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"1547 0x7f71c8f07070 0x2a83cfd63160 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103649.827636:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103649.827911:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103649.828013:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103649.828544:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da950
[1:1:0712/103649.828626:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103649.828791:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1556
[1:1:0712/103649.828882:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1556 0x7f71c8f07070 0x2a83cfd63960 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 1552 0x7f71c8f07070 0x2a83cf9e3f60 
[1:1:0712/103649.924800:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1555, 7f71cb84c881
[1:1:0712/103649.944090:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"1550 0x7f71c8f07070 0x2a83d02a94e0 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103649.944303:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"1550 0x7f71c8f07070 0x2a83d02a94e0 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103649.944515:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103649.944798:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103649.944889:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103649.945420:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da950
[1:1:0712/103649.945566:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103649.945804:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1558
[1:1:0712/103649.945925:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1558 0x7f71c8f07070 0x2a83cf9f2360 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 1555 0x7f71c8f07070 0x2a83cf17bae0 
[1:1:0712/103649.946426:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1556, 7f71cb84c881
[1:1:0712/103649.966085:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"1552 0x7f71c8f07070 0x2a83cf9e3f60 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103649.966257:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"1552 0x7f71c8f07070 0x2a83cf9e3f60 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103649.966457:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103649.966724:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103649.966837:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103649.967376:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da950
[1:1:0712/103649.967484:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103649.967710:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1560
[1:1:0712/103649.967828:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1560 0x7f71c8f07070 0x2a83d022bb60 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 1556 0x7f71c8f07070 0x2a83cfd63960 
[1:1:0712/103650.066606:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1558, 7f71cb84c881
[1:1:0712/103650.085697:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"1555 0x7f71c8f07070 0x2a83cf17bae0 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103650.085899:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"1555 0x7f71c8f07070 0x2a83cf17bae0 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103650.086145:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103650.086473:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103650.086620:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103650.087223:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da950
[1:1:0712/103650.087319:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103650.087497:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1562
[1:1:0712/103650.087602:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1562 0x7f71c8f07070 0x2a83cec04960 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 1558 0x7f71c8f07070 0x2a83cf9f2360 
[1:1:0712/103650.088064:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1560, 7f71cb84c881
[1:1:0712/103650.107320:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"1556 0x7f71c8f07070 0x2a83cfd63960 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103650.107492:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"1556 0x7f71c8f07070 0x2a83cfd63960 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103650.107710:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103650.107972:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103650.108079:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103650.108642:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da950
[1:1:0712/103650.108736:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103650.108901:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1564
[1:1:0712/103650.108992:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1564 0x7f71c8f07070 0x2a83cfbb53e0 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 1560 0x7f71c8f07070 0x2a83d022bb60 
[1:1:0712/103650.208421:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1562, 7f71cb84c881
[1:1:0712/103650.229973:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"1558 0x7f71c8f07070 0x2a83cf9f2360 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103650.230226:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"1558 0x7f71c8f07070 0x2a83cf9f2360 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103650.230506:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103650.230868:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103650.231031:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103650.231711:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da950
[1:1:0712/103650.231815:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103650.232015:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1566
[1:1:0712/103650.232135:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1566 0x7f71c8f07070 0x2a83cf178660 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 1562 0x7f71c8f07070 0x2a83cec04960 
[1:1:0712/103650.232663:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1564, 7f71cb84c881
[1:1:0712/103650.255005:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"1560 0x7f71c8f07070 0x2a83d022bb60 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103650.255214:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"1560 0x7f71c8f07070 0x2a83d022bb60 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103650.255447:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103650.255747:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103650.255862:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103650.256428:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da950
[1:1:0712/103650.256535:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103650.256716:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1568
[1:1:0712/103650.256823:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1568 0x7f71c8f07070 0x2a83cda37960 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 1564 0x7f71c8f07070 0x2a83cfbb53e0 
[1:1:0712/103650.352731:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1566, 7f71cb84c881
[1:1:0712/103650.371885:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"1562 0x7f71c8f07070 0x2a83cec04960 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103650.372089:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"1562 0x7f71c8f07070 0x2a83cec04960 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103650.372322:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103650.372634:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103650.372732:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103650.373288:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da950
[1:1:0712/103650.373384:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103650.373564:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1570
[1:1:0712/103650.373668:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1570 0x7f71c8f07070 0x2a83cff5ec60 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 1566 0x7f71c8f07070 0x2a83cf178660 
[1:1:0712/103650.374148:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1568, 7f71cb84c881
[1:1:0712/103650.393155:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"1564 0x7f71c8f07070 0x2a83cfbb53e0 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103650.393306:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"1564 0x7f71c8f07070 0x2a83cfbb53e0 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103650.393505:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103650.393771:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103650.393889:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103650.394446:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da950
[1:1:0712/103650.394540:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103650.394714:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1572
[1:1:0712/103650.394819:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1572 0x7f71c8f07070 0x2a83cde640e0 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 1568 0x7f71c8f07070 0x2a83cda37960 
[1:1:0712/103650.496227:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1570, 7f71cb84c881
[1:1:0712/103650.519149:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"1566 0x7f71c8f07070 0x2a83cf178660 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103650.519389:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"1566 0x7f71c8f07070 0x2a83cf178660 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103650.519650:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103650.519989:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103650.520152:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103650.520750:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da950
[1:1:0712/103650.520853:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103650.521047:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1575
[1:1:0712/103650.521169:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1575 0x7f71c8f07070 0x2a83cefb86e0 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 1570 0x7f71c8f07070 0x2a83cff5ec60 
[1:1:0712/103650.521711:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1572, 7f71cb84c881
[1:1:0712/103650.543035:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"083408f42860","ptid":"1568 0x7f71c8f07070 0x2a83cda37960 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103650.543228:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baa.bitauto.com/","ptid":"1568 0x7f71c8f07070 0x2a83cda37960 ","rf":"5:3_http://baa.bitauto.com/"}
[1:1:0712/103650.543448:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baa.bitauto.com/cs55/thread-15796781.html"
[1:1:0712/103650.543741:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baa.bitauto.com/, 083408f42860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103650.543834:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baa.bitauto.com/cs55/thread-15796781.html", "bitauto.com", 3, 1, , , 0
[1:1:0712/103650.544421:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3092138629c8, 0x2a83cd9da950
[1:1:0712/103650.544519:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baa.bitauto.com/cs55/thread-15796781.html", 100
[1:1:0712/103650.544693:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baa.bitauto.com/, 1576
[1:1:0712/103650.544788:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1576 0x7f71c8f07070 0x2a83ce07b4e0 , 5:3_http://baa.bitauto.com/, 1, -5:3_http://baa.bitauto.com/, 1572 0x7f71c8f07070 0x2a83cde640e0 
