[0712/103430.366740:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/103430.366991:INFO:switcher_clone.cc(787)] backtrace rip is 7f426ef0b891
[0712/103430.937199:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/103430.937473:INFO:switcher_clone.cc(787)] backtrace rip is 7f3a18c39891
[1:1:0712/103430.941683:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/103430.941870:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/103430.944772:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[28334:28334:0712/103431.736459:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/fcad320b-3b32-4913-8160-8d5042688910
[0712/103431.833786:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/103431.834111:INFO:switcher_clone.cc(787)] backtrace rip is 7f437a1be891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[28367:28367:0712/103432.046367:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=28367
[28380:28380:0712/103432.046752:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=28380
[28334:28334:0712/103432.106652:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[28334:28365:0712/103432.107046:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/103432.107162:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/103432.107318:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/103432.107634:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/103432.107749:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/103432.115953:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x134bf70c, 1
[1:1:0712/103432.116194:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x30420dbb, 0
[1:1:0712/103432.117755:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x134b862b, 3
[1:1:0712/103432.117854:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0xa6d7d36, 2
[1:1:0712/103432.117957:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffbb0d4230 0cfffffff74b13 367d6d0a 2bffffff864b13 , 10104, 4
[1:1:0712/103432.118688:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[28334:28365:0712/103432.118817:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�B0�K6}m
+�K���
[28334:28365:0712/103432.118857:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �B0�K6}m
+�K8���
[28334:28365:0712/103432.119012:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[28334:28365:0712/103432.119042:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 28388, 4, bb0d4230 0cf74b13 367d6d0a 2b864b13 
[1:1:0712/103432.119298:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f3a16e730a0, 3
[1:1:0712/103432.119406:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f3a16fff080, 2
[1:1:0712/103432.119488:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f3a00cc1d20, -2
[1:1:0712/103432.127422:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/103432.127881:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal a6d7d36
[1:1:0712/103432.128309:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal a6d7d36
[1:1:0712/103432.129070:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal a6d7d36
[1:1:0712/103432.129632:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal a6d7d36
[1:1:0712/103432.129749:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal a6d7d36
[1:1:0712/103432.129870:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal a6d7d36
[1:1:0712/103432.129984:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal a6d7d36
[1:1:0712/103432.130246:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal a6d7d36
[1:1:0712/103432.130397:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f3a18c397ba
[1:1:0712/103432.130480:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f3a18c30def, 7f3a18c3977a, 7f3a18c3b0cf
[1:1:0712/103432.132120:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal a6d7d36
[1:1:0712/103432.132294:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal a6d7d36
[1:1:0712/103432.132588:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal a6d7d36
[1:1:0712/103432.133382:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal a6d7d36
[1:1:0712/103432.133493:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal a6d7d36
[1:1:0712/103432.133580:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal a6d7d36
[1:1:0712/103432.133681:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal a6d7d36
[1:1:0712/103432.134196:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal a6d7d36
[1:1:0712/103432.134386:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f3a18c397ba
[1:1:0712/103432.134479:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f3a18c30def, 7f3a18c3977a, 7f3a18c3b0cf
[1:1:0712/103432.137198:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/103432.137426:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/103432.137525:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffcc60371d8, 0x7ffcc6037158)
[1:1:0712/103432.144230:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/103432.147228:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[28334:28334:0712/103432.601957:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[28334:28334:0712/103432.602480:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[28334:28347:0712/103432.610470:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[28334:28347:0712/103432.610533:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[28334:28334:0712/103432.610548:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[28334:28334:0712/103432.610590:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[28334:28334:0712/103432.610651:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,28388, 4
[1:7:0712/103432.616804:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[28334:28359:0712/103432.683703:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/103432.663004:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x1a5a70903220
[1:1:0712/103432.703646:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/103432.919824:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[28334:28334:0712/103433.666570:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[28334:28334:0712/103433.666701:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/103433.683422:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/103433.685161:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/103434.149095:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 330407e41f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/103434.149335:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/103434.155938:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 330407e41f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/103434.156149:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/103434.182709:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/103434.282621:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/103434.282794:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/103434.423665:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/103434.426170:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 330407e41f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/103434.426303:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/103434.438103:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 356, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/103434.441014:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 330407e41f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/103434.441171:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/103434.445026:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[28334:28334:0712/103434.445717:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/103434.446758:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x1a5a70901e20
[1:1:0712/103434.446878:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[28334:28334:0712/103434.448138:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[28334:28334:0712/103434.459466:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[28334:28334:0712/103434.459544:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/103434.479802:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/103434.842108:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 418 0x7f3a0289c2e0 0x1a5a70addde0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/103434.842838:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 330407e41f78, , , var configData = {"googleBaseUrl":"https://www.google.com.hk/","isAccessibleBrowser":false,"isGoogle
[1:1:0712/103434.842981:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/103434.843555:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[28334:28334:0712/103434.872263:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/103434.873468:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x1a5a70902820
[1:1:0712/103434.873618:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[28334:28334:0712/103434.875036:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/103434.881385:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/103434.881546:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[28334:28334:0712/103434.887049:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[28334:28334:0712/103434.891582:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[28334:28334:0712/103434.892608:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[28334:28347:0712/103434.897631:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[28334:28347:0712/103434.897691:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[28334:28334:0712/103434.897722:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[28334:28334:0712/103434.897764:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[28334:28334:0712/103434.897829:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,28388, 4
[1:7:0712/103434.899460:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/103435.203849:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/103435.349417:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 469 0x7f3a0289c2e0 0x1a5a70d17fe0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/103435.350010:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 330407e41f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/103435.350183:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/103435.350560:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[28334:28334:0712/103435.490789:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[28334:28365:0712/103435.491080:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/103435.491223:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/103435.491637:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/103435.491870:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/103435.492375:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/103435.497173:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x2b8cffc4, 1
[1:1:0712/103435.497399:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x3d483e2e, 0
[1:1:0712/103435.497556:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x24debc79, 3
[1:1:0712/103435.497691:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x2254606, 2
[1:1:0712/103435.497809:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 2e3e483d ffffffc4ffffffffffffff8c2b 06462502 79ffffffbcffffffde24 , 10104, 5
[1:1:0712/103435.498578:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[28334:28365:0712/103435.498738:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING.>H=���+F%y��$���
[28334:28365:0712/103435.498789:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is .>H=���+F%y��$U���
[1:1:0712/103435.498847:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f3a16e730a0, 3
[28334:28365:0712/103435.498934:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 28429, 5, 2e3e483d c4ff8c2b 06462502 79bcde24 
[1:1:0712/103435.498931:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f3a16fff080, 2
[1:1:0712/103435.499039:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f3a00cc1d20, -2
[28334:28334:0712/103435.506686:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[28334:28334:0712/103435.506751:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/103435.507433:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/103435.508216:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/103435.508375:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2254606
[1:1:0712/103435.508571:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2254606
[1:1:0712/103435.508861:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2254606
[1:1:0712/103435.509376:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2254606
[1:1:0712/103435.509478:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2254606
[1:1:0712/103435.509569:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2254606
[1:1:0712/103435.509657:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2254606
[1:1:0712/103435.509905:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2254606
[1:1:0712/103435.510036:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f3a18c397ba
[1:1:0712/103435.510108:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f3a18c30def, 7f3a18c3977a, 7f3a18c3b0cf
[1:1:0712/103435.511833:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2254606
[1:1:0712/103435.511998:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2254606
[1:1:0712/103435.512291:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2254606
[1:1:0712/103435.513074:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2254606
[1:1:0712/103435.513180:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2254606
[1:1:0712/103435.513275:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2254606
[1:1:0712/103435.513375:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2254606
[1:1:0712/103435.513874:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2254606
[1:1:0712/103435.514037:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f3a18c397ba
[1:1:0712/103435.514109:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f3a18c30def, 7f3a18c3977a, 7f3a18c3b0cf
[1:1:0712/103435.516809:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/103435.517046:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/103435.517126:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffcc60371d8, 0x7ffcc6037158)
[1:1:0712/103435.523098:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/103435.525407:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/103435.625668:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x1a5a7089b220
[1:1:0712/103435.625883:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/103435.742624:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[28334:28334:0712/103435.768520:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[28334:28334:0712/103435.770606:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[28334:28347:0712/103435.784163:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[28334:28347:0712/103435.784229:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[28334:28334:0712/103435.784379:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://car.m.yiche.com/
[28334:28334:0712/103435.784422:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://car.m.yiche.com/, http://car.m.yiche.com/maiteng/, 1
[28334:28334:0712/103435.784485:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://car.m.yiche.com/, HTTP/1.1 200 OK Server: Tengine Date: Fri, 12 Jul 2019 02:22:00 GMT Content-Type: text/html; charset=utf-8 Content-Length: 36905 Connection: keep-alive Vary: Accept-Encoding Cache-Control: public, max-age=600 Expires: Fri, 12 Jul 2019 02:36:11 GMT Vary: Accept-Encoding X-Cache: HIT from QD-6401.cdn.bitautotech.com Content-Encoding: gzip Age: 506 X-Cache: HIT from YHGYD-3501.cdn.bitautotech.com  ,28429, 5
[1:7:0712/103435.786890:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/103435.800128:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://car.m.yiche.com/
[28334:28334:0712/103435.857563:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://car.m.yiche.com/, http://car.m.yiche.com/, 1
[28334:28334:0712/103435.857643:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://car.m.yiche.com/, http://car.m.yiche.com
[1:1:0712/103435.870135:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/103435.913266:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/103435.932343:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/103435.946244:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/103435.946437:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://car.m.yiche.com/maiteng/"
[1:1:0712/103436.011421:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/103436.011606:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/103436.046019:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/103436.412233:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 169 0x7f3a00974070 0x1a5a70a323e0 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103436.413077:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , , var bit_IpRegion = '218.241.135.34:北京市;201,北京,beijing';
var bit_locationInfo = {cityId:'2
[1:1:0712/103436.413257:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103436.416893:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 169 0x7f3a00974070 0x1a5a70a323e0 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103436.417786:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/103436.513069:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 169 0x7f3a00974070 0x1a5a70a323e0 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103436.596158:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.182438, 132, 1
[1:1:0712/103436.596404:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/103436.826808:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/103436.826984:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://car.m.yiche.com/maiteng/"
[1:1:0712/103436.830746:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 201 0x7f3a00974070 0x1a5a70c5ef60 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103436.839748:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , , /*! jQuery v@1.8.0 jquery.com | jquery.org/license */
(function(a,b){function G(a){var b=F[a]={};re
[1:1:0712/103436.839908:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103436.944323:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 201 0x7f3a00974070 0x1a5a70c5ef60 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103436.945784:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 201 0x7f3a00974070 0x1a5a70c5ef60 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103436.951440:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.124457, 98, 1
[1:1:0712/103436.951610:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/103437.792772:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/103437.792967:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://car.m.yiche.com/maiteng/"
[1:1:0712/103437.794405:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 307 0x7f3a00974070 0x1a5a70c866e0 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103437.795022:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , , 
                    if (typeof (bitLoadScript) == "undefined") {
                        bitLoadScr
[1:1:0712/103437.795183:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103437.811054:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.017087, 225, 1
[1:1:0712/103437.811216:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/103437.889306:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: the server responded with a status of 403 (Forbidden)","http://img3.bitautoimg.com/autoalbum/http://img2.bitautoimg.com/bitauto/2019/06/05/e8825996-8eab-4b95-a01f-f73777eb65c0_630_w0_6755854_4.jpg"
[1:1:0712/103438.528184:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/103438.528361:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://car.m.yiche.com/maiteng/"
[1:1:0712/103438.529573:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 390 0x7f3a00974070 0x1a5a70a02ee0 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103438.530044:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , , var LuxuryPlusAdv={FillId:"luxuryPlusAdvDiv",GetPromotionNews:function(n,t){arguments.length<2||$.aj
[1:1:0712/103438.530166:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103438.531457:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 390 0x7f3a00974070 0x1a5a70a02ee0 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103438.560176:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 390 0x7f3a00974070 0x1a5a70a02ee0 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103438.562548:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 390 0x7f3a00974070 0x1a5a70a02ee0 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103438.699087:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 390 0x7f3a00974070 0x1a5a70a02ee0 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103438.705621:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 390 0x7f3a00974070 0x1a5a70a02ee0 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103438.718401:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.190027, 369, 1
[1:1:0712/103438.718568:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/103439.111196:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 435 0x7f3a0289c2e0 0x1a5a70bd3860 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103439.111923:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , , var CarNavForWireless =
{
	DivID: "m-car-nav", 		// 页面导航元素Div ID
	CurrentTagIndex: -1
[1:1:0712/103439.112047:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103439.112599:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://car.m.yiche.com/maiteng/"
[1:1:0712/103439.516762:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/103439.516927:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://car.m.yiche.com/maiteng/"
[1:1:0712/103439.517371:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 476 0x7f3a00974070 0x1a5a709f8960 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103439.517838:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , , 
            showNewsInsCode('f327fc17-f1ad-4fcd-91d7-03e42c9b72b4', 'f31814e7-225c-4e92-8ea9-c28763
[1:1:0712/103439.517954:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103439.528491:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.011517, 178, 1
[1:1:0712/103439.528630:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/103439.591526:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 487 0x7f3a0289c2e0 0x1a5a70bbb560 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103439.592075:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , , success_LuxuryPlusAdv_JsonpCallback([{"NewsId":319085684,"VendorId":100008403,"NewsShortTitle":"华�
[1:1:0712/103439.592200:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103439.592644:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://car.m.yiche.com/maiteng/"
[1:1:0712/103439.898854:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/103439.899067:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://car.m.yiche.com/maiteng/"
[1:1:0712/103439.899720:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 507 0x7f3a00974070 0x1a5a70741c60 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103439.900913:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , , 



            $.ajax({
                url: "http://mapi.yiche.com/web_app/api/v1/review/get_car_r
[1:1:0712/103439.901037:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103439.946019:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0469439, 51, 1
[1:1:0712/103439.946177:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/103440.182232:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/103440.182380:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://car.m.yiche.com/maiteng/"
[1:1:0712/103440.182854:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 531 0x7f3a00974070 0x1a5a70f61ee0 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103440.183450:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , , 
                             var loadPingCe = function () {
                                    $.a
[1:1:0712/103440.183538:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103440.211198:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0287881, 65, 1
[1:1:0712/103440.211358:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/103440.294398:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://car.m.yiche.com/maiteng/"
[1:1:0712/103440.294809:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , d, (a,e){var h,j,k,l,m;try{if(d&&(e||i.readyState===4)){d=b,g&&(i.onreadystatechange=p.noop,cI&&delete 
[1:1:0712/103440.294935:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103440.295556:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://car.m.yiche.com/maiteng/"
[1:1:0712/103440.296912:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://car.m.yiche.com/maiteng/"
[1:1:0712/103440.297288:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1d6357e37b90
[1:1:0712/103440.353828:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://car.m.yiche.com/maiteng/"
[1:1:0712/103440.354188:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , d, (a,e){var h,j,k,l,m;try{if(d&&(e||i.readyState===4)){d=b,g&&(i.onreadystatechange=p.noop,cI&&delete 
[1:1:0712/103440.354308:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103440.355681:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://car.m.yiche.com/maiteng/"
[1:1:0712/103440.426298:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/103440.426443:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://car.m.yiche.com/maiteng/"
[1:1:0712/103440.426867:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 551 0x7f3a00974070 0x1a5a70e42960 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103440.427344:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , , showNewsInsCode('4b61d3eb-4afc-4a8d-9d72-e4898c983feb', 'f599d929-c9d6-48db-9747-4e48e5e51a24', '15b
[1:1:0712/103440.427463:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103440.459154:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0326898, 559, 1
[1:1:0712/103440.459310:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/103440.548649:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://car.m.yiche.com/maiteng/"
[1:1:0712/103440.549128:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , d, (a,e){var h,j,k,l,m;try{if(d&&(e||i.readyState===4)){d=b,g&&(i.onreadystatechange=p.noop,cI&&delete 
[1:1:0712/103440.549247:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103440.549458:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1d6357e37b90
[1:1:0712/103440.884311:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/103441.120992:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/103441.121142:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://car.m.yiche.com/maiteng/"
[1:1:0712/103441.121580:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 594 0x7f3a00974070 0x1a5a70f6dae0 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103441.122115:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , , 
            var CarCommonBSID = "8"; //大数据组统计用
            var CarCommonCBID = "10015
[1:1:0712/103441.122217:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103441.125002:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 594 0x7f3a00974070 0x1a5a70f6dae0 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103441.149216:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 597 0x7f3a0289c2e0 0x1a5a70c81ee0 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103441.150103:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , , success_jsonpCallback_getEntranceData({"ImageUrl":"http://image.bitautoimg.com/cargroup/carpc/report
[1:1:0712/103441.150213:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103441.150717:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://car.m.yiche.com/maiteng/"
[1:1:0712/103441.925877:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 650, "http://car.m.yiche.com/maiteng/"
[1:1:0712/103441.926773:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , , document.write("<div class='tt-first'><h3>经销商</h3><a href='javascript:;' id='m-dealer-city' da
[1:1:0712/103441.926905:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103442.390663:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 682, "http://car.m.yiche.com/maiteng/"
[1:1:0712/103442.391954:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , , var CsModel={MActiveUrl:"//huodong.yiche.com/m/detail/{activeid}?csid={csid}&osp=signClick",DefaultM
[1:1:0712/103442.392209:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103442.533865:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/103442.722362:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/103442.722531:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://car.m.yiche.com/maiteng/"
[1:1:0712/103442.722954:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 701 0x7f3a00974070 0x1a5a70f58560 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103442.723429:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , , CsModel.AddTimeRobActiveTag(GlobalSummaryConfig.SerialId,'mcsreview');
[1:1:0712/103442.723540:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103442.754794:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 701 0x7f3a00974070 0x1a5a70f58560 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103442.756170:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 701 0x7f3a00974070 0x1a5a70f58560 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103442.763694:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 701 0x7f3a00974070 0x1a5a70f58560 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103442.768960:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0464361, 97, 1
[1:1:0712/103442.769148:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/103443.108489:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/103443.108664:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://car.m.yiche.com/maiteng/"
[1:1:0712/103443.109201:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 729 0x7f3a00974070 0x1a5a70a1ede0 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103443.110004:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , , 
            //如果有广告数据 第六位置使用广告数据 需要排重
            $.ajax(
[1:1:0712/103443.110132:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103443.133162:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x1d2e65ca29c8, 0x1a5a7072e1a8
[1:1:0712/103443.133313:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.m.yiche.com/maiteng/", 5000
[1:1:0712/103443.133501:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.m.yiche.com/, 737
[1:1:0712/103443.133613:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 737 0x7f3a00974070 0x1a5a708700e0 , 5:3_http://car.m.yiche.com/, 1, -5:3_http://car.m.yiche.com/, 729 0x7f3a00974070 0x1a5a70a1ede0 
[1:1:0712/103443.146201:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0374999, 87, 1
[1:1:0712/103443.146356:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/103443.370397:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/103443.371818:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://car.m.yiche.com/maiteng/"
[1:1:0712/103443.372294:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 746 0x7f3a00974070 0x1a5a710c7c60 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103443.372770:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , , 
            showNewsInsCode('893f9a91-0f1e-484c-8263-37d815e64d1b', '09dc099f-5b52-4a70-8edd-faa0d7
[1:1:0712/103443.372873:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103443.378984:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 746 0x7f3a00974070 0x1a5a710c7c60 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103443.380424:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 746 0x7f3a00974070 0x1a5a710c7c60 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103443.382157:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 746 0x7f3a00974070 0x1a5a710c7c60 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103443.383607:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 746 0x7f3a00974070 0x1a5a710c7c60 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103443.389149:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0172992, 69, 1
[1:1:0712/103443.389303:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/103443.446344:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 751 0x7f3a0289c2e0 0x1a5a710d88e0 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103443.446948:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , , jQuery18005516273126226581_1562898876926({"result":1,"title":"小易购车-抢优惠","description":
[1:1:0712/103443.447048:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103443.447407:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://car.m.yiche.com/maiteng/"
[1:1:0712/103443.527450:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/103443.527634:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[28334:28334:0712/103443.656450:INFO:CONSOLE(1019)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://m.h5.qiche4s.cn/priceapiv2/ajax/InitData.ashx?action=cardealerlist&brandid=1909&citycode=201, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://car.m.yiche.com/maiteng/ (1019)
[28334:28334:0712/103443.668928:INFO:CONSOLE(1019)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://m.h5.qiche4s.cn/priceapiv2/ajax/InitData.ashx?action=cardealerlist&brandid=1909&citycode=201, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://car.m.yiche.com/maiteng/ (1019)
[28334:28334:0712/103443.693013:INFO:CONSOLE(1)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://img1.bitauto.com/dealer/DealerActivity/Js/TimeActiveTag.min.js, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://m.h5.qiche4s.cn/priceapiv2/ajax/InitData.ashx?action=cardealerlist&brandid=1909&citycode=201 (1)
[28334:28334:0712/103443.694171:INFO:CONSOLE(1)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://img1.bitauto.com/dealer/DealerActivity/Js/TimeActiveTag.min.js, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://m.h5.qiche4s.cn/priceapiv2/ajax/InitData.ashx?action=cardealerlist&brandid=1909&citycode=201 (1)
[28334:28334:0712/103443.695003:INFO:CONSOLE(1)] "A parser-blocking, cross site (i.e. different eTLD+1) script, https://image.bitautoimg.com/bt/price/common/dialDealerPhone.min.js, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://m.h5.qiche4s.cn/priceapiv2/ajax/InitData.ashx?action=cardealerlist&brandid=1909&citycode=201 (1)
[3:3:0712/103443.712311:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/103443.848762:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/103443.848950:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://car.m.yiche.com/maiteng/"
[1:1:0712/103443.850236:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 775 0x7f3a00974070 0x1a5a710ebfe0 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103443.850832:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , , function Anchor(){return(this instanceof Anchor)?this.Init():new Anchor();}Anchor.prototype.Init=fun
[1:1:0712/103443.850933:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103444.796401:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.947419, 0, 0
[1:1:0712/103444.796557:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/103444.993117:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 786 0x7f3a0289c2e0 0x1a5a710737e0 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103444.993658:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , , handleJson([])
[1:1:0712/103444.993785:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103444.994091:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://car.m.yiche.com/maiteng/"
[1:1:0712/103445.059647:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/103445.294233:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , , document.readyState
[1:1:0712/103445.294419:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103445.866474:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/103445.866662:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://car.m.yiche.com/maiteng/"
[1:1:0712/103445.867631:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 821 0x7f3a00974070 0x1a5a71439360 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103445.868209:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , , 
var global_BottomLayerData={"luntan":{"Title":"易车APP 原创车评应有尽有","ImgUrl":"http:/
[1:1:0712/103445.868328:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103445.870488:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 821 0x7f3a00974070 0x1a5a71439360 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103445.873026:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 821 0x7f3a00974070 0x1a5a71439360 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103445.888976:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 821 0x7f3a00974070 0x1a5a71439360 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103445.921325:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 821 0x7f3a00974070 0x1a5a71439360 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103445.923458:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 821 0x7f3a00974070 0x1a5a71439360 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103445.927635:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 821 0x7f3a00974070 0x1a5a71439360 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103445.931181:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 821 0x7f3a00974070 0x1a5a71439360 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103445.992669:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/103446.008958:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 821 0x7f3a00974070 0x1a5a71439360 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103446.039831:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 821 0x7f3a00974070 0x1a5a71439360 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103446.072223:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 821 0x7f3a00974070 0x1a5a71439360 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103446.079356:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 821 0x7f3a00974070 0x1a5a71439360 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103446.083811:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.m.yiche.com/maiteng/", 0
[1:1:0712/103446.084035:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.m.yiche.com/, 928
[1:1:0712/103446.084156:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 928 0x7f3a00974070 0x1a5a71e3c760 , 5:3_http://car.m.yiche.com/, 1, -5:3_http://car.m.yiche.com/, 821 0x7f3a00974070 0x1a5a71439360 
[1:1:0712/103446.127435:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 821 0x7f3a00974070 0x1a5a71439360 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103446.131095:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 821 0x7f3a00974070 0x1a5a71439360 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103446.158918:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 821 0x7f3a00974070 0x1a5a71439360 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103446.168872:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 821 0x7f3a00974070 0x1a5a71439360 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103446.180023:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 821 0x7f3a00974070 0x1a5a71439360 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103446.182148:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 821 0x7f3a00974070 0x1a5a71439360 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103446.216550:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 821 0x7f3a00974070 0x1a5a71439360 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103446.226536:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 821 0x7f3a00974070 0x1a5a71439360 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103446.233807:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.36709, 89, 1
[1:1:0712/103446.233957:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/103446.322458:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 826 0x7f3a0289c2e0 0x1a5a71073360 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103446.324034:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , , (function(){var h={},mt={},c={id:"c1ef3e92dc0e8d0be141d3635d5a08a8",dm:["car.m.yiche.com"],js:"tongj
[1:1:0712/103446.324167:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103446.335298:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1d2e65ca29c8, 0x1a5a7072e190
[1:1:0712/103446.335453:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.m.yiche.com/maiteng/", 100
[1:1:0712/103446.335676:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.m.yiche.com/, 974
[1:1:0712/103446.335800:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 974 0x7f3a00974070 0x1a5a70f63ce0 , 5:3_http://car.m.yiche.com/, 1, -5:3_http://car.m.yiche.com/, 826 0x7f3a0289c2e0 0x1a5a71073360 
[1:1:0712/103446.676382:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , , document.readyState
[1:1:0712/103446.676572:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103449.547648:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/103449.547832:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://car.m.yiche.com/maiteng/"
[1:1:0712/103449.559340:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.011446, 64, 1
[1:1:0712/103449.559519:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/103449.598025:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.m.yiche.com/, 928, 7f3a032b9881
[1:1:0712/103449.615187:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1f831a402860","ptid":"821 0x7f3a00974070 0x1a5a71439360 ","rf":"5:3_http://car.m.yiche.com/"}
[1:1:0712/103449.615369:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.m.yiche.com/","ptid":"821 0x7f3a00974070 0x1a5a71439360 ","rf":"5:3_http://car.m.yiche.com/"}
[1:1:0712/103449.615589:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.m.yiche.com/maiteng/"
[1:1:0712/103449.616093:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , , gJsWtid.src="http://Webtrends.yccdn.com/dcs8maysp00000kf91652w2qz_5f3k/wtid.js"
[1:1:0712/103449.616227:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103450.248568:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.m.yiche.com/, 974, 7f3a032b9881
[1:1:0712/103450.266721:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1f831a402860","ptid":"826 0x7f3a0289c2e0 0x1a5a71073360 ","rf":"5:3_http://car.m.yiche.com/"}
[1:1:0712/103450.266917:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.m.yiche.com/","ptid":"826 0x7f3a0289c2e0 0x1a5a71073360 ","rf":"5:3_http://car.m.yiche.com/"}
[1:1:0712/103450.267183:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.m.yiche.com/maiteng/"
[1:1:0712/103450.267493:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/103450.267615:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103450.267988:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1d2e65ca29c8, 0x1a5a7072e150
[1:1:0712/103450.268076:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.m.yiche.com/maiteng/", 100
[1:1:0712/103450.268259:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.m.yiche.com/, 1084
[1:1:0712/103450.268374:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1084 0x7f3a00974070 0x1a5a7086fb60 , 5:3_http://car.m.yiche.com/, 1, -5:3_http://car.m.yiche.com/, 974 0x7f3a00974070 0x1a5a70f63ce0 
[1:1:0712/103450.367658:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , , document.readyState
[1:1:0712/103450.367839:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103450.754104:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "http://car.m.yiche.com/maiteng/"
[1:1:0712/103450.754589:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , eventHander, (e){
            var elem = e.target;
            if(elem.tagName.toLowerCase() === 'script' && elem
[1:1:0712/103450.754711:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103450.809710:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1021 0x7f3a0289c2e0 0x1a5a70bf2060 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103450.810270:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , , sspCallBackSenseNew.handleJson([])
[1:1:0712/103450.810418:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103450.830799:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1022 0x7f3a0289c2e0 0x1a5a710ee6e0 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103450.831325:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , , sspCallBackSenseNew.handleJson([])
[1:1:0712/103450.831490:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103450.891822:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1024 0x7f3a0289c2e0 0x1a5a710f3e60 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103450.892524:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , , sspCallBackSenseNew.handleJson([{"width":750,"pvid":"5ace035a2c1606c11a203a29f03f0dbc","pid":36128,"
[1:1:0712/103450.892651:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103450.924044:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1025 0x7f3a0289c2e0 0x1a5a71432960 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103450.924807:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , , sspCallBackSenseNew.handleJson([{"width":750,"pvid":"8df72ef3707408953bd8e7051716d56e","pid":19889,"
[1:1:0712/103450.924926:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103450.983792:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1027 0x7f3a0289c2e0 0x1a5a720196e0 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103450.984616:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , , sspCallBackSenseNew.handleJson([{"width":0,"pvid":"f96bcaf0f0ecb552f16e21ef4c008f63","pid":36632,"ma
[1:1:0712/103450.984723:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103451.037677:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1028 0x7f3a0289c2e0 0x1a5a72035e60 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103451.038342:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , , sspCallBackSenseNew.handleJson([{"width":750,"pvid":"ec4130ced45ec126b3972c371e935d7e","pid":36569,"
[1:1:0712/103451.038475:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103451.090526:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1030 0x7f3a0289c2e0 0x1a5a71f4bde0 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103451.094003:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , , !function(b,a){"object"==typeof exports&&"undefined"!=typeof module?module.exports=a():"function"==t
[1:1:0712/103451.098020:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103451.104503:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://car.m.yiche.com/maiteng/"
[1:1:0712/103451.133016:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1031 0x7f3a0289c2e0 0x1a5a71fa2960 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103451.151485:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , , !function(){"use strict";var a={key_str:"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456
[1:1:0712/103451.151666:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103451.163824:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://car.m.yiche.com/maiteng/"
[1:1:0712/103451.166669:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://car.m.yiche.com/maiteng/"
[1:1:0712/103451.171271:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.m.yiche.com/maiteng/", 100
[1:1:0712/103451.171524:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://car.m.yiche.com/, 1127
[1:1:0712/103451.171638:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1127 0x7f3a00974070 0x1a5a71fbc660 , 5:3_http://car.m.yiche.com/, 1, -5:3_http://car.m.yiche.com/, 1031 0x7f3a0289c2e0 0x1a5a71fa2960 
[1:1:0712/103451.236732:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1033 0x7f3a0289c2e0 0x1a5a71438160 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103451.242489:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , , !function(){"use strict";var a={key_str:"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456
[1:1:0712/103451.242702:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103451.251524:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1d6357f4e170
[1:1:0712/103451.251932:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://car.m.yiche.com/maiteng/"
[1:1:0712/103451.254593:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://car.m.yiche.com/maiteng/"
[1:1:0712/103451.257305:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.m.yiche.com/maiteng/", 100
[1:1:0712/103451.257593:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://car.m.yiche.com/, 1129
[1:1:0712/103451.257769:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1129 0x7f3a00974070 0x1a5a7027eae0 , 5:3_http://car.m.yiche.com/, 1, -5:3_http://car.m.yiche.com/, 1033 0x7f3a0289c2e0 0x1a5a71438160 
[1:1:0712/103451.460697:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "http://car.m.yiche.com/maiteng/"
[1:1:0712/103451.461146:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , eventHander, (e){
            var elem = e.target;
            if(elem.tagName.toLowerCase() === 'script' && elem
[1:1:0712/103451.461309:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103452.258263:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/103452.258442:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://car.m.yiche.com/maiteng/"
[1:1:0712/103452.258985:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1072 0x7f3a00974070 0x1a5a72227ee0 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103452.259794:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , , 
    var commonSCInfoOb = {
        InitSCInfo: function (csid, cityid) {
            if (GlobalSumm
[1:1:0712/103452.259888:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103452.265005:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1072 0x7f3a00974070 0x1a5a72227ee0 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103452.267694:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1072 0x7f3a00974070 0x1a5a72227ee0 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103452.276622:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1072 0x7f3a00974070 0x1a5a72227ee0 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103452.330099:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1072 0x7f3a00974070 0x1a5a72227ee0 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103452.377603:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1072 0x7f3a00974070 0x1a5a72227ee0 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103452.384855:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1072 0x7f3a00974070 0x1a5a72227ee0 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103452.393474:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1072 0x7f3a00974070 0x1a5a72227ee0 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103452.397228:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1072 0x7f3a00974070 0x1a5a72227ee0 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103452.403543:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1072 0x7f3a00974070 0x1a5a72227ee0 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103452.468350:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1072 0x7f3a00974070 0x1a5a72227ee0 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103452.470894:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1072 0x7f3a00974070 0x1a5a72227ee0 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103452.550370:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1072 0x7f3a00974070 0x1a5a72227ee0 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103452.553763:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1072 0x7f3a00974070 0x1a5a72227ee0 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103452.555384:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1072 0x7f3a00974070 0x1a5a72227ee0 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103452.561780:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1072 0x7f3a00974070 0x1a5a72227ee0 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103452.570625:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1072 0x7f3a00974070 0x1a5a72227ee0 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103452.575232:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1072 0x7f3a00974070 0x1a5a72227ee0 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103452.587599:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1072 0x7f3a00974070 0x1a5a72227ee0 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103452.803911:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.545438, 31, 0
[1:1:0712/103452.804108:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/103452.995691:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1079 0x7f3a0289c2e0 0x1a5a721fc0e0 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103452.996920:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , , <!-- 
gWtId="139.207.78.31-2425217536.30750809";  
gWtAccountRollup=1; 
 
// -->

[1:1:0712/103452.997098:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103453.139216:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://car.m.yiche.com/maiteng/"
[1:1:0712/103453.139682:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , f.onload, (){f.onload=u;f=window[d]=u;a&&a(b)}
[1:1:0712/103453.139814:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103453.143483:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.m.yiche.com/, 1084, 7f3a032b9881
[1:1:0712/103453.165756:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1f831a402860","ptid":"974 0x7f3a00974070 0x1a5a70f63ce0 ","rf":"5:3_http://car.m.yiche.com/"}
[1:1:0712/103453.165947:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.m.yiche.com/","ptid":"974 0x7f3a00974070 0x1a5a70f63ce0 ","rf":"5:3_http://car.m.yiche.com/"}
[1:1:0712/103453.166150:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.m.yiche.com/maiteng/"
[1:1:0712/103453.166490:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/103453.166634:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103453.167445:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1d2e65ca29c8, 0x1a5a7072e150
[1:1:0712/103453.167537:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.m.yiche.com/maiteng/", 100
[1:1:0712/103453.167705:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.m.yiche.com/, 1218
[1:1:0712/103453.167792:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1218 0x7f3a00974070 0x1a5a727817e0 , 5:3_http://car.m.yiche.com/, 1, -5:3_http://car.m.yiche.com/, 1084 0x7f3a00974070 0x1a5a7086fb60 
[1:1:0712/103453.190692:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , , document.readyState
[1:1:0712/103453.191096:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103454.278455:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://car.m.yiche.com/, 1127, 7f3a032b98db
[1:1:0712/103454.302701:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1f831a402860","ptid":"1031 0x7f3a0289c2e0 0x1a5a71fa2960 ","rf":"5:3_http://car.m.yiche.com/"}
[1:1:0712/103454.302938:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.m.yiche.com/","ptid":"1031 0x7f3a0289c2e0 0x1a5a71fa2960 ","rf":"5:3_http://car.m.yiche.com/"}
[1:1:0712/103454.303230:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://car.m.yiche.com/, 1242
[1:1:0712/103454.303404:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1242 0x7f3a00974070 0x1a5a727fa260 , 5:3_http://car.m.yiche.com/, 0, , 1127 0x7f3a00974070 0x1a5a71fbc660 
[1:1:0712/103454.303652:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.m.yiche.com/maiteng/"
[1:1:0712/103454.304026:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , , (){if(1==B){clearInterval(w),u++,l=null==l||l,this.DEBUG&&console.log("linkedme.link()");var e=serve
[1:1:0712/103454.304177:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103454.305418:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://car.m.yiche.com/, 1129, 7f3a032b98db
[1:1:0712/103454.329446:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1f831a402860","ptid":"1033 0x7f3a0289c2e0 0x1a5a71438160 ","rf":"5:3_http://car.m.yiche.com/"}
[1:1:0712/103454.329662:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.m.yiche.com/","ptid":"1033 0x7f3a0289c2e0 0x1a5a71438160 ","rf":"5:3_http://car.m.yiche.com/"}
[1:1:0712/103454.329960:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://car.m.yiche.com/, 1243
[1:1:0712/103454.330567:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1243 0x7f3a00974070 0x1a5a703fd9e0 , 5:3_http://car.m.yiche.com/, 0, , 1129 0x7f3a00974070 0x1a5a7027eae0 
[1:1:0712/103454.330819:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.m.yiche.com/maiteng/"
[1:1:0712/103454.331166:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , , (){if(1==B){clearInterval(w),u++,l=null==l||l,this.DEBUG&&console.log("linkedme.link()");var e=serve
[1:1:0712/103454.331282:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103454.795418:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://car.m.yiche.com/maiteng/"
[1:1:0712/103454.795915:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , s.onreadystatechange, (){var i;if(4===s.readyState)if(200===s.status){if(t)i=s.responseText;else try{i=JSON.parse(s.respon
[1:1:0712/103454.796066:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103454.796375:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://car.m.yiche.com/maiteng/"
[1:1:0712/103454.797723:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://car.m.yiche.com/maiteng/"
[1:1:0712/103454.860517:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://car.m.yiche.com/maiteng/"
[1:1:0712/103454.860937:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , s.onreadystatechange, (){var i;if(4===s.readyState)if(200===s.status){if(t)i=s.responseText;else try{i=JSON.parse(s.respon
[1:1:0712/103454.861090:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103454.861386:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://car.m.yiche.com/maiteng/"
[1:1:0712/103454.862742:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://car.m.yiche.com/maiteng/"
[1:1:0712/103456.621970:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/103456.622162:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://car.m.yiche.com/maiteng/"
[1:1:0712/103456.625597:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1207 0x7f3a00974070 0x1a5a720d81e0 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103456.628276:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , , /*##file:audio/jplayer/jquery.jplayer.min.js##*/
/*! jPlayer 2.9.2 for jQuery ~ (c) 2009-2014 Happy
[1:1:0712/103456.628459:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103456.651965:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1207 0x7f3a00974070 0x1a5a720d81e0 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103456.736876:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1207 0x7f3a00974070 0x1a5a720d81e0 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103456.894180:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1207 0x7f3a00974070 0x1a5a720d81e0 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103456.898024:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1207 0x7f3a00974070 0x1a5a720d81e0 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103456.900174:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1207 0x7f3a00974070 0x1a5a720d81e0 , "http://car.m.yiche.com/maiteng/"
[28334:28334:0712/103456.918887:INFO:CONSOLE(2381)] "http://img2.bitautoimg.com/bitauto/2019/06/05/e8825996-8eab-4b95-a01f-f73777eb65c0_630_w0.jpg", source: http://car.m.yiche.com/maiteng/ (2381)
[1:1:0712/103456.920958:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://car.m.yiche.com/maiteng/"
[1:1:0712/103456.983776:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://car.m.yiche.com/maiteng/"
[1:1:0712/103457.177670:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://car.m.yiche.com/maiteng/"
[1:1:0712/103457.178477:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://car.m.yiche.com/maiteng/"
[1:1:0712/103457.268216:INFO:document.cc(5190)] >>> Document::setDomain. [old, new] = "car.m.yiche.com", "car.m.yiche.com"
[1:1:0712/103457.294415:INFO:document.cc(5190)] >>> Document::setDomain. [old, new] = "car.m.yiche.com", "car.m.yiche.com"
[28334:28334:0712/103457.392487:INFO:CONSOLE(2284)] "0", source: http://car.m.yiche.com/maiteng/ (2284)
[1:1:0712/103457.470001:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://car.m.yiche.com/maiteng/"
[1:1:0712/103457.751137:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1213 0x7f3a0289c2e0 0x1a5a71e47c60 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103457.751901:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , , 
var YCWapPageFilter = (function (window) {
    var Filter_Param = [
        {
            "para
[1:1:0712/103457.752004:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[28334:28334:0712/103457.762070:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/103457.763328:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x1a5a712eb820
[1:1:0712/103457.764085:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[28334:28334:0712/103457.764405:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 4, 4, 
[28334:28334:0712/103457.778707:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_http://car.m.yiche.com/, http://car.m.yiche.com/, 4
[28334:28334:0712/103457.778797:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, http://car.m.yiche.com/, http://car.m.yiche.com
[1:1:0712/103457.799420:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x1d2e65ca29c8, 0x1a5a7072e190
[1:1:0712/103457.799629:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.m.yiche.com/maiteng/", 5000
[1:1:0712/103457.799876:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.m.yiche.com/, 1372
[1:1:0712/103457.799975:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1372 0x7f3a00974070 0x1a5a72cdf8e0 , 5:3_http://car.m.yiche.com/, 1, -5:3_http://car.m.yiche.com/, 1213 0x7f3a0289c2e0 0x1a5a71e47c60 
[1:1:0712/103457.800493:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://car.m.yiche.com/maiteng/"
[1:1:0712/103457.852701:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1214 0x7f3a0289c2e0 0x1a5a70c36fe0 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103457.853521:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , , businessCarCallBack({"CityId":201,"CsId":1909,"CsName":"迈腾","CsShowName":"迈腾","CsSpell":"mai
[1:1:0712/103457.853663:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103457.854739:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://car.m.yiche.com/maiteng/"
[1:1:0712/103457.981796:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , , document.readyState
[1:1:0712/103457.981977:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103457.983433:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.m.yiche.com/, 1218, 7f3a032b9881
[1:1:0712/103458.008120:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1f831a402860","ptid":"1084 0x7f3a00974070 0x1a5a7086fb60 ","rf":"5:3_http://car.m.yiche.com/"}
[1:1:0712/103458.008320:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.m.yiche.com/","ptid":"1084 0x7f3a00974070 0x1a5a7086fb60 ","rf":"5:3_http://car.m.yiche.com/"}
[1:1:0712/103458.008542:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.m.yiche.com/maiteng/"
[1:1:0712/103458.008820:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103458.008912:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103458.009712:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1d2e65ca29c8, 0x1a5a7072e150
[1:1:0712/103458.009818:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.m.yiche.com/maiteng/", 100
[1:1:0712/103458.009981:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.m.yiche.com/, 1380
[1:1:0712/103458.010075:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1380 0x7f3a00974070 0x1a5a727fa8e0 , 5:3_http://car.m.yiche.com/, 1, -5:3_http://car.m.yiche.com/, 1218 0x7f3a00974070 0x1a5a727817e0 
[1:1:0712/103458.771688:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1240 0x7f3a0289c2e0 0x1a5a713e10e0 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103458.772511:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , , businessCarCallBackNew({"CityId":201,"CsId":1909,"CsName":"迈腾","CsShowName":"迈腾","CsSpell":"
[1:1:0712/103458.772643:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103458.773406:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://car.m.yiche.com/maiteng/"
[1:1:0712/103458.847902:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1241 0x7f3a0289c2e0 0x1a5a71f823e0 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103458.848589:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , , GetVrCallback({"Code":0,"Message":null,"Description":"成功","Data":{"Total":4,"DataList":[{"AlbumT
[1:1:0712/103458.848721:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103458.849349:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://car.m.yiche.com/maiteng/"
[1:1:0712/103458.926330:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://car.m.yiche.com/, 1243, 7f3a032b98db
[1:1:0712/103458.952062:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1129 0x7f3a00974070 0x1a5a7027eae0 ","rf":"5:3_http://car.m.yiche.com/"}
[1:1:0712/103458.952241:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1129 0x7f3a00974070 0x1a5a7027eae0 ","rf":"5:3_http://car.m.yiche.com/"}
[1:1:0712/103458.952479:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://car.m.yiche.com/, 1408
[1:1:0712/103458.952595:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1408 0x7f3a00974070 0x1a5a70cd8560 , 5:3_http://car.m.yiche.com/, 0, , 1243 0x7f3a00974070 0x1a5a703fd9e0 
[1:1:0712/103458.952795:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.m.yiche.com/maiteng/"
[1:1:0712/103458.953133:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , , (){if(1==B){clearInterval(w),u++,l=null==l||l,this.DEBUG&&console.log("linkedme.link()");var e=serve
[1:1:0712/103458.953255:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103459.183698:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://car.m.yiche.com/maiteng/"
[1:1:0712/103459.212659:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://car.m.yiche.com/, 1242, 7f3a032b98db
[1:1:0712/103459.237423:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1127 0x7f3a00974070 0x1a5a71fbc660 ","rf":"5:3_http://car.m.yiche.com/"}
[1:1:0712/103459.237659:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1127 0x7f3a00974070 0x1a5a71fbc660 ","rf":"5:3_http://car.m.yiche.com/"}
[1:1:0712/103459.237950:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://car.m.yiche.com/, 1413
[1:1:0712/103459.238102:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1413 0x7f3a00974070 0x1a5a72cdfd60 , 5:3_http://car.m.yiche.com/, 0, , 1242 0x7f3a00974070 0x1a5a727fa260 
[1:1:0712/103459.238332:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.m.yiche.com/maiteng/"
[1:1:0712/103459.238649:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , , (){if(1==B){clearInterval(w),u++,l=null==l||l,this.DEBUG&&console.log("linkedme.link()");var e=serve
[1:1:0712/103459.238771:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103459.462860:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://car.m.yiche.com/maiteng/"
[1:1:0712/103500.366113:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1279 0x7f3a0289c2e0 0x1a5a727812e0 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103500.366678:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , , GetSerialAreaPriceRangeCallback([{"Id":1909,"MinReferPrice":12.67,"MaxReferPrice":30.91,"ReturnType"
[1:1:0712/103500.366843:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103500.367288:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://car.m.yiche.com/maiteng/"
[1:1:0712/103500.403524:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1280 0x7f3a0289c2e0 0x1a5a70c133e0 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103500.404457:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , , (function(){function wa(d){function b(d){function u(){g.onreadystatechange=g.onload=null;d.callback&
[1:1:0712/103500.404623:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103500.440349:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 13, 0x1d2e65ca29c8, 0x1a5a7072e190
[1:1:0712/103500.440550:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.m.yiche.com/maiteng/", 13
[1:1:0712/103500.440783:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.m.yiche.com/, 1443
[1:1:0712/103500.440896:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1443 0x7f3a00974070 0x1a5a727fa060 , 5:3_http://car.m.yiche.com/, 1, -5:3_http://car.m.yiche.com/, 1280 0x7f3a0289c2e0 0x1a5a70c133e0 
[1:1:0712/103500.441373:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10000, 0x1d2e65ca29c8, 0x1a5a7072e190
[1:1:0712/103500.441496:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.m.yiche.com/maiteng/", 10000
[1:1:0712/103500.441729:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.m.yiche.com/, 1444
[1:1:0712/103500.441866:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1444 0x7f3a00974070 0x1a5a709b7260 , 5:3_http://car.m.yiche.com/, 1, -5:3_http://car.m.yiche.com/, 1280 0x7f3a0289c2e0 0x1a5a70c133e0 
[1:1:0712/103500.554943:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1283 0x7f3a0289c2e0 0x1a5a7284e760 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103500.555498:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , , callgetGuanFang()
[1:1:0712/103500.555637:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103500.555977:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://car.m.yiche.com/maiteng/"
[1:1:0712/103500.919784:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x19c0944131a8
[1:1:0712/103501.237501:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1284 0x7f3a0289c2e0 0x1a5a72227de0 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103501.238056:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , , getHQCallback([{"newsTitle":"捷亚泰中兴迈腾优惠高达4万元","URL":"http://m.qiche4s.cn/10
[1:1:0712/103501.238164:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103501.238557:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://car.m.yiche.com/maiteng/"
[1:1:0712/103501.324545:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1286 0x7f3a0289c2e0 0x1a5a720db9e0 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103501.325145:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , , jQuery180033051634538925034_1562898892454({"result":"no","url":"","slogan":"","title":"","tag":""})
[1:1:0712/103501.325289:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103501.325683:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://car.m.yiche.com/maiteng/"
[1:1:0712/103501.354070:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1287 0x7f3a0289c2e0 0x1a5a71e3cde0 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103501.354625:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , , var jjviewed={"nlist":[{CsID:"1977",CsName:"\u9510\u5FD7",CsImage:"http://img3.bitautoimg.com/autoal
[1:1:0712/103501.354753:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103501.355144:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://car.m.yiche.com/maiteng/"
[1:1:0712/103501.413623:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1289 0x7f3a0289c2e0 0x1a5a713ea560 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103501.414231:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , , getSubsidyCallback([])
[1:1:0712/103501.414364:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103501.414674:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://car.m.yiche.com/maiteng/"
[1:1:0712/103502.424498:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://car.m.yiche.com/maiteng/"
[1:1:0712/103502.424945:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , d, (a,e){var h,j,k,l,m;try{if(d&&(e||i.readyState===4)){d=b,g&&(i.onreadystatechange=p.noop,cI&&delete 
[1:1:0712/103502.425180:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103502.425535:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://car.m.yiche.com/maiteng/"
[1:1:0712/103502.427073:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://car.m.yiche.com/maiteng/"
[1:1:0712/103502.427446:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1d6357f27d78
[1:1:0712/103502.940049:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1350 0x7f3a0289c2e0 0x1a5a70a02f60 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103502.940673:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , , GetCarAreaPriceListCallback([{"Id":131436,"MinReferPrice":12.67,"MaxReferPrice":18.61,"ReturnType":1
[1:1:0712/103502.940806:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103502.941283:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://car.m.yiche.com/maiteng/"
[1:1:0712/103503.059810:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1351 0x7f3a0289c2e0 0x1a5a7282b060 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103503.060459:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , , success_jsonpCallback([{"Id":1039953,"Name":"李霞","JobLvl":2,"ImgUrl":"https://epbf.bitautoimg.co
[1:1:0712/103503.060573:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103503.061130:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://car.m.yiche.com/maiteng/"
[1:1:0712/103503.124036:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1353 0x7f3a0289c2e0 0x1a5a70a26460 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103503.124620:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , , successHandler([{"VideoType":"vf","VideoId":571827,"PlayCount":19806,"ReplyCount":5,"FavoritesCount"
[1:1:0712/103503.124725:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103503.125225:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://car.m.yiche.com/maiteng/"
[1:1:0712/103503.185795:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1354 0x7f3a0289c2e0 0x1a5a72230460 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103503.186458:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , , successHandlerNew([{"VideoType":"vf","VideoId":571827,"PlayCount":19806,"ReplyCount":5,"FavoritesCou
[1:1:0712/103503.186584:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103503.187015:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://car.m.yiche.com/maiteng/"
[1:1:0712/103503.514240:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/103503.514437:INFO:render_frame_impl.cc(7019)] 	 [url] = http://car.m.yiche.com
[28334:28334:0712/103503.515238:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://car.m.yiche.com/
[28334:28334:0712/103503.524069:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[28334:28334:0712/103503.525503:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[28334:28347:0712/103503.537347:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 4
[28334:28347:0712/103503.537415:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 4, HandleIncomingMessage, HandleIncomingMessage
[28334:28334:0712/103503.537437:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://image.bitautoimg.com/
[28334:28334:0712/103503.537478:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_http://image.bitautoimg.com/, http://image.bitautoimg.com/cargroup/other/crossstorage/hubsession.html, 4
[28334:28334:0712/103503.537542:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:4_http://image.bitautoimg.com/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 02:30:36 GMT Content-Type: text/html Expires: Sun, 29 Sep 2019 08:41:48 GMT Server: Tengine Last-Modified: Fri, 18 Aug 2017 08:52:18 GMT Cache-Control: max-age=7776000 Content-Encoding: gzip Age: 928128 X-Cache: HIT from cache.51cdn.com X-Via: 1.1 PSzjtzsx4uu157:9 (Cdn Cache Server V2.0), 1.1 hangkuan52:0 (Cdn Cache Server V2.0)  ,28429, 5
[1:7:0712/103503.542504:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/103503.747601:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , , document.readyState
[1:1:0712/103503.747760:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103503.773688:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.m.yiche.com/, 1380, 7f3a032b9881
[1:1:0712/103503.797939:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1f831a402860","ptid":"1218 0x7f3a00974070 0x1a5a727817e0 ","rf":"5:3_http://car.m.yiche.com/"}
[1:1:0712/103503.798132:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.m.yiche.com/","ptid":"1218 0x7f3a00974070 0x1a5a727817e0 ","rf":"5:3_http://car.m.yiche.com/"}
[1:1:0712/103503.798384:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.m.yiche.com/maiteng/"
[1:1:0712/103503.798693:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103503.798798:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103503.799423:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1d2e65ca29c8, 0x1a5a7072e150
[1:1:0712/103503.799517:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.m.yiche.com/maiteng/", 100
[1:1:0712/103503.799688:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.m.yiche.com/, 1509
[1:1:0712/103503.799801:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1509 0x7f3a00974070 0x1a5a73ec34e0 , 5:3_http://car.m.yiche.com/, 1, -5:3_http://car.m.yiche.com/, 1380 0x7f3a00974070 0x1a5a727fa8e0 
[28334:28347:0712/103504.320372:ERROR:ssl_client_socket_impl.cc(1046)] handshake failed; returned -1, SSL error code 1, net_error -101
[28334:28347:0712/103504.384326:ERROR:ssl_client_socket_impl.cc(1046)] handshake failed; returned -1, SSL error code 1, net_error -101
[1:1:0712/103504.555298:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://car.m.yiche.com/maiteng/"
[1:1:0712/103504.555703:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , d, (a,e){var h,j,k,l,m;try{if(d&&(e||i.readyState===4)){d=b,g&&(i.onreadystatechange=p.noop,cI&&delete 
[1:1:0712/103504.555810:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103504.556050:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://car.m.yiche.com/maiteng/"
[1:1:0712/103504.557724:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://car.m.yiche.com/maiteng/"
[1:1:0712/103504.558123:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1d6357f27d78
[1:1:0712/103505.168725:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://car.m.yiche.com/maiteng/"
[1:1:0712/103505.169164:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , s.onreadystatechange, (){var i;if(4===s.readyState)if(200===s.status){if(t)i=s.responseText;else try{i=JSON.parse(s.respon
[1:1:0712/103505.169331:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103505.169620:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://car.m.yiche.com/maiteng/"
[1:1:0712/103505.170859:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://car.m.yiche.com/maiteng/"
[1:1:0712/103505.323473:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://car.m.yiche.com/maiteng/"
[1:1:0712/103505.323947:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , s.onreadystatechange, (){var i;if(4===s.readyState)if(200===s.status){if(t)i=s.responseText;else try{i=JSON.parse(s.respon
[1:1:0712/103505.324079:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103505.324314:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://car.m.yiche.com/maiteng/"
[1:1:0712/103505.325604:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://car.m.yiche.com/maiteng/"
[1:1:0712/103506.115556:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.m.yiche.com/, 1443, 7f3a032b9881
[1:1:0712/103506.162158:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1f831a402860","ptid":"1280 0x7f3a0289c2e0 0x1a5a70c133e0 ","rf":"5:3_http://car.m.yiche.com/"}
[1:1:0712/103506.162350:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.m.yiche.com/","ptid":"1280 0x7f3a0289c2e0 0x1a5a70c133e0 ","rf":"5:3_http://car.m.yiche.com/"}
[1:1:0712/103506.162603:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.m.yiche.com/maiteng/"
[1:1:0712/103506.162930:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103506.163070:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[28334:28334:0712/103506.164294:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/103506.165428:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 5, 0x1a5a73d87a20
[1:1:0712/103506.165793:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 5
[28334:28334:0712/103506.166606:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 5, 5, 
[1:1:0712/103506.174329:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/103506.174519:INFO:render_frame_impl.cc(7019)] 	 [url] = http://car.m.yiche.com
[28334:28334:0712/103506.175386:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://car.m.yiche.com/
[1:1:0712/103506.177231:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 6, 0x1a5a73d87020
[1:1:0712/103506.179375:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 6
[28334:28334:0712/103506.179961:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[28334:28334:0712/103506.182126:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 6, 6, 
[28334:28334:0712/103506.194385:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:6_http://car.m.yiche.com/, http://car.m.yiche.com/, 6
[28334:28334:0712/103506.194477:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 6, 6, http://car.m.yiche.com/, http://car.m.yiche.com
[28334:28334:0712/103506.278710:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[28334:28334:0712/103506.280461:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[28334:28347:0712/103506.292639:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 5
[28334:28347:0712/103506.292711:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 5, HandleIncomingMessage, HandleIncomingMessage
[28334:28334:0712/103506.292729:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://cms.gtags.net/
[28334:28334:0712/103506.292770:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:5_http://cms.gtags.net/, http://cms.gtags.net/w?a=12&zid=vpTerIpAwbLiSqxcLqHkUxn3p5lIrXpI, 5
[28334:28334:0712/103506.292832:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:5_http://cms.gtags.net/, HTTP/1.1 200 OK Server: nginx/1.1.19 Date: Fri, 12 Jul 2019 02:35:06 GMT Content-Type: text/html Transfer-Encoding: chunked Connection: keep-alive P3P: CP="CURa ADMa DEVa TAIo PSAo PSDo OUR IND BUS UNI PUR INT DEM STA PRE COM NAV OTC NOI DSP COR" Cache-Control: no-cache, must-revalidate, max-age=0 Set-Cookie: cmtf=lq1-2-5.lw9.ll31.; expires=Fri, 26 Jul 2019 02:35:06 GMT; path=/; domain=.gtags.net; Content-Encoding: gzip  ,28429, 5
[1:7:0712/103506.296084:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/103506.428885:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1456 0x7f3a0289c2e0 0x1a5a727fc5e0 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103506.429418:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , , 
[1:1:0712/103506.429570:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103506.429850:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://car.m.yiche.com/maiteng/"
[1:1:0712/103506.456949:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1457 0x7f3a0289c2e0 0x1a5a712c72e0 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103506.457532:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , , LoadXianShiQiangCallback({"IsTimeLimitRobbing":1,"ActivityUrl":"http://huodong.yiche.com/m/index/201
[1:1:0712/103506.457696:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103506.458091:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://car.m.yiche.com/maiteng/"
[1:1:0712/103506.615559:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1460 0x7f3a0289c2e0 0x1a5a73d39de0 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103506.616252:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , , successHandlerCC({"0_9445339":{"ArticleType":0,"ID":9445339,"CommentCount":1},"0_9444349":{"ArticleT
[1:1:0712/103506.616407:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
		remove user.e_10af8259 -> 0
		remove user.e_d9f54c2 -> 0
		remove user.f_7441d248 -> 0
[1:1:0712/103507.249667:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1461 0x7f3a0289c2e0 0x1a5a728620e0 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103507.255984:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , , jQuery180033051634538925034_1562898892455([{"PCDetailsUrl":"http://fenqi.taoche.com/beijing/m131436/
[1:1:0712/103507.256141:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103507.257055:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://car.m.yiche.com/maiteng/"
[1:1:0712/103507.712254:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1463 0x7f3a0289c2e0 0x1a5a73d20560 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103507.713755:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , , callgetUCar({"CarListInfo":[{"UcarID":"209209725","UcarSerialNumber":"dealerydg219210724t","CarID":"
[1:1:0712/103507.713969:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103507.715538:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://car.m.yiche.com/maiteng/"
[28334:28334:0712/103508.323294:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -356
[1:1:0712/103509.199186:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.m.yiche.com/, 1372, 7f3a032b9881
[1:1:0712/103509.227196:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1f831a402860","ptid":"1213 0x7f3a0289c2e0 0x1a5a71e47c60 ","rf":"5:3_http://car.m.yiche.com/"}
[1:1:0712/103509.227399:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.m.yiche.com/","ptid":"1213 0x7f3a0289c2e0 0x1a5a71e47c60 ","rf":"5:3_http://car.m.yiche.com/"}
[1:1:0712/103509.227679:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.m.yiche.com/maiteng/"
[1:1:0712/103509.228068:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103509.228223:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103509.537979:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:4_http://image.bitautoimg.com/
[1:1:0712/103509.572376:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , , document.readyState
[1:1:0712/103509.574659:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103509.576458:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.m.yiche.com/, 1509, 7f3a032b9881
[1:1:0712/103509.606610:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1f831a402860","ptid":"1380 0x7f3a00974070 0x1a5a727fa8e0 ","rf":"5:3_http://car.m.yiche.com/"}
[1:1:0712/103509.608823:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.m.yiche.com/","ptid":"1380 0x7f3a00974070 0x1a5a727fa8e0 ","rf":"5:3_http://car.m.yiche.com/"}
[1:1:0712/103509.609079:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.m.yiche.com/maiteng/"
[1:1:0712/103509.609436:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103509.609595:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103509.610250:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1d2e65ca29c8, 0x1a5a7072e150
[1:1:0712/103509.610367:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.m.yiche.com/maiteng/", 100
[1:1:0712/103509.610544:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.m.yiche.com/, 1624
[1:1:0712/103509.610630:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1624 0x7f3a00974070 0x1a5a72e38b60 , 5:3_http://car.m.yiche.com/, 1, -5:3_http://car.m.yiche.com/, 1509 0x7f3a00974070 0x1a5a73ec34e0 
[1:1:0712/103511.312189:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:5_http://cms.gtags.net/
[1:1:0712/103511.397841:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1569 0x7f3a0289c2e0 0x1a5a74631160 , "http://car.m.yiche.com/maiteng/"
[1:1:0712/103511.398413:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , , GetDownPaymentCallback({"PcListUrl":"http://www.daikuan.com/beijing/maiteng/?from=yc9&leads_source=p
[1:1:0712/103511.398542:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103511.398922:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://car.m.yiche.com/maiteng/"
[28334:28334:0712/103512.881481:INFO:CONSOLE(1)] "Uncaught (in promise) Error: CrossStorageClient could not connect", source: http://img1.bitautoimg.com/com/cb.ashx?v=2017.6.30&path=/M/other/crossstorage/es6-promise.auto.min.js,/M/other/crossstorage/client.js (1)
[1:1:0712/103512.988082:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[28334:28334:0712/103512.990828:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_http://image.bitautoimg.com/, http://image.bitautoimg.com/, 4
[28334:28334:0712/103512.990888:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, http://image.bitautoimg.com/, http://image.bitautoimg.com
[1:1:0712/103513.053261:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , , document.readyState
[1:1:0712/103513.053443:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103513.054876:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.m.yiche.com/, 1624, 7f3a032b9881
[1:1:0712/103513.086471:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1f831a402860","ptid":"1509 0x7f3a00974070 0x1a5a73ec34e0 ","rf":"5:3_http://car.m.yiche.com/"}
[1:1:0712/103513.086673:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.m.yiche.com/","ptid":"1509 0x7f3a00974070 0x1a5a73ec34e0 ","rf":"5:3_http://car.m.yiche.com/"}
[1:1:0712/103513.086903:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.m.yiche.com/maiteng/"
[1:1:0712/103513.087219:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103513.087328:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103513.088051:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1d2e65ca29c8, 0x1a5a7072e150
[1:1:0712/103513.088167:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.m.yiche.com/maiteng/", 100
[1:1:0712/103513.088328:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.m.yiche.com/, 1699
[1:1:0712/103513.088411:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1699 0x7f3a00974070 0x1a5a73d543e0 , 5:3_http://car.m.yiche.com/, 1, -5:3_http://car.m.yiche.com/, 1624 0x7f3a00974070 0x1a5a72e38b60 
[1:1:0712/103513.917959:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://car.m.yiche.com/maiteng/"
[1:1:0712/103513.918342:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , d, (a,e){var h,j,k,l,m;try{if(d&&(e||i.readyState===4)){d=b,g&&(i.onreadystatechange=p.noop,cI&&delete 
[1:1:0712/103513.918456:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103513.918691:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://car.m.yiche.com/maiteng/"
[1:1:0712/103513.919833:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://car.m.yiche.com/maiteng/"
[1:1:0712/103513.920130:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1d6357f27d78
[1:1:0712/103513.922803:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.m.yiche.com/maiteng/", 100
[1:1:0712/103513.922994:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://car.m.yiche.com/, 1711
[1:1:0712/103513.923109:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1711 0x7f3a00974070 0x1a5a7199b0e0 , 5:3_http://car.m.yiche.com/, 1, -5:3_http://car.m.yiche.com/, 1651
[1:1:0712/103513.927469:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.m.yiche.com/, 1444, 7f3a032b9881
[1:1:0712/103513.961966:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1f831a402860","ptid":"1280 0x7f3a0289c2e0 0x1a5a70c133e0 ","rf":"5:3_http://car.m.yiche.com/"}
[1:1:0712/103513.962176:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.m.yiche.com/","ptid":"1280 0x7f3a0289c2e0 0x1a5a70c133e0 ","rf":"5:3_http://car.m.yiche.com/"}
[1:1:0712/103513.962417:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.m.yiche.com/maiteng/"
[1:1:0712/103513.962783:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103513.962909:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103515.167489:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/103515.388558:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , , document.readyState
[1:1:0712/103515.388733:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103515.457476:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.m.yiche.com/, 1699, 7f3a032b9881
[1:1:0712/103515.488852:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1f831a402860","ptid":"1624 0x7f3a00974070 0x1a5a72e38b60 ","rf":"5:3_http://car.m.yiche.com/"}
[1:1:0712/103515.489091:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.m.yiche.com/","ptid":"1624 0x7f3a00974070 0x1a5a72e38b60 ","rf":"5:3_http://car.m.yiche.com/"}
[1:1:0712/103515.489373:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.m.yiche.com/maiteng/"
[1:1:0712/103515.489733:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103515.489906:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103515.490656:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1d2e65ca29c8, 0x1a5a7072e150
[1:1:0712/103515.490799:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.m.yiche.com/maiteng/", 100
[1:1:0712/103515.490997:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.m.yiche.com/, 1743
[1:1:0712/103515.491120:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1743 0x7f3a00974070 0x1a5a7285c660 , 5:3_http://car.m.yiche.com/, 1, -5:3_http://car.m.yiche.com/, 1699 0x7f3a00974070 0x1a5a73d543e0 
[1:1:0712/103516.453668:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://car.m.yiche.com/, 1711, 7f3a032b98db
[1:1:0712/103516.482541:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1f831a402860","ptid":"1651","rf":"5:3_http://car.m.yiche.com/"}
[1:1:0712/103516.482728:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.m.yiche.com/","ptid":"1651","rf":"5:3_http://car.m.yiche.com/"}
[1:1:0712/103516.482965:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://car.m.yiche.com/, 1756
[1:1:0712/103516.483165:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1756 0x7f3a00974070 0x1a5a715953e0 , 5:3_http://car.m.yiche.com/, 0, , 1711 0x7f3a00974070 0x1a5a7199b0e0 
[1:1:0712/103516.483453:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.m.yiche.com/maiteng/"
[1:1:0712/103516.483789:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , , () {
                        if (oldFlag) {
                            callback(oldData);
      
[1:1:0712/103516.483918:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103516.757517:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/103516.757715:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://image.bitautoimg.com/cargroup/other/crossstorage/hubsession.html"
[1:1:0712/103516.759366:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1741 0x7f3a00974070 0x1a5a71ad0560 , "http://image.bitautoimg.com/cargroup/other/crossstorage/hubsession.html"
[1:1:0712/103516.760527:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://image.bitautoimg.com/, 1f831a438880, , , 
  ;(function(root) {
  var CrossStorageHub = {};

  CrossStorageHub.init = function(permissions) {

[1:1:0712/103516.760690:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://image.bitautoimg.com/cargroup/other/crossstorage/hubsession.html", "image.bitautoimg.com", 4, 1, http://car.m.yiche.com, car.m.yiche.com, 3
[1:1:0712/103516.762182:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1741 0x7f3a00974070 0x1a5a71ad0560 , "http://image.bitautoimg.com/cargroup/other/crossstorage/hubsession.html"
[1:1:0712/103516.770283:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://car.m.yiche.com/maiteng/"
[1:1:0712/103516.770660:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_http://image.bitautoimg.com/-5:3_http://car.m.yiche.com/, 1f831a402860, 1f831a438880, ready, (a){if(a===!0?--p.readyWait:p.isReady)return;if(!e.body)return setTimeout(p.ready,1);p.isReady=!0;if
[1:1:0712/103516.770792:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 2, , , 0
[1:1:0712/103516.770964:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 

[1:1:0712/103516.771106:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://car.m.yiche.com/maiteng/"
[1:1:0712/103516.772921:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://car.m.yiche.com/maiteng/"
[1:1:0712/103517.124883:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://car.m.yiche.com/maiteng/"
[1:1:0712/103517.125269:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://car.m.yiche.com/maiteng/"
[1:1:0712/103517.126110:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "pageshow", "http://car.m.yiche.com/maiteng/"
[1:1:0712/103517.126882:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1d2e65ca29c8, 0x1a5a7072e2f0
[1:1:0712/103517.126995:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.m.yiche.com/maiteng/", 100
[1:1:0712/103517.127190:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://image.bitautoimg.com/, 1769
[1:1:0712/103517.127324:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1769 0x7f3a00974070 0x1a5a752e9de0 , 5:4_http://image.bitautoimg.com/, 2, -5:4_http://image.bitautoimg.com/-5:3_http://car.m.yiche.com/, 1741 0x7f3a00974070 0x1a5a71ad0560 
[1:1:0712/103517.193782:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , , document.readyState
[1:1:0712/103517.194026:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103517.624727:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "http://car.m.yiche.com/maiteng/"
[1:1:0712/103517.625474:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:3_http://car.m.yiche.com/, 5:4_http://image.bitautoimg.com/
[1:1:0712/103517.625626:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , _listener, (h){var g,j,f,k;if(c._closed||!h.data||typeof h.data!=="string"){return}j=(h.origin==="null")?"file:
[1:1:0712/103517.625780:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103517.626955:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "http://car.m.yiche.com/maiteng/"
[1:1:0712/103517.952214:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://image.bitautoimg.com/, 1769, 7f3a032b9881
[1:1:0712/103517.982800:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1f831a4388801f831a402860","ptid":"1741 0x7f3a00974070 0x1a5a71ad0560 ","rf":"5:4_http://image.bitautoimg.com/"}
[1:1:0712/103517.982991:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_http://image.bitautoimg.com/-5:3_http://car.m.yiche.com/","ptid":"1741 0x7f3a00974070 0x1a5a71ad0560 ","rf":"5:4_http://image.bitautoimg.com/"}
[1:1:0712/103517.983181:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.m.yiche.com/maiteng/"
[1:1:0712/103517.983450:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103517.983548:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103517.984073:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1d2e65ca29c8, 0x1a5a7072e150
[1:1:0712/103517.984154:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.m.yiche.com/maiteng/", 100
[1:1:0712/103517.984318:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://image.bitautoimg.com/, 1800
[1:1:0712/103517.984422:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1800 0x7f3a00974070 0x1a5a71597360 , 5:4_http://image.bitautoimg.com/, 1, -5:3_http://car.m.yiche.com/, 1769 0x7f3a00974070 0x1a5a752e9de0 
[1:1:0712/103518.406175:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://image.bitautoimg.com/, 1800, 7f3a032b9881
[1:1:0712/103518.434008:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1f831a402860","ptid":"1769 0x7f3a00974070 0x1a5a752e9de0 ","rf":"5:4_http://image.bitautoimg.com/"}
[1:1:0712/103518.434194:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.m.yiche.com/","ptid":"1769 0x7f3a00974070 0x1a5a752e9de0 ","rf":"5:4_http://image.bitautoimg.com/"}
[1:1:0712/103518.434385:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.m.yiche.com/maiteng/"
[1:1:0712/103518.434655:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103518.434754:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103518.435282:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1d2e65ca29c8, 0x1a5a7072e150
[1:1:0712/103518.435373:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.m.yiche.com/maiteng/", 100
[1:1:0712/103518.435540:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://image.bitautoimg.com/, 1811
[1:1:0712/103518.435642:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1811 0x7f3a00974070 0x1a5a71989860 , 5:4_http://image.bitautoimg.com/, 1, -5:3_http://car.m.yiche.com/, 1800 0x7f3a00974070 0x1a5a71597360 
[1:1:0712/103518.692831:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://image.bitautoimg.com/, 1811, 7f3a032b9881
[1:1:0712/103518.719635:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1f831a402860","ptid":"1800 0x7f3a00974070 0x1a5a71597360 ","rf":"5:4_http://image.bitautoimg.com/"}
[1:1:0712/103518.719824:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.m.yiche.com/","ptid":"1800 0x7f3a00974070 0x1a5a71597360 ","rf":"5:4_http://image.bitautoimg.com/"}
[1:1:0712/103518.720017:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.m.yiche.com/maiteng/"
[1:1:0712/103518.720293:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103518.720409:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103518.720969:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1d2e65ca29c8, 0x1a5a7072e150
[1:1:0712/103518.721068:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.m.yiche.com/maiteng/", 100
[1:1:0712/103518.721220:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://image.bitautoimg.com/, 1818
[1:1:0712/103518.721328:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1818 0x7f3a00974070 0x1a5a70668ae0 , 5:4_http://image.bitautoimg.com/, 1, -5:3_http://car.m.yiche.com/, 1811 0x7f3a00974070 0x1a5a71989860 
[1:1:0712/103518.893283:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://image.bitautoimg.com/, 1818, 7f3a032b9881
[1:1:0712/103518.921156:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1f831a402860","ptid":"1811 0x7f3a00974070 0x1a5a71989860 ","rf":"5:4_http://image.bitautoimg.com/"}
[1:1:0712/103518.921324:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.m.yiche.com/","ptid":"1811 0x7f3a00974070 0x1a5a71989860 ","rf":"5:4_http://image.bitautoimg.com/"}
[1:1:0712/103518.921510:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.m.yiche.com/maiteng/"
[1:1:0712/103518.921789:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103518.921887:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103518.923780:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1d2e65ca29c8, 0x1a5a7072e150
[1:1:0712/103518.923874:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.m.yiche.com/maiteng/", 100
[1:1:0712/103518.924041:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://image.bitautoimg.com/, 1827
[1:1:0712/103518.924143:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1827 0x7f3a00974070 0x1a5a70932760 , 5:4_http://image.bitautoimg.com/, 1, -5:3_http://car.m.yiche.com/, 1818 0x7f3a00974070 0x1a5a70668ae0 
[1:1:0712/103519.040017:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://image.bitautoimg.com/, 1827, 7f3a032b9881
[1:1:0712/103519.073103:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1f831a402860","ptid":"1818 0x7f3a00974070 0x1a5a70668ae0 ","rf":"5:4_http://image.bitautoimg.com/"}
[1:1:0712/103519.073332:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.m.yiche.com/","ptid":"1818 0x7f3a00974070 0x1a5a70668ae0 ","rf":"5:4_http://image.bitautoimg.com/"}
[1:1:0712/103519.073577:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.m.yiche.com/maiteng/"
[1:1:0712/103519.073912:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103519.074046:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103519.074666:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1d2e65ca29c8, 0x1a5a7072e150
[1:1:0712/103519.074771:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.m.yiche.com/maiteng/", 100
[1:1:0712/103519.074962:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://image.bitautoimg.com/, 1833
[1:1:0712/103519.075070:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1833 0x7f3a00974070 0x1a5a74cb4960 , 5:4_http://image.bitautoimg.com/, 1, -5:3_http://car.m.yiche.com/, 1827 0x7f3a00974070 0x1a5a70932760 
[1:1:0712/103519.250614:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://image.bitautoimg.com/, 1833, 7f3a032b9881
[1:1:0712/103519.280906:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1f831a402860","ptid":"1827 0x7f3a00974070 0x1a5a70932760 ","rf":"5:4_http://image.bitautoimg.com/"}
[1:1:0712/103519.281135:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.m.yiche.com/","ptid":"1827 0x7f3a00974070 0x1a5a70932760 ","rf":"5:4_http://image.bitautoimg.com/"}
[1:1:0712/103519.281356:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.m.yiche.com/maiteng/"
[1:1:0712/103519.281669:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103519.281797:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103519.282389:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1d2e65ca29c8, 0x1a5a7072e150
[1:1:0712/103519.282504:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.m.yiche.com/maiteng/", 100
[1:1:0712/103519.282699:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://image.bitautoimg.com/, 1843
[1:1:0712/103519.282826:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1843 0x7f3a00974070 0x1a5a71fb3160 , 5:4_http://image.bitautoimg.com/, 1, -5:3_http://car.m.yiche.com/, 1833 0x7f3a00974070 0x1a5a74cb4960 
[1:1:0712/103519.410065:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://image.bitautoimg.com/, 1843, 7f3a032b9881
[1:1:0712/103519.439571:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1f831a402860","ptid":"1833 0x7f3a00974070 0x1a5a74cb4960 ","rf":"5:4_http://image.bitautoimg.com/"}
[1:1:0712/103519.439783:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.m.yiche.com/","ptid":"1833 0x7f3a00974070 0x1a5a74cb4960 ","rf":"5:4_http://image.bitautoimg.com/"}
[1:1:0712/103519.440030:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.m.yiche.com/maiteng/"
[1:1:0712/103519.440395:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103519.440510:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103519.441166:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1d2e65ca29c8, 0x1a5a7072e150
[1:1:0712/103519.441263:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.m.yiche.com/maiteng/", 100
[1:1:0712/103519.441476:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://image.bitautoimg.com/, 1847
[1:1:0712/103519.441598:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1847 0x7f3a00974070 0x1a5a71d2eae0 , 5:4_http://image.bitautoimg.com/, 1, -5:3_http://car.m.yiche.com/, 1843 0x7f3a00974070 0x1a5a71fb3160 
[1:1:0712/103519.569516:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://image.bitautoimg.com/, 1847, 7f3a032b9881
[1:1:0712/103519.595817:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1f831a402860","ptid":"1843 0x7f3a00974070 0x1a5a71fb3160 ","rf":"5:4_http://image.bitautoimg.com/"}
[1:1:0712/103519.596038:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.m.yiche.com/","ptid":"1843 0x7f3a00974070 0x1a5a71fb3160 ","rf":"5:4_http://image.bitautoimg.com/"}
[1:1:0712/103519.596241:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.m.yiche.com/maiteng/"
[1:1:0712/103519.596506:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103519.596610:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103519.597235:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1d2e65ca29c8, 0x1a5a7072e150
[1:1:0712/103519.597374:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.m.yiche.com/maiteng/", 100
[1:1:0712/103519.597678:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://image.bitautoimg.com/, 1851
[1:1:0712/103519.597843:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1851 0x7f3a00974070 0x1a5a73d65ae0 , 5:4_http://image.bitautoimg.com/, 1, -5:3_http://car.m.yiche.com/, 1847 0x7f3a00974070 0x1a5a71d2eae0 
[1:1:0712/103519.727682:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://image.bitautoimg.com/, 1851, 7f3a032b9881
[1:1:0712/103519.753945:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1f831a402860","ptid":"1847 0x7f3a00974070 0x1a5a71d2eae0 ","rf":"5:4_http://image.bitautoimg.com/"}
[1:1:0712/103519.754160:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.m.yiche.com/","ptid":"1847 0x7f3a00974070 0x1a5a71d2eae0 ","rf":"5:4_http://image.bitautoimg.com/"}
[1:1:0712/103519.754388:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.m.yiche.com/maiteng/"
[1:1:0712/103519.754707:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103519.754854:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103519.755424:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1d2e65ca29c8, 0x1a5a7072e150
[1:1:0712/103519.755530:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.m.yiche.com/maiteng/", 100
[1:1:0712/103519.755705:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://image.bitautoimg.com/, 1854
[1:1:0712/103519.755811:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1854 0x7f3a00974070 0x1a5a7093e0e0 , 5:4_http://image.bitautoimg.com/, 1, -5:3_http://car.m.yiche.com/, 1851 0x7f3a00974070 0x1a5a73d65ae0 
[1:1:0712/103519.887253:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://image.bitautoimg.com/, 1854, 7f3a032b9881
[1:1:0712/103519.917613:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1f831a402860","ptid":"1851 0x7f3a00974070 0x1a5a73d65ae0 ","rf":"5:4_http://image.bitautoimg.com/"}
[1:1:0712/103519.917837:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.m.yiche.com/","ptid":"1851 0x7f3a00974070 0x1a5a73d65ae0 ","rf":"5:4_http://image.bitautoimg.com/"}
[1:1:0712/103519.918052:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.m.yiche.com/maiteng/"
[1:1:0712/103519.918355:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103519.918481:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103519.919204:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1d2e65ca29c8, 0x1a5a7072e150
[1:1:0712/103519.919321:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.m.yiche.com/maiteng/", 100
[1:1:0712/103519.919504:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://image.bitautoimg.com/, 1856
[1:1:0712/103519.919617:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1856 0x7f3a00974070 0x1a5a7543cf60 , 5:4_http://image.bitautoimg.com/, 1, -5:3_http://car.m.yiche.com/, 1854 0x7f3a00974070 0x1a5a7093e0e0 
[1:1:0712/103520.048383:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://image.bitautoimg.com/, 1856, 7f3a032b9881
[1:1:0712/103520.079051:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1f831a402860","ptid":"1854 0x7f3a00974070 0x1a5a7093e0e0 ","rf":"5:4_http://image.bitautoimg.com/"}
[1:1:0712/103520.079294:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.m.yiche.com/","ptid":"1854 0x7f3a00974070 0x1a5a7093e0e0 ","rf":"5:4_http://image.bitautoimg.com/"}
[1:1:0712/103520.079529:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.m.yiche.com/maiteng/"
[1:1:0712/103520.079851:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103520.079984:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103520.080557:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1d2e65ca29c8, 0x1a5a7072e150
[1:1:0712/103520.080675:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.m.yiche.com/maiteng/", 100
[1:1:0712/103520.080827:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://image.bitautoimg.com/, 1858
[1:1:0712/103520.080909:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1858 0x7f3a00974070 0x1a5a710c9560 , 5:4_http://image.bitautoimg.com/, 1, -5:3_http://car.m.yiche.com/, 1856 0x7f3a00974070 0x1a5a7543cf60 
[1:1:0712/103520.208455:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://image.bitautoimg.com/, 1858, 7f3a032b9881
[1:1:0712/103520.234463:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1f831a402860","ptid":"1856 0x7f3a00974070 0x1a5a7543cf60 ","rf":"5:4_http://image.bitautoimg.com/"}
[1:1:0712/103520.234730:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.m.yiche.com/","ptid":"1856 0x7f3a00974070 0x1a5a7543cf60 ","rf":"5:4_http://image.bitautoimg.com/"}
[1:1:0712/103520.234972:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.m.yiche.com/maiteng/"
[1:1:0712/103520.235303:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103520.235460:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103520.236065:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1d2e65ca29c8, 0x1a5a7072e150
[1:1:0712/103520.236176:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.m.yiche.com/maiteng/", 100
[1:1:0712/103520.236348:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://image.bitautoimg.com/, 1860
[1:1:0712/103520.236453:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1860 0x7f3a00974070 0x1a5a7184e260 , 5:4_http://image.bitautoimg.com/, 1, -5:3_http://car.m.yiche.com/, 1858 0x7f3a00974070 0x1a5a710c9560 
[1:1:0712/103520.364650:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://image.bitautoimg.com/, 1860, 7f3a032b9881
[1:1:0712/103520.390987:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1f831a402860","ptid":"1858 0x7f3a00974070 0x1a5a710c9560 ","rf":"5:4_http://image.bitautoimg.com/"}
[1:1:0712/103520.391205:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.m.yiche.com/","ptid":"1858 0x7f3a00974070 0x1a5a710c9560 ","rf":"5:4_http://image.bitautoimg.com/"}
[1:1:0712/103520.391434:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.m.yiche.com/maiteng/"
[1:1:0712/103520.391753:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103520.391901:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103520.392489:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1d2e65ca29c8, 0x1a5a7072e150
[1:1:0712/103520.392570:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.m.yiche.com/maiteng/", 100
[1:1:0712/103520.392709:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://image.bitautoimg.com/, 1862
[1:1:0712/103520.392785:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1862 0x7f3a00974070 0x1a5a72fa5ce0 , 5:4_http://image.bitautoimg.com/, 1, -5:3_http://car.m.yiche.com/, 1860 0x7f3a00974070 0x1a5a7184e260 
[1:1:0712/103520.522637:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://image.bitautoimg.com/, 1862, 7f3a032b9881
[1:1:0712/103520.553774:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1f831a402860","ptid":"1860 0x7f3a00974070 0x1a5a7184e260 ","rf":"5:4_http://image.bitautoimg.com/"}
[1:1:0712/103520.554020:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.m.yiche.com/","ptid":"1860 0x7f3a00974070 0x1a5a7184e260 ","rf":"5:4_http://image.bitautoimg.com/"}
[1:1:0712/103520.554275:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.m.yiche.com/maiteng/"
[1:1:0712/103520.554607:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103520.554762:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103520.555429:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1d2e65ca29c8, 0x1a5a7072e150
[1:1:0712/103520.555529:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.m.yiche.com/maiteng/", 100
[1:1:0712/103520.555697:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://image.bitautoimg.com/, 1864
[1:1:0712/103520.555811:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1864 0x7f3a00974070 0x1a5a71ace2e0 , 5:4_http://image.bitautoimg.com/, 1, -5:3_http://car.m.yiche.com/, 1862 0x7f3a00974070 0x1a5a72fa5ce0 
[1:1:0712/103520.683978:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://image.bitautoimg.com/, 1864, 7f3a032b9881
[1:1:0712/103520.715392:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1f831a402860","ptid":"1862 0x7f3a00974070 0x1a5a72fa5ce0 ","rf":"5:4_http://image.bitautoimg.com/"}
[1:1:0712/103520.715658:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.m.yiche.com/","ptid":"1862 0x7f3a00974070 0x1a5a72fa5ce0 ","rf":"5:4_http://image.bitautoimg.com/"}
[1:1:0712/103520.715930:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.m.yiche.com/maiteng/"
[1:1:0712/103520.716263:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103520.716391:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103520.716936:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1d2e65ca29c8, 0x1a5a7072e150
[1:1:0712/103520.717006:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.m.yiche.com/maiteng/", 100
[1:1:0712/103520.717213:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://image.bitautoimg.com/, 1867
[1:1:0712/103520.717336:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1867 0x7f3a00974070 0x1a5a74c0f3e0 , 5:4_http://image.bitautoimg.com/, 1, -5:3_http://car.m.yiche.com/, 1864 0x7f3a00974070 0x1a5a71ace2e0 
[1:1:0712/103520.845641:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://image.bitautoimg.com/, 1867, 7f3a032b9881
[1:1:0712/103520.872161:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1f831a402860","ptid":"1864 0x7f3a00974070 0x1a5a71ace2e0 ","rf":"5:4_http://image.bitautoimg.com/"}
[1:1:0712/103520.872393:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.m.yiche.com/","ptid":"1864 0x7f3a00974070 0x1a5a71ace2e0 ","rf":"5:4_http://image.bitautoimg.com/"}
[1:1:0712/103520.872626:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.m.yiche.com/maiteng/"
[1:1:0712/103520.872900:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103520.872995:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103520.873518:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1d2e65ca29c8, 0x1a5a7072e150
[1:1:0712/103520.873668:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.m.yiche.com/maiteng/", 100
[1:1:0712/103520.873896:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://image.bitautoimg.com/, 1869
[1:1:0712/103520.874059:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1869 0x7f3a00974070 0x1a5a71a80de0 , 5:4_http://image.bitautoimg.com/, 1, -5:3_http://car.m.yiche.com/, 1867 0x7f3a00974070 0x1a5a74c0f3e0 
[1:1:0712/103521.001729:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://image.bitautoimg.com/, 1869, 7f3a032b9881
[1:1:0712/103521.028128:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1f831a402860","ptid":"1867 0x7f3a00974070 0x1a5a74c0f3e0 ","rf":"5:4_http://image.bitautoimg.com/"}
[1:1:0712/103521.028350:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.m.yiche.com/","ptid":"1867 0x7f3a00974070 0x1a5a74c0f3e0 ","rf":"5:4_http://image.bitautoimg.com/"}
[1:1:0712/103521.028595:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.m.yiche.com/maiteng/"
[1:1:0712/103521.028859:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103521.028948:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103521.029479:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1d2e65ca29c8, 0x1a5a7072e150
[1:1:0712/103521.029616:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.m.yiche.com/maiteng/", 100
[1:1:0712/103521.029835:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://image.bitautoimg.com/, 1871
[1:1:0712/103521.029988:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1871 0x7f3a00974070 0x1a5a712c7260 , 5:4_http://image.bitautoimg.com/, 1, -5:3_http://car.m.yiche.com/, 1869 0x7f3a00974070 0x1a5a71a80de0 
[1:1:0712/103521.159918:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://image.bitautoimg.com/, 1871, 7f3a032b9881
[1:1:0712/103521.190401:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1f831a402860","ptid":"1869 0x7f3a00974070 0x1a5a71a80de0 ","rf":"5:4_http://image.bitautoimg.com/"}
[1:1:0712/103521.190618:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.m.yiche.com/","ptid":"1869 0x7f3a00974070 0x1a5a71a80de0 ","rf":"5:4_http://image.bitautoimg.com/"}
[1:1:0712/103521.190854:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.m.yiche.com/maiteng/"
[1:1:0712/103521.191199:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103521.191346:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103521.191957:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1d2e65ca29c8, 0x1a5a7072e150
[1:1:0712/103521.192061:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.m.yiche.com/maiteng/", 100
[1:1:0712/103521.192223:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://image.bitautoimg.com/, 1873
[1:1:0712/103521.192370:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1873 0x7f3a00974070 0x1a5a70cd9260 , 5:4_http://image.bitautoimg.com/, 1, -5:3_http://car.m.yiche.com/, 1871 0x7f3a00974070 0x1a5a712c7260 
[1:1:0712/103521.319343:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://image.bitautoimg.com/, 1873, 7f3a032b9881
[1:1:0712/103521.351722:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1f831a402860","ptid":"1871 0x7f3a00974070 0x1a5a712c7260 ","rf":"5:4_http://image.bitautoimg.com/"}
[1:1:0712/103521.351968:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.m.yiche.com/","ptid":"1871 0x7f3a00974070 0x1a5a712c7260 ","rf":"5:4_http://image.bitautoimg.com/"}
[1:1:0712/103521.352243:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.m.yiche.com/maiteng/"
[1:1:0712/103521.352557:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103521.352662:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103521.353278:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1d2e65ca29c8, 0x1a5a7072e150
[1:1:0712/103521.353424:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.m.yiche.com/maiteng/", 100
[1:1:0712/103521.353655:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://image.bitautoimg.com/, 1875
[1:1:0712/103521.353818:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1875 0x7f3a00974070 0x1a5a7542e0e0 , 5:4_http://image.bitautoimg.com/, 1, -5:3_http://car.m.yiche.com/, 1873 0x7f3a00974070 0x1a5a70cd9260 
[1:1:0712/103521.481788:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://image.bitautoimg.com/, 1875, 7f3a032b9881
[1:1:0712/103521.508665:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1f831a402860","ptid":"1873 0x7f3a00974070 0x1a5a70cd9260 ","rf":"5:4_http://image.bitautoimg.com/"}
[1:1:0712/103521.508884:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.m.yiche.com/","ptid":"1873 0x7f3a00974070 0x1a5a70cd9260 ","rf":"5:4_http://image.bitautoimg.com/"}
[1:1:0712/103521.509105:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.m.yiche.com/maiteng/"
[1:1:0712/103521.509437:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103521.509600:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103521.510189:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1d2e65ca29c8, 0x1a5a7072e150
[1:1:0712/103521.510338:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.m.yiche.com/maiteng/", 100
[1:1:0712/103521.510529:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://image.bitautoimg.com/, 1877
[1:1:0712/103521.510613:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1877 0x7f3a00974070 0x1a5a71ad0960 , 5:4_http://image.bitautoimg.com/, 1, -5:3_http://car.m.yiche.com/, 1875 0x7f3a00974070 0x1a5a7542e0e0 
[1:1:0712/103521.639438:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://image.bitautoimg.com/, 1877, 7f3a032b9881
[1:1:0712/103521.666863:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1f831a402860","ptid":"1875 0x7f3a00974070 0x1a5a7542e0e0 ","rf":"5:4_http://image.bitautoimg.com/"}
[1:1:0712/103521.667089:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.m.yiche.com/","ptid":"1875 0x7f3a00974070 0x1a5a7542e0e0 ","rf":"5:4_http://image.bitautoimg.com/"}
[1:1:0712/103521.667325:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.m.yiche.com/maiteng/"
[1:1:0712/103521.667649:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103521.667823:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103521.668389:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1d2e65ca29c8, 0x1a5a7072e150
[1:1:0712/103521.668498:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.m.yiche.com/maiteng/", 100
[1:1:0712/103521.668664:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://image.bitautoimg.com/, 1879
[1:1:0712/103521.668745:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1879 0x7f3a00974070 0x1a5a71ad0560 , 5:4_http://image.bitautoimg.com/, 1, -5:3_http://car.m.yiche.com/, 1877 0x7f3a00974070 0x1a5a71ad0960 
[1:1:0712/103521.799961:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://image.bitautoimg.com/, 1879, 7f3a032b9881
[1:1:0712/103521.829234:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1f831a402860","ptid":"1877 0x7f3a00974070 0x1a5a71ad0960 ","rf":"5:4_http://image.bitautoimg.com/"}
[1:1:0712/103521.829454:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.m.yiche.com/","ptid":"1877 0x7f3a00974070 0x1a5a71ad0960 ","rf":"5:4_http://image.bitautoimg.com/"}
[1:1:0712/103521.829691:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.m.yiche.com/maiteng/"
[1:1:0712/103521.830010:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103521.830165:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103521.830735:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1d2e65ca29c8, 0x1a5a7072e150
[1:1:0712/103521.830841:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.m.yiche.com/maiteng/", 100
[1:1:0712/103521.831018:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://image.bitautoimg.com/, 1881
[1:1:0712/103521.831137:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1881 0x7f3a00974070 0x1a5a7198b660 , 5:4_http://image.bitautoimg.com/, 1, -5:3_http://car.m.yiche.com/, 1879 0x7f3a00974070 0x1a5a71ad0560 
[1:1:0712/103521.967799:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://image.bitautoimg.com/, 1881, 7f3a032b9881
[1:1:0712/103521.997552:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1f831a402860","ptid":"1879 0x7f3a00974070 0x1a5a71ad0560 ","rf":"5:4_http://image.bitautoimg.com/"}
[1:1:0712/103521.997810:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.m.yiche.com/","ptid":"1879 0x7f3a00974070 0x1a5a71ad0560 ","rf":"5:4_http://image.bitautoimg.com/"}
[1:1:0712/103521.998048:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.m.yiche.com/maiteng/"
[1:1:0712/103521.998377:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103521.998515:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103521.999068:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1d2e65ca29c8, 0x1a5a7072e150
[1:1:0712/103521.999213:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.m.yiche.com/maiteng/", 100
[1:1:0712/103521.999416:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://image.bitautoimg.com/, 1883
[1:1:0712/103521.999544:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1883 0x7f3a00974070 0x1a5a71850560 , 5:4_http://image.bitautoimg.com/, 1, -5:3_http://car.m.yiche.com/, 1881 0x7f3a00974070 0x1a5a7198b660 
[1:1:0712/103522.133356:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://image.bitautoimg.com/, 1883, 7f3a032b9881
[1:1:0712/103522.161239:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1f831a402860","ptid":"1881 0x7f3a00974070 0x1a5a7198b660 ","rf":"5:4_http://image.bitautoimg.com/"}
[1:1:0712/103522.161498:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.m.yiche.com/","ptid":"1881 0x7f3a00974070 0x1a5a7198b660 ","rf":"5:4_http://image.bitautoimg.com/"}
[1:1:0712/103522.161749:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.m.yiche.com/maiteng/"
[1:1:0712/103522.162109:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.m.yiche.com/, 1f831a402860, , f, () {
            fRef.apply(null, argu);
        }
[1:1:0712/103522.162279:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.m.yiche.com/maiteng/", "car.m.yiche.com", 3, 1, , , 0
[1:1:0712/103522.162967:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1d2e65ca29c8, 0x1a5a7072e150
[1:1:0712/103522.163071:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.m.yiche.com/maiteng/", 100
[1:1:0712/103522.163257:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://image.bitautoimg.com/, 1885
[1:1:0712/103522.163377:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1885 0x7f3a00974070 0x1a5a70667360 , 5:4_http://image.bitautoimg.com/, 1, -5:3_http://car.m.yiche.com/, 1883 0x7f3a00974070 0x1a5a71850560 
