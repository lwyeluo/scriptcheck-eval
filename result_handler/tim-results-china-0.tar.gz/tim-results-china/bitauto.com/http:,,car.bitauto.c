[0712/103830.062624:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/103830.062931:INFO:switcher_clone.cc(787)] backtrace rip is 7faa95b64891
[0712/103830.642782:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/103830.643028:INFO:switcher_clone.cc(787)] backtrace rip is 7f3bfe7b4891
[1:1:0712/103830.646832:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/103830.646993:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/103830.649799:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[29202:29202:0712/103831.548946:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/84988724-dd58-469d-a3e9-bf64db605af8
[0712/103831.645184:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/103831.645450:INFO:switcher_clone.cc(787)] backtrace rip is 7fb56c426891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[29233:29233:0712/103831.887443:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=29233
[29246:29246:0712/103831.896523:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=29246
[29202:29202:0712/103831.927583:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[29202:29230:0712/103831.931841:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/103831.932010:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/103831.932144:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/103831.932411:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/103831.932503:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/103831.934160:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x2a812e95, 1
[1:1:0712/103831.934348:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x21adab7e, 0
[1:1:0712/103831.934440:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x297f8952, 3
[1:1:0712/103831.934533:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x301b9e5b, 2
[1:1:0712/103831.934622:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 7effffffabffffffad21 ffffff952effffff812a 5bffffff9e1b30 52ffffff897f29 , 10104, 4
[1:1:0712/103831.935308:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[29202:29230:0712/103831.935429:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING~��!�.�*[�0R�)푼-
[29202:29230:0712/103831.935469:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ~��!�.�*[�0R�)�Y푼-
[29202:29230:0712/103831.935602:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[29202:29230:0712/103831.935632:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 29254, 4, 7eabad21 952e812a 5b9e1b30 52897f29 
[1:1:0712/103831.935791:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f3bfc9ee0a0, 3
[1:1:0712/103831.935929:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f3bfcb7a080, 2
[1:1:0712/103831.936030:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f3be683cd20, -2
[1:1:0712/103831.943476:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/103831.943924:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 301b9e5b
[1:1:0712/103831.944363:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 301b9e5b
[1:1:0712/103831.945188:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 301b9e5b
[1:1:0712/103831.945733:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 301b9e5b
[1:1:0712/103831.945863:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 301b9e5b
[1:1:0712/103831.945978:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 301b9e5b
[1:1:0712/103831.946093:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 301b9e5b
[1:1:0712/103831.946361:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 301b9e5b
[1:1:0712/103831.946507:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f3bfe7b47ba
[1:1:0712/103831.946590:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f3bfe7abdef, 7f3bfe7b477a, 7f3bfe7b60cf
[1:1:0712/103831.948213:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 301b9e5b
[1:1:0712/103831.948389:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 301b9e5b
[1:1:0712/103831.948691:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 301b9e5b
[1:1:0712/103831.949472:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 301b9e5b
[1:1:0712/103831.949591:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 301b9e5b
[1:1:0712/103831.949707:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 301b9e5b
[1:1:0712/103831.949819:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 301b9e5b
[1:1:0712/103831.950445:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 301b9e5b
[1:1:0712/103831.950618:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f3bfe7b47ba
[1:1:0712/103831.950716:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f3bfe7abdef, 7f3bfe7b477a, 7f3bfe7b60cf
[1:1:0712/103831.953834:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/103831.954059:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/103831.954159:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffff58b9198, 0x7ffff58b9118)
[1:1:0712/103831.961061:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/103831.964972:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[29202:29202:0712/103832.397463:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[29202:29202:0712/103832.398001:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[29202:29213:0712/103832.406364:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[29202:29213:0712/103832.406428:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[29202:29202:0712/103832.406438:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[29202:29202:0712/103832.406480:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[29202:29202:0712/103832.406548:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,29254, 4
[1:7:0712/103832.407285:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[29202:29226:0712/103832.459419:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/103832.459042:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x255cfe8f9220
[1:1:0712/103832.460151:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/103832.662120:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[29202:29213:0712/103832.873400:ERROR:ssl_client_socket_impl.cc(1046)] handshake failed; returned -1, SSL error code 1, net_error -101
[29202:29202:0712/103833.357662:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[29202:29202:0712/103833.357736:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/103833.366886:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/103833.368508:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/103833.827169:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3e95d1061f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/103833.827351:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/103833.836539:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3e95d1061f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/103833.836673:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/103833.854941:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/103833.999782:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/103833.999935:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/103834.170824:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 363, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/103834.173324:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3e95d1061f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/103834.173465:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/103834.185684:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 364, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/103834.188634:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3e95d1061f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/103834.188744:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/103834.192503:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[29202:29202:0712/103834.193157:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/103834.194257:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x255cfe8f7e20
[1:1:0712/103834.195081:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[29202:29202:0712/103834.195551:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[29202:29202:0712/103834.207619:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[29202:29202:0712/103834.207707:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/103834.227537:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/103834.585911:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 425 0x7f3be84172e0 0x255cfeafa460 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/103834.586713:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3e95d1061f78, , , var configData = {"googleBaseUrl":"https://www.google.com.hk/","isAccessibleBrowser":false,"isGoogle
[1:1:0712/103834.586879:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/103834.587532:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[29202:29202:0712/103834.615830:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/103834.616903:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x255cfe8f8820
[1:1:0712/103834.617342:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[29202:29202:0712/103834.618760:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/103834.624397:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/103834.624550:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[29202:29202:0712/103834.625429:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[29202:29202:0712/103834.632311:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[29202:29202:0712/103834.633393:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[29202:29213:0712/103834.638191:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[29202:29213:0712/103834.638249:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[29202:29202:0712/103834.638280:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[29202:29202:0712/103834.638324:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[29202:29202:0712/103834.638383:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,29254, 4
[1:7:0712/103834.641295:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/103834.924882:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[29202:29202:0712/103835.072564:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[29202:29230:0712/103835.072861:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/103835.072986:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/103835.073133:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/103835.073324:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/103835.073399:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/103835.075516:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x22bd679b, 1
[1:1:0712/103835.075715:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x2b73a98d, 0
[1:1:0712/103835.075806:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x15d4de3, 3
[1:1:0712/103835.075914:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x4cd1689, 2
[1:1:0712/103835.076000:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffff8dffffffa9732b ffffff9b67ffffffbd22 ffffff8916ffffffcd04 ffffffe34d5d01 , 10104, 5
[1:1:0712/103835.076706:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[29202:29230:0712/103835.076901:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING��s+�g�"���M]i��-
[29202:29230:0712/103835.076947:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ��s+�g�"���M]8ni��-
[1:1:0712/103835.076896:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f3bfc9ee0a0, 3
[29202:29230:0712/103835.077095:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 29301, 5, 8da9732b 9b67bd22 8916cd04 e34d5d01 
[1:1:0712/103835.077086:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f3bfcb7a080, 2
[1:1:0712/103835.077183:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f3be683cd20, -2
[1:1:0712/103835.084083:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 478 0x7f3be84172e0 0x255cfe99bd60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/103835.086232:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/103835.087113:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3e95d1061f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/103835.087255:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/103835.087363:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 4cd1689
[1:1:0712/103835.087644:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/103835.087962:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 4cd1689
[1:1:0712/103835.088261:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 4cd1689
[1:1:0712/103835.088783:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 4cd1689
[1:1:0712/103835.088875:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 4cd1689
[1:1:0712/103835.088944:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 4cd1689
[1:1:0712/103835.089013:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 4cd1689
[1:1:0712/103835.089292:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 4cd1689
[1:1:0712/103835.089445:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f3bfe7b47ba
[1:1:0712/103835.089769:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f3bfe7abdef, 7f3bfe7b477a, 7f3bfe7b60cf
[1:1:0712/103835.091511:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 4cd1689
[1:1:0712/103835.091740:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 4cd1689
[1:1:0712/103835.092120:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 4cd1689
[1:1:0712/103835.092917:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 4cd1689
[1:1:0712/103835.093024:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 4cd1689
[1:1:0712/103835.093131:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 4cd1689
[1:1:0712/103835.093206:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 4cd1689
[1:1:0712/103835.093686:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 4cd1689
[1:1:0712/103835.093836:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f3bfe7b47ba
[1:1:0712/103835.093923:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f3bfe7abdef, 7f3bfe7b477a, 7f3bfe7b60cf
[1:1:0712/103835.096530:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/103835.096819:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/103835.096947:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffff58b9198, 0x7ffff58b9118)
[1:1:0712/103835.103273:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/103835.106023:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/103835.214236:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x255cfe8a1220
[1:1:0712/103835.214399:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/103835.262979:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[29202:29202:0712/103835.270774:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[29202:29202:0712/103835.270840:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[29202:29202:0712/103835.428110:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[29202:29202:0712/103835.430407:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[29202:29202:0712/103835.441412:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://car.bitauto.com/
[29202:29202:0712/103835.441479:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://car.bitauto.com/, http://car.bitauto.com/suv/z/, 1
[29202:29202:0712/103835.441552:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://car.bitauto.com/, HTTP/1.1 200 OK Server: Tengine Date: Fri, 12 Jul 2019 02:38:33 GMT Content-Type: text/html; charset=utf-8 Content-Length: 15420 Connection: keep-alive Cache-Control: public, max-age=1800 Content-Encoding: gzip Vary: Accept-Encoding Age: 1135 X-Cache: HIT from QD-5701.cdn.bitautotech.com X-Cache: MISS from ycbj14601.bitautotech.com  ,29301, 5
[29202:29213:0712/103835.441860:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[29202:29213:0712/103835.441915:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[1:7:0712/103835.442750:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/103835.470275:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://car.bitauto.com/
[1:1:0712/103835.524736:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[29202:29202:0712/103835.552838:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://car.bitauto.com/, http://car.bitauto.com/, 1
[29202:29202:0712/103835.552899:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://car.bitauto.com/, http://car.bitauto.com
[1:1:0712/103835.560667:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/103835.598803:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/103835.643415:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/103835.643612:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://car.bitauto.com/suv/z/"
[1:1:0712/103835.907950:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/103835.908100:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/103835.968194:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 157 0x7f3be64ef070 0x255cfea360e0 , "http://car.bitauto.com/suv/z/"
[1:1:0712/103835.969018:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , , 
        var _SearchUrl = '/xuanchegongju/';
    
[1:1:0712/103835.969216:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "car.bitauto.com", 3, 1, , , 0
[1:1:0712/103835.970959:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 157 0x7f3be64ef070 0x255cfea360e0 , "http://car.bitauto.com/suv/z/"
[1:1:0712/103835.972188:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/103836.004011:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0344079, 221, 1
[1:1:0712/103836.004173:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/103836.144268:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/103836.144491:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://car.bitauto.com/suv/z/"
[1:1:0712/103836.146279:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 187 0x7f3be64ef070 0x255cfe5fb960 , "http://car.bitauto.com/suv/z/"
[1:1:0712/103836.148387:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , , (function(E){var F={templateSettings:{TemplateRegQueue:[{reg:/^\s*|\s$/g,func:""},{reg:/\r|\n|\t|\/\
[1:1:0712/103836.148515:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "car.bitauto.com", 3, 1, , , 0
[1:1:0712/103836.159768:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 187 0x7f3be64ef070 0x255cfe5fb960 , "http://car.bitauto.com/suv/z/"
[1:1:0712/103836.187187:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 187 0x7f3be64ef070 0x255cfe5fb960 , "http://car.bitauto.com/suv/z/"
[1:1:0712/103836.190341:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 187 0x7f3be64ef070 0x255cfe5fb960 , "http://car.bitauto.com/suv/z/"
[1:1:0712/103836.212338:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0678031, 140, 1
[1:1:0712/103836.212492:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/103836.459700:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/103836.459872:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://car.bitauto.com/suv/z/"
[1:1:0712/103836.460322:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 223 0x7f3be64ef070 0x255cfe8b1460 , "http://car.bitauto.com/suv/z/"
[1:1:0712/103836.460998:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , , 
    var BitNav_current_url = window.location.href;
    var BitNav_vc_url="http://vc.yiche.com/";
  
[1:1:0712/103836.461165:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "car.bitauto.com", 3, 1, , , 0
[1:1:0712/103836.475432:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 223 0x7f3be64ef070 0x255cfe8b1460 , "http://car.bitauto.com/suv/z/"
[1:1:0712/103836.477531:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 223 0x7f3be64ef070 0x255cfe8b1460 , "http://car.bitauto.com/suv/z/"
[1:1:0712/103836.482439:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 223 0x7f3be64ef070 0x255cfe8b1460 , "http://car.bitauto.com/suv/z/"
[1:1:0712/103836.903770:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 223 0x7f3be64ef070 0x255cfe8b1460 , "http://car.bitauto.com/suv/z/"
[1:1:0712/103836.911425:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 223 0x7f3be64ef070 0x255cfe8b1460 , "http://car.bitauto.com/suv/z/"
[1:1:0712/103837.052560:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.592663, 6, 0
[1:1:0712/103837.052745:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/103837.074581:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/103837.185432:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 244 0x7f3be84172e0 0x255cfe9d40e0 , "http://car.bitauto.com/suv/z/"
[1:1:0712/103837.186015:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , , /**/ typeof mabCallback66 === 'function' && mabCallback66({"Result":[{"BsId":3,"TagName":"https://im
[1:1:0712/103837.186145:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "car.bitauto.com", 3, 1, , , 0
[1:1:0712/103837.187134:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://car.bitauto.com/suv/z/"
[1:1:0712/103837.194174:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 245 0x7f3be84172e0 0x255cfe9aea60 , "http://car.bitauto.com/suv/z/"
[1:1:0712/103837.195340:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , , csCallback66([{"CsId":4229,"pbUrlPC":"http://item.mai.bitauto.com/45/?externalrfpa_tracker=17_28_1_1
[1:1:0712/103837.195457:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "car.bitauto.com", 3, 1, , , 0
[1:1:0712/103837.199146:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://car.bitauto.com/suv/z/"
[1:1:0712/103837.372544:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/103837.372703:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://car.bitauto.com/suv/z/"
[1:1:0712/103837.373970:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 275 0x7f3be64ef070 0x255cfeaee8e0 , "http://car.bitauto.com/suv/z/"
[1:1:0712/103837.374813:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , , function GetNewCarText(a){if(a==""){return;}var b="http://api.car.bitauto.com/carinfo/GetCarIntoMark
[1:1:0712/103837.374935:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "car.bitauto.com", 3, 1, , , 0
[1:1:0712/103837.376593:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 275 0x7f3be64ef070 0x255cfeaee8e0 , "http://car.bitauto.com/suv/z/"
[1:1:0712/103837.380153:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 275 0x7f3be64ef070 0x255cfeaee8e0 , "http://car.bitauto.com/suv/z/"
[1:1:0712/103837.386622:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 275 0x7f3be64ef070 0x255cfeaee8e0 , "http://car.bitauto.com/suv/z/"
[1:1:0712/103837.410017:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.037267, 560, 1
[1:1:0712/103837.410168:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/103837.430570:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 280 0x7f3be84172e0 0x255cfe749c60 , "http://car.bitauto.com/suv/z/"
[1:1:0712/103837.433404:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , , (function(){var h={},mt={},c={id:"7b86db06beda666182190f07e1af98e3",dm:["car.bitauto.com"],js:"tongj
[1:1:0712/103837.433532:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "car.bitauto.com", 3, 1, , , 0
[1:1:0712/103837.446438:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xd28ccf829c8, 0x255cfe734948
[1:1:0712/103837.446637:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.bitauto.com/suv/z/", 100
[1:1:0712/103837.446880:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 313
[1:1:0712/103837.447050:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 313 0x7f3be64ef070 0x255cfe4b4960 , 5:3_http://car.bitauto.com/, 1, -5:3_http://car.bitauto.com/, 280 0x7f3be84172e0 0x255cfe749c60 
[1:1:0712/103840.623963:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[3:3:0712/103842.639146:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/103843.023933:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 281 0x7f3be84172e0 0x255cff2151e0 , "http://car.bitauto.com/suv/z/"
[1:1:0712/103843.026347:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , , JsonpCallBack({char:{A:1,B:1,C:1,D:1,E:0,F:1,G:1,H:1,I:0,J:1,K:1,L:1,M:1,N:1,O:1,P:1,Q:1,R:1,S:1,T:1
[1:1:0712/103843.026470:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "car.bitauto.com", 3, 1, , , 0
[1:1:0712/103843.933245:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xd28ccf829c8, 0x255cfe734980
[1:1:0712/103843.933460:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.bitauto.com/suv/z/", 10
[1:1:0712/103843.933735:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 368
[1:1:0712/103843.933934:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 368 0x7f3be64ef070 0x255cff285460 , 5:3_http://car.bitauto.com/, 1, -5:3_http://car.bitauto.com/, 281 0x7f3be84172e0 0x255cff2151e0 
[1:1:0712/103844.202157:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://car.bitauto.com/suv/z/"
[1:1:0712/103844.575472:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/103844.575664:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://car.bitauto.com/suv/z/"
[1:1:0712/103844.576207:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 307 0x7f3be64ef070 0x255cfe951c60 , "http://car.bitauto.com/suv/z/"
[1:1:0712/103844.576759:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , , conditionObj.Level=15;

[1:1:0712/103844.576892:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "car.bitauto.com", 3, 1, , , 0
[1:1:0712/103844.580723:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.00511408, 51, 1
[1:1:0712/103844.580993:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/103844.702746:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/103844.702904:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "car.bitauto.com", 3, 1, , , 0
[1:1:0712/103845.289909:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 313, 7f3be8e34881
[1:1:0712/103845.300349:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"18a6e6b42860","ptid":"280 0x7f3be84172e0 0x255cfe749c60 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103845.300531:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.bitauto.com/","ptid":"280 0x7f3be84172e0 0x255cfe749c60 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103845.300738:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.bitauto.com/suv/z/"
[1:1:0712/103845.301071:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/103845.301201:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "car.bitauto.com", 3, 1, , , 0
[1:1:0712/103845.301638:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xd28ccf829c8, 0x255cfe734950
[1:1:0712/103845.301745:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.bitauto.com/suv/z/", 100
[1:1:0712/103845.301947:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 694
[1:1:0712/103845.302076:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 694 0x7f3be64ef070 0x255cff8eca60 , 5:3_http://car.bitauto.com/, 1, -5:3_http://car.bitauto.com/, 313 0x7f3be64ef070 0x255cfe4b4960 
[1:1:0712/103849.419810:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 368, 7f3be8e34881
[1:1:0712/103849.433711:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"18a6e6b42860","ptid":"281 0x7f3be84172e0 0x255cff2151e0 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103849.433934:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.bitauto.com/","ptid":"281 0x7f3be84172e0 0x255cff2151e0 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103849.434189:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.bitauto.com/suv/z/"
[1:1:0712/103849.434499:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , , () { self.mathTreeBoxHeight(false) }
[1:1:0712/103849.434632:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "car.bitauto.com", 3, 1, , , 0
[1:1:0712/103850.244068:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/103850.244215:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://car.bitauto.com/suv/z/"
[1:1:0712/103850.244668:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 631 0x7f3be64ef070 0x255cff843460 , "http://car.bitauto.com/suv/z/"
[1:1:0712/103850.245194:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , , 
    (function(global) {
        global.SidebarConfig={
            headerModules: ['my', 'collectCa
[1:1:0712/103850.245343:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "car.bitauto.com", 3, 1, , , 0
[1:1:0712/103850.247098:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 631 0x7f3be64ef070 0x255cff843460 , "http://car.bitauto.com/suv/z/"
[1:1:0712/103850.248694:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 631 0x7f3be64ef070 0x255cff843460 , "http://car.bitauto.com/suv/z/"
[1:1:0712/103850.251434:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 631 0x7f3be64ef070 0x255cff843460 , "http://car.bitauto.com/suv/z/"
[1:1:0712/103850.252654:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 631 0x7f3be64ef070 0x255cff843460 , "http://car.bitauto.com/suv/z/"
[1:1:0712/103850.256541:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.01228, 52, 1
[1:1:0712/103850.256685:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/103850.533720:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , , document.readyState
[1:1:0712/103850.533911:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "car.bitauto.com", 3, 1, , , 0
[1:1:0712/103852.311262:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://car.bitauto.com/suv/z/"
[1:1:0712/103852.311670:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , f.onload, (){f.onload=u;f=window[d]=u;a&&a(b)}
[1:1:0712/103852.311799:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "car.bitauto.com", 3, 1, , , 0
[1:1:0712/103852.315696:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 694, 7f3be8e34881
[1:1:0712/103852.332594:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"18a6e6b42860","ptid":"313 0x7f3be64ef070 0x255cfe4b4960 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103852.332777:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.bitauto.com/","ptid":"313 0x7f3be64ef070 0x255cfe4b4960 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103852.332970:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.bitauto.com/suv/z/"
[1:1:0712/103852.333274:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/103852.333391:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "car.bitauto.com", 3, 1, , , 0
[1:1:0712/103852.333696:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xd28ccf829c8, 0x255cfe734950
[1:1:0712/103852.333802:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.bitauto.com/suv/z/", 100
[1:1:0712/103852.333975:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 1065
[1:1:0712/103852.334092:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1065 0x7f3be64ef070 0x255cfe4b3160 , 5:3_http://car.bitauto.com/, 1, -5:3_http://car.bitauto.com/, 694 0x7f3be64ef070 0x255cff8eca60 
[1:1:0712/103852.410536:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 707 0x7f3be84172e0 0x255cfeb54be0 , "http://car.bitauto.com/suv/z/"
[1:1:0712/103852.411879:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , , getLikeCallback([{"CityId":201,"CsId":1909,"CsName":"迈腾","CsShowName":"迈腾","CsSpell":"maiten
[1:1:0712/103852.412006:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "car.bitauto.com", 3, 1, , , 0
[1:1:0712/103852.430006:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://car.bitauto.com/suv/z/"
[1:1:0712/103858.605709:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/103858.605877:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://car.bitauto.com/suv/z/"
[1:1:0712/103858.606419:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 930 0x7f3be64ef070 0x255cff27e660 , "http://car.bitauto.com/suv/z/"
[1:1:0712/103858.607163:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , , 
       

        (function(global) {
            var extend = function(target, extendObj) {
       
[1:1:0712/103858.607266:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "car.bitauto.com", 3, 1, , , 0
[1:1:0712/103858.612550:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 930 0x7f3be64ef070 0x255cff27e660 , "http://car.bitauto.com/suv/z/"
[1:1:0712/103858.634345:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 930 0x7f3be64ef070 0x255cff27e660 , "http://car.bitauto.com/suv/z/"
[1:1:0712/103858.636595:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 930 0x7f3be64ef070 0x255cff27e660 , "http://car.bitauto.com/suv/z/"
[1:1:0712/103858.654357:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 930 0x7f3be64ef070 0x255cff27e660 , "http://car.bitauto.com/suv/z/"
[1:1:0712/103858.661682:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 930 0x7f3be64ef070 0x255cff27e660 , "http://car.bitauto.com/suv/z/"
[1:1:0712/103858.682148:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 930 0x7f3be64ef070 0x255cff27e660 , "http://car.bitauto.com/suv/z/"
[1:1:0712/103858.686632:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 930 0x7f3be64ef070 0x255cff27e660 , "http://car.bitauto.com/suv/z/"
[1:1:0712/103858.689079:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 930 0x7f3be64ef070 0x255cff27e660 , "http://car.bitauto.com/suv/z/"
[1:1:0712/103858.695106:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.bitauto.com/suv/z/", 0
[1:1:0712/103858.695359:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 1391
[1:1:0712/103858.695466:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1391 0x7f3be64ef070 0x255cff02aa60 , 5:3_http://car.bitauto.com/, 1, -5:3_http://car.bitauto.com/, 930 0x7f3be64ef070 0x255cff27e660 
[1:1:0712/103858.743003:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 930 0x7f3be64ef070 0x255cff27e660 , "http://car.bitauto.com/suv/z/"
[1:1:0712/103859.452094:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , , document.readyState
[1:1:0712/103859.452282:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "car.bitauto.com", 3, 1, , , 0
[1:1:0712/103900.190677:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "http://car.bitauto.com/suv/z/"
[1:1:0712/103900.191097:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , module.mathScrollSettingTagBar, () { var scrollHeight = document.documentElement.scrollTop || document.body.scrollTop; var navBox = 
[1:1:0712/103900.191181:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "car.bitauto.com", 3, 1, , , 0
[1:1:0712/103900.191785:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xd28ccf829c8, 0x255cfe734a20
[1:1:0712/103900.191868:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.bitauto.com/suv/z/", 10
[1:1:0712/103900.192051:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 1417
[1:1:0712/103900.192155:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1417 0x7f3be64ef070 0x255cff5e7fe0 , 5:3_http://car.bitauto.com/, 1, -5:3_http://car.bitauto.com/, 968 0x7f3bf5800960 0x255cff8aab00 0x255cff8aab10 
[1:1:0712/103903.277371:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 1065, 7f3be8e34881
[1:1:0712/103903.301017:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"18a6e6b42860","ptid":"694 0x7f3be64ef070 0x255cff8eca60 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103903.301271:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.bitauto.com/","ptid":"694 0x7f3be64ef070 0x255cff8eca60 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103903.301526:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.bitauto.com/suv/z/"
[1:1:0712/103903.301878:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/103903.302011:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "car.bitauto.com", 3, 1, , , 0
[1:1:0712/103903.302383:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xd28ccf829c8, 0x255cfe734950
[1:1:0712/103903.302470:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.bitauto.com/suv/z/", 100
[1:1:0712/103903.302630:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 1428
[1:1:0712/103903.302744:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1428 0x7f3be64ef070 0x255cfe5388e0 , 5:3_http://car.bitauto.com/, 1, -5:3_http://car.bitauto.com/, 1065 0x7f3be64ef070 0x255cfe4b3160 
[1:1:0712/103913.182334:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 1391, 7f3be8e34881
[1:1:0712/103913.209741:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"18a6e6b42860","ptid":"930 0x7f3be64ef070 0x255cff27e660 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103913.209930:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.bitauto.com/","ptid":"930 0x7f3be64ef070 0x255cff27e660 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103913.210144:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.bitauto.com/suv/z/"
[1:1:0712/103913.210656:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , , gJsWtid.src="http://Webtrends.yccdn.com/dcsch99qiltq365sx91aocd9v_7o1i/wtid.js"
[1:1:0712/103913.210762:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "car.bitauto.com", 3, 1, , , 0
[1:1:0712/103913.321888:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1406, "http://car.bitauto.com/suv/z/"
[1:1:0712/103913.322409:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , , document.write('<iframe  height="0" width="1" src="http://gstat.bitauto.com/stat.htm"></iframe>');
[1:1:0712/103913.322501:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "car.bitauto.com", 3, 1, , , 0
[1:1:0712/103913.322794:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[29202:29202:0712/103913.323412:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/103913.324549:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x255d003c7a20
[1:1:0712/103913.325209:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[29202:29202:0712/103913.326022:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 4, 4, 
[1:1:0712/103913.334884:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/103913.335072:INFO:render_frame_impl.cc(7019)] 	 [url] = http://car.bitauto.com
[29202:29202:0712/103913.336906:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://car.bitauto.com/
[1:1:0712/103913.337866:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1406, "http://car.bitauto.com/suv/z/"
[29202:29202:0712/103913.344472:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[1:1:0712/103913.344951:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1406, "http://car.bitauto.com/suv/z/"
[29202:29202:0712/103913.345777:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0712/103913.347002:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1406, "http://car.bitauto.com/suv/z/"
[1:1:0712/103913.349775:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1406, "http://car.bitauto.com/suv/z/"
[29202:29213:0712/103913.358773:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 4
[29202:29213:0712/103913.358842:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 4, HandleIncomingMessage, HandleIncomingMessage
[29202:29202:0712/103913.358861:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://gstat.bitauto.com/
[29202:29202:0712/103913.358903:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_http://gstat.bitauto.com/, http://gstat.bitauto.com/stat.htm, 4
[29202:29202:0712/103913.358968:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:4_http://gstat.bitauto.com/, HTTP/1.1 200 OK Server: Tengine Date: Fri, 12 Jul 2019 02:32:21 GMT Content-Type: text/html Content-Length: 536 Last-Modified: Wed, 30 Sep 2015 02:31:36 GMT Accept-Ranges: bytes ETag: "0f4b82028fbd01:3cb" X-Powered-By: ASP.NET  ,29301, 5
[1:7:0712/103913.361219:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/103913.448920:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1406, "http://car.bitauto.com/suv/z/"
[1:1:0712/103913.480683:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1406, "http://car.bitauto.com/suv/z/"
[29202:29202:0712/103913.483973:INFO:CONSOLE(854)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://hm.baidu.com/h.js?7b86db06beda666182190f07e1af98e3, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://car.bitauto.com/suv/z/ (854)
[29202:29202:0712/103913.487552:INFO:CONSOLE(854)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://hm.baidu.com/h.js?7b86db06beda666182190f07e1af98e3, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://car.bitauto.com/suv/z/ (854)
[1:1:0712/103913.515393:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , , document.readyState
[1:1:0712/103913.515580:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "car.bitauto.com", 3, 1, , , 0
[1:1:0712/103913.619060:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 1417, 7f3be8e34881
[1:1:0712/103913.646102:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"18a6e6b42860","ptid":"968 0x7f3bf5800960 0x255cff8aab00 0x255cff8aab10 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103913.646303:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.bitauto.com/","ptid":"968 0x7f3bf5800960 0x255cff8aab00 0x255cff8aab10 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103913.646527:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.bitauto.com/suv/z/"
[1:1:0712/103913.646821:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , , () { self.mathTreeBoxHeight(false) }
[1:1:0712/103913.646921:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "car.bitauto.com", 3, 1, , , 0
[1:1:0712/103914.459911:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 1428, 7f3be8e34881
[1:1:0712/103914.487392:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"18a6e6b42860","ptid":"1065 0x7f3be64ef070 0x255cfe4b3160 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103914.487638:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.bitauto.com/","ptid":"1065 0x7f3be64ef070 0x255cfe4b3160 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103914.488037:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.bitauto.com/suv/z/"
[1:1:0712/103914.488380:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/103914.488511:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "car.bitauto.com", 3, 1, , , 0
[1:1:0712/103914.488880:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xd28ccf829c8, 0x255cfe734950
[1:1:0712/103914.488973:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.bitauto.com/suv/z/", 100
[1:1:0712/103914.489166:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 1514
[1:1:0712/103914.489433:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1514 0x7f3be64ef070 0x255cffbdba60 , 5:3_http://car.bitauto.com/, 1, -5:3_http://car.bitauto.com/, 1428 0x7f3be64ef070 0x255cfe5388e0 
[1:1:0712/103914.727494:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1444 0x7f3be84172e0 0x255cff5f07e0 , "http://car.bitauto.com/suv/z/"
[1:1:0712/103914.731790:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , , (function(C){var B,A,D;A=("Bitauto" in C&&C.Bitauto&&"DomainManager" in C.Bitauto);if(A){D=C.DomainM
[1:1:0712/103914.731978:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "car.bitauto.com", 3, 1, , , 0
[1:1:0712/103914.733118:INFO:document.cc(5190)] >>> Document::setDomain. [old, new] = "car.bitauto.com", "bitauto.com"
[1:1:0712/103914.740268:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/103915.072596:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x22ea54e90400
[1:1:0712/103915.087533:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/103915.089633:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x22ea54e908b0
[1:1:0712/103915.601050:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://car.bitauto.com/suv/z/"
[1:1:0712/103916.686447:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:4_http://gstat.bitauto.com/
[1:1:0712/103917.040198:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , , document.readyState
[1:1:0712/103917.040420:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "bitauto.com", 3, 1, , , 0
[1:1:0712/103917.587354:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 1514, 7f3be8e34881
[1:1:0712/103917.614132:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"18a6e6b42860","ptid":"1428 0x7f3be64ef070 0x255cfe5388e0 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103917.614327:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.bitauto.com/","ptid":"1428 0x7f3be64ef070 0x255cfe5388e0 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103917.614581:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.bitauto.com/suv/z/"
[1:1:0712/103917.614862:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/103917.614964:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "bitauto.com", 3, 1, , , 0
[1:1:0712/103917.615258:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xd28ccf829c8, 0x255cfe734950
[1:1:0712/103917.615340:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.bitauto.com/suv/z/", 100
[1:1:0712/103917.615511:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 1549
[1:1:0712/103917.615618:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1549 0x7f3be64ef070 0x255cff036a60 , 5:3_http://car.bitauto.com/, 1, -5:3_http://car.bitauto.com/, 1514 0x7f3be64ef070 0x255cffbdba60 
[1:1:0712/103918.066327:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1524 0x7f3be84172e0 0x255cff5f7de0 , "http://car.bitauto.com/suv/z/"
[1:1:0712/103918.070665:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , , City_Select._$JSON_callback.$JSON([{"cityId":"201","regionId":"110100","cityName":"北京","regionNa
[1:1:0712/103918.070774:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "bitauto.com", 3, 1, , , 0
[1:1:0712/103918.199015:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xd28ccf829c8, 0x255cfe734988
[1:1:0712/103918.199169:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.bitauto.com/suv/z/", 100
[1:1:0712/103918.199352:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 1596
[1:1:0712/103918.199449:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1596 0x7f3be64ef070 0x255cffc4b9e0 , 5:3_http://car.bitauto.com/, 1, -5:3_http://car.bitauto.com/, 1524 0x7f3be84172e0 0x255cff5f7de0 
[1:1:0712/103918.232203:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1525 0x7f3be84172e0 0x255d0033abe0 , "http://car.bitauto.com/suv/z/"
[1:1:0712/103918.233206:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , , <!-- 
gWtId="139.207.78.31-2425217536.30750809";  
gWtAccountRollup=1; 
 
// -->

[1:1:0712/103918.233333:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "bitauto.com", 3, 1, , , 0
[1:1:0712/103918.318785:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1527 0x7f3be84172e0 0x255cff270460 , "http://car.bitauto.com/suv/z/"
[1:1:0712/103918.320365:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , , tcCallback({"CarListInfo":[{"UcarID":"202587716","UcarSerialNumber":"dealerydg212588715t","CarID":"1
[1:1:0712/103918.320473:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "bitauto.com", 3, 1, , , 0
[1:1:0712/103918.323079:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://car.bitauto.com/suv/z/"
[1:1:0712/103918.416819:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1528 0x7f3be84172e0 0x255cffb2b560 , "http://car.bitauto.com/suv/z/"
[1:1:0712/103918.418087:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , , jsonpCallback({"Count":120,"CarNumber":957,"ResList":[{"MasterId":8,"SerialId":5415,"ShowName":"探�
[1:1:0712/103918.418235:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "bitauto.com", 3, 1, , , 0
[1:1:0712/103918.419729:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://car.bitauto.com/suv/z/"
		remove user.e_b4590a32 -> 0
		remove user.f_5431ce7b -> 0
		remove user.10_433d7956 -> 0
[1:1:0712/103919.031656:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[29202:29202:0712/103919.033761:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_http://gstat.bitauto.com/, http://gstat.bitauto.com/, 4
[29202:29202:0712/103919.033825:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, http://gstat.bitauto.com/, http://gstat.bitauto.com
[1:1:0712/103919.102419:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , , document.readyState
[1:1:0712/103919.102589:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "bitauto.com", 3, 1, , , 0
[1:1:0712/103919.194190:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1539 0x7f3be84172e0 0x255d00299fe0 , "http://car.bitauto.com/suv/z/"
[1:1:0712/103919.194847:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , , 
var Bitauto = Bitauto || {};
Bitauto.location = {
  "ip": "218.241.135.34",
  "regionId": "1101
[1:1:0712/103919.194970:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "bitauto.com", 3, 1, , , 0
[1:1:0712/103919.195456:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://car.bitauto.com/suv/z/"
[1:1:0712/103919.500806:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 1549, 7f3be8e34881
[1:1:0712/103919.532681:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"18a6e6b42860","ptid":"1514 0x7f3be64ef070 0x255cffbdba60 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103919.532917:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.bitauto.com/","ptid":"1514 0x7f3be64ef070 0x255cffbdba60 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103919.534070:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.bitauto.com/suv/z/"
[1:1:0712/103919.534462:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/103919.534558:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "bitauto.com", 3, 1, , , 0
[1:1:0712/103919.534924:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xd28ccf829c8, 0x255cfe734950
[1:1:0712/103919.535025:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.bitauto.com/suv/z/", 100
[1:1:0712/103919.535199:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 1675
[1:1:0712/103919.535304:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1675 0x7f3be64ef070 0x255d0044c4e0 , 5:3_http://car.bitauto.com/, 1, -5:3_http://car.bitauto.com/, 1549 0x7f3be64ef070 0x255cff036a60 
[1:1:0712/103921.280239:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 1596, 7f3be8e34881
[1:1:0712/103921.307756:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"18a6e6b42860","ptid":"1524 0x7f3be84172e0 0x255cff5f7de0 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103921.308006:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.bitauto.com/","ptid":"1524 0x7f3be84172e0 0x255cff5f7de0 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103921.308291:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.bitauto.com/suv/z/"
[1:1:0712/103921.308665:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , , () {
                    delete City_Select._$JSON_callback[fun.id];
                    script.pa
[1:1:0712/103921.308798:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "bitauto.com", 3, 1, , , 0
[1:1:0712/103923.112796:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/103923.383408:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1662 0x7f3be6857bd0 0x255cffa78158 , "http://car.bitauto.com/suv/z/"
[1:1:0712/103923.386558:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , , (function(){var h={},mt={},c={id:"7b86db06beda666182190f07e1af98e3",dm:["car.bitauto.com"],js:"tongj
[1:1:0712/103923.386668:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "bitauto.com", 3, 1, , , 0
[1:1:0712/103923.401225:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xd28ccf829c8, 0x255cfe734958
[1:1:0712/103923.401376:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.bitauto.com/suv/z/", 100
[1:1:0712/103923.401542:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 1736
[1:1:0712/103923.401636:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1736 0x7f3be64ef070 0x255cfeb3c760 , 5:3_http://car.bitauto.com/, 1, -5:3_http://car.bitauto.com/, 1662 0x7f3be6857bd0 0x255cffa78158 
[1:1:0712/103923.408247:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1662 0x7f3be6857bd0 0x255cffa78158 , "http://car.bitauto.com/suv/z/"
[1:1:0712/103923.411492:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1662 0x7f3be6857bd0 0x255cffa78158 , "http://car.bitauto.com/suv/z/"
[1:1:0712/103923.419695:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1662 0x7f3be6857bd0 0x255cffa78158 , "http://car.bitauto.com/suv/z/"
[1:1:0712/103923.448539:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1662 0x7f3be6857bd0 0x255cffa78158 , "http://car.bitauto.com/suv/z/"
[1:1:0712/103923.453199:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://car.bitauto.com/suv/z/"
[1:1:0712/103923.495648:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://car.bitauto.com/suv/z/"
[1:1:0712/103923.496521:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://car.bitauto.com/suv/z/"
[1:1:0712/103923.639323:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , , document.readyState
[1:1:0712/103923.639473:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "bitauto.com", 3, 1, , , 0
[1:1:0712/103924.051493:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 1675, 7f3be8e34881
[1:1:0712/103924.080485:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"18a6e6b42860","ptid":"1549 0x7f3be64ef070 0x255cff036a60 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103924.080741:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.bitauto.com/","ptid":"1549 0x7f3be64ef070 0x255cff036a60 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103924.080929:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.bitauto.com/suv/z/"
[1:1:0712/103924.081240:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/103924.081340:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "bitauto.com", 3, 1, , , 0
[1:1:0712/103924.081632:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xd28ccf829c8, 0x255cfe734950
[1:1:0712/103924.081726:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.bitauto.com/suv/z/", 100
[1:1:0712/103924.081884:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 1782
[1:1:0712/103924.081962:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1782 0x7f3be64ef070 0x255cffd31de0 , 5:3_http://car.bitauto.com/, 1, -5:3_http://car.bitauto.com/, 1675 0x7f3be64ef070 0x255d0044c4e0 
[1:1:0712/103924.896205:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1698 0x7f3be84172e0 0x255d002d2660 , "http://car.bitauto.com/suv/z/"
[1:1:0712/103924.897266:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , , var PageAreaStatistics = {
    config: null,
    configUrl: ('https:' == document.location.protoco
[1:1:0712/103924.897424:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "bitauto.com", 3, 1, , , 0
[1:1:0712/103924.898096:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://car.bitauto.com/suv/z/"
[1:1:0712/103924.965824:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1699 0x7f3be84172e0 0x255cff267960 , "http://car.bitauto.com/suv/z/"
[1:1:0712/103924.966364:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , , GetNewCarTextCallback([{"csid":"2694","text":"新款上市"},{"csid":"4470","text":"新款上市"},{
[1:1:0712/103924.966469:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "bitauto.com", 3, 1, , , 0
[1:1:0712/103924.966857:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://car.bitauto.com/suv/z/"
[1:1:0712/103926.521341:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/103926.521539:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://gstat.bitauto.com/stat.htm"
[1:1:0712/103926.955791:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 1736, 7f3be8e34881
[1:1:0712/103926.988482:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"18a6e6b42860","ptid":"1662 0x7f3be6857bd0 0x255cffa78158 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103926.988778:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.bitauto.com/","ptid":"1662 0x7f3be6857bd0 0x255cffa78158 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103926.989058:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.bitauto.com/suv/z/"
[1:1:0712/103926.989392:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/103926.989506:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "bitauto.com", 3, 1, , , 0
[1:1:0712/103926.989883:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xd28ccf829c8, 0x255cfe734950
[1:1:0712/103926.989978:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.bitauto.com/suv/z/", 100
[1:1:0712/103926.990156:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 1831
[1:1:0712/103926.990267:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1831 0x7f3be64ef070 0x255cff29f460 , 5:3_http://car.bitauto.com/, 1, -5:3_http://car.bitauto.com/, 1736 0x7f3be64ef070 0x255cfeb3c760 
[1:1:0712/103927.088185:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , , document.readyState
[1:1:0712/103927.088398:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "bitauto.com", 3, 1, , , 0
[1:1:0712/103927.851181:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 1782, 7f3be8e34881
[1:1:0712/103927.886325:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"18a6e6b42860","ptid":"1675 0x7f3be64ef070 0x255d0044c4e0 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103927.886501:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.bitauto.com/","ptid":"1675 0x7f3be64ef070 0x255d0044c4e0 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103927.886714:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.bitauto.com/suv/z/"
[1:1:0712/103927.887020:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/103927.887124:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "bitauto.com", 3, 1, , , 0
[1:1:0712/103927.887426:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xd28ccf829c8, 0x255cfe734950
[1:1:0712/103927.887535:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.bitauto.com/suv/z/", 100
[1:1:0712/103927.887710:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 1846
[1:1:0712/103927.887819:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1846 0x7f3be64ef070 0x255cff02e960 , 5:3_http://car.bitauto.com/, 1, -5:3_http://car.bitauto.com/, 1782 0x7f3be64ef070 0x255cffd31de0 
[1:1:0712/103928.952059:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1820, "http://gstat.bitauto.com/stat.htm"
[1:1:0712/103928.953734:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://gstat.bitauto.com/, 18a6e6b7bc48, , , function $() {
  var elements = new Array();

  for (var i = 0; i < arguments.length; i++) {
   
[1:1:0712/103928.953903:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://gstat.bitauto.com/stat.htm", "gstat.bitauto.com", 4, 1, http://car.bitauto.com, bitauto.com, 3
[1:1:0712/103928.957913:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1820, "http://gstat.bitauto.com/stat.htm"
[1:1:0712/103929.032116:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1822 0x7f3be84172e0 0x255cff0395e0 , "http://car.bitauto.com/suv/z/"
[1:1:0712/103929.032720:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , , !function(t,e){function i(t){for(var e;e=t.shift();)e()}function n(){p.loading=1;var n,o="";try{n=t.
[1:1:0712/103929.032827:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "bitauto.com", 3, 1, , , 0
[1:1:0712/103929.136268:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1823 0x7f3be84172e0 0x255d005c9560 , "http://car.bitauto.com/suv/z/"
[1:1:0712/103929.137167:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , , var bdShare=bdShare||{version:"1.0"};bdShare.ready=bdShare.ready||function(B,C){C=C||document;if(/co
[1:1:0712/103929.137317:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "bitauto.com", 3, 1, , , 0
[1:1:0712/103929.144575:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://car.bitauto.com/suv/z/"
[1:1:0712/103929.145304:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.bitauto.com/suv/z/", 1000
[1:1:0712/103929.145507:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://car.bitauto.com/, 1873
[1:1:0712/103929.145615:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1873 0x7f3be64ef070 0x255cff860f60 , 5:3_http://car.bitauto.com/, 1, -5:3_http://car.bitauto.com/, 1823 0x7f3be84172e0 0x255d005c9560 
[1:1:0712/103929.216213:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1825 0x7f3be84172e0 0x255cff11d5e0 , "http://car.bitauto.com/suv/z/"
[1:1:0712/103929.216763:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , , sspCallBackSenseNew.handleJson([])
[1:1:0712/103929.216892:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "bitauto.com", 3, 1, , , 0
[1:1:0712/103929.320419:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1826 0x7f3be84172e0 0x255cff72fbe0 , "http://car.bitauto.com/suv/z/"
[1:1:0712/103929.321119:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , , PageAreaStatistics.bind([{"ID":294,"PageAreaName":"PC选车-二手车-标题","Selector":"#ucar-titl
[1:1:0712/103929.321270:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "bitauto.com", 3, 1, , , 0
[1:1:0712/103929.553341:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , , document.readyState
[1:1:0712/103929.553534:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "bitauto.com", 3, 1, , , 0
[1:1:0712/103929.586454:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 1831, 7f3be8e34881
[1:1:0712/103929.616607:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"18a6e6b42860","ptid":"1736 0x7f3be64ef070 0x255cfeb3c760 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103929.616791:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.bitauto.com/","ptid":"1736 0x7f3be64ef070 0x255cfeb3c760 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103929.616986:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.bitauto.com/suv/z/"
[1:1:0712/103929.617301:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/103929.617421:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "bitauto.com", 3, 1, , , 0
[1:1:0712/103929.617723:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xd28ccf829c8, 0x255cfe734950
[1:1:0712/103929.617829:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.bitauto.com/suv/z/", 100
[1:1:0712/103929.618003:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 1885
[1:1:0712/103929.618121:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1885 0x7f3be64ef070 0x255d000d0e60 , 5:3_http://car.bitauto.com/, 1, -5:3_http://car.bitauto.com/, 1831 0x7f3be64ef070 0x255cff29f460 
[1:1:0712/103929.879880:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 1846, 7f3be8e34881
[1:1:0712/103929.912881:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"18a6e6b42860","ptid":"1782 0x7f3be64ef070 0x255cffd31de0 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103929.913103:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.bitauto.com/","ptid":"1782 0x7f3be64ef070 0x255cffd31de0 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103929.913292:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.bitauto.com/suv/z/"
[1:1:0712/103929.913557:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/103929.913673:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "bitauto.com", 3, 1, , , 0
[1:1:0712/103929.914021:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xd28ccf829c8, 0x255cfe734950
[1:1:0712/103929.914137:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.bitauto.com/suv/z/", 100
[1:1:0712/103929.914325:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 1894
[1:1:0712/103929.914453:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1894 0x7f3be64ef070 0x255cff027ae0 , 5:3_http://car.bitauto.com/, 1, -5:3_http://car.bitauto.com/, 1846 0x7f3be64ef070 0x255cff02e960 
[1:1:0712/103930.363357:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1864, "http://gstat.bitauto.com/stat.htm"
[1:1:0712/103930.363896:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://gstat.bitauto.com/, 18a6e6b7bc48, , , 
[1:1:0712/103930.364039:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://gstat.bitauto.com/stat.htm", "gstat.bitauto.com", 4, 1, http://car.bitauto.com, bitauto.com, 3
[1:1:0712/103930.739523:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , , document.readyState
[1:1:0712/103930.739738:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "bitauto.com", 3, 1, , , 0
[1:1:0712/103930.938463:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 1885, 7f3be8e34881
[1:1:0712/103930.968250:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"18a6e6b42860","ptid":"1831 0x7f3be64ef070 0x255cff29f460 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103930.968436:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.bitauto.com/","ptid":"1831 0x7f3be64ef070 0x255cff29f460 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103930.968635:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.bitauto.com/suv/z/"
[1:1:0712/103930.968932:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/103930.969025:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "bitauto.com", 3, 1, , , 0
[1:1:0712/103930.969376:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xd28ccf829c8, 0x255cfe734950
[1:1:0712/103930.969482:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.bitauto.com/suv/z/", 100
[1:1:0712/103930.969655:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 1927
[1:1:0712/103930.969775:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1927 0x7f3be64ef070 0x255cfeaf88e0 , 5:3_http://car.bitauto.com/, 1, -5:3_http://car.bitauto.com/, 1885 0x7f3be64ef070 0x255d000d0e60 
[1:1:0712/103931.003779:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 1894, 7f3be8e34881
[1:1:0712/103931.038270:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"18a6e6b42860","ptid":"1846 0x7f3be64ef070 0x255cff02e960 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103931.038453:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.bitauto.com/","ptid":"1846 0x7f3be64ef070 0x255cff02e960 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103931.038666:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.bitauto.com/suv/z/"
[1:1:0712/103931.038955:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/103931.039065:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "bitauto.com", 3, 1, , , 0
[1:1:0712/103931.039392:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xd28ccf829c8, 0x255cfe734950
[1:1:0712/103931.039503:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.bitauto.com/suv/z/", 100
[1:1:0712/103931.039693:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 1931
[1:1:0712/103931.039809:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1931 0x7f3be64ef070 0x255cff2507e0 , 5:3_http://car.bitauto.com/, 1, -5:3_http://car.bitauto.com/, 1894 0x7f3be64ef070 0x255cff027ae0 
[1:1:0712/103931.140420:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://car.bitauto.com/, 1873, 7f3be8e348db
[1:1:0712/103931.171361:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"18a6e6b42860","ptid":"1823 0x7f3be84172e0 0x255d005c9560 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103931.171541:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.bitauto.com/","ptid":"1823 0x7f3be84172e0 0x255d005c9560 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103931.171771:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://car.bitauto.com/, 1938
[1:1:0712/103931.171893:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1938 0x7f3be64ef070 0x255cfeb54960 , 5:3_http://car.bitauto.com/, 0, , 1873 0x7f3be64ef070 0x255cff860f60 
[1:1:0712/103931.172090:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.bitauto.com/suv/z/"
[1:1:0712/103931.172357:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , , () {
					var share = document.getElementById("bdshare");
					if (share && share.tagName.toUpperCas
[1:1:0712/103931.172472:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "bitauto.com", 3, 1, , , 0
[29202:29230:0712/103931.205334:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 6
[3:3:0712/103931.205465:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/103931.205656:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/103931.205813:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/103931.205940:INFO:zygote_linux.cc(633)] 		cid is 6
[1:1:0712/103931.210197:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x2d2afe9d, 1
[1:1:0712/103931.210462:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x564c746, 0
[1:1:0712/103931.210579:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x189abbbe, 3
[1:1:0712/103931.210695:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x159d0cd8, 2
[1:1:0712/103931.210782:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 46ffffffc76405 ffffff9dfffffffe2a2d ffffffd80cffffff9d15 ffffffbeffffffbbffffff9a18 , 10104, 6
[1:1:0712/103931.211513:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[29202:29230:0712/103931.211725:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGF�d��*-��������-
[29202:29230:0712/103931.211795:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is F�d��*-���������-
[1:1:0712/103931.211725:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f3bfc9ee0a0, 3
[29202:29230:0712/103931.212003:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 29380, 6, 46c76405 9dfe2a2d d80c9d15 bebb9a18 
[1:1:0712/103931.211942:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f3bfcb7a080, 2
[1:1:0712/103931.212285:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f3be683cd20, -2
[1:1:0712/103931.224398:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/103931.224839:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 159d0cd8
[1:1:0712/103931.225505:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 159d0cd8
[1:1:0712/103931.226825:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 159d0cd8
[1:1:0712/103931.227403:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 159d0cd8
[1:1:0712/103931.227500:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 159d0cd8
[1:1:0712/103931.227593:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 159d0cd8
[1:1:0712/103931.227685:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 159d0cd8
[1:1:0712/103931.227896:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 159d0cd8
[1:1:0712/103931.228031:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f3bfe7b47ba
[1:1:0712/103931.228104:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f3bfe7abdef, 7f3bfe7b477a, 7f3bfe7b60cf
[1:1:0712/103931.230225:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 159d0cd8
[1:1:0712/103931.230407:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 159d0cd8
[1:1:0712/103931.230719:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 159d0cd8
[1:1:0712/103931.231472:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 159d0cd8
[1:1:0712/103931.231571:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 159d0cd8
[1:1:0712/103931.231664:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 159d0cd8
[1:1:0712/103931.231757:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 159d0cd8
[1:1:0712/103931.232155:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 159d0cd8
[1:1:0712/103931.232320:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f3bfe7b47ba
[1:1:0712/103931.232396:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f3bfe7abdef, 7f3bfe7b477a, 7f3bfe7b60cf
[1:1:0712/103931.238195:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/103931.238678:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/103931.238761:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffff58b9a28, 0x7ffff58b99a8)
[1:1:0712/103931.270161:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/103931.475861:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1911 0x7f3be84172e0 0x255cfe957de0 , "http://car.bitauto.com/suv/z/"
[1:1:0712/103931.476453:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , , _1FNYP('CLAnatI5Al0pHgsbR1XsgQA')
[1:1:0712/103931.476577:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "bitauto.com", 3, 1, , , 0
[1:1:0712/103931.512364:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1912 0x7f3be84172e0 0x255cff6d3460 , "http://car.bitauto.com/suv/z/"
[1:1:0712/103931.513977:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , , var bdShare=bdShare||{};bdShare._LogPool=bdShare._LogPool||[],bdShare.ApiPVLogger||function(e){funct
[1:1:0712/103931.514167:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "bitauto.com", 3, 1, , , 0
[1:1:0712/103931.643202:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1916 0x7f3be84172e0 0x255cff2a56e0 , "http://car.bitauto.com/suv/z/"
[1:1:0712/103931.648324:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , , var bdShare=bdShare||{version:"1.0"};(function(){var P=new Date().getTime();var N=new Date().getTime
[1:1:0712/103931.648521:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "bitauto.com", 3, 1, , , 0
[1:1:0712/103931.664461:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 5, 0x255cfee6fe20
[29202:29202:0712/103931.664795:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[29202:29202:0712/103931.666859:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 5, 5, 
[1:1:0712/103931.664607:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 5
[29202:29202:0712/103931.689500:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:5_http://car.bitauto.com/, http://car.bitauto.com/, 5
[29202:29202:0712/103931.689596:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 5, 5, http://car.bitauto.com/, http://car.bitauto.com
[1:1:0712/103931.703872:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[29202:29202:0712/103931.709400:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[29202:29202:0712/103931.711571:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 6, 6, 
[1:1:0712/103931.722406:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 6, 0x255d00f58820
[1:1:0712/103931.722550:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 6
[29202:29202:0712/103931.736765:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:6_http://car.bitauto.com/, http://car.bitauto.com/, 6
[29202:29202:0712/103931.736853:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 6, 6, http://car.bitauto.com/, http://car.bitauto.com
[1:1:0712/103931.998279:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , , document.readyState
[1:1:0712/103931.998430:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "bitauto.com", 3, 1, , , 0
[1:1:0712/103932.168266:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 1927, 7f3be8e34881
[1:1:0712/103932.200190:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"18a6e6b42860","ptid":"1885 0x7f3be64ef070 0x255d000d0e60 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103932.200359:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.bitauto.com/","ptid":"1885 0x7f3be64ef070 0x255d000d0e60 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103932.200529:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.bitauto.com/suv/z/"
[1:1:0712/103932.200839:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/103932.200924:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "bitauto.com", 3, 1, , , 0
[1:1:0712/103932.201238:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xd28ccf829c8, 0x255cfe734950
[1:1:0712/103932.201330:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.bitauto.com/suv/z/", 100
[1:1:0712/103932.201495:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 1995
[1:1:0712/103932.201573:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1995 0x7f3be64ef070 0x255cff2775e0 , 5:3_http://car.bitauto.com/, 1, -5:3_http://car.bitauto.com/, 1927 0x7f3be64ef070 0x255cfeaf88e0 
[1:1:0712/103932.202140:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 1931, 7f3be8e34881
[1:1:0712/103932.235386:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"18a6e6b42860","ptid":"1894 0x7f3be64ef070 0x255cff027ae0 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103932.235559:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.bitauto.com/","ptid":"1894 0x7f3be64ef070 0x255cff027ae0 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103932.235754:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.bitauto.com/suv/z/"
[1:1:0712/103932.236022:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/103932.236121:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "bitauto.com", 3, 1, , , 0
[1:1:0712/103932.236396:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xd28ccf829c8, 0x255cfe734950
[1:1:0712/103932.236472:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.bitauto.com/suv/z/", 100
[1:1:0712/103932.236643:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 1996
[1:1:0712/103932.236733:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1996 0x7f3be64ef070 0x255cff027be0 , 5:3_http://car.bitauto.com/, 1, -5:3_http://car.bitauto.com/, 1931 0x7f3be64ef070 0x255cff2507e0 
[1:1:0712/103933.910644:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , , document.readyState
[1:1:0712/103933.910825:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "bitauto.com", 3, 1, , , 0
[1:1:0712/103933.977878:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://car.bitauto.com/, 1938, 7f3be8e348db
[1:1:0712/103934.009702:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1873 0x7f3be64ef070 0x255cff860f60 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103934.009865:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1873 0x7f3be64ef070 0x255cff860f60 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103934.010081:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://car.bitauto.com/, 2028
[1:1:0712/103934.010203:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2028 0x7f3be64ef070 0x255cffc9cde0 , 5:3_http://car.bitauto.com/, 0, , 1938 0x7f3be64ef070 0x255cfeb54960 
[1:1:0712/103934.010409:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.bitauto.com/suv/z/"
[1:1:0712/103934.010723:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , , () {
					var share = document.getElementById("bdshare");
					if (share && share.tagName.toUpperCas
[1:1:0712/103934.010828:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "bitauto.com", 3, 1, , , 0
[1:1:0712/103934.011698:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 1995, 7f3be8e34881
[1:1:0712/103934.043476:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"18a6e6b42860","ptid":"1927 0x7f3be64ef070 0x255cfeaf88e0 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103934.043663:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.bitauto.com/","ptid":"1927 0x7f3be64ef070 0x255cfeaf88e0 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103934.043877:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.bitauto.com/suv/z/"
[1:1:0712/103934.044161:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/103934.044278:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "bitauto.com", 3, 1, , , 0
[1:1:0712/103934.044579:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xd28ccf829c8, 0x255cfe734950
[1:1:0712/103934.044687:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.bitauto.com/suv/z/", 100
[1:1:0712/103934.044853:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 2029
[1:1:0712/103934.044953:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2029 0x7f3be64ef070 0x255cff0999e0 , 5:3_http://car.bitauto.com/, 1, -5:3_http://car.bitauto.com/, 1995 0x7f3be64ef070 0x255cff2775e0 
[1:1:0712/103934.045530:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 1996, 7f3be8e34881
[1:1:0712/103934.079823:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"18a6e6b42860","ptid":"1931 0x7f3be64ef070 0x255cff2507e0 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103934.080002:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.bitauto.com/","ptid":"1931 0x7f3be64ef070 0x255cff2507e0 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103934.080203:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.bitauto.com/suv/z/"
[1:1:0712/103934.080472:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/103934.080627:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "bitauto.com", 3, 1, , , 0
[1:1:0712/103934.080986:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xd28ccf829c8, 0x255cfe734950
[1:1:0712/103934.081077:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.bitauto.com/suv/z/", 100
[1:1:0712/103934.081244:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 2030
[1:1:0712/103934.081337:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2030 0x7f3be64ef070 0x255cff4c2de0 , 5:3_http://car.bitauto.com/, 1, -5:3_http://car.bitauto.com/, 1996 0x7f3be64ef070 0x255cff027be0 
[1:1:0712/103934.662145:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://car.bitauto.com/suv/z/"
[1:1:0712/103934.662592:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , M.D.onload, (){bdShare.velocity.cssLoadEnd=+new Date()}
[1:1:0712/103934.662683:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "bitauto.com", 3, 1, , , 0
[1:1:0712/103935.095436:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://car.bitauto.com/suv/z/"
[1:1:0712/103935.095924:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , a, (){if(!a.U){a.U=t;for(var d=0,b=g.length;d<b;d++)g[d]()}}
[1:1:0712/103935.096062:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "bitauto.com", 3, 1, , , 0
[1:1:0712/103935.096283:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://car.bitauto.com/suv/z/"
[1:1:0712/103935.096874:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xd28ccf829c8, 0x255cfe7349f0
[1:1:0712/103935.096965:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.bitauto.com/suv/z/", 10
[1:1:0712/103935.097156:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 2055
[1:1:0712/103935.097339:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2055 0x7f3be64ef070 0x255cff02fb60 , 5:3_http://car.bitauto.com/, 1, -5:3_http://car.bitauto.com/, 2025 0x7f3be64ef070 0x255cff2617e0 
[1:1:0712/103935.097578:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://car.bitauto.com/suv/z/"
[1:1:0712/103935.520000:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://car.bitauto.com/suv/z/"
[1:1:0712/103935.520386:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://car.bitauto.com/suv/z/"
[1:1:0712/103935.521147:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0xd28ccf829c8, 0x255cfe7349f0
[1:1:0712/103935.521266:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.bitauto.com/suv/z/", 1000
[1:1:0712/103935.521454:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 2056
[1:1:0712/103935.521580:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2056 0x7f3be64ef070 0x255cff6c0960 , 5:3_http://car.bitauto.com/, 1, -5:3_http://car.bitauto.com/, 2025 0x7f3be64ef070 0x255cff2617e0 
[1:1:0712/103935.522354:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "pageshow", "http://car.bitauto.com/suv/z/"
[1:1:0712/103935.522951:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xd28ccf829c8, 0x255cfe734af0
[1:1:0712/103935.523062:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.bitauto.com/suv/z/", 100
[1:1:0712/103935.523256:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 2057
[1:1:0712/103935.523376:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2057 0x7f3be64ef070 0x255cff9fbc60 , 5:3_http://car.bitauto.com/, 1, -5:3_http://car.bitauto.com/, 2025 0x7f3be64ef070 0x255cff2617e0 
[1:1:0712/103935.523581:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "pageshow", "http://car.bitauto.com/suv/z/"
[1:1:0712/103935.523986:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xd28ccf829c8, 0x255cfe7349f0
[1:1:0712/103935.524078:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.bitauto.com/suv/z/", 100
[1:1:0712/103935.524238:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 2058
[1:1:0712/103935.524355:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2058 0x7f3be64ef070 0x255cff5f0f60 , 5:3_http://car.bitauto.com/, 1, -5:3_http://car.bitauto.com/, 2025 0x7f3be64ef070 0x255cff2617e0 
[1:1:0712/103935.626408:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , , document.readyState
[1:1:0712/103935.626570:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "bitauto.com", 3, 1, , , 0
[1:1:0712/103936.218622:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 2055, 7f3be8e34881
[1:1:0712/103936.248644:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"18a6e6b42860","ptid":"2025 0x7f3be64ef070 0x255cff2617e0 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103936.248829:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.bitauto.com/","ptid":"2025 0x7f3be64ef070 0x255cff2617e0 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103936.249100:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.bitauto.com/suv/z/"
[1:1:0712/103936.249383:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , , () { self.mathTreeBoxHeight(false) }
[1:1:0712/103936.249496:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "bitauto.com", 3, 1, , , 0
[1:1:0712/103936.250618:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 2057, 7f3be8e34881
[1:1:0712/103936.284097:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"18a6e6b42860","ptid":"2025 0x7f3be64ef070 0x255cff2617e0 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103936.284299:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.bitauto.com/","ptid":"2025 0x7f3be64ef070 0x255cff2617e0 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103936.284523:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.bitauto.com/suv/z/"
[1:1:0712/103936.284821:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/103936.284917:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "bitauto.com", 3, 1, , , 0
[1:1:0712/103936.285240:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xd28ccf829c8, 0x255cfe734950
[1:1:0712/103936.285351:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.bitauto.com/suv/z/", 100
[1:1:0712/103936.285535:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 2075
[1:1:0712/103936.285659:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2075 0x7f3be64ef070 0x255d00485be0 , 5:3_http://car.bitauto.com/, 1, -5:3_http://car.bitauto.com/, 2057 0x7f3be64ef070 0x255cff9fbc60 
[1:1:0712/103936.286187:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 2058, 7f3be8e34881
[3:3:0712/103936.309611:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 2
[1:1:0712/103936.321731:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"18a6e6b42860","ptid":"2025 0x7f3be64ef070 0x255cff2617e0 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103936.321938:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.bitauto.com/","ptid":"2025 0x7f3be64ef070 0x255cff2617e0 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103936.322154:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.bitauto.com/suv/z/"
[1:1:0712/103936.322441:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/103936.322546:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "bitauto.com", 3, 1, , , 0
[1:1:0712/103936.322855:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xd28ccf829c8, 0x255cfe734950
[1:1:0712/103936.322961:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.bitauto.com/suv/z/", 100
[1:1:0712/103936.323158:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 2076
[1:1:0712/103936.323263:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2076 0x7f3be64ef070 0x255d004866e0 , 5:3_http://car.bitauto.com/, 1, -5:3_http://car.bitauto.com/, 2058 0x7f3be64ef070 0x255cff5f0f60 
[1:1:0712/103936.708860:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 2075, 7f3be8e34881
[1:1:0712/103936.744386:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"18a6e6b42860","ptid":"2057 0x7f3be64ef070 0x255cff9fbc60 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103936.744578:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.bitauto.com/","ptid":"2057 0x7f3be64ef070 0x255cff9fbc60 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103936.744788:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.bitauto.com/suv/z/"
[1:1:0712/103936.745079:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/103936.745203:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "bitauto.com", 3, 1, , , 0
[1:1:0712/103936.745526:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xd28ccf829c8, 0x255cfe734950
[1:1:0712/103936.745638:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.bitauto.com/suv/z/", 100
[1:1:0712/103936.745831:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 2093
[1:1:0712/103936.745960:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2093 0x7f3be64ef070 0x255d005c99e0 , 5:3_http://car.bitauto.com/, 1, -5:3_http://car.bitauto.com/, 2075 0x7f3be64ef070 0x255d00485be0 
[1:1:0712/103936.746583:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 2076, 7f3be8e34881
[1:1:0712/103936.782118:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"18a6e6b42860","ptid":"2058 0x7f3be64ef070 0x255cff5f0f60 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103936.782324:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.bitauto.com/","ptid":"2058 0x7f3be64ef070 0x255cff5f0f60 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103936.782551:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.bitauto.com/suv/z/"
[1:1:0712/103936.782878:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/103936.783001:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "bitauto.com", 3, 1, , , 0
[1:1:0712/103936.783326:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xd28ccf829c8, 0x255cfe734950
[1:1:0712/103936.783442:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.bitauto.com/suv/z/", 100
[1:1:0712/103936.783645:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 2095
[1:1:0712/103936.783771:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2095 0x7f3be64ef070 0x255cff6567e0 , 5:3_http://car.bitauto.com/, 1, -5:3_http://car.bitauto.com/, 2076 0x7f3be64ef070 0x255d004866e0 
[1:1:0712/103936.784309:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 2056, 7f3be8e34881
[1:1:0712/103936.819816:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"18a6e6b42860","ptid":"2025 0x7f3be64ef070 0x255cff2617e0 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103936.820002:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.bitauto.com/","ptid":"2025 0x7f3be64ef070 0x255cff2617e0 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103936.820201:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.bitauto.com/suv/z/"
[1:1:0712/103936.820476:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , , (){p(),h()}
[1:1:0712/103936.820581:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "bitauto.com", 3, 1, , , 0
[1:1:0712/103936.830032:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.bitauto.com/suv/z/", 1000
[1:1:0712/103936.830250:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://car.bitauto.com/, 2096
[1:1:0712/103936.830365:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2096 0x7f3be64ef070 0x255cff26ea60 , 5:3_http://car.bitauto.com/, 1, -5:3_http://car.bitauto.com/, 2056 0x7f3be64ef070 0x255cff6c0960 
[1:1:0712/103937.130912:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 2093, 7f3be8e34881
[1:1:0712/103937.162885:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"18a6e6b42860","ptid":"2075 0x7f3be64ef070 0x255d00485be0 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103937.163078:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.bitauto.com/","ptid":"2075 0x7f3be64ef070 0x255d00485be0 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103937.163303:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.bitauto.com/suv/z/"
[1:1:0712/103937.163602:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/103937.163722:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "bitauto.com", 3, 1, , , 0
[1:1:0712/103937.164040:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xd28ccf829c8, 0x255cfe734950
[1:1:0712/103937.164151:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.bitauto.com/suv/z/", 100
[1:1:0712/103937.164341:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 2113
[1:1:0712/103937.164479:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2113 0x7f3be64ef070 0x255cff25ec60 , 5:3_http://car.bitauto.com/, 1, -5:3_http://car.bitauto.com/, 2093 0x7f3be64ef070 0x255d005c99e0 
[1:1:0712/103937.165098:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 2095, 7f3be8e34881
[1:1:0712/103937.199982:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"18a6e6b42860","ptid":"2076 0x7f3be64ef070 0x255d004866e0 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103937.200161:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.bitauto.com/","ptid":"2076 0x7f3be64ef070 0x255d004866e0 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103937.200363:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.bitauto.com/suv/z/"
[1:1:0712/103937.200652:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/103937.200732:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "bitauto.com", 3, 1, , , 0
[1:1:0712/103937.201019:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xd28ccf829c8, 0x255cfe734950
[1:1:0712/103937.201165:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.bitauto.com/suv/z/", 100
[1:1:0712/103937.201357:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 2115
[1:1:0712/103937.201483:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2115 0x7f3be64ef070 0x255cff294160 , 5:3_http://car.bitauto.com/, 1, -5:3_http://car.bitauto.com/, 2095 0x7f3be64ef070 0x255cff6567e0 
[1:1:0712/103937.476097:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "http://car.bitauto.com/suv/z/"
[1:1:0712/103937.476561:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , r.onload.r.onerror, (){e[n]=null}
[1:1:0712/103937.476668:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "bitauto.com", 3, 1, , , 0
[1:1:0712/103937.477538:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 2113, 7f3be8e34881
[1:1:0712/103937.511524:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"18a6e6b42860","ptid":"2093 0x7f3be64ef070 0x255d005c99e0 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103937.511719:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.bitauto.com/","ptid":"2093 0x7f3be64ef070 0x255d005c99e0 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103937.511940:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.bitauto.com/suv/z/"
[1:1:0712/103937.512231:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/103937.512335:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "bitauto.com", 3, 1, , , 0
[1:1:0712/103937.512642:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xd28ccf829c8, 0x255cfe734950
[1:1:0712/103937.512728:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.bitauto.com/suv/z/", 100
[1:1:0712/103937.512873:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 2126
[1:1:0712/103937.512954:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2126 0x7f3be64ef070 0x255cff024760 , 5:3_http://car.bitauto.com/, 1, -5:3_http://car.bitauto.com/, 2113 0x7f3be64ef070 0x255cff25ec60 
[1:1:0712/103937.575325:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 2115, 7f3be8e34881
[1:1:0712/103937.606702:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"18a6e6b42860","ptid":"2095 0x7f3be64ef070 0x255cff6567e0 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103937.606896:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.bitauto.com/","ptid":"2095 0x7f3be64ef070 0x255cff6567e0 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103937.607120:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.bitauto.com/suv/z/"
[1:1:0712/103937.607438:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/103937.607558:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "bitauto.com", 3, 1, , , 0
[1:1:0712/103937.607873:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xd28ccf829c8, 0x255cfe734950
[1:1:0712/103937.607982:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.bitauto.com/suv/z/", 100
[1:1:0712/103937.608171:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 2129
[1:1:0712/103937.608296:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2129 0x7f3be64ef070 0x255cff29c9e0 , 5:3_http://car.bitauto.com/, 1, -5:3_http://car.bitauto.com/, 2115 0x7f3be64ef070 0x255cff294160 
[1:1:0712/103937.642694:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 2126, 7f3be8e34881
[1:1:0712/103937.678300:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"18a6e6b42860","ptid":"2113 0x7f3be64ef070 0x255cff25ec60 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103937.678503:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.bitauto.com/","ptid":"2113 0x7f3be64ef070 0x255cff25ec60 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103937.678738:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.bitauto.com/suv/z/"
[1:1:0712/103937.679042:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/103937.679164:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "bitauto.com", 3, 1, , , 0
[1:1:0712/103937.679490:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xd28ccf829c8, 0x255cfe734950
[1:1:0712/103937.679615:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.bitauto.com/suv/z/", 100
[1:1:0712/103937.679807:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 2133
[1:1:0712/103937.679924:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2133 0x7f3be64ef070 0x255cfec7d0e0 , 5:3_http://car.bitauto.com/, 1, -5:3_http://car.bitauto.com/, 2126 0x7f3be64ef070 0x255cff024760 
[1:1:0712/103937.779259:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 2129, 7f3be8e34881
[1:1:0712/103937.809984:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"18a6e6b42860","ptid":"2115 0x7f3be64ef070 0x255cff294160 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103937.810173:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.bitauto.com/","ptid":"2115 0x7f3be64ef070 0x255cff294160 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103937.810386:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.bitauto.com/suv/z/"
[1:1:0712/103937.810688:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/103937.810804:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "bitauto.com", 3, 1, , , 0
[1:1:0712/103937.811104:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xd28ccf829c8, 0x255cfe734950
[1:1:0712/103937.811212:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.bitauto.com/suv/z/", 100
[1:1:0712/103937.811392:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 2139
[1:1:0712/103937.811513:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2139 0x7f3be64ef070 0x255cff693460 , 5:3_http://car.bitauto.com/, 1, -5:3_http://car.bitauto.com/, 2129 0x7f3be64ef070 0x255cff29c9e0 
[1:1:0712/103937.844868:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 2133, 7f3be8e34881
[1:1:0712/103937.879824:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"18a6e6b42860","ptid":"2126 0x7f3be64ef070 0x255cff024760 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103937.880029:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.bitauto.com/","ptid":"2126 0x7f3be64ef070 0x255cff024760 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103937.880251:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.bitauto.com/suv/z/"
[1:1:0712/103937.880552:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/103937.880661:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "bitauto.com", 3, 1, , , 0
[1:1:0712/103937.880966:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xd28ccf829c8, 0x255cfe734950
[1:1:0712/103937.881064:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.bitauto.com/suv/z/", 100
[1:1:0712/103937.881268:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 2145
[1:1:0712/103937.881396:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2145 0x7f3be64ef070 0x255cff9b1e60 , 5:3_http://car.bitauto.com/, 1, -5:3_http://car.bitauto.com/, 2133 0x7f3be64ef070 0x255cfec7d0e0 
[1:1:0712/103937.951524:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://car.bitauto.com/, 2096, 7f3be8e348db
[1:1:0712/103937.982792:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"18a6e6b42860","ptid":"2056 0x7f3be64ef070 0x255cff6c0960 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103937.982978:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.bitauto.com/","ptid":"2056 0x7f3be64ef070 0x255cff6c0960 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103937.983214:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://car.bitauto.com/, 2149
[1:1:0712/103937.983359:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2149 0x7f3be64ef070 0x255cffcc9f60 , 5:3_http://car.bitauto.com/, 0, , 2096 0x7f3be64ef070 0x255cff26ea60 
[1:1:0712/103937.983549:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.bitauto.com/suv/z/"
[1:1:0712/103937.983816:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , , (){document.hasFocus()&&u++}
[1:1:0712/103937.983930:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "bitauto.com", 3, 1, , , 0
[1:1:0712/103938.082006:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 2139, 7f3be8e34881
[1:1:0712/103938.117688:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"18a6e6b42860","ptid":"2129 0x7f3be64ef070 0x255cff29c9e0 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103938.117900:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.bitauto.com/","ptid":"2129 0x7f3be64ef070 0x255cff29c9e0 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103938.118138:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.bitauto.com/suv/z/"
[1:1:0712/103938.118467:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/103938.118593:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "bitauto.com", 3, 1, , , 0
[1:1:0712/103938.118920:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xd28ccf829c8, 0x255cfe734950
[1:1:0712/103938.119035:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.bitauto.com/suv/z/", 100
[1:1:0712/103938.119216:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 2154
[1:1:0712/103938.119330:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2154 0x7f3be64ef070 0x255d0048be60 , 5:3_http://car.bitauto.com/, 1, -5:3_http://car.bitauto.com/, 2139 0x7f3be64ef070 0x255cff693460 
[1:1:0712/103938.119936:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 2145, 7f3be8e34881
[1:1:0712/103938.156253:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"18a6e6b42860","ptid":"2133 0x7f3be64ef070 0x255cfec7d0e0 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103938.156459:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.bitauto.com/","ptid":"2133 0x7f3be64ef070 0x255cfec7d0e0 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103938.156696:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.bitauto.com/suv/z/"
[1:1:0712/103938.156980:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/103938.157100:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "bitauto.com", 3, 1, , , 0
[1:1:0712/103938.157403:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xd28ccf829c8, 0x255cfe734950
[1:1:0712/103938.157498:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.bitauto.com/suv/z/", 100
[1:1:0712/103938.157672:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 2156
[1:1:0712/103938.157781:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2156 0x7f3be64ef070 0x255cff9ea060 , 5:3_http://car.bitauto.com/, 1, -5:3_http://car.bitauto.com/, 2145 0x7f3be64ef070 0x255cff9b1e60 
[1:1:0712/103938.314314:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 2154, 7f3be8e34881
[1:1:0712/103938.351101:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"18a6e6b42860","ptid":"2139 0x7f3be64ef070 0x255cff693460 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103938.351306:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.bitauto.com/","ptid":"2139 0x7f3be64ef070 0x255cff693460 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103938.351524:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.bitauto.com/suv/z/"
[1:1:0712/103938.351817:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/103938.351911:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "bitauto.com", 3, 1, , , 0
[1:1:0712/103938.352852:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xd28ccf829c8, 0x255cfe734950
[1:1:0712/103938.352934:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.bitauto.com/suv/z/", 100
[1:1:0712/103938.353118:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 2166
[1:1:0712/103938.353213:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2166 0x7f3be64ef070 0x255cff040860 , 5:3_http://car.bitauto.com/, 1, -5:3_http://car.bitauto.com/, 2154 0x7f3be64ef070 0x255d0048be60 
[1:1:0712/103938.355219:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 2156, 7f3be8e34881
[1:1:0712/103938.389273:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"18a6e6b42860","ptid":"2145 0x7f3be64ef070 0x255cff9b1e60 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103938.389465:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.bitauto.com/","ptid":"2145 0x7f3be64ef070 0x255cff9b1e60 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103938.389689:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.bitauto.com/suv/z/"
[1:1:0712/103938.389997:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/103938.390112:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "bitauto.com", 3, 1, , , 0
[1:1:0712/103938.390417:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xd28ccf829c8, 0x255cfe734950
[1:1:0712/103938.390525:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.bitauto.com/suv/z/", 100
[1:1:0712/103938.390706:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 2167
[1:1:0712/103938.390825:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2167 0x7f3be64ef070 0x255cff860ae0 , 5:3_http://car.bitauto.com/, 1, -5:3_http://car.bitauto.com/, 2156 0x7f3be64ef070 0x255cff9ea060 
[1:1:0712/103938.453946:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 2166, 7f3be8e34881
[1:1:0712/103938.486145:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"18a6e6b42860","ptid":"2154 0x7f3be64ef070 0x255d0048be60 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103938.486342:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.bitauto.com/","ptid":"2154 0x7f3be64ef070 0x255d0048be60 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103938.486563:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.bitauto.com/suv/z/"
[1:1:0712/103938.486858:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/103938.486976:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "bitauto.com", 3, 1, , , 0
[1:1:0712/103938.487293:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xd28ccf829c8, 0x255cfe734950
[1:1:0712/103938.487403:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.bitauto.com/suv/z/", 100
[1:1:0712/103938.487590:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 2170
[1:1:0712/103938.487717:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2170 0x7f3be64ef070 0x255cff2ab260 , 5:3_http://car.bitauto.com/, 1, -5:3_http://car.bitauto.com/, 2166 0x7f3be64ef070 0x255cff040860 
[1:1:0712/103938.524187:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 2167, 7f3be8e34881
[1:1:0712/103938.559803:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"18a6e6b42860","ptid":"2156 0x7f3be64ef070 0x255cff9ea060 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103938.560045:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.bitauto.com/","ptid":"2156 0x7f3be64ef070 0x255cff9ea060 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103938.560288:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.bitauto.com/suv/z/"
[1:1:0712/103938.560623:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/103938.560734:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "bitauto.com", 3, 1, , , 0
[1:1:0712/103938.561069:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xd28ccf829c8, 0x255cfe734950
[1:1:0712/103938.561175:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.bitauto.com/suv/z/", 100
[1:1:0712/103938.561339:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 2175
[1:1:0712/103938.561468:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2175 0x7f3be64ef070 0x255d00287ce0 , 5:3_http://car.bitauto.com/, 1, -5:3_http://car.bitauto.com/, 2167 0x7f3be64ef070 0x255cff860ae0 
[1:1:0712/103938.660008:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 2170, 7f3be8e34881
[1:1:0712/103938.691812:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"18a6e6b42860","ptid":"2166 0x7f3be64ef070 0x255cff040860 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103938.691997:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.bitauto.com/","ptid":"2166 0x7f3be64ef070 0x255cff040860 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103938.692220:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.bitauto.com/suv/z/"
[1:1:0712/103938.692503:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/103938.692611:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "bitauto.com", 3, 1, , , 0
[1:1:0712/103938.692909:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xd28ccf829c8, 0x255cfe734950
[1:1:0712/103938.692977:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.bitauto.com/suv/z/", 100
[1:1:0712/103938.693188:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 2181
[1:1:0712/103938.693312:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2181 0x7f3be64ef070 0x255cfe9aefe0 , 5:3_http://car.bitauto.com/, 1, -5:3_http://car.bitauto.com/, 2170 0x7f3be64ef070 0x255cff2ab260 
[1:1:0712/103938.693974:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 2175, 7f3be8e34881
[1:1:0712/103938.727649:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"18a6e6b42860","ptid":"2167 0x7f3be64ef070 0x255cff860ae0 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103938.727843:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.bitauto.com/","ptid":"2167 0x7f3be64ef070 0x255cff860ae0 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103938.728086:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.bitauto.com/suv/z/"
[1:1:0712/103938.728400:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/103938.728489:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "bitauto.com", 3, 1, , , 0
[1:1:0712/103938.728779:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xd28ccf829c8, 0x255cfe734950
[1:1:0712/103938.728852:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.bitauto.com/suv/z/", 100
[1:1:0712/103938.729012:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 2184
[1:1:0712/103938.729146:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2184 0x7f3be64ef070 0x255cfeb178e0 , 5:3_http://car.bitauto.com/, 1, -5:3_http://car.bitauto.com/, 2175 0x7f3be64ef070 0x255d00287ce0 
[1:1:0712/103938.802789:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 2181, 7f3be8e34881
[1:1:0712/103938.835416:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"18a6e6b42860","ptid":"2170 0x7f3be64ef070 0x255cff2ab260 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103938.835610:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.bitauto.com/","ptid":"2170 0x7f3be64ef070 0x255cff2ab260 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103938.835824:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.bitauto.com/suv/z/"
[1:1:0712/103938.836097:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/103938.836190:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "bitauto.com", 3, 1, , , 0
[1:1:0712/103938.836465:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xd28ccf829c8, 0x255cfe734950
[1:1:0712/103938.836559:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.bitauto.com/suv/z/", 100
[1:1:0712/103938.836728:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 2188
[1:1:0712/103938.836828:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2188 0x7f3be64ef070 0x255cff261ae0 , 5:3_http://car.bitauto.com/, 1, -5:3_http://car.bitauto.com/, 2181 0x7f3be64ef070 0x255cfe9aefe0 
[1:1:0712/103938.837466:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 2184, 7f3be8e34881
[1:1:0712/103938.869360:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"18a6e6b42860","ptid":"2175 0x7f3be64ef070 0x255d00287ce0 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103938.869539:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.bitauto.com/","ptid":"2175 0x7f3be64ef070 0x255d00287ce0 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103938.869739:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.bitauto.com/suv/z/"
[1:1:0712/103938.870020:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/103938.870124:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "bitauto.com", 3, 1, , , 0
[1:1:0712/103938.870413:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xd28ccf829c8, 0x255cfe734950
[1:1:0712/103938.870514:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.bitauto.com/suv/z/", 100
[1:1:0712/103938.870684:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 2192
[1:1:0712/103938.870786:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2192 0x7f3be64ef070 0x255cff9ee060 , 5:3_http://car.bitauto.com/, 1, -5:3_http://car.bitauto.com/, 2184 0x7f3be64ef070 0x255cfeb178e0 
[1:1:0712/103938.901392:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://car.bitauto.com/, 2149, 7f3be8e348db
[1:1:0712/103938.931841:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"2096 0x7f3be64ef070 0x255cff26ea60 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103938.932014:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"2096 0x7f3be64ef070 0x255cff26ea60 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103938.932241:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://car.bitauto.com/, 2195
[1:1:0712/103938.932359:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2195 0x7f3be64ef070 0x255cff2650e0 , 5:3_http://car.bitauto.com/, 0, , 2149 0x7f3be64ef070 0x255cffcc9f60 
[1:1:0712/103938.932549:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.bitauto.com/suv/z/"
[1:1:0712/103938.932803:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , , (){document.hasFocus()&&u++}
[1:1:0712/103938.932916:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "bitauto.com", 3, 1, , , 0
[1:1:0712/103938.967581:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 2188, 7f3be8e34881
[1:1:0712/103939.000759:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"18a6e6b42860","ptid":"2181 0x7f3be64ef070 0x255cfe9aefe0 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103939.000968:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.bitauto.com/","ptid":"2181 0x7f3be64ef070 0x255cfe9aefe0 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103939.001182:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.bitauto.com/suv/z/"
[1:1:0712/103939.001482:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/103939.001598:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "bitauto.com", 3, 1, , , 0
[1:1:0712/103939.001907:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xd28ccf829c8, 0x255cfe734950
[1:1:0712/103939.002017:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.bitauto.com/suv/z/", 100
[1:1:0712/103939.002202:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 2197
[1:1:0712/103939.002324:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2197 0x7f3be64ef070 0x255cfe9b0360 , 5:3_http://car.bitauto.com/, 1, -5:3_http://car.bitauto.com/, 2188 0x7f3be64ef070 0x255cff261ae0 
[1:1:0712/103939.003015:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 2192, 7f3be8e34881
[1:1:0712/103939.037409:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"18a6e6b42860","ptid":"2184 0x7f3be64ef070 0x255cfeb178e0 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103939.037612:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.bitauto.com/","ptid":"2184 0x7f3be64ef070 0x255cfeb178e0 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103939.037831:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.bitauto.com/suv/z/"
[1:1:0712/103939.038136:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/103939.038259:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "bitauto.com", 3, 1, , , 0
[1:1:0712/103939.038555:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xd28ccf829c8, 0x255cfe734950
[1:1:0712/103939.038649:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.bitauto.com/suv/z/", 100
[1:1:0712/103939.038818:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 2200
[1:1:0712/103939.038925:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2200 0x7f3be64ef070 0x255cff257e60 , 5:3_http://car.bitauto.com/, 1, -5:3_http://car.bitauto.com/, 2192 0x7f3be64ef070 0x255cff9ee060 
[1:1:0712/103939.168720:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 2197, 7f3be8e34881
[1:1:0712/103939.203505:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"18a6e6b42860","ptid":"2188 0x7f3be64ef070 0x255cff261ae0 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103939.203714:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.bitauto.com/","ptid":"2188 0x7f3be64ef070 0x255cff261ae0 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103939.203935:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.bitauto.com/suv/z/"
[1:1:0712/103939.204231:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/103939.204348:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "bitauto.com", 3, 1, , , 0
[1:1:0712/103939.204639:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xd28ccf829c8, 0x255cfe734950
[1:1:0712/103939.204733:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.bitauto.com/suv/z/", 100
[1:1:0712/103939.204899:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 2209
[1:1:0712/103939.204981:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2209 0x7f3be64ef070 0x255cfe944660 , 5:3_http://car.bitauto.com/, 1, -5:3_http://car.bitauto.com/, 2197 0x7f3be64ef070 0x255cfe9b0360 
[1:1:0712/103939.240567:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 2200, 7f3be8e34881
[1:1:0712/103939.271765:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"18a6e6b42860","ptid":"2192 0x7f3be64ef070 0x255cff9ee060 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103939.271933:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.bitauto.com/","ptid":"2192 0x7f3be64ef070 0x255cff9ee060 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103939.272127:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.bitauto.com/suv/z/"
[1:1:0712/103939.272390:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/103939.272487:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "bitauto.com", 3, 1, , , 0
[1:1:0712/103939.272758:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xd28ccf829c8, 0x255cfe734950
[1:1:0712/103939.272834:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.bitauto.com/suv/z/", 100
[1:1:0712/103939.272981:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 2212
[1:1:0712/103939.273071:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2212 0x7f3be64ef070 0x255cff024de0 , 5:3_http://car.bitauto.com/, 1, -5:3_http://car.bitauto.com/, 2200 0x7f3be64ef070 0x255cff257e60 
[1:1:0712/103939.333931:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 2209, 7f3be8e34881
[1:1:0712/103939.364741:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"18a6e6b42860","ptid":"2197 0x7f3be64ef070 0x255cfe9b0360 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103939.364932:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.bitauto.com/","ptid":"2197 0x7f3be64ef070 0x255cfe9b0360 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103939.365172:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.bitauto.com/suv/z/"
[1:1:0712/103939.365470:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/103939.365591:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "bitauto.com", 3, 1, , , 0
[1:1:0712/103939.365888:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xd28ccf829c8, 0x255cfe734950
[1:1:0712/103939.365994:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.bitauto.com/suv/z/", 100
[1:1:0712/103939.366170:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 2215
[1:1:0712/103939.366251:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2215 0x7f3be64ef070 0x255cff027be0 , 5:3_http://car.bitauto.com/, 1, -5:3_http://car.bitauto.com/, 2209 0x7f3be64ef070 0x255cfe944660 
[1:1:0712/103939.401641:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 2212, 7f3be8e34881
[1:1:0712/103939.436797:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"18a6e6b42860","ptid":"2200 0x7f3be64ef070 0x255cff257e60 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103939.436992:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://car.bitauto.com/","ptid":"2200 0x7f3be64ef070 0x255cff257e60 ","rf":"5:3_http://car.bitauto.com/"}
[1:1:0712/103939.437210:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://car.bitauto.com/suv/z/"
[1:1:0712/103939.437508:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://car.bitauto.com/, 18a6e6b42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/103939.437627:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://car.bitauto.com/suv/z/", "bitauto.com", 3, 1, , , 0
[1:1:0712/103939.437950:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xd28ccf829c8, 0x255cfe734950
[1:1:0712/103939.438061:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://car.bitauto.com/suv/z/", 100
[1:1:0712/103939.438253:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 2219
[1:1:0712/103939.438378:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2219 0x7f3be64ef070 0x255cffabb460 , 5:3_http://car.bitauto.com/, 1, -5:3_http://car.bitauto.com/, 2212 0x7f3be64ef070 0x255cff024de0 
[1:1:0100/000000.504776:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://car.bitauto.com/, 2215, 7f3be8e34881
