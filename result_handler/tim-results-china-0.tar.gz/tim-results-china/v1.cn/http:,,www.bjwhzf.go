[0713/035438.108500:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/035438.108757:INFO:switcher_clone.cc(787)] backtrace rip is 7f01713f0891
[0713/035438.655598:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/035438.655846:INFO:switcher_clone.cc(787)] backtrace rip is 7f0a83914891
[1:1:0713/035438.659664:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0713/035438.659831:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0713/035438.662636:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[0713/035439.495404:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/035439.495687:INFO:switcher_clone.cc(787)] backtrace rip is 7fb50788a891
[31568:31568:0713/035439.567804:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/6342e1ab-2def-445a-8627-2be24dbd27f1
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[31599:31599:0713/035439.651251:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=31599
[31612:31612:0713/035439.651561:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=31612
[31568:31568:0713/035439.813938:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[31568:31597:0713/035439.814334:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0713/035439.815463:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0713/035439.815820:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0713/035439.816143:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0713/035439.816319:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0713/035439.818063:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x30567853, 1
[1:1:0713/035439.818319:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x25ee60ee, 0
[1:1:0713/035439.818473:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x213a373f, 3
[1:1:0713/035439.818630:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x16a008f8, 2
[1:1:0713/035439.818779:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffee60ffffffee25 53785630 fffffff808ffffffa016 3f373a21 , 10104, 4
[1:1:0713/035439.819446:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[31568:31597:0713/035439.819571:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�`�%SxV0��?7:!�F
[1:1:0713/035439.819568:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f0a81b4e0a0, 3
[31568:31597:0713/035439.819650:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �`�%SxV0��?7:!��F
[1:1:0713/035439.819702:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f0a81cda080, 2
[31568:31597:0713/035439.819831:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[31568:31597:0713/035439.819859:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 31620, 4, ee60ee25 53785630 f808a016 3f373a21 
[1:1:0713/035439.819815:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f0a6b99cd20, -2
[1:1:0713/035439.827660:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0713/035439.828116:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 16a008f8
[1:1:0713/035439.828545:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 16a008f8
[1:1:0713/035439.829347:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 16a008f8
[1:1:0713/035439.829926:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 16a008f8
[1:1:0713/035439.830090:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 16a008f8
[1:1:0713/035439.830249:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 16a008f8
[1:1:0713/035439.830392:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 16a008f8
[1:1:0713/035439.830659:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 16a008f8
[1:1:0713/035439.830814:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f0a839147ba
[1:1:0713/035439.830899:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f0a8390bdef, 7f0a8391477a, 7f0a839160cf
[1:1:0713/035439.832593:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 16a008f8
[1:1:0713/035439.832762:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 16a008f8
[1:1:0713/035439.833099:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 16a008f8
[1:1:0713/035439.833908:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 16a008f8
[1:1:0713/035439.834078:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 16a008f8
[1:1:0713/035439.834236:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 16a008f8
[1:1:0713/035439.834361:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 16a008f8
[1:1:0713/035439.834867:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 16a008f8
[1:1:0713/035439.835010:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f0a839147ba
[1:1:0713/035439.835113:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f0a8390bdef, 7f0a8391477a, 7f0a839160cf
[1:1:0713/035439.837575:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0713/035439.837775:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0713/035439.837887:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fff2042a058, 0x7fff20429fd8)
[1:1:0713/035439.844560:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0713/035439.847367:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[31568:31568:0713/035440.226713:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[31568:31568:0713/035440.227200:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[31568:31579:0713/035440.237080:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[31568:31568:0713/035440.237115:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[31568:31579:0713/035440.237149:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[31568:31568:0713/035440.237162:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[31568:31568:0713/035440.237237:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,31620, 4
[1:7:0713/035440.245494:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/035440.288109:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x211865288220
[1:1:0713/035440.288268:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[31568:31590:0713/035440.333842:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0713/035440.478978:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0713/035441.194017:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/035441.195578:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[31568:31568:0713/035441.446195:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[31568:31568:0713/035441.446305:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0713/035441.689382:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/035441.785306:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 387cc44e1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0713/035441.785503:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/035441.790847:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 387cc44e1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0713/035441.790990:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/035441.834381:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/035441.834555:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/035441.989893:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 357, "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/035441.992412:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 387cc44e1f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0713/035441.992566:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/035442.004632:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 358, "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/035442.007651:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 387cc44e1f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0713/035442.007801:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/035442.011630:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[31568:31568:0713/035442.012269:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0713/035442.013443:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x211865286e20
[1:1:0713/035442.013803:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[31568:31568:0713/035442.014783:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[31568:31568:0713/035442.026386:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[31568:31568:0713/035442.026477:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0713/035442.046075:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/035442.340790:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 417 0x7f0a6d5772e0 0x21186542e7e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/035442.341475:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 387cc44e1f78, , , var configData = {"googleBaseUrl":"https://www.google.com.hk/","isAccessibleBrowser":false,"isGoogle
[1:1:0713/035442.341652:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/035442.342206:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[31568:31568:0713/035442.367458:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0713/035442.368516:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x211865287820
[1:1:0713/035442.368677:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[31568:31568:0713/035442.369804:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0713/035442.375542:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0713/035442.375710:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[31568:31568:0713/035442.376720:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[31568:31568:0713/035442.380978:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[31568:31568:0713/035442.381439:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[31568:31579:0713/035442.385834:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[31568:31579:0713/035442.385887:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[31568:31568:0713/035442.385908:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[31568:31568:0713/035442.385947:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[31568:31568:0713/035442.386006:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,31620, 4
[1:7:0713/035442.387642:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/035442.653839:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0713/035442.770149:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 464 0x7f0a6d5772e0 0x2118654c2b60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/035442.770748:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 387cc44e1f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0713/035442.770932:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/035442.771308:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[31568:31568:0713/035442.930650:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[31568:31568:0713/035442.930737:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0713/035442.942231:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[31568:31568:0713/035443.055599:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[31568:31597:0713/035443.055939:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0713/035443.056060:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0713/035443.056205:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0713/035443.056412:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0713/035443.056498:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0713/035443.058994:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x13ffd0f6, 1
[1:1:0713/035443.059241:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x1aaea6a2, 0
[1:1:0713/035443.059412:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x3549ace0, 3
[1:1:0713/035443.059571:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x3b5342f, 2
[1:1:0713/035443.059695:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffa2ffffffa6ffffffae1a fffffff6ffffffd0ffffffff13 2f34ffffffb503 ffffffe0ffffffac4935 , 10104, 5
[1:1:0713/035443.060838:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[31568:31597:0713/035443.060996:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING������/4��I5�F
[31568:31597:0713/035443.061048:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ������/4��I5(D�F
[1:1:0713/035443.061110:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f0a81b4e0a0, 3
[1:1:0713/035443.061203:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f0a81cda080, 2
[1:1:0713/035443.061302:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f0a6b99cd20, -2
[31568:31597:0713/035443.063367:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 31664, 5, a2a6ae1a f6d0ff13 2f34b503 e0ac4935 
[1:1:0713/035443.073077:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0713/035443.073312:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3b5342f
[1:1:0713/035443.073472:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3b5342f
[1:1:0713/035443.073769:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3b5342f
[1:1:0713/035443.074278:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3b5342f
[1:1:0713/035443.074379:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3b5342f
[1:1:0713/035443.074477:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3b5342f
[1:1:0713/035443.074572:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3b5342f
[1:1:0713/035443.074826:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3b5342f
[1:1:0713/035443.074955:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f0a839147ba
[1:1:0713/035443.075031:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f0a8390bdef, 7f0a8391477a, 7f0a839160cf
[1:1:0713/035443.076824:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3b5342f
[1:1:0713/035443.076999:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3b5342f
[1:1:0713/035443.077325:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3b5342f
[1:1:0713/035443.077566:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/035443.078210:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3b5342f
[1:1:0713/035443.078334:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3b5342f
[1:1:0713/035443.078445:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3b5342f
[1:1:0713/035443.078612:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3b5342f
[1:1:0713/035443.079173:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3b5342f
[1:1:0713/035443.079491:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f0a839147ba
[1:1:0713/035443.079645:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f0a8390bdef, 7f0a8391477a, 7f0a839160cf
[1:1:0713/035443.082436:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0713/035443.082661:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0713/035443.082784:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fff2042a058, 0x7fff20429fd8)
[1:1:0713/035443.088909:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0713/035443.090835:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0713/035443.183026:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x21186522e220
[1:1:0713/035443.183189:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0713/035443.371412:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/035443.371715:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[31568:31568:0713/035443.502330:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_null/, , 1
[31568:31568:0713/035443.502430:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, , null
[1:1:0713/035443.509147:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 538, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/035443.510941:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 387cc460e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0713/035443.511161:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/035443.513712:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/035443.516136:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/035443.516396:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/035443.516577:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/035443.516788:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/035443.516964:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/035443.517148:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/035443.517311:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/035443.517478:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/035443.517653:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/035443.517811:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/035443.517966:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/035443.518199:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/035443.518355:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/035443.518510:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/035443.518661:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/035443.518810:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/035443.518977:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/035443.519137:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/035443.519293:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/035443.519446:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/035443.519601:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/035443.519753:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/035443.519917:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/035443.520078:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/035443.520239:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/035443.520399:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/035443.520549:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/035443.520700:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/035443.520860:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/035443.521019:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/035443.521187:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/035443.521346:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/035443.521515:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/035443.521675:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/035443.521825:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/035443.521976:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/035443.522131:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/035443.522301:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/035443.522454:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/035443.522606:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/035443.522770:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/035443.522933:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/035443.574055:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/035443.607661:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/035443.608109:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 387cc44e1f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0713/035443.608258:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/035443.754972:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/035443.755151:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-error://chromewebdata/"
[1:1:0713/035443.772459:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 156 0x7f0a6b64f070 0x211864e3bce0 , "chrome-error://chromewebdata/"
[1:1:0713/035443.774056:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 156 0x7f0a6b64f070 0x211864e3bce0 , "chrome-error://chromewebdata/"
[1:1:0713/035443.775537:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 156 0x7f0a6b64f070 0x211864e3bce0 , "chrome-error://chromewebdata/"
[1:1:0713/035443.779969:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 156 0x7f0a6b64f070 0x211864e3bce0 , "chrome-error://chromewebdata/"
[1:1:0713/035443.784236:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/035443.800538:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.045357, 81, 1
[1:1:0713/035443.800737:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[3:3:0713/035444.017721:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0713/035444.166798:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/035444.166946:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-error://chromewebdata/"
[1:1:0713/035444.167582:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 238 0x7f0a6b64f070 0x2118652331e0 , "chrome-error://chromewebdata/"
[1:1:0713/035444.169850:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 238 0x7f0a6b64f070 0x2118652331e0 , "chrome-error://chromewebdata/"
[1:1:0713/035444.171592:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 238 0x7f0a6b64f070 0x2118652331e0 , "chrome-error://chromewebdata/"
[1:1:0713/035444.184710:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 238 0x7f0a6b64f070 0x2118652331e0 , "chrome-error://chromewebdata/"
[1:1:0713/035444.187160:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 238 0x7f0a6b64f070 0x2118652331e0 , "chrome-error://chromewebdata/"
[1:1:0713/035444.228368:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-error://chromewebdata/"
[1:1:0713/035444.230387:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-error://chromewebdata/"
[1:1:0713/035444.408014:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "loadstart", "chrome-error://chromewebdata/"
[1:1:0713/035444.413335:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "loadstart", "chrome-error://chromewebdata/"
[1:1:0713/035444.418078:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "loadstart", "chrome-error://chromewebdata/"
[1:1:0713/035444.441239:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0713/035444.441434:INFO:render_frame_impl.cc(7019)] 	 [url] = null
[31568:31568:0713/035444.442060:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 0:0_switcher://chrome
[1:1:0713/035444.589302:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "chrome-error://chromewebdata/"
