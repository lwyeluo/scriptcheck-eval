[0713/034945.420470:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/034945.420728:INFO:switcher_clone.cc(787)] backtrace rip is 7f94a2132891
[0713/034945.961505:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/034945.961754:INFO:switcher_clone.cc(787)] backtrace rip is 7f407e360891
[1:1:0713/034945.965559:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0713/034945.965714:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0713/034945.968500:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[0713/034946.786543:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/034946.786808:INFO:switcher_clone.cc(787)] backtrace rip is 7f01af306891
[30642:30642:0713/034946.866735:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile
ATTENTION: default value of option force_s3tc_enable overridden by environment.

DevTools listening on ws://127.0.0.1:9222/devtools/browser/86d08d8b-c1c6-4de4-95cc-4e8e33956769
[30673:30673:0713/034946.937132:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=30673
[30686:30686:0713/034946.937435:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=30686
[30642:30642:0713/034947.118893:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[30642:30671:0713/034947.119355:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0713/034947.119497:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0713/034947.119690:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0713/034947.120021:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0713/034947.120173:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0713/034947.122750:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x1dbe056e, 1
[1:1:0713/034947.122975:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x1c11e03e, 0
[1:1:0713/034947.123094:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x143921cb, 3
[1:1:0713/034947.123165:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x3816cbf5, 2
[1:1:0713/034947.123283:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 3effffffe0111c 6e05ffffffbe1d fffffff5ffffffcb1638 ffffffcb213914 , 10104, 4
[1:1:0713/034947.123969:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[30642:30671:0713/034947.124064:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING>�n���8�!9�?�
[30642:30671:0713/034947.124116:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is >�n���8�!9Ȧ�?�
[1:1:0713/034947.124062:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f407c59a0a0, 3
[1:1:0713/034947.124201:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f407c726080, 2
[1:1:0713/034947.124265:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f40663e8d20, -2
[30642:30671:0713/034947.124301:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[30642:30671:0713/034947.124347:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 30694, 4, 3ee0111c 6e05be1d f5cb1638 cb213914 
[1:1:0713/034947.131908:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0713/034947.132336:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3816cbf5
[1:1:0713/034947.132775:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3816cbf5
[1:1:0713/034947.133540:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3816cbf5
[1:1:0713/034947.134067:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3816cbf5
[1:1:0713/034947.134194:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3816cbf5
[1:1:0713/034947.134321:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3816cbf5
[1:1:0713/034947.134443:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3816cbf5
[1:1:0713/034947.134702:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3816cbf5
[1:1:0713/034947.134856:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f407e3607ba
[1:1:0713/034947.134954:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f407e357def, 7f407e36077a, 7f407e3620cf
[1:1:0713/034947.136580:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3816cbf5
[1:1:0713/034947.136753:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3816cbf5
[1:1:0713/034947.137075:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3816cbf5
[1:1:0713/034947.137932:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3816cbf5
[1:1:0713/034947.138045:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3816cbf5
[1:1:0713/034947.138149:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3816cbf5
[1:1:0713/034947.138245:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3816cbf5
[1:1:0713/034947.138774:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3816cbf5
[1:1:0713/034947.138918:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f407e3607ba
[1:1:0713/034947.138997:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f407e357def, 7f407e36077a, 7f407e3620cf
[1:1:0713/034947.141502:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0713/034947.141742:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0713/034947.141854:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffff06e1e78, 0x7ffff06e1df8)
[1:1:0713/034947.148503:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0713/034947.151613:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[30642:30642:0713/034947.325968:ERROR:in_progress_cache_impl.cc(188)] Cache is not initialized, cannot RetrieveEntry.
[30642:30642:0713/034947.326249:ERROR:in_progress_cache_impl.cc(188)] Cache is not initialized, cannot RetrieveEntry.
[30642:30642:0713/034947.326427:ERROR:in_progress_cache_impl.cc(188)] Cache is not initialized, cannot RetrieveEntry.
[30642:30642:0713/034947.326610:ERROR:in_progress_cache_impl.cc(188)] Cache is not initialized, cannot RetrieveEntry.
[30642:30642:0713/034947.551138:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[30642:30642:0713/034947.551667:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[30642:30642:0713/034947.560517:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[30642:30642:0713/034947.560576:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[30642:30642:0713/034947.560648:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,30694, 4
[30642:30653:0713/034947.569496:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[30642:30653:0713/034947.569563:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[1:7:0713/034947.569979:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[30642:30665:0713/034947.612155:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0713/034947.631253:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x29785308c220
[1:1:0713/034947.631790:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0713/034947.868156:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0713/034948.575582:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/034948.577535:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[30642:30642:0713/034948.724784:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[30642:30642:0713/034948.724863:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0713/034949.026844:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/034949.083191:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 19e80e701f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0713/034949.083409:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/034949.089224:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 19e80e701f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0713/034949.089392:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/034949.173646:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/034949.173817:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/034949.343857:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 356, "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/034949.346417:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 19e80e701f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0713/034949.346569:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/034949.359754:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 357, "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/034949.363208:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 19e80e701f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0713/034949.363370:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/034949.367447:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[30642:30642:0713/034949.368128:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0713/034949.369400:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x29785308ae20
[1:1:0713/034949.369519:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[30642:30642:0713/034949.370723:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[30642:30642:0713/034949.382541:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[30642:30642:0713/034949.382620:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0713/034949.402249:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/034949.696767:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 416 0x7f4067fc32e0 0x2978532595e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/034949.697456:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 19e80e701f78, , , var configData = {"googleBaseUrl":"https://www.google.com.hk/","isAccessibleBrowser":false,"isGoogle
[1:1:0713/034949.697600:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/034949.698156:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[30642:30642:0713/034949.723407:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0713/034949.724495:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x29785308b820
[1:1:0713/034949.724708:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[30642:30642:0713/034949.725908:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0713/034949.731990:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0713/034949.732184:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[30642:30642:0713/034949.733852:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[30642:30642:0713/034949.737710:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[30642:30642:0713/034949.738097:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[30642:30653:0713/034949.742564:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[30642:30653:0713/034949.742617:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[30642:30642:0713/034949.742643:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[30642:30642:0713/034949.742683:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[30642:30642:0713/034949.742747:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,30694, 4
[1:7:0713/034949.744347:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/034950.008529:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0713/034950.199517:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 468 0x7f4067fc32e0 0x2978532c64e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/034950.200199:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 19e80e701f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0713/034950.200379:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/034950.200784:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[30642:30642:0713/034950.296445:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[30642:30642:0713/034950.296508:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0713/034950.308490:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[30642:30642:0713/034950.414256:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[30642:30671:0713/034950.414515:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0713/034950.414645:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0713/034950.414831:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0713/034950.415036:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0713/034950.415122:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0713/034950.417285:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x35eb6654, 1
[1:1:0713/034950.417491:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x351ea37d, 0
[1:1:0713/034950.417663:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x1783f1eb, 3
[1:1:0713/034950.417822:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x3fb53fec, 2
[1:1:0713/034950.417973:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 7dffffffa31e35 5466ffffffeb35 ffffffec3fffffffb53f ffffffebfffffff1ffffff8317 , 10104, 5
[1:1:0713/034950.418734:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[30642:30671:0713/034950.418927:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING}�5Tf�5�?�?��.B�
[30642:30671:0713/034950.418979:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is }�5Tf�5�?�?���
.B�
[1:1:0713/034950.418916:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f407c59a0a0, 3
[30642:30671:0713/034950.419114:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 30736, 5, 7da31e35 5466eb35 ec3fb53f ebf18317 
[1:1:0713/034950.419113:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f407c726080, 2
[1:1:0713/034950.419215:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f40663e8d20, -2
[1:1:0713/034950.429047:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0713/034950.429251:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3fb53fec
[1:1:0713/034950.429422:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3fb53fec
[1:1:0713/034950.429687:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3fb53fec
[1:1:0713/034950.430194:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3fb53fec
[1:1:0713/034950.430294:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3fb53fec
[1:1:0713/034950.430394:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3fb53fec
[1:1:0713/034950.430486:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3fb53fec
[1:1:0713/034950.430741:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3fb53fec
[1:1:0713/034950.430877:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f407e3607ba
[1:1:0713/034950.430959:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f407e357def, 7f407e36077a, 7f407e3620cf
[1:1:0713/034950.432646:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3fb53fec
[1:1:0713/034950.432850:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3fb53fec
[1:1:0713/034950.433181:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3fb53fec
[1:1:0713/034950.434024:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3fb53fec
[1:1:0713/034950.434187:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3fb53fec
[1:1:0713/034950.434324:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3fb53fec
[1:1:0713/034950.434430:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3fb53fec
[1:1:0713/034950.434930:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3fb53fec
[1:1:0713/034950.435102:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f407e3607ba
[1:1:0713/034950.435190:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f407e357def, 7f407e36077a, 7f407e3620cf
[1:1:0713/034950.437821:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0713/034950.438084:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0713/034950.438184:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffff06e1e78, 0x7ffff06e1df8)
[1:1:0713/034950.444335:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0713/034950.446337:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0713/034950.454128:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/034950.546205:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x29785302a220
[1:1:0713/034950.546419:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0713/034950.740490:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/034950.740675:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[30642:30642:0713/034950.844499:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_null/, , 1
[30642:30642:0713/034950.844620:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, , null
[1:1:0713/034950.859275:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/034950.859555:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/034950.859758:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/034950.859916:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/034950.860107:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/034950.860262:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/034950.860459:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/034950.860623:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/034950.860806:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/034950.860960:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/034950.861132:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/034950.861289:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/034950.861443:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/034950.861593:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/034950.861755:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/034950.861923:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/034950.862884:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/034950.863753:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/034950.863928:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/034950.864141:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/034950.864308:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/034950.864462:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/034950.864631:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/034950.864784:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/034950.864952:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/034950.865120:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/034950.865271:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/034950.865424:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/034950.865584:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/034950.865733:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/034950.865883:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/034950.866048:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/034950.866215:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/034950.866378:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/034950.866529:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/034950.866678:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/034950.866826:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/034950.866994:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/034950.867154:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/034950.867307:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/034950.867463:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/034950.867612:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/034950.902605:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 534, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/034950.904380:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 19e80e82e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0713/034950.904572:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/034950.907084:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/034950.920509:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/034951.116098:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/034951.116281:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-error://chromewebdata/"
[1:1:0713/034951.135750:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 156 0x7f406609b070 0x297852b8f560 , "chrome-error://chromewebdata/"
[1:1:0713/034951.137464:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 156 0x7f406609b070 0x297852b8f560 , "chrome-error://chromewebdata/"
[1:1:0713/034951.139023:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 156 0x7f406609b070 0x297852b8f560 , "chrome-error://chromewebdata/"
[1:1:0713/034951.144039:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 156 0x7f406609b070 0x297852b8f560 , "chrome-error://chromewebdata/"
[1:1:0713/034951.148598:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/034951.165128:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0488191, 81, 1
[1:1:0713/034951.165317:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[3:3:0713/034951.375775:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0713/034951.549441:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/034951.549593:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-error://chromewebdata/"
[1:1:0713/034951.550259:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 238 0x7f406609b070 0x2978530d50e0 , "chrome-error://chromewebdata/"
[1:1:0713/034951.552491:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 238 0x7f406609b070 0x2978530d50e0 , "chrome-error://chromewebdata/"
[1:1:0713/034951.554032:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 238 0x7f406609b070 0x2978530d50e0 , "chrome-error://chromewebdata/"
[1:1:0713/034951.567112:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 238 0x7f406609b070 0x2978530d50e0 , "chrome-error://chromewebdata/"
[1:1:0713/034951.569901:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 238 0x7f406609b070 0x2978530d50e0 , "chrome-error://chromewebdata/"
[1:1:0713/034951.612557:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-error://chromewebdata/"
[1:1:0713/034951.614612:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-error://chromewebdata/"
[1:1:0713/034951.798768:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "loadstart", "chrome-error://chromewebdata/"
[1:1:0713/034951.804087:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "loadstart", "chrome-error://chromewebdata/"
[1:1:0713/034951.809214:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "loadstart", "chrome-error://chromewebdata/"
[1:1:0713/034951.836292:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0713/034951.836481:INFO:render_frame_impl.cc(7019)] 	 [url] = null
[30642:30642:0713/034951.837141:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 0:0_switcher://chrome
[1:1:0713/034951.993449:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "chrome-error://chromewebdata/"
