[0712/144041.434922:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/144041.435191:INFO:switcher_clone.cc(787)] backtrace rip is 7fae6c43b891
[0712/144041.987242:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/144041.987486:INFO:switcher_clone.cc(787)] backtrace rip is 7f988b3a9891
[1:1:0712/144041.991234:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/144041.991396:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/144041.994118:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[6361:6361:0712/144042.743973:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/01fbd2ab-2472-4480-88ba-baaac444ff38
[0712/144042.810565:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/144042.810803:INFO:switcher_clone.cc(787)] backtrace rip is 7f532e61c891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[6393:6393:0712/144042.963308:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=6393
[6406:6406:0712/144042.963674:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=6406
[6361:6361:0712/144042.987008:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[6361:6391:0712/144042.987417:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/144042.987541:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/144042.987685:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/144042.987992:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/144042.988116:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/144042.989868:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x1c5342ea, 1
[1:1:0712/144042.990065:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x327d13e5, 0
[1:1:0712/144042.990150:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x3074a2d5, 3
[1:1:0712/144042.990236:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x38750c81, 2
[1:1:0712/144042.990324:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffe5137d32 ffffffea42531c ffffff810c7538 ffffffd5ffffffa27430 , 10104, 4
[1:1:0712/144042.991007:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[6361:6391:0712/144042.991204:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�}2�BS�u8բt0��T;
[6361:6391:0712/144042.991246:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �}2�BS�u8բt0h���T;
[1:1:0712/144042.991200:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f98895e30a0, 3
[1:1:0712/144042.991309:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f988976f080, 2
[6361:6391:0712/144042.991385:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0712/144042.991389:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f9873431d20, -2
[6361:6391:0712/144042.991425:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 6414, 4, e5137d32 ea42531c 810c7538 d5a27430 
[1:1:0712/144042.999200:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/144042.999657:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 38750c81
[1:1:0712/144043.000180:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 38750c81
[1:1:0712/144043.000961:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 38750c81
[1:1:0712/144043.001557:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 38750c81
[1:1:0712/144043.001703:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 38750c81
[1:1:0712/144043.001849:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 38750c81
[1:1:0712/144043.001993:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 38750c81
[1:1:0712/144043.002246:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 38750c81
[1:1:0712/144043.002398:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f988b3a97ba
[1:1:0712/144043.002483:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f988b3a0def, 7f988b3a977a, 7f988b3ab0cf
[1:1:0712/144043.004135:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 38750c81
[1:1:0712/144043.004277:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 38750c81
[1:1:0712/144043.004572:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 38750c81
[1:1:0712/144043.005366:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 38750c81
[1:1:0712/144043.005484:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 38750c81
[1:1:0712/144043.005585:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 38750c81
[1:1:0712/144043.005684:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 38750c81
[1:1:0712/144043.006249:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 38750c81
[1:1:0712/144043.006397:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f988b3a97ba
[1:1:0712/144043.006453:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f988b3a0def, 7f988b3a977a, 7f988b3ab0cf
[1:1:0712/144043.008982:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/144043.009212:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/144043.009338:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fffecf52b78, 0x7fffecf52af8)
[1:1:0712/144043.016021:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/144043.018762:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[6361:6361:0712/144043.398550:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[6361:6361:0712/144043.399018:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[6361:6372:0712/144043.407746:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[6361:6372:0712/144043.407811:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[6361:6361:0712/144043.407844:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[6361:6361:0712/144043.407891:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[6361:6361:0712/144043.408033:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,6414, 4
[1:7:0712/144043.409011:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/144043.419870:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x29426572d220
[1:1:0712/144043.420014:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[6361:6384:0712/144043.516654:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/144043.655499:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0712/144044.387452:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/144044.389022:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[6361:6361:0712/144044.510758:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[6361:6361:0712/144044.510836:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/144044.818732:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/144044.888345:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3af571101f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/144044.888517:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/144044.893456:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3af571101f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/144044.893586:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/144044.940072:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/144044.940209:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/144045.079186:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 359, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/144045.081687:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3af571101f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/144045.081816:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/144045.093676:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 360, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/144045.096576:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3af571101f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/144045.096699:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/144045.100419:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[6361:6361:0712/144045.101046:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/144045.102183:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x29426572be20
[1:1:0712/144045.102286:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[6361:6361:0712/144045.103560:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[6361:6361:0712/144045.114885:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[6361:6361:0712/144045.114965:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/144045.134153:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/144045.423391:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 419 0x7f987500c2e0 0x2942659b5ee0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/144045.424020:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3af571101f78, , , var configData = {"googleBaseUrl":"https://www.google.com.hk/","isAccessibleBrowser":false,"isGoogle
[1:1:0712/144045.424145:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/144045.424681:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[6361:6361:0712/144045.449357:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/144045.450466:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x29426572c820
[1:1:0712/144045.450622:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[6361:6361:0712/144045.451798:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/144045.457456:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/144045.457645:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[6361:6361:0712/144045.458818:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[6361:6361:0712/144045.462773:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[6361:6361:0712/144045.463163:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[6361:6372:0712/144045.467543:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[6361:6372:0712/144045.467597:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[6361:6361:0712/144045.467615:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[6361:6361:0712/144045.467652:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[6361:6361:0712/144045.467732:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,6414, 4
[1:7:0712/144045.469319:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/144045.725554:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/144045.835866:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 468 0x7f987500c2e0 0x294265890360 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/144045.836449:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3af571101f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/144045.836591:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/144045.836933:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[6361:6361:0712/144045.985700:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[6361:6361:0712/144045.985781:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/144045.996735:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/144046.153948:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[6361:6361:0712/144046.361718:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[6361:6391:0712/144046.361990:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/144046.362117:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/144046.362241:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/144046.362422:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/144046.362497:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/144046.364675:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/144046.365192:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x2fcd3f78, 1
[1:1:0712/144046.365427:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x2e8c6d7c, 0
[1:1:0712/144046.364831:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/144046.365530:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x67de155, 3
[1:1:0712/144046.365613:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x1e503c99, 2
[1:1:0712/144046.365697:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 7c6dffffff8c2e 783fffffffcd2f ffffff993c501e 55ffffffe17d06 , 10104, 5
[1:1:0712/144046.366495:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[6361:6391:0712/144046.366734:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING|m�.x?�/�<PU�}��T;
[6361:6391:0712/144046.366782:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is |m�.x?�/�<PU�}H��T;
[1:1:0712/144046.366727:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f98895e30a0, 3
[1:1:0712/144046.366828:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f988976f080, 2
[6361:6391:0712/144046.366933:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 6456, 5, 7c6d8c2e 783fcd2f 993c501e 55e17d06 
[1:1:0712/144046.366920:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f9873431d20, -2
[1:1:0712/144046.375824:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/144046.376040:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1e503c99
[1:1:0712/144046.376196:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1e503c99
[1:1:0712/144046.376469:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1e503c99
[1:1:0712/144046.376965:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1e503c99
[1:1:0712/144046.377092:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1e503c99
[1:1:0712/144046.377217:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1e503c99
[1:1:0712/144046.377326:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1e503c99
[1:1:0712/144046.377580:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1e503c99
[1:1:0712/144046.377730:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f988b3a97ba
[1:1:0712/144046.377806:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f988b3a0def, 7f988b3a977a, 7f988b3ab0cf
[1:1:0712/144046.379508:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1e503c99
[1:1:0712/144046.379654:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1e503c99
[1:1:0712/144046.379948:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1e503c99
[1:1:0712/144046.380722:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1e503c99
[1:1:0712/144046.380823:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1e503c99
[1:1:0712/144046.380901:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1e503c99
[1:1:0712/144046.380974:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1e503c99
[1:1:0712/144046.381465:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1e503c99
[1:1:0712/144046.381616:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f988b3a97ba
[1:1:0712/144046.381680:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f988b3a0def, 7f988b3a977a, 7f988b3ab0cf
[1:1:0712/144046.384243:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/144046.384481:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/144046.384579:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fffecf52b78, 0x7fffecf52af8)
[1:1:0712/144046.390334:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/144046.392303:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/144046.477702:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x2942656f3220
[1:1:0712/144046.477854:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/144046.547278:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 541, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/144046.549674:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3af57122e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/144046.549875:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/144046.554665:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/144046.608060:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/144046.611851:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3af571101f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/144046.611975:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/144046.672228:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/144046.673016:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/144046.673121:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3af57122e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/144046.673226:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[6361:6361:0712/144046.696871:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[6361:6361:0712/144046.698999:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[6361:6361:0712/144046.717025:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://beian.miit.gov.cn/
[6361:6361:0712/144046.717097:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://beian.miit.gov.cn/, http://beian.miit.gov.cn/, 1
[6361:6361:0712/144046.717157:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://beian.miit.gov.cn/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 06:40:46 GMT Content-Type: text/html; charset=GBK Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Set-Cookie: JSESSIONID=_-Hk7SNI6e-lnY1DSMl-Dn8L84HhQ5eg-0yJ3a-30VQFUq41E5Ey!-1797433545; path=/; HttpOnly Content-Encoding: gzip X-Via-JSL: 0b3d685,- Set-Cookie: __jsluid_h=786ccb404ba976b9a72a06ece1102d14; max-age=31536000; path=/; HttpOnly X-Cache: bypass  ,6456, 5
[6361:6372:0712/144046.723009:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[6361:6372:0712/144046.723074:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[1:7:0712/144046.732019:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/144046.738722:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/144046.753563:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/144046.753758:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3af57122e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/144046.745852:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://beian.miit.gov.cn/
[1:1:0712/144046.753949:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/144046.823590:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[6361:6361:0712/144046.825206:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://beian.miit.gov.cn/, http://beian.miit.gov.cn/, 1
[6361:6361:0712/144046.825267:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://beian.miit.gov.cn/, http://beian.miit.gov.cn
[1:1:0712/144046.861767:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/144046.888503:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/144046.888689:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://beian.miit.gov.cn/"
[1:1:0712/144046.964467:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: the server responded with a status of 404 (Not Found)","http://beian.miit.gov.cn/styles/styles.css"
[1:1:0712/144047.032517:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.qq.com/"
[1:1:0712/144047.047517:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 143 0x7f988976f080 0x2942658504c0 1 0 0x2942658504d8 , "http://beian.miit.gov.cn/"
[1:1:0712/144047.049309:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://beian.miit.gov.cn/, 074a03d62860, , , /*
 * jQuery 1.2.6 - New Wave Javascript
 *
 * Copyright (c) 2008 John Resig (jquery.com)
 * Dua
[1:1:0712/144047.049483:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://beian.miit.gov.cn/", "beian.miit.gov.cn", 3, 1, , , 0
[1:1:0712/144047.138845:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://amazon.com/"
[1:1:0712/144047.172469:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://taobao.com/"
[1:1:0712/144047.221439:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/144047.236331:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://tmall.com/"
[1:1:0712/144047.270157:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://vk.com/"
[1:1:0712/144047.294418:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.jd.com/"
[1:1:0712/144047.365381:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://yahoo.com/"
[1:1:0712/144047.399842:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://sohu.com/"
[1:1:0712/144047.638215:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 143 0x7f988976f080 0x2942658504c0 1 0 0x2942658504d8 , "http://beian.miit.gov.cn/"
[1:1:0712/144047.640630:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x1a78054029c8, 0x2942655879a0
[1:1:0712/144047.640808:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://beian.miit.gov.cn/", 0
[1:1:0712/144047.641060:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://beian.miit.gov.cn/, 150
[1:1:0712/144047.641266:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 150 0x7f98730e4070 0x2942658458e0 , 5:3_http://beian.miit.gov.cn/, 1, -5:3_http://beian.miit.gov.cn/, 143 0x7f988976f080 0x2942658504c0 1 0 0x2942658504d8 
[1:1:0712/144047.643955:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://beian.miit.gov.cn/"
[1:1:0712/144047.677905:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/144047.678094:INFO:render_frame_impl.cc(7019)] 	 [url] = http://beian.miit.gov.cn
[1:1:0712/144047.690030:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://beian.miit.gov.cn/, 150, 7f9875a29881
[1:1:0712/144047.693014:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"074a03d62860","ptid":"143 0x7f988976f080 0x2942658504c0 1 0 0x2942658504d8 ","rf":"5:3_http://beian.miit.gov.cn/"}
[1:1:0712/144047.693260:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://beian.miit.gov.cn/","ptid":"143 0x7f988976f080 0x2942658504c0 1 0 0x2942658504d8 ","rf":"5:3_http://beian.miit.gov.cn/"}
[1:1:0712/144047.693477:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://beian.miit.gov.cn/"
[1:1:0712/144047.693763:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://beian.miit.gov.cn/, 074a03d62860, , , (){if(D.isReady)return;if(document.readyState!="loaded"&&document.readyState!="complete"){setTimeout
[1:1:0712/144047.693883:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://beian.miit.gov.cn/", "beian.miit.gov.cn", 3, 1, , , 0
[1:1:0712/144051.565529:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/144056.025049:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://beian.miit.gov.cn/, 074a03d62860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/144056.025274:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://beian.miit.gov.cn/", "beian.miit.gov.cn", 3, 1, , , 0
[6361:6361:0712/144056.174805:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://beian.miit.gov.cn/
[3:3:0712/144056.193039:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[6361:6361:0712/144056.444039:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[6361:6361:0712/144056.444480:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[6361:6372:0712/144056.454461:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[6361:6372:0712/144056.454529:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[6361:6361:0712/144056.454551:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://beian.miit.gov.cn/
[6361:6361:0712/144056.454595:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://beian.miit.gov.cn/, http://beian.miit.gov.cn/state/outPortal/loginPortal.action;jsessionid=_-Hk7SNI6e-lnY1DSMl-Dn8L84HhQ5eg-0yJ3a-30VQFUq41E5Ey!-1797433545, 1
[6361:6361:0712/144056.454646:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://beian.miit.gov.cn/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 06:40:56 GMT Content-Type: text/html; charset=GBK Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Content-Language: en-US Content-Encoding: gzip X-Via-JSL: 0b3d685,- X-Cache: bypass  ,6456, 5
[1:7:0712/144056.455774:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/144056.489108:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://beian.miit.gov.cn/
[1:1:0712/144056.515975:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "unload", "http://beian.miit.gov.cn/"
[1:1:0712/144056.516397:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://beian.miit.gov.cn/, 074a03d62860, , , (){if(typeof D!="undefined"&&!D.event.triggered)return D.event.handle.apply(arguments.callee.elem,ar
[1:1:0712/144056.516554:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://beian.miit.gov.cn/", "beian.miit.gov.cn", 3, 1, , , 0
[1:1:0712/144056.563894:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[6361:6361:0712/144056.566399:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://beian.miit.gov.cn/, http://beian.miit.gov.cn/, 1
[6361:6361:0712/144056.566455:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://beian.miit.gov.cn/, http://beian.miit.gov.cn
[1:1:0712/144056.596980:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/144056.619438:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/144056.648739:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/144056.648885:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://beian.miit.gov.cn/state/outPortal/loginPortal.action;jsessionid=_-Hk7SNI6e-lnY1DSMl-Dn8L84HhQ5eg-0yJ3a-30VQFUq41E5Ey!-1797433545"
[1:1:0712/144058.443251:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: the server responded with a status of 404 (Not Found)","http://beian.miit.gov.cn/state/outPortal/images/portal_0/portal/6px.gif"
[1:1:0712/144059.038090:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 415 0x7f988976f080 0x2942661ad7e0 1 0 0x2942661ad7f8 , "http://beian.miit.gov.cn/state/outPortal/loginPortal.action;jsessionid=_-Hk7SNI6e-lnY1DSMl-Dn8L84HhQ5eg-0yJ3a-30VQFUq41E5Ey!-1797433545"
[1:1:0712/144059.039770:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://beian.miit.gov.cn/, 074a03d62860, , , /*
 * jQuery 1.2.6 - New Wave Javascript
 *
 * Copyright (c) 2008 John Resig (jquery.com)
 * Dua
[1:1:0712/144059.039954:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://beian.miit.gov.cn/state/outPortal/loginPortal.action;jsessionid=_-Hk7SNI6e-lnY1DSMl-Dn8L84HhQ5eg-0yJ3a-30VQFUq41E5Ey!-1797433545", "beian.miit.gov.cn", 3, 1, , , 0
[1:1:0712/144059.582538:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/144059.589902:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 415 0x7f988976f080 0x2942661ad7e0 1 0 0x2942661ad7f8 , "http://beian.miit.gov.cn/state/outPortal/loginPortal.action;jsessionid=_-Hk7SNI6e-lnY1DSMl-Dn8L84HhQ5eg-0yJ3a-30VQFUq41E5Ey!-1797433545"
[1:1:0712/144059.592911:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 415 0x7f988976f080 0x2942661ad7e0 1 0 0x2942661ad7f8 , "http://beian.miit.gov.cn/state/outPortal/loginPortal.action;jsessionid=_-Hk7SNI6e-lnY1DSMl-Dn8L84HhQ5eg-0yJ3a-30VQFUq41E5Ey!-1797433545"
[1:1:0712/144059.596165:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 415 0x7f988976f080 0x2942661ad7e0 1 0 0x2942661ad7f8 , "http://beian.miit.gov.cn/state/outPortal/loginPortal.action;jsessionid=_-Hk7SNI6e-lnY1DSMl-Dn8L84HhQ5eg-0yJ3a-30VQFUq41E5Ey!-1797433545"
[1:1:0712/144059.598819:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 415 0x7f988976f080 0x2942661ad7e0 1 0 0x2942661ad7f8 , "http://beian.miit.gov.cn/state/outPortal/loginPortal.action;jsessionid=_-Hk7SNI6e-lnY1DSMl-Dn8L84HhQ5eg-0yJ3a-30VQFUq41E5Ey!-1797433545"
[1:1:0712/144059.602894:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 415 0x7f988976f080 0x2942661ad7e0 1 0 0x2942661ad7f8 , "http://beian.miit.gov.cn/state/outPortal/loginPortal.action;jsessionid=_-Hk7SNI6e-lnY1DSMl-Dn8L84HhQ5eg-0yJ3a-30VQFUq41E5Ey!-1797433545"
[1:1:0712/144059.726304:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.137956, 1427, 1
[1:1:0712/144059.726494:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/144100.927460:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/144100.927649:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://beian.miit.gov.cn/state/outPortal/loginPortal.action;jsessionid=_-Hk7SNI6e-lnY1DSMl-Dn8L84HhQ5eg-0yJ3a-30VQFUq41E5Ey!-1797433545"
[1:1:0712/144100.928876:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 544 0x7f98730e4070 0x2942669883e0 , "http://beian.miit.gov.cn/state/outPortal/loginPortal.action;jsessionid=_-Hk7SNI6e-lnY1DSMl-Dn8L84HhQ5eg-0yJ3a-30VQFUq41E5Ey!-1797433545"
[1:1:0712/144100.929613:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://beian.miit.gov.cn/, 074a03d62860, , , //在页面增加一个放置图标的区块
if(!document.getElementById('_span_jiucuo'))
	documen
[1:1:0712/144100.929735:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://beian.miit.gov.cn/state/outPortal/loginPortal.action;jsessionid=_-Hk7SNI6e-lnY1DSMl-Dn8L84HhQ5eg-0yJ3a-30VQFUq41E5Ey!-1797433545", "beian.miit.gov.cn", 3, 1, , , 0
[1:1:0712/144100.934620:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 544 0x7f98730e4070 0x2942669883e0 , "http://beian.miit.gov.cn/state/outPortal/loginPortal.action;jsessionid=_-Hk7SNI6e-lnY1DSMl-Dn8L84HhQ5eg-0yJ3a-30VQFUq41E5Ey!-1797433545"
[1:1:0712/144100.939884:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x1a78055219d0, 0x2942655879b0
[1:1:0712/144100.940042:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://beian.miit.gov.cn/state/outPortal/loginPortal.action;jsessionid=_-Hk7SNI6e-lnY1DSMl-Dn8L84HhQ5eg-0yJ3a-30VQFUq41E5Ey!-1797433545", 0
[1:1:0712/144100.940323:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://beian.miit.gov.cn/, 600
[1:1:0712/144100.940451:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 600 0x7f98730e4070 0x29426697afe0 , 5:3_http://beian.miit.gov.cn/, 1, -5:3_http://beian.miit.gov.cn/, 544 0x7f98730e4070 0x2942669883e0 
[1:1:0712/144100.942972:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://beian.miit.gov.cn/state/outPortal/loginPortal.action;jsessionid=_-Hk7SNI6e-lnY1DSMl-Dn8L84HhQ5eg-0yJ3a-30VQFUq41E5Ey!-1797433545"
