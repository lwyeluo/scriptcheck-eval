[0712/144523.237046:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/144523.237312:INFO:switcher_clone.cc(787)] backtrace rip is 7f0bc4db4891
[0712/144523.788230:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/144523.788479:INFO:switcher_clone.cc(787)] backtrace rip is 7fcbef41e891
[1:1:0712/144523.792291:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/144523.792455:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/144523.795281:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[7207:7207:0712/144524.540618:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/3b4f0f31-c40c-4ada-ac8a-222285c854ab
[0712/144524.604892:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/144524.605166:INFO:switcher_clone.cc(787)] backtrace rip is 7ffb3e8b9891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[7239:7239:0712/144524.751444:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=7239
[7252:7252:0712/144524.751771:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=7252
[7207:7207:0712/144524.789980:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[7207:7237:0712/144524.790401:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/144524.791131:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/144524.791289:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/144524.791592:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/144524.791707:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/144524.793549:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x20bdd6ae, 1
[1:1:0712/144524.793736:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x44c3fa1, 0
[1:1:0712/144524.793823:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x3fbd4e0b, 3
[1:1:0712/144524.793886:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x3165e1f, 2
[1:1:0712/144524.793955:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffa13f4c04 ffffffaeffffffd6ffffffbd20 1f5e1603 0b4effffffbd3f , 10104, 4
[1:1:0712/144524.794620:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[7207:7237:0712/144524.794720:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�?L�ֽ ^N�?��
[7207:7237:0712/144524.794759:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �?L�ֽ ^N�?A��
[1:1:0712/144524.794719:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fcbed6580a0, 3
[1:1:0712/144524.794823:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fcbed7e4080, 2
[7207:7237:0712/144524.794919:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0712/144524.794903:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fcbd74a6d20, -2
[7207:7237:0712/144524.794962:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 7260, 4, a13f4c04 aed6bd20 1f5e1603 0b4ebd3f 
[1:1:0712/144524.802785:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/144524.803218:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3165e1f
[1:1:0712/144524.803661:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3165e1f
[1:1:0712/144524.804425:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3165e1f
[1:1:0712/144524.804941:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3165e1f
[1:1:0712/144524.805027:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3165e1f
[1:1:0712/144524.805170:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3165e1f
[1:1:0712/144524.805272:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3165e1f
[1:1:0712/144524.805530:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3165e1f
[1:1:0712/144524.805673:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fcbef41e7ba
[1:1:0712/144524.805755:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fcbef415def, 7fcbef41e77a, 7fcbef4200cf
[1:1:0712/144524.807415:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3165e1f
[1:1:0712/144524.807566:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3165e1f
[1:1:0712/144524.807844:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3165e1f
[1:1:0712/144524.808645:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3165e1f
[1:1:0712/144524.808736:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3165e1f
[1:1:0712/144524.808814:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3165e1f
[1:1:0712/144524.808890:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3165e1f
[1:1:0712/144524.809394:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3165e1f
[1:1:0712/144524.809540:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fcbef41e7ba
[1:1:0712/144524.809607:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fcbef415def, 7fcbef41e77a, 7fcbef4200cf
[1:1:0712/144524.812199:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/144524.812378:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/144524.812450:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffd84cc3908, 0x7ffd84cc3888)
[1:1:0712/144524.819151:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/144524.827183:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[7207:7207:0712/144525.238442:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[7207:7207:0712/144525.238966:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[7207:7219:0712/144525.246846:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[7207:7219:0712/144525.246907:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[7207:7207:0712/144525.246927:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[7207:7207:0712/144525.246967:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[7207:7207:0712/144525.247035:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,7260, 4
[1:7:0712/144525.249282:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/144525.301321:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x1e44b30d8220
[1:1:0712/144525.301475:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[7207:7230:0712/144525.341303:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/144525.483912:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[7207:7207:0712/144526.126142:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[7207:7207:0712/144526.126223:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/144526.138625:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/144526.140187:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/144526.543209:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 01d728ae1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/144526.543395:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/144526.548402:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 01d728ae1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/144526.548528:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/144526.582726:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/144526.692850:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/144526.693003:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/144526.827262:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 356, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/144526.829787:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 01d728ae1f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/144526.829927:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/144526.841677:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 357, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/144526.844574:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 01d728ae1f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/144526.844708:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/144526.848487:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[7207:7207:0712/144526.849149:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/144526.850262:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x1e44b30d6e20
[1:1:0712/144526.850361:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[7207:7207:0712/144526.851786:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[7207:7207:0712/144526.862879:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[7207:7207:0712/144526.862958:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/144526.882498:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/144527.181135:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 417 0x7fcbd90812e0 0x1e44b32d8960 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/144527.181782:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 01d728ae1f78, , , var configData = {"googleBaseUrl":"https://www.google.com.hk/","isAccessibleBrowser":false,"isGoogle
[1:1:0712/144527.181905:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/144527.182444:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[7207:7207:0712/144527.207031:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/144527.208102:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x1e44b30d7820
[1:1:0712/144527.208219:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[7207:7207:0712/144527.209389:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/144527.215082:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/144527.215236:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[7207:7207:0712/144527.217249:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[7207:7207:0712/144527.220997:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[7207:7207:0712/144527.221411:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[7207:7219:0712/144527.225864:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[7207:7219:0712/144527.225920:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[7207:7207:0712/144527.225936:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[7207:7207:0712/144527.225975:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[7207:7207:0712/144527.226032:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,7260, 4
[1:7:0712/144527.227351:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/144527.473287:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/144527.582326:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 464 0x7fcbd90812e0 0x1e44b3222e60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/144527.582866:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 01d728ae1f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/144527.582986:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/144527.583287:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[7207:7207:0712/144527.720372:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[7207:7207:0712/144527.720441:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/144527.732287:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/144527.844151:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/144528.040702:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/144528.040863:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[7207:7207:0712/144528.091450:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[7207:7237:0712/144528.091718:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/144528.091842:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/144528.091965:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/144528.092146:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/144528.092222:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/144528.094314:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x33cb0e0, 1
[1:1:0712/144528.094531:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x3df5008b, 0
[1:1:0712/144528.094640:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x122af6bc, 3
[1:1:0712/144528.094776:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x1620cfd, 2
[1:1:0712/144528.094899:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffff8b00fffffff53d ffffffe0ffffffb03c03 fffffffd0c6201 ffffffbcfffffff62a12 , 10104, 5
[1:1:0712/144528.095647:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[7207:7237:0712/144528.095818:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�
[7207:7237:0712/144528.095862:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �
[1:1:0712/144528.095817:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fcbed6580a0, 3
[7207:7237:0712/144528.095990:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 7304, 5, 8b00f53d e0b03c03 fd0c6201 bcf62a12 
[1:1:0712/144528.096162:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fcbed7e4080, 2
[1:1:0712/144528.096275:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fcbd74a6d20, -2
[1:1:0712/144528.105661:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/144528.105870:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1620cfd
[1:1:0712/144528.106040:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1620cfd
[1:1:0712/144528.106301:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1620cfd
[1:1:0712/144528.106791:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1620cfd
[1:1:0712/144528.106894:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1620cfd
[1:1:0712/144528.106991:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1620cfd
[1:1:0712/144528.107088:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1620cfd
[1:1:0712/144528.107343:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1620cfd
[1:1:0712/144528.107476:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fcbef41e7ba
[1:1:0712/144528.107559:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fcbef415def, 7fcbef41e77a, 7fcbef4200cf
[1:1:0712/144528.109281:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1620cfd
[1:1:0712/144528.109455:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1620cfd
[1:1:0712/144528.109756:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1620cfd
[1:1:0712/144528.110528:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1620cfd
[1:1:0712/144528.110634:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1620cfd
[1:1:0712/144528.110726:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1620cfd
[1:1:0712/144528.110817:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1620cfd
[1:1:0712/144528.111344:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1620cfd
[1:1:0712/144528.111495:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fcbef41e7ba
[1:1:0712/144528.111575:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fcbef415def, 7fcbef41e77a, 7fcbef4200cf
[1:1:0712/144528.114204:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/144528.114452:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/144528.114551:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffd84cc3908, 0x7ffd84cc3888)
[1:1:0712/144528.120501:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/144528.122710:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/144528.196543:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 531, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/144528.199213:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 01d728c0e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/144528.199387:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/144528.201817:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/144528.210563:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x1e44b307f220
[1:1:0712/144528.210691:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[7207:7207:0712/144534.355186:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[7207:7207:0712/144534.357151:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[7207:7219:0712/144534.371688:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[7207:7219:0712/144534.371753:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[7207:7207:0712/144534.371881:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://account.youdao.com/
[7207:7207:0712/144534.371920:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://account.youdao.com/, http://account.youdao.com/login?service=dict&back_url=http://dict.youdao.com/wordbook/wordlist%3Fkeyfrom%3Dlogin_from_dict2.index, 1
[7207:7207:0712/144534.371987:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://account.youdao.com/, HTTP/1.1 200 OK Server: nginx Date: Fri, 12 Jul 2019 06:45:33 GMT Content-Type: text/html; charset=UTF-8 Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Content-Language: en-US Content-Encoding: gzip  ,7304, 5
[1:7:0712/144534.374421:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/144534.387180:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://account.youdao.com/
[7207:7207:0712/144534.438608:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://account.youdao.com/, http://account.youdao.com/, 1
[7207:7207:0712/144534.438670:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://account.youdao.com/, http://account.youdao.com
[1:1:0712/144534.448470:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/144534.448885:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/144534.488232:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/144534.508101:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/144534.519128:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/144534.519314:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://account.youdao.com/login?service=dict&back_url=http://dict.youdao.com/wordbook/wordlist%3Fkeyfrom%3Dlogin_from_dict2.index"
[1:1:0712/144534.555493:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0360579, 186, 1
[1:1:0712/144534.555686:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/144534.654089:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/144534.654210:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://account.youdao.com/login?service=dict&back_url=http://dict.youdao.com/wordbook/wordlist%3Fkeyfrom%3Dlogin_from_dict2.index"
[1:1:0712/144534.781701:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 183 0x7fcbd7159070 0x1e44b32299e0 , "http://account.youdao.com/login?service=dict&back_url=http://dict.youdao.com/wordbook/wordlist%3Fkeyfrom%3Dlogin_from_dict2.index"
[1:1:0712/144534.783459:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://account.youdao.com/, 0ac36cfe2860, , , var hexcase=0,b64pad="";function hex_md5(d){return rstr2hex(rstr_md5(str2rstr_utf8(d)))}function b64
[1:1:0712/144534.783604:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://account.youdao.com/login?service=dict&back_url=http://dict.youdao.com/wordbook/wordlist%3Fkeyfrom%3Dlogin_from_dict2.index", "account.youdao.com", 3, 1, , , 0
[1:1:0712/144534.791490:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.00704312, 62, 1
[1:1:0712/144534.791652:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/144534.872534:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/144534.872693:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://account.youdao.com/login?service=dict&back_url=http://dict.youdao.com/wordbook/wordlist%3Fkeyfrom%3Dlogin_from_dict2.index"
[1:1:0712/144534.874037:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 202 0x7fcbd7159070 0x1e44b2dccde0 , "http://account.youdao.com/login?service=dict&back_url=http://dict.youdao.com/wordbook/wordlist%3Fkeyfrom%3Dlogin_from_dict2.index"
[1:1:0712/144534.875279:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://account.youdao.com/, 0ac36cfe2860, , , String.prototype.trim=function(){return this.replace(/(^\s*)|(\s*$)/g,"")};String.prototype.endsWith
[1:1:0712/144534.875421:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://account.youdao.com/login?service=dict&back_url=http://dict.youdao.com/wordbook/wordlist%3Fkeyfrom%3Dlogin_from_dict2.index", "account.youdao.com", 3, 1, , , 0
[1:1:0712/144534.878497:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 202 0x7fcbd7159070 0x1e44b2dccde0 , "http://account.youdao.com/login?service=dict&back_url=http://dict.youdao.com/wordbook/wordlist%3Fkeyfrom%3Dlogin_from_dict2.index"
[1:1:0712/144534.879801:INFO:document.cc(5190)] >>> Document::setDomain. [old, new] = "account.youdao.com", "youdao.com"
[1:1:0712/144534.880654:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/144541.576025:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/144544.010035:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://account.youdao.com/, 0ac36cfe2860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/144544.010210:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://account.youdao.com/login?service=dict&back_url=http://dict.youdao.com/wordbook/wordlist%3Fkeyfrom%3Dlogin_from_dict2.index", "youdao.com", 3, 1, , , 0
[7207:7207:0712/144544.145244:INFO:CONSOLE(0)] "[DOM] Input elements should have autocomplete attributes (suggested: "current-password"): (More info: https://goo.gl/9p2vKq) %o", source: http://account.youdao.com/login?service=dict&back_url=http://dict.youdao.com/wordbook/wordlist%3Fkeyfrom%3Dlogin_from_dict2.index (0)
[3:3:0712/144544.192805:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[7207:7207:0712/144544.211035:INFO:CONSOLE(0)] "This page includes a password or credit card input in a non-secure context. A warning has been added to the URL bar. For more information, see https://goo.gl/zmWq3m.", source: http://account.youdao.com/login?service=dict&back_url=http://dict.youdao.com/wordbook/wordlist%3Fkeyfrom%3Dlogin_from_dict2.index (0)
