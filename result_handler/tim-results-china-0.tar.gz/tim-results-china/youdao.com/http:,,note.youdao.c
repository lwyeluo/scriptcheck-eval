[0712/143931.685168:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/143931.685425:INFO:switcher_clone.cc(787)] backtrace rip is 7f3521cbc891
[0712/143932.240727:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/143932.240967:INFO:switcher_clone.cc(787)] backtrace rip is 7fe619dee891
[1:1:0712/143932.244895:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/143932.245100:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/143932.247907:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[6119:6119:0712/143932.984487:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/fa5de11d-d8a0-4dca-9bef-59bc235ff91c
[0712/143933.074424:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/143933.074698:INFO:switcher_clone.cc(787)] backtrace rip is 7f2e0a44a891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[6151:6151:0712/143933.226401:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=6151
[6164:6164:0712/143933.231229:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=6164
[6119:6119:0712/143933.237082:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[6119:6149:0712/143933.237455:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/143933.237580:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/143933.237736:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/143933.238047:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/143933.238198:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/143933.240325:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x46f5502, 1
[1:1:0712/143933.240498:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x1dd2b3f9, 0
[1:1:0712/143933.240568:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x199bbe92, 3
[1:1:0712/143933.240627:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x1db0b2f, 2
[1:1:0712/143933.240697:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = fffffff9ffffffb3ffffffd21d 02556f04 2f0bffffffdb01 ffffff92ffffffbeffffff9b19 , 10104, 4
[1:1:0712/143933.241410:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[6119:6149:0712/143933.241559:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING���Uo/����^,2
[6119:6149:0712/143933.241606:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ���Uo/�����O^,2
[1:1:0712/143933.241551:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fe6180280a0, 3
[1:1:0712/143933.241649:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fe6181b4080, 2
[6119:6149:0712/143933.241741:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0712/143933.241732:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fe601e76d20, -2
[6119:6149:0712/143933.241783:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 6172, 4, f9b3d21d 02556f04 2f0bdb01 92be9b19 
[1:1:0712/143933.249566:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/143933.250011:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1db0b2f
[1:1:0712/143933.250507:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1db0b2f
[1:1:0712/143933.251312:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1db0b2f
[1:1:0712/143933.251911:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1db0b2f
[1:1:0712/143933.252015:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1db0b2f
[1:1:0712/143933.252113:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1db0b2f
[1:1:0712/143933.252205:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1db0b2f
[1:1:0712/143933.252454:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1db0b2f
[1:1:0712/143933.252606:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fe619dee7ba
[1:1:0712/143933.252680:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fe619de5def, 7fe619dee77a, 7fe619df00cf
[1:1:0712/143933.254425:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1db0b2f
[1:1:0712/143933.254597:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1db0b2f
[1:1:0712/143933.254897:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1db0b2f
[1:1:0712/143933.255689:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1db0b2f
[1:1:0712/143933.255787:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1db0b2f
[1:1:0712/143933.255884:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1db0b2f
[1:1:0712/143933.255978:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1db0b2f
[1:1:0712/143933.256477:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1db0b2f
[1:1:0712/143933.256638:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fe619dee7ba
[1:1:0712/143933.256711:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fe619de5def, 7fe619dee77a, 7fe619df00cf
[1:1:0712/143933.259838:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/143933.260074:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/143933.260180:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffd3a63e728, 0x7ffd3a63e6a8)
[1:1:0712/143933.276439:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/143933.279409:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/143933.679533:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x96c237e3220
[1:1:0712/143933.679700:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[6119:6119:0712/143933.680126:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[6119:6119:0712/143933.680634:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[6119:6131:0712/143933.688405:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[6119:6131:0712/143933.688468:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[6119:6119:0712/143933.688480:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[6119:6119:0712/143933.688521:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[6119:6119:0712/143933.688583:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,6172, 4
[1:7:0712/143933.689766:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[6119:6143:0712/143933.794900:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/143933.914332:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[6119:6119:0712/143934.563059:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[6119:6119:0712/143934.563143:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/143934.579524:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/143934.581226:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/143934.992160:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2cd5ad6c1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/143934.992363:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/143934.998315:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2cd5ad6c1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/143934.998451:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/143935.019997:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/143935.124463:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/143935.124605:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/143935.241127:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 360, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/143935.243600:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2cd5ad6c1f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/143935.243730:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/143935.255560:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 361, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/143935.258515:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2cd5ad6c1f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/143935.258638:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/143935.262400:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[6119:6119:0712/143935.263017:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/143935.264094:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x96c237e1e20
[1:1:0712/143935.264211:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[6119:6119:0712/143935.265592:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[6119:6119:0712/143935.276718:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[6119:6119:0712/143935.276796:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/143935.296884:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/143935.588200:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 420 0x7fe603a512e0 0x96c23a880e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/143935.588842:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2cd5ad6c1f78, , , var configData = {"googleBaseUrl":"https://www.google.com.hk/","isAccessibleBrowser":false,"isGoogle
[1:1:0712/143935.588953:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/143935.589500:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[6119:6119:0712/143935.614186:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/143935.615231:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x96c237e2820
[1:1:0712/143935.615368:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[6119:6119:0712/143935.616434:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/143935.622260:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/143935.622449:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[6119:6119:0712/143935.623503:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[6119:6119:0712/143935.627505:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[6119:6119:0712/143935.627913:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[6119:6131:0712/143935.632199:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[6119:6131:0712/143935.632250:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[6119:6119:0712/143935.632270:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[6119:6119:0712/143935.632307:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[6119:6119:0712/143935.632364:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,6172, 4
[1:7:0712/143935.633736:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/143935.879230:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/143935.987865:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 467 0x7fe603a512e0 0x96c23a5b860 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/143935.988439:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2cd5ad6c1f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/143935.988581:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/143935.988923:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[6119:6119:0712/143936.134448:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[6119:6119:0712/143936.135830:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/143936.146840:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/143936.269534:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/143936.477422:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/143936.477615:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[6119:6119:0712/143936.517680:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[6119:6149:0712/143936.517943:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/143936.518071:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/143936.518193:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/143936.518372:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/143936.518448:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/143936.520787:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x2ffac05c, 1
[1:1:0712/143936.520969:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0xa1a4b7f, 0
[1:1:0712/143936.521083:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x3c1fb44c, 3
[1:1:0712/143936.521168:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x355584c5, 2
[1:1:0712/143936.521333:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 7f4b1a0a 5cffffffc0fffffffa2f ffffffc5ffffff845535 4cffffffb41f3c , 10104, 5
[1:1:0712/143936.522074:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[6119:6149:0712/143936.522207:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGK
\��/ńU5L�<�.2
[6119:6149:0712/143936.522254:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is K
\��/ńU5L�<���.2
[1:1:0712/143936.522205:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fe6180280a0, 3
[1:1:0712/143936.522303:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fe6181b4080, 2
[6119:6149:0712/143936.522388:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 6215, 5, 7f4b1a0a 5cc0fa2f c5845535 4cb41f3c 
[1:1:0712/143936.522398:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fe601e76d20, -2
[1:1:0712/143936.531206:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/143936.531427:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 355584c5
[1:1:0712/143936.531594:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 355584c5
[1:1:0712/143936.531838:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 355584c5
[1:1:0712/143936.532347:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 355584c5
[1:1:0712/143936.532461:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 355584c5
[1:1:0712/143936.532560:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 355584c5
[1:1:0712/143936.532663:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 355584c5
[1:1:0712/143936.532912:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 355584c5
[1:1:0712/143936.533064:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fe619dee7ba
[1:1:0712/143936.533153:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fe619de5def, 7fe619dee77a, 7fe619df00cf
[1:1:0712/143936.534845:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 355584c5
[1:1:0712/143936.535008:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 355584c5
[1:1:0712/143936.535293:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 355584c5
[1:1:0712/143936.536046:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 355584c5
[1:1:0712/143936.536157:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 355584c5
[1:1:0712/143936.536258:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 355584c5
[1:1:0712/143936.536357:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 355584c5
[1:1:0712/143936.536841:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 355584c5
[1:1:0712/143936.537003:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fe619dee7ba
[1:1:0712/143936.537084:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fe619de5def, 7fe619dee77a, 7fe619df00cf
[1:1:0712/143936.539616:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/143936.539846:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/143936.539943:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffd3a63e728, 0x7ffd3a63e6a8)
[1:1:0712/143936.545743:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/143936.547995:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/143936.616515:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 533, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/143936.618246:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2cd5ad7ee5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/143936.618446:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/143936.620814:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/143936.636553:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x96c237cc220
[1:1:0712/143936.636861:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[6119:6119:0712/143936.965874:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[6119:6119:0712/143936.967928:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[6119:6131:0712/143936.983561:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[6119:6131:0712/143936.983642:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[6119:6119:0712/143936.984391:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://note.youdao.com/
[6119:6119:0712/143936.984440:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://note.youdao.com/, http://note.youdao.com/?keyfrom=dict2.index, 1
[6119:6119:0712/143936.984516:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://note.youdao.com/, HTTP/1.1 200 OK Server: Tengine Date: Fri, 12 Jul 2019 06:39:36 GMT Content-Type: text/html; charset=utf-8 Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Last-Modified: Fri, 21 Jun 2019 03:26:16 GMT Cache-Control: no-cache Content-Encoding: gzip  ,6215, 5
[1:7:0712/143936.985975:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/143936.997795:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://note.youdao.com/
[6119:6119:0712/143937.056888:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://note.youdao.com/, http://note.youdao.com/, 1
[6119:6119:0712/143937.056962:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://note.youdao.com/, http://note.youdao.com
[1:1:0712/143937.063876:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/143937.064246:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/143937.105388:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/143937.136163:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/143937.136321:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/143938.839488:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 199 0x7fe601b29070 0x96c2397c3e0 , "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/143938.840386:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , , 
        var detectmob = function () {
            return navigator.userAgent.match(/Android/i)
    
[1:1:0712/143938.840573:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/143938.884426:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.041662, 273, 1
[1:1:0712/143938.884628:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/143939.056077:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/143939.056280:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/143939.058498:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 239 0x7fe601b29070 0x96c2398a660 , "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/143939.061160:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , , (function() {
  var MutationObserver, Util, WeakMap, getComputedStyle, getComputedStyleRX,
    bind 
[1:1:0712/143939.061308:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/143940.096391:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/143941.823069:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/143946.284820:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 695 0x7fe603a512e0 0x96c241177e0 , "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/143946.285275:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/143946.290960:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , , window.__YSFWINTYPE__ = Number('2');
window.__YSFMODILEWINTYPE__ = Number('1');
window.__YSFTHEMELAY
[1:1:0712/143946.291162:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/143946.315480:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/143946.317727:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x96c237ca420
[1:1:0712/143946.317894:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[1:1:0712/143946.325644:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/143946.325835:INFO:render_frame_impl.cc(7019)] 	 [url] = http://note.youdao.com
		remove user.d_7883a5b3 -> 0
		remove user.e_62a0afe9 -> 0
[6119:6119:0712/143947.148210:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[6119:6119:0712/143947.150254:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 4, 4, 
[6119:6119:0712/143947.153322:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://note.youdao.com/
[3:3:0712/143947.175153:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[6119:6119:0712/143947.276524:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[6119:6119:0712/143947.278761:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[6119:6131:0712/143947.293944:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 4
[6119:6131:0712/143947.294014:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 4, HandleIncomingMessage, HandleIncomingMessage
[6119:6119:0712/143947.294041:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://qiyukf.com/
[6119:6119:0712/143947.294083:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_https://qiyukf.com/, https://qiyukf.com/sdk/res/delegate.html?1562913586315, 4
[6119:6119:0712/143947.294150:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:4_https://qiyukf.com/, HTTP/1.1 200 OK Server: nginx Date: Fri, 12 Jul 2019 06:39:47 GMT Content-Type: text/html Last-Modified: Thu, 14 Feb 2019 09:29:37 GMT Transfer-Encoding: chunked Vary: Accept-Encoding ETag: W/"5c653501-68c" Content-Encoding: gzip  ,6215, 5
[1:7:0712/143947.303091:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/143947.361884:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/143947.658448:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/143947.658677:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/143948.582399:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:4_https://qiyukf.com/
[1:1:0712/143948.651634:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "loadstart", "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/143949.851777:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , , document.readyState
[1:1:0712/143949.852246:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[6119:6119:0712/143950.501466:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_https://qiyukf.com/, https://qiyukf.com/, 4
[1:1:0712/143950.501414:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[6119:6119:0712/143950.501536:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, https://qiyukf.com/, https://qiyukf.com
[1:1:0712/143950.704877:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/143950.705745:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , xhr.onreadystatechange, (){if(4==xhr.readyState)if(200===xhr.status)try{result=eval("("+xhr.responseText+")");if(200==(resul
[1:1:0712/143950.705902:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/143950.706448:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/143950.708175:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/143952.604046:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , , document.readyState
[1:1:0712/143952.604213:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/143953.717970:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/143954.739005:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , , document.readyState
[1:1:0712/143954.739189:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:7:0712/143954.854256:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/143954.953524:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/143954.953671:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://qiyukf.com/sdk/res/delegate.html?1562913586315"
[1:1:0712/143954.954656:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1087 0x7fe601b29070 0x96c24e0e3e0 , "https://qiyukf.com/sdk/res/delegate.html?1562913586315"
[1:1:0712/143954.955549:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://qiyukf.com/, 3b3bee226978, , , !function(){if(window.localStorage&&window.postMessage){var e,t={findLocalItems:function(e,t){var a,
[1:1:0712/143954.955687:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://qiyukf.com/sdk/res/delegate.html?1562913586315", "qiyukf.com", 4, 1, http://note.youdao.com, note.youdao.com, 3
[1:1:0712/143954.959559:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://qiyukf.com/sdk/res/delegate.html?1562913586315", 2000
[1:1:0712/143954.959795:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:4_https://qiyukf.com/, 1131
[1:1:0712/143954.959906:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1131 0x7fe601b29070 0x96c24d5c0e0 , 5:4_https://qiyukf.com/, 1, -5:4_https://qiyukf.com/, 1087 0x7fe601b29070 0x96c24e0e3e0 
[1:1:0712/143954.963959:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/143954.964279:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://qiyukf.com/-5:3_http://note.youdao.com/, 3b3bee1c2860, 3b3bee226978, e, (){for(var e=n.length-1;e>=0;e--)n[e]()}
[1:1:0712/143954.964403:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 2, , , 0
[1:1:0712/143954.964574:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 

[1:1:0712/143955.181707:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1096 0x7fe601e91bd0 0x96c24d51558 , "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/143955.185013:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , , !function(e){function t(i){if(n[i])return n[i].exports;var r=n[i]={exports:{},id:i,loaded:!1};return
[1:1:0712/143955.185158:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/143955.423744:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1096 0x7fe601e91bd0 0x96c24d51558 , "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/143955.428578:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://note.youdao.com/?keyfrom=dict2.index"
[6119:6119:0712/143955.461281:INFO:CONSOLE(3)] "Synchronous XMLHttpRequest on the main thread is deprecated because of its detrimental effects to the end user's experience. For more help, check https://xhr.spec.whatwg.org/.", source: http://note.youdao.com/index-511c6627f6.bundle.js (3)
[1:1:0712/143955.464118:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:7:0712/143955.468604:INFO:scheduler_single_thread_task_runner_manager.cc(299)] >>> [Task] IO thread post a task: 60
[1:7:0712/143955.581406:INFO:scheduler_single_thread_task_runner_manager.cc(299)] >>> [Task] IO thread post a task: 61
[1:7:0712/143955.582547:INFO:scheduler_single_thread_task_runner_manager.cc(299)] >>> [Task] IO thread post a task: 62
[1:7:0712/143955.583499:INFO:scheduler_single_thread_task_runner_manager.cc(299)] >>> [Task] IO thread post a task: 63
[1:1:0712/143955.818371:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://note.youdao.com/?keyfrom=dict2.index", 50
[1:1:0712/143955.818708:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1165
[1:1:0712/143955.818889:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1165 0x7fe601b29070 0x96c2424c760 , 5:3_http://note.youdao.com/, 1, -5:3_http://note.youdao.com/, 1096 0x7fe601e91bd0 0x96c24d51558 
[1:1:0712/143955.941691:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , , () {
          return _this.customStyle(box, hidden, duration, delay, iteration);
        }
[1:1:0712/143955.941867:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/143956.153433:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , , document.readyState
[1:1:0712/143956.153611:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/143956.636786:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/143956.637469:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:3_http://note.youdao.com/, 5:4_https://qiyukf.com/
[1:1:0712/143956.637611:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , receiveMsg, (e){if(e.origin==ysf.ROOT||""==ysf.ROOT){var t=(e.data||"").split(":"),n=t.shift();if("pkg"!=n){var 
[1:1:0712/143956.637782:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/143956.944719:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: the server responded with a status of 500 (Internal Server Error)","http://note.youdao.com/yws/mapi/user?keyfrom=web&method=get&_=1562913595286"
[1:1:0712/143956.945564:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/143956.945941:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , t, (n,i){var o,l,u;if(t&&(i||4===a.readyState))if(delete pn[s],t=void 0,a.onreadystatechange=ve.noop,i)
[1:1:0712/143956.946063:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/143956.946334:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/143956.947594:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/143956.947979:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x24e0e3b7c9d8
[1:1:0712/143957.060962:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: the server responded with a status of 500 (Internal Server Error)","http://note.youdao.com/login/acc/pe/getsess?product=YNOTE&product=YNOTE&_=1562913595388"
[1:1:0712/143957.061751:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/143957.062065:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , t, (n,i){var o,l,u;if(t&&(i||4===a.readyState))if(delete pn[s],t=void 0,a.onreadystatechange=ve.noop,i)
[1:1:0712/143957.062166:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/143957.062386:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/143957.063464:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/143957.063759:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x24e0e3b7c9d8
[1:1:0712/143957.311576:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: the server responded with a status of 500 (Internal Server Error)","http://note.youdao.com/login/acc/pe/getsess?product=YNOTE&product=YNOTE&_=1562913595612"
[1:1:0712/143957.312546:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/143957.313140:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , t, (n,i){var o,l,u;if(t&&(i||4===a.readyState))if(delete pn[s],t=void 0,a.onreadystatechange=ve.noop,i)
[1:1:0712/143957.313260:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/143957.313466:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/143957.314649:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/143957.315045:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x24e0e3b7c9d8
[1:1:0712/143957.461055:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1165, 7fe60446e8db
[1:1:0712/143957.482375:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3b3bee1c2860","ptid":"1096 0x7fe601e91bd0 0x96c24d51558 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/143957.482603:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://note.youdao.com/","ptid":"1096 0x7fe601e91bd0 0x96c24d51558 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/143957.482890:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1223
[1:1:0712/143957.483032:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1223 0x7fe601b29070 0x96c234322e0 , 5:3_http://note.youdao.com/, 0, , 1165 0x7fe601b29070 0x96c2424c760 
[1:1:0712/143957.483237:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/143957.483525:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , , (){ return fn.apply(me, arguments); }
[1:1:0712/143957.483639:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/143957.528255:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/143957.528680:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , t, (n,i){var o,l,u;if(t&&(i||4===a.readyState))if(delete pn[s],t=void 0,a.onreadystatechange=ve.noop,i)
[1:1:0712/143957.528805:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/143957.529087:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/143957.530339:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/143957.530651:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x24e0e3b7c9d8
[1:1:0712/143957.745441:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , , document.readyState
[1:1:0712/143957.745629:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/143958.003741:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://qiyukf.com/sdk/res/delegate.html?1562913586315"
[1:1:0712/143958.004737:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://qiyukf.com/, 5:3_http://note.youdao.com/
[1:1:0712/143958.004868:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://qiyukf.com/, 3b3bee226978, , r, (e){try{var t=(e.data||"").split(":"),o=a[(t.shift()||"").toLowerCase()];o&&o(t.join(":"))}catch(e){
[1:1:0712/143958.004999:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://qiyukf.com/sdk/res/delegate.html?1562913586315", "qiyukf.com", 4, 1, http://note.youdao.com, note.youdao.com, 3
[1:1:0712/143958.048189:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://qiyukf.com/sdk/res/delegate.html?1562913586315"
[1:1:0712/143958.048587:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://qiyukf.com/, 5:3_http://note.youdao.com/
[1:1:0712/143958.048748:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://qiyukf.com/, 3b3bee226978, , r, (e){try{var t=(e.data||"").split(":"),o=a[(t.shift()||"").toLowerCase()];o&&o(t.join(":"))}catch(e){
[1:1:0712/143958.048865:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://qiyukf.com/sdk/res/delegate.html?1562913586315", "qiyukf.com", 4, 1, http://note.youdao.com, note.youdao.com, 3
[1:1:0712/143958.132977:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:4_https://qiyukf.com/, 1131, 7fe60446e8db
[1:1:0712/143958.153252:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3b3bee226978","ptid":"1087 0x7fe601b29070 0x96c24e0e3e0 ","rf":"5:4_https://qiyukf.com/"}
[1:1:0712/143958.153438:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_https://qiyukf.com/","ptid":"1087 0x7fe601b29070 0x96c24e0e3e0 ","rf":"5:4_https://qiyukf.com/"}
[1:1:0712/143958.153649:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:4_https://qiyukf.com/, 1250
[1:1:0712/143958.153752:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1250 0x7fe601b29070 0x96c25b4b060 , 5:4_https://qiyukf.com/, 0, , 1131 0x7fe601b29070 0x96c24d5c0e0 
[1:1:0712/143958.153994:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://qiyukf.com/sdk/res/delegate.html?1562913586315"
[1:1:0712/143958.154310:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://qiyukf.com/, 3b3bee226978, , n, (){if(e){var t="X-"+e.toUpperCase()+"-YSF-ACK",a=localStorage.getItem(t);o("ACK:"+a)}}
[1:1:0712/143958.154434:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://qiyukf.com/sdk/res/delegate.html?1562913586315", "qiyukf.com", 4, 1, http://note.youdao.com, note.youdao.com, 3
[1:1:0712/143958.256815:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/143958.257329:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , t, (n,i){var o,l,u;if(t&&(i||4===a.readyState))if(delete pn[s],t=void 0,a.onreadystatechange=ve.noop,i)
[1:1:0712/143958.257470:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/143958.257742:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/143958.259122:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/143958.259479:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x24e0e3b7c9d8
[1:1:0712/143958.433818:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/143958.434198:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , t, (n,i){var o,l,u;if(t&&(i||4===a.readyState))if(delete pn[s],t=void 0,a.onreadystatechange=ve.noop,i)
[1:1:0712/143958.434300:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/143958.434508:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/143958.435600:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/143958.435892:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x24e0e3b7c9d8
[1:1:0712/143958.495675:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1223, 7fe60446e8db
[1:1:0712/143958.516400:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1165 0x7fe601b29070 0x96c2424c760 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/143958.516570:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1165 0x7fe601b29070 0x96c2424c760 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/143958.516777:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1269
[1:1:0712/143958.516868:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1269 0x7fe601b29070 0x96c24d630e0 , 5:3_http://note.youdao.com/, 0, , 1223 0x7fe601b29070 0x96c234322e0 
[1:1:0712/143958.517063:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/143958.517348:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , , (){ return fn.apply(me, arguments); }
[1:1:0712/143958.517445:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/143958.624541:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , , document.readyState
[1:1:0712/143958.624753:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/143959.107419:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/143959.107827:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:3_http://note.youdao.com/, 5:4_https://qiyukf.com/
[1:1:0712/143959.107993:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , receiveMsg, (e){if(e.origin==ysf.ROOT||""==ysf.ROOT){var t=(e.data||"").split(":"),n=t.shift();if("pkg"!=n){var 
[1:1:0712/143959.108150:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/143959.299870:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/143959.300274:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , t, (n,i){var o,l,u;if(t&&(i||4===a.readyState))if(delete pn[s],t=void 0,a.onreadystatechange=ve.noop,i)
[1:1:0712/143959.300422:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/143959.300637:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/143959.302045:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/143959.302337:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x24e0e3b7c9d8
[1:1:0712/143959.335429:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1261 0x7fe603a512e0 0x96c244976e0 , "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/143959.338670:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , , (function(){var h={},mt={},c={id:"30b679eb2c90c60ff8679ce4ca562fcc",dm:["note.youdao.com"],js:"tongj
[1:1:0712/143959.338873:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/143959.351951:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3bd957fe29c8, 0x96c23656148
[1:1:0712/143959.352145:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://note.youdao.com/?keyfrom=dict2.index", 100
[1:1:0712/143959.352386:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://note.youdao.com/, 1300
[1:1:0712/143959.352532:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1300 0x7fe601b29070 0x96c24cbb7e0 , 5:3_http://note.youdao.com/, 1, -5:3_http://note.youdao.com/, 1261 0x7fe603a512e0 0x96c244976e0 
[1:1:0712/143959.360647:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/143959.576892:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1269, 7fe60446e8db
[1:1:0712/143959.597346:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1223 0x7fe601b29070 0x96c234322e0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/143959.597567:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1223 0x7fe601b29070 0x96c234322e0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/143959.597839:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1325
[1:1:0712/143959.598002:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1325 0x7fe601b29070 0x96c23fc72e0 , 5:3_http://note.youdao.com/, 0, , 1269 0x7fe601b29070 0x96c24d630e0 
[1:1:0712/143959.598240:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/143959.598580:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , , (){ return fn.apply(me, arguments); }
[1:1:0712/143959.598712:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/143959.622652:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/143959.623004:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , t, (n,i){var o,l,u;if(t&&(i||4===a.readyState))if(delete pn[s],t=void 0,a.onreadystatechange=ve.noop,i)
[1:1:0712/143959.623113:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/143959.623312:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/143959.624515:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/143959.624855:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x24e0e3b7c9d8
[1:1:0712/143959.774931:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , , document.readyState
[1:1:0712/143959.775089:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/143959.776673:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:4_https://qiyukf.com/, 1250, 7fe60446e8db
[1:1:0712/143959.800836:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1131 0x7fe601b29070 0x96c24d5c0e0 ","rf":"5:4_https://qiyukf.com/"}
[1:1:0712/143959.801047:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1131 0x7fe601b29070 0x96c24d5c0e0 ","rf":"5:4_https://qiyukf.com/"}
[1:1:0712/143959.801285:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:4_https://qiyukf.com/, 1340
[1:1:0712/143959.801411:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1340 0x7fe601b29070 0x96c237d8b60 , 5:4_https://qiyukf.com/, 0, , 1250 0x7fe601b29070 0x96c25b4b060 
[1:1:0712/143959.801614:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://qiyukf.com/sdk/res/delegate.html?1562913586315"
[1:1:0712/143959.801927:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://qiyukf.com/, 3b3bee226978, , n, (){if(e){var t="X-"+e.toUpperCase()+"-YSF-ACK",a=localStorage.getItem(t);o("ACK:"+a)}}
[1:1:0712/143959.802060:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://qiyukf.com/sdk/res/delegate.html?1562913586315", "qiyukf.com", 4, 1, http://note.youdao.com, note.youdao.com, 3
[1:1:0712/144000.532826:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://note.youdao.com/, 1300, 7fe60446e881
[1:1:0712/144000.555060:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3b3bee1c2860","ptid":"1261 0x7fe603a512e0 0x96c244976e0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144000.555282:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://note.youdao.com/","ptid":"1261 0x7fe603a512e0 0x96c244976e0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144000.555508:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144000.555882:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/144000.555987:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144000.556366:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3bd957fe29c8, 0x96c23656150
[1:1:0712/144000.556496:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://note.youdao.com/?keyfrom=dict2.index", 100
[1:1:0712/144000.556699:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://note.youdao.com/, 1366
[1:1:0712/144000.556815:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1366 0x7fe601b29070 0x96c24cc0060 , 5:3_http://note.youdao.com/, 1, -5:3_http://note.youdao.com/, 1300 0x7fe601b29070 0x96c24cbb7e0 
[1:1:0712/144000.601269:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1325, 7fe60446e8db
[1:1:0712/144000.623733:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1269 0x7fe601b29070 0x96c24d630e0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144000.623914:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1269 0x7fe601b29070 0x96c24d630e0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144000.624140:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1374
[1:1:0712/144000.624246:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1374 0x7fe601b29070 0x96c24d46460 , 5:3_http://note.youdao.com/, 0, , 1325 0x7fe601b29070 0x96c23fc72e0 
[1:1:0712/144000.624411:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144000.624765:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , , (){ return fn.apply(me, arguments); }
[1:1:0712/144000.624878:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144000.690264:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , , document.readyState
[1:1:0712/144000.690417:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144000.757157:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144000.757542:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:3_http://note.youdao.com/, 5:4_https://qiyukf.com/
[1:1:0712/144000.757655:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , receiveMsg, (e){if(e.origin==ysf.ROOT||""==ysf.ROOT){var t=(e.data||"").split(":"),n=t.shift();if("pkg"!=n){var 
[1:1:0712/144000.757765:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144001.566625:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://note.youdao.com/, 1366, 7fe60446e881
[1:1:0712/144001.588068:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3b3bee1c2860","ptid":"1300 0x7fe601b29070 0x96c24cbb7e0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144001.588280:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://note.youdao.com/","ptid":"1300 0x7fe601b29070 0x96c24cbb7e0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144001.588591:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144001.588998:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/144001.589189:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144001.589528:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3bd957fe29c8, 0x96c23656150
[1:1:0712/144001.589626:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://note.youdao.com/?keyfrom=dict2.index", 100
[1:1:0712/144001.589801:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://note.youdao.com/, 1405
[1:1:0712/144001.589922:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1405 0x7fe601b29070 0x96c23a93c60 , 5:3_http://note.youdao.com/, 1, -5:3_http://note.youdao.com/, 1366 0x7fe601b29070 0x96c24cc0060 
[1:1:0712/144001.634882:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , , document.readyState
[1:1:0712/144001.635038:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144001.636500:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1374, 7fe60446e8db
[1:1:0712/144001.658926:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1325 0x7fe601b29070 0x96c23fc72e0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144001.659100:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1325 0x7fe601b29070 0x96c23fc72e0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144001.659327:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1408
[1:1:0712/144001.659439:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1408 0x7fe601b29070 0x96c24d79ae0 , 5:3_http://note.youdao.com/, 0, , 1374 0x7fe601b29070 0x96c24d46460 
[1:1:0712/144001.659633:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144001.659904:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , , (){ return fn.apply(me, arguments); }
[1:1:0712/144001.660006:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144001.843855:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:4_https://qiyukf.com/, 1340, 7fe60446e8db
[1:1:0712/144001.866490:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1250 0x7fe601b29070 0x96c25b4b060 ","rf":"5:4_https://qiyukf.com/"}
[1:1:0712/144001.866658:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1250 0x7fe601b29070 0x96c25b4b060 ","rf":"5:4_https://qiyukf.com/"}
[1:1:0712/144001.866872:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:4_https://qiyukf.com/, 1417
[1:1:0712/144001.866987:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1417 0x7fe601b29070 0x96c2489eee0 , 5:4_https://qiyukf.com/, 0, , 1340 0x7fe601b29070 0x96c237d8b60 
[1:1:0712/144001.867162:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://qiyukf.com/sdk/res/delegate.html?1562913586315"
[1:1:0712/144001.867427:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://qiyukf.com/, 3b3bee226978, , n, (){if(e){var t="X-"+e.toUpperCase()+"-YSF-ACK",a=localStorage.getItem(t);o("ACK:"+a)}}
[1:1:0712/144001.867541:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://qiyukf.com/sdk/res/delegate.html?1562913586315", "qiyukf.com", 4, 1, http://note.youdao.com, note.youdao.com, 3
[1:1:0712/144002.111063:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144002.111507:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , f.onload, (){f.onload=u;f=window[d]=u;a&&a(b)}
[1:1:0712/144002.111643:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144002.115616:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144002.117240:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "pageshow", "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144002.117843:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3bd957fe29c8, 0x96c236562f0
[1:1:0712/144002.117939:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://note.youdao.com/?keyfrom=dict2.index", 100
[1:1:0712/144002.118107:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://note.youdao.com/, 1424
[1:1:0712/144002.118212:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1424 0x7fe601b29070 0x96c24d48ae0 , 5:3_http://note.youdao.com/, 1, -5:3_http://note.youdao.com/, 1402 0x7fe601b29070 0x96c248d4360 
[1:1:0712/144002.145946:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , , document.readyState
[1:1:0712/144002.146103:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144002.147714:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1408, 7fe60446e8db
[1:1:0712/144002.170507:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1374 0x7fe601b29070 0x96c24d46460 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144002.170669:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1374 0x7fe601b29070 0x96c24d46460 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144002.170887:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1430
[1:1:0712/144002.170991:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1430 0x7fe601b29070 0x96c24ce5960 , 5:3_http://note.youdao.com/, 0, , 1408 0x7fe601b29070 0x96c24d79ae0 
[1:1:0712/144002.171165:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144002.171426:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , , (){ return fn.apply(me, arguments); }
[1:1:0712/144002.171523:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144002.251235:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144002.251602:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:3_http://note.youdao.com/, 5:4_https://qiyukf.com/
[1:1:0712/144002.251709:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , receiveMsg, (e){if(e.origin==ysf.ROOT||""==ysf.ROOT){var t=(e.data||"").split(":"),n=t.shift();if("pkg"!=n){var 
[1:1:0712/144002.251816:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144002.515713:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://note.youdao.com/, 1424, 7fe60446e881
[1:1:0712/144002.536570:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3b3bee1c2860","ptid":"1402 0x7fe601b29070 0x96c248d4360 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144002.536753:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://note.youdao.com/","ptid":"1402 0x7fe601b29070 0x96c248d4360 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144002.536945:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144002.537233:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/144002.537342:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144002.537641:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3bd957fe29c8, 0x96c23656150
[1:1:0712/144002.537743:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://note.youdao.com/?keyfrom=dict2.index", 100
[1:1:0712/144002.537915:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://note.youdao.com/, 1444
[1:1:0712/144002.537990:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1444 0x7fe601b29070 0x96c24d482e0 , 5:3_http://note.youdao.com/, 1, -5:3_http://note.youdao.com/, 1424 0x7fe601b29070 0x96c24d48ae0 
[1:1:0712/144002.538720:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1430, 7fe60446e8db
[1:1:0712/144002.560438:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1408 0x7fe601b29070 0x96c24d79ae0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144002.560622:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1408 0x7fe601b29070 0x96c24d79ae0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144002.560879:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1446
[1:1:0712/144002.560979:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1446 0x7fe601b29070 0x96c249e3860 , 5:3_http://note.youdao.com/, 0, , 1430 0x7fe601b29070 0x96c24ce5960 
[1:1:0712/144002.561178:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144002.561467:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , , (){ return fn.apply(me, arguments); }
[1:1:0712/144002.561586:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144002.654613:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1446, 7fe60446e8db
[1:1:0712/144002.676143:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1430 0x7fe601b29070 0x96c24ce5960 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144002.676294:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1430 0x7fe601b29070 0x96c24ce5960 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144002.676520:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1453
[1:1:0712/144002.676618:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1453 0x7fe601b29070 0x96c24e00be0 , 5:3_http://note.youdao.com/, 0, , 1446 0x7fe601b29070 0x96c249e3860 
[1:1:0712/144002.676781:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144002.677053:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , , (){ return fn.apply(me, arguments); }
[1:1:0712/144002.677141:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144002.719090:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://note.youdao.com/, 1444, 7fe60446e881
[1:1:0712/144002.738625:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3b3bee1c2860","ptid":"1424 0x7fe601b29070 0x96c24d48ae0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144002.738811:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://note.youdao.com/","ptid":"1424 0x7fe601b29070 0x96c24d48ae0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144002.738999:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144002.739274:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/144002.739385:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144002.739693:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3bd957fe29c8, 0x96c23656150
[1:1:0712/144002.739795:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://note.youdao.com/?keyfrom=dict2.index", 100
[1:1:0712/144002.739978:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://note.youdao.com/, 1455
[1:1:0712/144002.740093:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1455 0x7fe601b29070 0x96c238d88e0 , 5:3_http://note.youdao.com/, 1, -5:3_http://note.youdao.com/, 1444 0x7fe601b29070 0x96c24d482e0 
[1:1:0712/144002.780332:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1453, 7fe60446e8db
[1:1:0712/144002.799394:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1446 0x7fe601b29070 0x96c249e3860 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144002.799566:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1446 0x7fe601b29070 0x96c249e3860 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144002.799777:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1457
[1:1:0712/144002.799891:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1457 0x7fe601b29070 0x96c2421e360 , 5:3_http://note.youdao.com/, 0, , 1453 0x7fe601b29070 0x96c24e00be0 
[1:1:0712/144002.800081:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144002.800356:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , , (){ return fn.apply(me, arguments); }
[1:1:0712/144002.800468:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144002.821323:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1457, 7fe60446e8db
[1:1:0712/144002.840890:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1453 0x7fe601b29070 0x96c24e00be0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144002.841069:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1453 0x7fe601b29070 0x96c24e00be0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144002.841313:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1459
[1:1:0712/144002.841428:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1459 0x7fe601b29070 0x96c234a0fe0 , 5:3_http://note.youdao.com/, 0, , 1457 0x7fe601b29070 0x96c2421e360 
[1:1:0712/144002.841599:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144002.841861:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , , (){ return fn.apply(me, arguments); }
[1:1:0712/144002.841969:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144002.842971:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://note.youdao.com/, 1455, 7fe60446e881
[1:1:0712/144002.862687:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3b3bee1c2860","ptid":"1444 0x7fe601b29070 0x96c24d482e0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144002.862846:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://note.youdao.com/","ptid":"1444 0x7fe601b29070 0x96c24d482e0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144002.863046:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144002.863324:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/144002.863432:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144002.863723:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3bd957fe29c8, 0x96c23656150
[1:1:0712/144002.863811:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://note.youdao.com/?keyfrom=dict2.index", 100
[1:1:0712/144002.863979:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://note.youdao.com/, 1462
[1:1:0712/144002.864069:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1462 0x7fe601b29070 0x96c23f79a60 , 5:3_http://note.youdao.com/, 1, -5:3_http://note.youdao.com/, 1455 0x7fe601b29070 0x96c238d88e0 
[1:1:0712/144002.884821:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1459, 7fe60446e8db
[1:1:0712/144002.904696:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1457 0x7fe601b29070 0x96c2421e360 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144002.904855:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1457 0x7fe601b29070 0x96c2421e360 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144002.905078:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1466
[1:1:0712/144002.905182:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1466 0x7fe601b29070 0x96c2350a160 , 5:3_http://note.youdao.com/, 0, , 1459 0x7fe601b29070 0x96c234a0fe0 
[1:1:0712/144002.905363:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144002.905621:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , , (){ return fn.apply(me, arguments); }
[1:1:0712/144002.905721:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144002.945761:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1466, 7fe60446e8db
[1:1:0712/144002.965580:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1459 0x7fe601b29070 0x96c234a0fe0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144002.965801:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1459 0x7fe601b29070 0x96c234a0fe0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144002.966056:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1470
[1:1:0712/144002.966178:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1470 0x7fe601b29070 0x96c24cc98e0 , 5:3_http://note.youdao.com/, 0, , 1466 0x7fe601b29070 0x96c2350a160 
[1:1:0712/144002.966362:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144002.966647:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , , (){ return fn.apply(me, arguments); }
[1:1:0712/144002.966748:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144002.967673:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:4_https://qiyukf.com/, 1417, 7fe60446e8db
[1:1:0712/144002.988727:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1340 0x7fe601b29070 0x96c237d8b60 ","rf":"5:4_https://qiyukf.com/"}
[1:1:0712/144002.988892:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1340 0x7fe601b29070 0x96c237d8b60 ","rf":"5:4_https://qiyukf.com/"}
[1:1:0712/144002.989124:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:4_https://qiyukf.com/, 1474
[1:1:0712/144002.989240:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1474 0x7fe601b29070 0x96c24e510e0 , 5:4_https://qiyukf.com/, 0, , 1417 0x7fe601b29070 0x96c2489eee0 
[1:1:0712/144002.989416:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://qiyukf.com/sdk/res/delegate.html?1562913586315"
[1:1:0712/144002.989673:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://qiyukf.com/, 3b3bee226978, , n, (){if(e){var t="X-"+e.toUpperCase()+"-YSF-ACK",a=localStorage.getItem(t);o("ACK:"+a)}}
[1:1:0712/144002.989766:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://qiyukf.com/sdk/res/delegate.html?1562913586315", "qiyukf.com", 4, 1, http://note.youdao.com, note.youdao.com, 3
[1:1:0712/144003.031625:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://note.youdao.com/, 1462, 7fe60446e881
[1:1:0712/144003.051075:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3b3bee1c2860","ptid":"1455 0x7fe601b29070 0x96c238d88e0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144003.051239:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://note.youdao.com/","ptid":"1455 0x7fe601b29070 0x96c238d88e0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144003.051439:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144003.051724:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/144003.051835:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144003.052140:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3bd957fe29c8, 0x96c23656150
[1:1:0712/144003.052242:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://note.youdao.com/?keyfrom=dict2.index", 100
[1:1:0712/144003.052423:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://note.youdao.com/, 1480
[1:1:0712/144003.052540:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1480 0x7fe601b29070 0x96c24d88860 , 5:3_http://note.youdao.com/, 1, -5:3_http://note.youdao.com/, 1462 0x7fe601b29070 0x96c23f79a60 
[1:1:0712/144003.073246:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144003.073586:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:3_http://note.youdao.com/, 5:4_https://qiyukf.com/
[1:1:0712/144003.073692:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , receiveMsg, (e){if(e.origin==ysf.ROOT||""==ysf.ROOT){var t=(e.data||"").split(":"),n=t.shift();if("pkg"!=n){var 
[1:1:0712/144003.073891:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144003.075119:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1470, 7fe60446e8db
[1:1:0712/144003.095347:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1466 0x7fe601b29070 0x96c2350a160 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144003.095501:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1466 0x7fe601b29070 0x96c2350a160 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144003.095716:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1482
[1:1:0712/144003.095829:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1482 0x7fe601b29070 0x96c24dc1160 , 5:3_http://note.youdao.com/, 0, , 1470 0x7fe601b29070 0x96c24cc98e0 
[1:1:0712/144003.096006:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144003.096251:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , , (){ return fn.apply(me, arguments); }
[1:1:0712/144003.096360:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144003.267742:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1482, 7fe60446e8db
[1:1:0712/144003.288364:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1470 0x7fe601b29070 0x96c24cc98e0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144003.288534:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1470 0x7fe601b29070 0x96c24cc98e0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144003.288762:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1497
[1:1:0712/144003.288881:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1497 0x7fe601b29070 0x96c24cc9060 , 5:3_http://note.youdao.com/, 0, , 1482 0x7fe601b29070 0x96c24dc1160 
[1:1:0712/144003.289078:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144003.289361:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , , (){ return fn.apply(me, arguments); }
[1:1:0712/144003.289470:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144003.290227:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://note.youdao.com/, 1480, 7fe60446e881
[1:1:0712/144003.310851:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3b3bee1c2860","ptid":"1462 0x7fe601b29070 0x96c23f79a60 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144003.311023:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://note.youdao.com/","ptid":"1462 0x7fe601b29070 0x96c23f79a60 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144003.311236:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144003.311530:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/144003.311642:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144003.311950:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3bd957fe29c8, 0x96c23656150
[1:1:0712/144003.312056:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://note.youdao.com/?keyfrom=dict2.index", 100
[1:1:0712/144003.312231:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://note.youdao.com/, 1498
[1:1:0712/144003.312350:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1498 0x7fe601b29070 0x96c23abdee0 , 5:3_http://note.youdao.com/, 1, -5:3_http://note.youdao.com/, 1480 0x7fe601b29070 0x96c24d88860 
[1:1:0712/144003.480623:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1497, 7fe60446e8db
[1:1:0712/144003.501098:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1482 0x7fe601b29070 0x96c24dc1160 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144003.501294:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1482 0x7fe601b29070 0x96c24dc1160 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144003.501521:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1510
[1:1:0712/144003.501644:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1510 0x7fe601b29070 0x96c248e1660 , 5:3_http://note.youdao.com/, 0, , 1497 0x7fe601b29070 0x96c24cc9060 
[1:1:0712/144003.501835:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144003.502124:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , , (){ return fn.apply(me, arguments); }
[1:1:0712/144003.502241:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144003.502997:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://note.youdao.com/, 1498, 7fe60446e881
[1:1:0712/144003.523833:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3b3bee1c2860","ptid":"1480 0x7fe601b29070 0x96c24d88860 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144003.524012:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://note.youdao.com/","ptid":"1480 0x7fe601b29070 0x96c24d88860 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144003.524220:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144003.524505:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/144003.524620:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144003.524918:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3bd957fe29c8, 0x96c23656150
[1:1:0712/144003.525004:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://note.youdao.com/?keyfrom=dict2.index", 100
[1:1:0712/144003.525194:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://note.youdao.com/, 1511
[1:1:0712/144003.525312:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1511 0x7fe601b29070 0x96c2389e360 , 5:3_http://note.youdao.com/, 1, -5:3_http://note.youdao.com/, 1498 0x7fe601b29070 0x96c23abdee0 
[1:1:0712/144003.526009:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1510, 7fe60446e8db
[1:1:0712/144003.546920:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1497 0x7fe601b29070 0x96c24cc9060 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144003.547097:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1497 0x7fe601b29070 0x96c24cc9060 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144003.547887:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1513
[1:1:0712/144003.548039:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1513 0x7fe601b29070 0x96c24d66660 , 5:3_http://note.youdao.com/, 0, , 1510 0x7fe601b29070 0x96c248e1660 
[1:1:0712/144003.548248:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144003.548566:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , , (){ return fn.apply(me, arguments); }
[1:1:0712/144003.548645:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144003.571128:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1513, 7fe60446e8db
[1:1:0712/144003.591774:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1510 0x7fe601b29070 0x96c248e1660 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144003.591962:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1510 0x7fe601b29070 0x96c248e1660 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144003.592229:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1516
[1:1:0712/144003.592358:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1516 0x7fe601b29070 0x96c24d69a60 , 5:3_http://note.youdao.com/, 0, , 1513 0x7fe601b29070 0x96c24d66660 
[1:1:0712/144003.592541:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144003.592810:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , , (){ return fn.apply(me, arguments); }
[1:1:0712/144003.592902:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144003.636718:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1516, 7fe60446e8db
[1:1:0712/144003.657734:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1513 0x7fe601b29070 0x96c24d66660 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144003.657903:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1513 0x7fe601b29070 0x96c24d66660 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144003.658128:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1522
[1:1:0712/144003.658250:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1522 0x7fe601b29070 0x96c2381e5e0 , 5:3_http://note.youdao.com/, 0, , 1516 0x7fe601b29070 0x96c24d69a60 
[1:1:0712/144003.658437:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144003.658717:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , , (){ return fn.apply(me, arguments); }
[1:1:0712/144003.658833:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144003.701187:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://note.youdao.com/, 1511, 7fe60446e881
[1:1:0712/144003.721729:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3b3bee1c2860","ptid":"1498 0x7fe601b29070 0x96c23abdee0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144003.721919:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://note.youdao.com/","ptid":"1498 0x7fe601b29070 0x96c23abdee0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144003.722113:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144003.722403:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/144003.722526:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144003.722840:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3bd957fe29c8, 0x96c23656150
[1:1:0712/144003.722951:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://note.youdao.com/?keyfrom=dict2.index", 100
[1:1:0712/144003.723142:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://note.youdao.com/, 1526
[1:1:0712/144003.723261:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1526 0x7fe601b29070 0x96c244a1760 , 5:3_http://note.youdao.com/, 1, -5:3_http://note.youdao.com/, 1511 0x7fe601b29070 0x96c2389e360 
[1:1:0712/144003.723933:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1522, 7fe60446e8db
[1:1:0712/144003.744935:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1516 0x7fe601b29070 0x96c24d69a60 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144003.745114:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1516 0x7fe601b29070 0x96c24d69a60 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144003.745337:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1527
[1:1:0712/144003.745502:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1527 0x7fe601b29070 0x96c248f7d60 , 5:3_http://note.youdao.com/, 0, , 1522 0x7fe601b29070 0x96c2381e5e0 
[1:1:0712/144003.745751:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144003.746085:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , , (){ return fn.apply(me, arguments); }
[1:1:0712/144003.746245:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144003.832376:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1527, 7fe60446e8db
[1:1:0712/144003.853389:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1522 0x7fe601b29070 0x96c2381e5e0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144003.853606:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1522 0x7fe601b29070 0x96c2381e5e0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144003.853852:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1534
[1:1:0712/144003.853979:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1534 0x7fe601b29070 0x96c248d4360 , 5:3_http://note.youdao.com/, 0, , 1527 0x7fe601b29070 0x96c248f7d60 
[1:1:0712/144003.854176:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144003.854474:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , , (){ return fn.apply(me, arguments); }
[1:1:0712/144003.854599:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144003.876974:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://note.youdao.com/, 1526, 7fe60446e881
[1:1:0712/144003.897972:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3b3bee1c2860","ptid":"1511 0x7fe601b29070 0x96c2389e360 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144003.898157:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://note.youdao.com/","ptid":"1511 0x7fe601b29070 0x96c2389e360 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144003.898369:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144003.898660:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/144003.898775:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144003.899803:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3bd957fe29c8, 0x96c23656150
[1:1:0712/144003.899911:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://note.youdao.com/?keyfrom=dict2.index", 100
[1:1:0712/144003.901597:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://note.youdao.com/, 1538
[1:1:0712/144003.901713:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1538 0x7fe601b29070 0x96c238d88e0 , 5:3_http://note.youdao.com/, 1, -5:3_http://note.youdao.com/, 1526 0x7fe601b29070 0x96c244a1760 
[1:1:0712/144003.944467:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1534, 7fe60446e8db
[1:1:0712/144003.965391:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1527 0x7fe601b29070 0x96c248f7d60 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144003.965561:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1527 0x7fe601b29070 0x96c248f7d60 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144003.965789:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1541
[1:1:0712/144003.965899:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1541 0x7fe601b29070 0x96c2389ce60 , 5:3_http://note.youdao.com/, 0, , 1534 0x7fe601b29070 0x96c248d4360 
[1:1:0712/144003.966078:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144003.966346:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , , (){ return fn.apply(me, arguments); }
[1:1:0712/144003.966460:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144003.997450:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1541, 7fe60446e8db
[1:1:0712/144004.019212:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1534 0x7fe601b29070 0x96c248d4360 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144004.019386:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1534 0x7fe601b29070 0x96c248d4360 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144004.019615:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1545
[1:1:0712/144004.019744:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1545 0x7fe601b29070 0x96c249229e0 , 5:3_http://note.youdao.com/, 0, , 1541 0x7fe601b29070 0x96c2389ce60 
[1:1:0712/144004.019926:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144004.020206:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , , (){ return fn.apply(me, arguments); }
[1:1:0712/144004.020321:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144004.063090:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://note.youdao.com/, 1538, 7fe60446e881
[1:1:0712/144004.083915:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3b3bee1c2860","ptid":"1526 0x7fe601b29070 0x96c244a1760 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144004.084092:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://note.youdao.com/","ptid":"1526 0x7fe601b29070 0x96c244a1760 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144004.084300:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144004.084602:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/144004.084715:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144004.085015:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3bd957fe29c8, 0x96c23656150
[1:1:0712/144004.085142:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://note.youdao.com/?keyfrom=dict2.index", 100
[1:1:0712/144004.085334:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://note.youdao.com/, 1549
[1:1:0712/144004.085456:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1549 0x7fe601b29070 0x96c24d79460 , 5:3_http://note.youdao.com/, 1, -5:3_http://note.youdao.com/, 1538 0x7fe601b29070 0x96c238d88e0 
[1:1:0712/144004.086288:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1545, 7fe60446e8db
[1:1:0712/144004.107664:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1541 0x7fe601b29070 0x96c2389ce60 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144004.107833:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1541 0x7fe601b29070 0x96c2389ce60 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144004.108068:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1552
[1:1:0712/144004.108190:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1552 0x7fe601b29070 0x96c24dc11e0 , 5:3_http://note.youdao.com/, 0, , 1545 0x7fe601b29070 0x96c249229e0 
[1:1:0712/144004.108376:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144004.108653:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , , (){ return fn.apply(me, arguments); }
[1:1:0712/144004.108755:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144004.193917:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1552, 7fe60446e8db
[1:1:0712/144004.215325:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1545 0x7fe601b29070 0x96c249229e0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144004.215498:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1545 0x7fe601b29070 0x96c249229e0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144004.215724:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1562
[1:1:0712/144004.215845:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1562 0x7fe601b29070 0x96c25b4bbe0 , 5:3_http://note.youdao.com/, 0, , 1552 0x7fe601b29070 0x96c24dc11e0 
[1:1:0712/144004.216032:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144004.216310:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , , (){ return fn.apply(me, arguments); }
[1:1:0712/144004.216424:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144004.280262:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://note.youdao.com/, 1549, 7fe60446e881
[1:1:0712/144004.301191:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3b3bee1c2860","ptid":"1538 0x7fe601b29070 0x96c238d88e0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144004.301370:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://note.youdao.com/","ptid":"1538 0x7fe601b29070 0x96c238d88e0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144004.301579:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144004.301873:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/144004.301988:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144004.302308:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3bd957fe29c8, 0x96c23656150
[1:1:0712/144004.302414:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://note.youdao.com/?keyfrom=dict2.index", 100
[1:1:0712/144004.302625:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://note.youdao.com/, 1568
[1:1:0712/144004.302746:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1568 0x7fe601b29070 0x96c25998160 , 5:3_http://note.youdao.com/, 1, -5:3_http://note.youdao.com/, 1549 0x7fe601b29070 0x96c24d79460 
[1:1:0712/144004.303431:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1562, 7fe60446e8db
[1:1:0712/144004.324718:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1552 0x7fe601b29070 0x96c24dc11e0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144004.324889:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1552 0x7fe601b29070 0x96c24dc11e0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144004.325145:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1569
[1:1:0712/144004.325266:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1569 0x7fe601b29070 0x96c2446dee0 , 5:3_http://note.youdao.com/, 0, , 1562 0x7fe601b29070 0x96c25b4bbe0 
[1:1:0712/144004.325456:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144004.325727:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , , (){ return fn.apply(me, arguments); }
[1:1:0712/144004.325842:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144004.371086:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1569, 7fe60446e8db
[1:1:0712/144004.392807:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1562 0x7fe601b29070 0x96c25b4bbe0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144004.392966:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1562 0x7fe601b29070 0x96c25b4bbe0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144004.393197:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1573
[1:1:0712/144004.393317:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1573 0x7fe601b29070 0x96c24df2560 , 5:3_http://note.youdao.com/, 0, , 1569 0x7fe601b29070 0x96c2446dee0 
[1:1:0712/144004.393499:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144004.393778:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , , (){ return fn.apply(me, arguments); }
[1:1:0712/144004.393896:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144004.416824:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://note.youdao.com/, 1568, 7fe60446e881
[1:1:0712/144004.438138:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3b3bee1c2860","ptid":"1549 0x7fe601b29070 0x96c24d79460 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144004.438317:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://note.youdao.com/","ptid":"1549 0x7fe601b29070 0x96c24d79460 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144004.438538:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144004.438844:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/144004.438959:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144004.439269:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3bd957fe29c8, 0x96c23656150
[1:1:0712/144004.439376:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://note.youdao.com/?keyfrom=dict2.index", 100
[1:1:0712/144004.439565:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://note.youdao.com/, 1578
[1:1:0712/144004.439684:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1578 0x7fe601b29070 0x96c240a77e0 , 5:3_http://note.youdao.com/, 1, -5:3_http://note.youdao.com/, 1568 0x7fe601b29070 0x96c25998160 
[1:1:0712/144004.483014:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1573, 7fe60446e8db
[1:1:0712/144004.504029:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1569 0x7fe601b29070 0x96c2446dee0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144004.504191:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1569 0x7fe601b29070 0x96c2446dee0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144004.504390:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1582
[1:1:0712/144004.504510:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1582 0x7fe601b29070 0x96c2393c260 , 5:3_http://note.youdao.com/, 0, , 1573 0x7fe601b29070 0x96c24df2560 
[1:1:0712/144004.504693:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144004.504958:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , , (){ return fn.apply(me, arguments); }
[1:1:0712/144004.505070:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144004.527868:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1582, 7fe60446e8db
[1:1:0712/144004.549308:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1573 0x7fe601b29070 0x96c24df2560 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144004.549475:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1573 0x7fe601b29070 0x96c24df2560 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144004.549708:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1586
[1:1:0712/144004.549828:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1586 0x7fe601b29070 0x96c24e83ae0 , 5:3_http://note.youdao.com/, 0, , 1582 0x7fe601b29070 0x96c2393c260 
[1:1:0712/144004.550011:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144004.550291:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , , (){ return fn.apply(me, arguments); }
[1:1:0712/144004.550406:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144004.615251:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://note.youdao.com/, 1578, 7fe60446e881
[1:1:0712/144004.636701:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3b3bee1c2860","ptid":"1568 0x7fe601b29070 0x96c25998160 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144004.636878:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://note.youdao.com/","ptid":"1568 0x7fe601b29070 0x96c25998160 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144004.637108:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144004.637402:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/144004.637516:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144004.637827:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3bd957fe29c8, 0x96c23656150
[1:1:0712/144004.637926:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://note.youdao.com/?keyfrom=dict2.index", 100
[1:1:0712/144004.638107:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://note.youdao.com/, 1593
[1:1:0712/144004.638228:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1593 0x7fe601b29070 0x96c23ff11e0 , 5:3_http://note.youdao.com/, 1, -5:3_http://note.youdao.com/, 1578 0x7fe601b29070 0x96c240a77e0 
[1:1:0712/144004.639064:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1586, 7fe60446e8db
[1:1:0712/144004.660817:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1582 0x7fe601b29070 0x96c2393c260 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144004.660979:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1582 0x7fe601b29070 0x96c2393c260 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144004.661208:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1596
[1:1:0712/144004.661331:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1596 0x7fe601b29070 0x96c2388eae0 , 5:3_http://note.youdao.com/, 0, , 1586 0x7fe601b29070 0x96c24e83ae0 
[1:1:0712/144004.661526:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144004.661799:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , , (){ return fn.apply(me, arguments); }
[1:1:0712/144004.661913:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144004.748409:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1596, 7fe60446e8db
[1:1:0712/144004.770164:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1586 0x7fe601b29070 0x96c24e83ae0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144004.770338:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1586 0x7fe601b29070 0x96c24e83ae0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144004.770564:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1605
[1:1:0712/144004.770686:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1605 0x7fe601b29070 0x96c24e7d860 , 5:3_http://note.youdao.com/, 0, , 1596 0x7fe601b29070 0x96c2388eae0 
[1:1:0712/144004.770874:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144004.771177:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , , (){ return fn.apply(me, arguments); }
[1:1:0712/144004.771290:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144004.814904:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://note.youdao.com/, 1593, 7fe60446e881
[1:1:0712/144004.836066:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3b3bee1c2860","ptid":"1578 0x7fe601b29070 0x96c240a77e0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144004.836244:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://note.youdao.com/","ptid":"1578 0x7fe601b29070 0x96c240a77e0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144004.836452:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144004.836744:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/144004.836845:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144004.837185:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3bd957fe29c8, 0x96c23656150
[1:1:0712/144004.837295:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://note.youdao.com/?keyfrom=dict2.index", 100
[1:1:0712/144004.837484:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://note.youdao.com/, 1608
[1:1:0712/144004.837601:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1608 0x7fe601b29070 0x96c24477de0 , 5:3_http://note.youdao.com/, 1, -5:3_http://note.youdao.com/, 1593 0x7fe601b29070 0x96c23ff11e0 
[1:1:0712/144004.838395:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1605, 7fe60446e8db
[1:1:0712/144004.860367:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1596 0x7fe601b29070 0x96c2388eae0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144004.860545:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1596 0x7fe601b29070 0x96c2388eae0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144004.860760:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1611
[1:1:0712/144004.860866:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1611 0x7fe601b29070 0x96c24d2d7e0 , 5:3_http://note.youdao.com/, 0, , 1605 0x7fe601b29070 0x96c24e7d860 
[1:1:0712/144004.861062:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144004.861357:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , , (){ return fn.apply(me, arguments); }
[1:1:0712/144004.861470:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144004.884393:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1611, 7fe60446e8db
[1:1:0712/144004.905944:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1605 0x7fe601b29070 0x96c24e7d860 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144004.906114:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1605 0x7fe601b29070 0x96c24e7d860 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144004.906327:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1615
[1:1:0712/144004.906428:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1615 0x7fe601b29070 0x96c24e0a2e0 , 5:3_http://note.youdao.com/, 0, , 1611 0x7fe601b29070 0x96c24d2d7e0 
[1:1:0712/144004.906585:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144004.906861:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , , (){ return fn.apply(me, arguments); }
[1:1:0712/144004.906976:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144004.951796:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1615, 7fe60446e8db
[1:1:0712/144004.973574:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1611 0x7fe601b29070 0x96c24d2d7e0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144004.973741:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1611 0x7fe601b29070 0x96c24d2d7e0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144004.973953:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1620
[1:1:0712/144004.974083:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1620 0x7fe601b29070 0x96c24e818e0 , 5:3_http://note.youdao.com/, 0, , 1615 0x7fe601b29070 0x96c24e0a2e0 
[1:1:0712/144004.974275:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144004.974554:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , , (){ return fn.apply(me, arguments); }
[1:1:0712/144004.974671:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144004.997210:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://note.youdao.com/, 1608, 7fe60446e881
[1:1:0712/144005.018721:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3b3bee1c2860","ptid":"1593 0x7fe601b29070 0x96c23ff11e0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144005.018901:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://note.youdao.com/","ptid":"1593 0x7fe601b29070 0x96c23ff11e0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144005.019111:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144005.019403:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/144005.019518:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144005.019827:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3bd957fe29c8, 0x96c23656150
[1:1:0712/144005.019935:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://note.youdao.com/?keyfrom=dict2.index", 100
[1:1:0712/144005.020126:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://note.youdao.com/, 1625
[1:1:0712/144005.020233:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1625 0x7fe601b29070 0x96c24d4c5e0 , 5:3_http://note.youdao.com/, 1, -5:3_http://note.youdao.com/, 1608 0x7fe601b29070 0x96c24477de0 
[1:1:0712/144005.064601:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:4_https://qiyukf.com/, 1474, 7fe60446e8db
[1:1:0712/144005.086178:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1417 0x7fe601b29070 0x96c2489eee0 ","rf":"5:4_https://qiyukf.com/"}
[1:1:0712/144005.086348:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1417 0x7fe601b29070 0x96c2489eee0 ","rf":"5:4_https://qiyukf.com/"}
[1:1:0712/144005.086567:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:4_https://qiyukf.com/, 1630
[1:1:0712/144005.086687:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1630 0x7fe601b29070 0x96c23abe2e0 , 5:4_https://qiyukf.com/, 0, , 1474 0x7fe601b29070 0x96c24e510e0 
[1:1:0712/144005.086881:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://qiyukf.com/sdk/res/delegate.html?1562913586315"
[1:1:0712/144005.087166:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://qiyukf.com/, 3b3bee226978, , n, (){if(e){var t="X-"+e.toUpperCase()+"-YSF-ACK",a=localStorage.getItem(t);o("ACK:"+a)}}
[1:1:0712/144005.087304:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://qiyukf.com/sdk/res/delegate.html?1562913586315", "qiyukf.com", 4, 1, http://note.youdao.com, note.youdao.com, 3
[1:1:0712/144005.111839:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1620, 7fe60446e8db
[1:1:0712/144005.133398:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1615 0x7fe601b29070 0x96c24e0a2e0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144005.133587:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1615 0x7fe601b29070 0x96c24e0a2e0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144005.133811:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1632
[1:1:0712/144005.133934:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1632 0x7fe601b29070 0x96c2388a860 , 5:3_http://note.youdao.com/, 0, , 1620 0x7fe601b29070 0x96c24e818e0 
[1:1:0712/144005.134118:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144005.134397:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , , (){ return fn.apply(me, arguments); }
[1:1:0712/144005.134511:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144005.200830:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144005.201274:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:3_http://note.youdao.com/, 5:4_https://qiyukf.com/
[1:1:0712/144005.201403:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , receiveMsg, (e){if(e.origin==ysf.ROOT||""==ysf.ROOT){var t=(e.data||"").split(":"),n=t.shift();if("pkg"!=n){var 
[1:1:0712/144005.201526:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144005.224555:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://note.youdao.com/, 1625, 7fe60446e881
[1:1:0712/144005.246081:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3b3bee1c2860","ptid":"1608 0x7fe601b29070 0x96c24477de0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144005.246260:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://note.youdao.com/","ptid":"1608 0x7fe601b29070 0x96c24477de0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144005.246471:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144005.246762:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/144005.246888:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144005.247201:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3bd957fe29c8, 0x96c23656150
[1:1:0712/144005.247308:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://note.youdao.com/?keyfrom=dict2.index", 100
[1:1:0712/144005.247502:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://note.youdao.com/, 1640
[1:1:0712/144005.247625:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1640 0x7fe601b29070 0x96c232a67e0 , 5:3_http://note.youdao.com/, 1, -5:3_http://note.youdao.com/, 1625 0x7fe601b29070 0x96c24d4c5e0 
[1:1:0712/144005.270485:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1632, 7fe60446e8db
[1:1:0712/144005.291923:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1620 0x7fe601b29070 0x96c24e818e0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144005.292092:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1620 0x7fe601b29070 0x96c24e818e0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144005.292317:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1641
[1:1:0712/144005.292439:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1641 0x7fe601b29070 0x96c24cc59e0 , 5:3_http://note.youdao.com/, 0, , 1632 0x7fe601b29070 0x96c2388a860 
[1:1:0712/144005.292633:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144005.292899:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , , (){ return fn.apply(me, arguments); }
[1:1:0712/144005.292991:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144005.321686:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1641, 7fe60446e8db
[1:1:0712/144005.343937:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1632 0x7fe601b29070 0x96c2388a860 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144005.344108:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1632 0x7fe601b29070 0x96c2388a860 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144005.344335:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1646
[1:1:0712/144005.344458:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1646 0x7fe601b29070 0x96c23abdee0 , 5:3_http://note.youdao.com/, 0, , 1641 0x7fe601b29070 0x96c24cc59e0 
[1:1:0712/144005.344625:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144005.344889:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , , (){ return fn.apply(me, arguments); }
[1:1:0712/144005.344989:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144005.432814:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://note.youdao.com/, 1640, 7fe60446e881
[1:1:0712/144005.454734:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3b3bee1c2860","ptid":"1625 0x7fe601b29070 0x96c24d4c5e0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144005.454926:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://note.youdao.com/","ptid":"1625 0x7fe601b29070 0x96c24d4c5e0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144005.455159:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144005.455458:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/144005.455572:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144005.455884:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3bd957fe29c8, 0x96c23656150
[1:1:0712/144005.455992:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://note.youdao.com/?keyfrom=dict2.index", 100
[1:1:0712/144005.456170:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://note.youdao.com/, 1654
[1:1:0712/144005.456277:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1654 0x7fe601b29070 0x96c24cc7a60 , 5:3_http://note.youdao.com/, 1, -5:3_http://note.youdao.com/, 1640 0x7fe601b29070 0x96c232a67e0 
[1:1:0712/144005.456931:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1646, 7fe60446e8db
[1:1:0712/144005.478980:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1641 0x7fe601b29070 0x96c24cc59e0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144005.479153:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1641 0x7fe601b29070 0x96c24cc59e0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144005.479378:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1655
[1:1:0712/144005.479499:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1655 0x7fe601b29070 0x96c242deae0 , 5:3_http://note.youdao.com/, 0, , 1646 0x7fe601b29070 0x96c23abdee0 
[1:1:0712/144005.479691:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144005.479963:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , , (){ return fn.apply(me, arguments); }
[1:1:0712/144005.480076:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144005.525281:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1655, 7fe60446e8db
[1:1:0712/144005.547246:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1646 0x7fe601b29070 0x96c23abdee0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144005.547419:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1646 0x7fe601b29070 0x96c23abdee0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144005.547645:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1660
[1:1:0712/144005.547773:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1660 0x7fe601b29070 0x96c24e00660 , 5:3_http://note.youdao.com/, 0, , 1655 0x7fe601b29070 0x96c242deae0 
[1:1:0712/144005.547955:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144005.548233:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , , (){ return fn.apply(me, arguments); }
[1:1:0712/144005.548346:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144005.571242:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://note.youdao.com/, 1654, 7fe60446e881
[1:1:0712/144005.593169:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3b3bee1c2860","ptid":"1640 0x7fe601b29070 0x96c232a67e0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144005.593351:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://note.youdao.com/","ptid":"1640 0x7fe601b29070 0x96c232a67e0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144005.593561:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144005.593853:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/144005.593955:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144005.594257:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3bd957fe29c8, 0x96c23656150
[1:1:0712/144005.594392:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://note.youdao.com/?keyfrom=dict2.index", 100
[1:1:0712/144005.594565:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://note.youdao.com/, 1665
[1:1:0712/144005.594701:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1665 0x7fe601b29070 0x96c2489d060 , 5:3_http://note.youdao.com/, 1, -5:3_http://note.youdao.com/, 1654 0x7fe601b29070 0x96c24cc7a60 
[1:1:0712/144005.640506:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1660, 7fe60446e8db
[1:1:0712/144005.662532:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1655 0x7fe601b29070 0x96c242deae0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144005.662703:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1655 0x7fe601b29070 0x96c242deae0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144005.662971:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1668
[1:1:0712/144005.663195:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1668 0x7fe601b29070 0x96c249e2f60 , 5:3_http://note.youdao.com/, 0, , 1660 0x7fe601b29070 0x96c24e00660 
[1:1:0712/144005.663447:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144005.663790:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , , (){ return fn.apply(me, arguments); }
[1:1:0712/144005.663902:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144005.690321:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1668, 7fe60446e8db
[1:1:0712/144005.713140:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1660 0x7fe601b29070 0x96c24e00660 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144005.713316:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1660 0x7fe601b29070 0x96c24e00660 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144005.713545:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1672
[1:1:0712/144005.713667:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1672 0x7fe601b29070 0x96c2383d360 , 5:3_http://note.youdao.com/, 0, , 1668 0x7fe601b29070 0x96c249e2f60 
[1:1:0712/144005.713848:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144005.714128:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , , (){ return fn.apply(me, arguments); }
[1:1:0712/144005.714245:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144005.759451:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://note.youdao.com/, 1665, 7fe60446e881
[1:1:0712/144005.781708:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3b3bee1c2860","ptid":"1654 0x7fe601b29070 0x96c24cc7a60 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144005.781895:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://note.youdao.com/","ptid":"1654 0x7fe601b29070 0x96c24cc7a60 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144005.782106:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144005.782402:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/144005.782517:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144005.782815:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3bd957fe29c8, 0x96c23656150
[1:1:0712/144005.782930:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://note.youdao.com/?keyfrom=dict2.index", 100
[1:1:0712/144005.783122:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://note.youdao.com/, 1679
[1:1:0712/144005.783229:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1679 0x7fe601b29070 0x96c2448c560 , 5:3_http://note.youdao.com/, 1, -5:3_http://note.youdao.com/, 1665 0x7fe601b29070 0x96c2489d060 
[1:1:0712/144005.806358:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1672, 7fe60446e8db
[1:1:0712/144005.828161:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1668 0x7fe601b29070 0x96c249e2f60 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144005.828334:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1668 0x7fe601b29070 0x96c249e2f60 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144005.828565:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1682
[1:1:0712/144005.828674:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1682 0x7fe601b29070 0x96c24cdf3e0 , 5:3_http://note.youdao.com/, 0, , 1672 0x7fe601b29070 0x96c2383d360 
[1:1:0712/144005.828846:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144005.829140:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , , (){ return fn.apply(me, arguments); }
[1:1:0712/144005.829269:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144005.919290:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1682, 7fe60446e8db
[1:1:0712/144005.941345:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1672 0x7fe601b29070 0x96c2383d360 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144005.941517:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1672 0x7fe601b29070 0x96c2383d360 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144005.941737:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1689
[1:1:0712/144005.941881:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1689 0x7fe601b29070 0x96c248b4760 , 5:3_http://note.youdao.com/, 0, , 1682 0x7fe601b29070 0x96c24cdf3e0 
[1:1:0712/144005.942077:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144005.942357:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , , (){ return fn.apply(me, arguments); }
[1:1:0712/144005.942472:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144005.965933:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://note.youdao.com/, 1679, 7fe60446e881
[1:1:0712/144005.988105:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3b3bee1c2860","ptid":"1665 0x7fe601b29070 0x96c2489d060 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144005.988291:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://note.youdao.com/","ptid":"1665 0x7fe601b29070 0x96c2489d060 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144005.988514:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144005.988793:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/144005.988893:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144005.989199:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3bd957fe29c8, 0x96c23656150
[1:1:0712/144005.989308:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://note.youdao.com/?keyfrom=dict2.index", 100
[1:1:0712/144005.989497:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://note.youdao.com/, 1690
[1:1:0712/144005.989618:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1690 0x7fe601b29070 0x96c2489f360 , 5:3_http://note.youdao.com/, 1, -5:3_http://note.youdao.com/, 1679 0x7fe601b29070 0x96c2448c560 
[1:1:0712/144005.990447:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1689, 7fe60446e8db
[1:1:0712/144006.013074:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1682 0x7fe601b29070 0x96c24cdf3e0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144006.013249:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1682 0x7fe601b29070 0x96c24cdf3e0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144006.013482:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1693
[1:1:0712/144006.013604:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1693 0x7fe601b29070 0x96c24cbbbe0 , 5:3_http://note.youdao.com/, 0, , 1689 0x7fe601b29070 0x96c248b4760 
[1:1:0712/144006.013789:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144006.014060:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , , (){ return fn.apply(me, arguments); }
[1:1:0712/144006.014175:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144006.037400:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1693, 7fe60446e8db
[1:1:0712/144006.059542:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1689 0x7fe601b29070 0x96c248b4760 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144006.059718:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1689 0x7fe601b29070 0x96c248b4760 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144006.059954:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1697
[1:1:0712/144006.060075:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1697 0x7fe601b29070 0x96c24164be0 , 5:3_http://note.youdao.com/, 0, , 1693 0x7fe601b29070 0x96c24cbbbe0 
[1:1:0712/144006.060263:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144006.060523:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , , (){ return fn.apply(me, arguments); }
[1:1:0712/144006.060628:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144006.105913:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1697, 7fe60446e8db
[1:1:0712/144006.128093:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1693 0x7fe601b29070 0x96c24cbbbe0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144006.128258:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1693 0x7fe601b29070 0x96c24cbbbe0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144006.128474:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1702
[1:1:0712/144006.128582:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1702 0x7fe601b29070 0x96c23822fe0 , 5:3_http://note.youdao.com/, 0, , 1697 0x7fe601b29070 0x96c24164be0 
[1:1:0712/144006.128757:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144006.129017:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , , (){ return fn.apply(me, arguments); }
[1:1:0712/144006.129156:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144006.152414:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://note.youdao.com/, 1690, 7fe60446e881
[1:1:0712/144006.174687:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3b3bee1c2860","ptid":"1679 0x7fe601b29070 0x96c2448c560 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144006.174866:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://note.youdao.com/","ptid":"1679 0x7fe601b29070 0x96c2448c560 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144006.175076:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144006.175366:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/144006.175479:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144006.175787:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3bd957fe29c8, 0x96c23656150
[1:1:0712/144006.175903:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://note.youdao.com/?keyfrom=dict2.index", 100
[1:1:0712/144006.176094:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://note.youdao.com/, 1705
[1:1:0712/144006.176194:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1705 0x7fe601b29070 0x96c2349fce0 , 5:3_http://note.youdao.com/, 1, -5:3_http://note.youdao.com/, 1690 0x7fe601b29070 0x96c2489f360 
[1:1:0712/144006.222055:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1702, 7fe60446e8db
[1:1:0712/144006.244236:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1697 0x7fe601b29070 0x96c24164be0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144006.244411:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1697 0x7fe601b29070 0x96c24164be0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144006.244642:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1710
[1:1:0712/144006.244750:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1710 0x7fe601b29070 0x96c24cba560 , 5:3_http://note.youdao.com/, 0, , 1702 0x7fe601b29070 0x96c23822fe0 
[1:1:0712/144006.244929:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144006.245226:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , , (){ return fn.apply(me, arguments); }
[1:1:0712/144006.245341:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144006.273456:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1710, 7fe60446e8db
[1:1:0712/144006.296805:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1702 0x7fe601b29070 0x96c23822fe0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144006.296981:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1702 0x7fe601b29070 0x96c23822fe0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144006.297218:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1714
[1:1:0712/144006.297337:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1714 0x7fe601b29070 0x96c23d51660 , 5:3_http://note.youdao.com/, 0, , 1710 0x7fe601b29070 0x96c24cba560 
[1:1:0712/144006.297560:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144006.297837:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , , (){ return fn.apply(me, arguments); }
[1:1:0712/144006.297959:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144006.343062:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://note.youdao.com/, 1705, 7fe60446e881
[1:1:0712/144006.364124:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3b3bee1c2860","ptid":"1690 0x7fe601b29070 0x96c2489f360 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144006.364301:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://note.youdao.com/","ptid":"1690 0x7fe601b29070 0x96c2489f360 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144006.364502:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144006.364787:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/144006.364890:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144006.365211:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3bd957fe29c8, 0x96c23656150
[1:1:0712/144006.365315:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://note.youdao.com/?keyfrom=dict2.index", 100
[1:1:0712/144006.365497:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://note.youdao.com/, 1719
[1:1:0712/144006.365611:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1719 0x7fe601b29070 0x96c23491d60 , 5:3_http://note.youdao.com/, 1, -5:3_http://note.youdao.com/, 1705 0x7fe601b29070 0x96c2349fce0 
[1:1:0712/144006.366287:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1714, 7fe60446e8db
[1:1:0712/144006.387792:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1710 0x7fe601b29070 0x96c24cba560 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144006.387943:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1710 0x7fe601b29070 0x96c24cba560 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144006.388159:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1720
[1:1:0712/144006.388284:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1720 0x7fe601b29070 0x96c23abdee0 , 5:3_http://note.youdao.com/, 0, , 1714 0x7fe601b29070 0x96c23d51660 
[1:1:0712/144006.388484:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144006.388717:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , , (){ return fn.apply(me, arguments); }
[1:1:0712/144006.388799:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144006.433371:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1720, 7fe60446e8db
[1:1:0712/144006.454275:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1714 0x7fe601b29070 0x96c23d51660 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144006.454432:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1714 0x7fe601b29070 0x96c23d51660 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144006.454645:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1724
[1:1:0712/144006.454767:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1724 0x7fe601b29070 0x96c23ff11e0 , 5:3_http://note.youdao.com/, 0, , 1720 0x7fe601b29070 0x96c23abdee0 
[1:1:0712/144006.454951:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144006.455219:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , , (){ return fn.apply(me, arguments); }
[1:1:0712/144006.455330:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144006.478255:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://note.youdao.com/, 1719, 7fe60446e881
[1:1:0712/144006.499623:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3b3bee1c2860","ptid":"1705 0x7fe601b29070 0x96c2349fce0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144006.499790:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://note.youdao.com/","ptid":"1705 0x7fe601b29070 0x96c2349fce0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144006.499989:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144006.500269:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/144006.500379:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144006.500699:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3bd957fe29c8, 0x96c23656150
[1:1:0712/144006.500780:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://note.youdao.com/?keyfrom=dict2.index", 100
[1:1:0712/144006.500945:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://note.youdao.com/, 1730
[1:1:0712/144006.501050:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1730 0x7fe601b29070 0x96c25b4b1e0 , 5:3_http://note.youdao.com/, 1, -5:3_http://note.youdao.com/, 1719 0x7fe601b29070 0x96c23491d60 
[1:1:0712/144006.550228:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1724, 7fe60446e8db
[1:1:0712/144006.571546:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1720 0x7fe601b29070 0x96c23abdee0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144006.571742:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1720 0x7fe601b29070 0x96c23abdee0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144006.571961:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1733
[1:1:0712/144006.572077:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1733 0x7fe601b29070 0x96c24cea860 , 5:3_http://note.youdao.com/, 0, , 1724 0x7fe601b29070 0x96c23ff11e0 
[1:1:0712/144006.572252:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144006.572528:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , , (){ return fn.apply(me, arguments); }
[1:1:0712/144006.572637:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144006.621464:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://note.youdao.com/, 1730, 7fe60446e881
[1:1:0712/144006.642888:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3b3bee1c2860","ptid":"1719 0x7fe601b29070 0x96c23491d60 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144006.643052:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://note.youdao.com/","ptid":"1719 0x7fe601b29070 0x96c23491d60 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144006.643251:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144006.643535:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/144006.643645:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144006.643942:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3bd957fe29c8, 0x96c23656150
[1:1:0712/144006.644052:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://note.youdao.com/?keyfrom=dict2.index", 100
[1:1:0712/144006.644226:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://note.youdao.com/, 1741
[1:1:0712/144006.644329:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1741 0x7fe601b29070 0x96c24d4cd60 , 5:3_http://note.youdao.com/, 1, -5:3_http://note.youdao.com/, 1730 0x7fe601b29070 0x96c25b4b1e0 
[1:1:0712/144006.687880:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1733, 7fe60446e8db
[1:1:0712/144006.709906:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1724 0x7fe601b29070 0x96c23ff11e0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144006.710077:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1724 0x7fe601b29070 0x96c23ff11e0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144006.710298:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1745
[1:1:0712/144006.710414:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1745 0x7fe601b29070 0x96c244973e0 , 5:3_http://note.youdao.com/, 0, , 1733 0x7fe601b29070 0x96c24cea860 
[1:1:0712/144006.710598:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144006.710864:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , , (){ return fn.apply(me, arguments); }
[1:1:0712/144006.710972:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144006.739868:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1745, 7fe60446e8db
[1:1:0712/144006.762159:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1733 0x7fe601b29070 0x96c24cea860 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144006.762324:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1733 0x7fe601b29070 0x96c24cea860 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144006.762543:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1749
[1:1:0712/144006.762658:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1749 0x7fe601b29070 0x96c238872e0 , 5:3_http://note.youdao.com/, 0, , 1745 0x7fe601b29070 0x96c244973e0 
[1:1:0712/144006.762833:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144006.763108:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , , (){ return fn.apply(me, arguments); }
[1:1:0712/144006.763206:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144006.806800:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://note.youdao.com/, 1741, 7fe60446e881
[1:1:0712/144006.827916:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3b3bee1c2860","ptid":"1730 0x7fe601b29070 0x96c25b4b1e0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144006.828083:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://note.youdao.com/","ptid":"1730 0x7fe601b29070 0x96c25b4b1e0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144006.828280:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144006.828558:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/144006.828669:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144006.828954:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3bd957fe29c8, 0x96c23656150
[1:1:0712/144006.829049:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://note.youdao.com/?keyfrom=dict2.index", 100
[1:1:0712/144006.829232:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://note.youdao.com/, 1754
[1:1:0712/144006.829334:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1754 0x7fe601b29070 0x96c240962e0 , 5:3_http://note.youdao.com/, 1, -5:3_http://note.youdao.com/, 1741 0x7fe601b29070 0x96c24d4cd60 
[1:1:0712/144006.829970:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1749, 7fe60446e8db
[1:1:0712/144006.851579:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1745 0x7fe601b29070 0x96c244973e0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144006.851736:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1745 0x7fe601b29070 0x96c244973e0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144006.851967:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1755
[1:1:0712/144006.852081:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1755 0x7fe601b29070 0x96c24cca6e0 , 5:3_http://note.youdao.com/, 0, , 1749 0x7fe601b29070 0x96c238872e0 
[1:1:0712/144006.852266:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144006.852535:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , , (){ return fn.apply(me, arguments); }
[1:1:0712/144006.852638:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144006.918149:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1755, 7fe60446e8db
[1:1:0712/144006.939277:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1749 0x7fe601b29070 0x96c238872e0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144006.939432:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1749 0x7fe601b29070 0x96c238872e0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144006.939656:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1760
[1:1:0712/144006.939770:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1760 0x7fe601b29070 0x96c249e5060 , 5:3_http://note.youdao.com/, 0, , 1755 0x7fe601b29070 0x96c24cca6e0 
[1:1:0712/144006.939944:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144006.940215:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , , (){ return fn.apply(me, arguments); }
[1:1:0712/144006.940315:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144006.941220:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://note.youdao.com/, 1754, 7fe60446e881
[1:1:0712/144006.963028:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3b3bee1c2860","ptid":"1741 0x7fe601b29070 0x96c24d4cd60 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144006.963192:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://note.youdao.com/","ptid":"1741 0x7fe601b29070 0x96c24d4cd60 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144006.963388:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144006.963654:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/144006.963762:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144006.964062:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3bd957fe29c8, 0x96c23656150
[1:1:0712/144006.964164:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://note.youdao.com/?keyfrom=dict2.index", 100
[1:1:0712/144006.964341:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://note.youdao.com/, 1763
[1:1:0712/144006.964456:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1763 0x7fe601b29070 0x96c24ccf260 , 5:3_http://note.youdao.com/, 1, -5:3_http://note.youdao.com/, 1754 0x7fe601b29070 0x96c240962e0 
[1:1:0712/144007.029556:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:4_https://qiyukf.com/, 1630, 7fe60446e8db
[1:1:0712/144007.050924:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1474 0x7fe601b29070 0x96c24e510e0 ","rf":"5:4_https://qiyukf.com/"}
[1:1:0712/144007.051081:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1474 0x7fe601b29070 0x96c24e510e0 ","rf":"5:4_https://qiyukf.com/"}
[1:1:0712/144007.051286:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:4_https://qiyukf.com/, 1770
[1:1:0712/144007.051400:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1770 0x7fe601b29070 0x96c24496be0 , 5:4_https://qiyukf.com/, 0, , 1630 0x7fe601b29070 0x96c23abe2e0 
[1:1:0712/144007.051580:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://qiyukf.com/sdk/res/delegate.html?1562913586315"
[1:1:0712/144007.051840:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://qiyukf.com/, 3b3bee226978, , n, (){if(e){var t="X-"+e.toUpperCase()+"-YSF-ACK",a=localStorage.getItem(t);o("ACK:"+a)}}
[1:1:0712/144007.051962:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://qiyukf.com/sdk/res/delegate.html?1562913586315", "qiyukf.com", 4, 1, http://note.youdao.com, note.youdao.com, 3
[1:1:0712/144007.053191:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1760, 7fe60446e8db
[1:1:0712/144007.075222:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1755 0x7fe601b29070 0x96c24cca6e0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144007.075380:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1755 0x7fe601b29070 0x96c24cca6e0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0712/144007.075592:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://note.youdao.com/, 1772
[1:1:0712/144007.075708:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1772 0x7fe601b29070 0x96c23d51e60 , 5:3_http://note.youdao.com/, 0, , 1760 0x7fe601b29070 0x96c249e5060 
[1:1:0712/144007.075880:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144007.076133:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , , (){ return fn.apply(me, arguments); }
[1:1:0712/144007.076241:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144007.099292:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0712/144007.099635:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:3_http://note.youdao.com/, 5:4_https://qiyukf.com/
[1:1:0712/144007.099741:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , receiveMsg, (e){if(e.origin==ysf.ROOT||""==ysf.ROOT){var t=(e.data||"").split(":"),n=t.shift();if("pkg"!=n){var 
[1:1:0712/144007.099841:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
[1:1:0712/144007.144774:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://note.youdao.com/, 1763, 7fe60446e881
[1:1:0100/000000.178141:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3b3bee1c2860","ptid":"1754 0x7fe601b29070 0x96c240962e0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0100/000000.178270:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://note.youdao.com/","ptid":"1754 0x7fe601b29070 0x96c240962e0 ","rf":"5:3_http://note.youdao.com/"}
[1:1:0100/000000.178450:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://note.youdao.com/?keyfrom=dict2.index"
[1:1:0100/000000.178736:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://note.youdao.com/, 3b3bee1c2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0100/000000.178800:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://note.youdao.com/?keyfrom=dict2.index", "note.youdao.com", 3, 1, , , 0
