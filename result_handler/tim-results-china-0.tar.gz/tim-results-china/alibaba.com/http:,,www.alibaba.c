[0712/130308.266817:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/130308.267095:INFO:switcher_clone.cc(787)] backtrace rip is 7fb2c53a9891
[0712/130308.826529:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/130308.826778:INFO:switcher_clone.cc(787)] backtrace rip is 7fc5816c9891
[1:1:0712/130308.830613:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/130308.830783:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/130308.833554:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[20680:20680:0712/130309.546780:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/d28063c0-7773-4fef-8eb1-25101629fe7b
[0712/130309.672558:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/130309.672808:INFO:switcher_clone.cc(787)] backtrace rip is 7f9089281891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[20680:20680:0712/130309.799061:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[20680:20711:0712/130309.799475:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/130309.799698:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/130309.800732:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/130309.801252:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/130309.801368:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/130309.805115:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x3617d2ba, 1
[1:1:0712/130309.805356:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x207fca72, 0
[1:1:0712/130309.805480:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x38df846f, 3
[1:1:0712/130309.805553:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x1fa0d2b9, 2
[1:1:0712/130309.805658:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 72ffffffca7f20 ffffffbaffffffd21736 ffffffb9ffffffd2ffffffa01f 6fffffff84ffffffdf38 , 10104, 4
[1:1:0712/130309.806324:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[20680:20711:0712/130309.806457:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGr� ��6�Ҡo��8�Ά(
[20680:20711:0712/130309.806500:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is r� ��6�Ҡo��8H3�Ά(
[1:1:0712/130309.806455:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc57f9030a0, 3
[20680:20711:0712/130309.806632:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[20680:20711:0712/130309.806670:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 20727, 4, 72ca7f20 bad21736 b9d2a01f 6f84df38 
[1:1:0712/130309.806921:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc57fa8f080, 2
[1:1:0712/130309.807018:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc569751d20, -2
[1:1:0712/130309.814661:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/130309.815126:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1fa0d2b9
[1:1:0712/130309.815574:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1fa0d2b9
[1:1:0712/130309.816311:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1fa0d2b9
[1:1:0712/130309.816876:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1fa0d2b9
[1:1:0712/130309.816981:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1fa0d2b9
[1:1:0712/130309.817088:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1fa0d2b9
[1:1:0712/130309.817211:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1fa0d2b9
[1:1:0712/130309.817457:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1fa0d2b9
[1:1:0712/130309.817606:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fc5816c97ba
[1:1:0712/130309.817695:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fc5816c0def, 7fc5816c977a, 7fc5816cb0cf
[20713:20713:0712/130309.818441:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=20713
[20728:20728:0712/130309.819119:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=20728
[1:1:0712/130309.819425:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1fa0d2b9
[1:1:0712/130309.819609:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1fa0d2b9
[1:1:0712/130309.819916:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1fa0d2b9
[1:1:0712/130309.820707:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1fa0d2b9
[1:1:0712/130309.820809:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1fa0d2b9
[1:1:0712/130309.820903:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1fa0d2b9
[1:1:0712/130309.820997:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1fa0d2b9
[1:1:0712/130309.821521:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1fa0d2b9
[1:1:0712/130309.821681:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fc5816c97ba
[1:1:0712/130309.821750:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fc5816c0def, 7fc5816c977a, 7fc5816cb0cf
[1:1:0712/130309.824336:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/130309.824518:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/130309.824598:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffca62d5a48, 0x7ffca62d59c8)
[1:1:0712/130309.834028:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/130309.836735:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/130310.234664:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x937b8a57220
[1:1:0712/130310.234886:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[20680:20680:0712/130310.237981:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[20680:20680:0712/130310.238455:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[20680:20692:0712/130310.246923:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[20680:20692:0712/130310.246990:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[20680:20680:0712/130310.247018:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[20680:20680:0712/130310.247067:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[20680:20680:0712/130310.247139:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,20727, 4
[1:7:0712/130310.247976:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[20680:20706:0712/130310.278627:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/130310.478810:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[20680:20680:0712/130311.144693:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[20680:20680:0712/130311.144808:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/130311.149514:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/130311.151045:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/130311.576888:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0a71db061f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/130311.577093:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/130311.582483:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0a71db061f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/130311.582656:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/130311.588742:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/130311.689593:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/130311.689724:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/130311.824136:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 358, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/130311.826708:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0a71db061f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/130311.826839:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/130311.838798:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 359, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/130311.841757:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0a71db061f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/130311.841881:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/130311.845658:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[20680:20680:0712/130311.846239:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/130311.847361:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x937b8a55e20
[1:1:0712/130311.848242:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[20680:20680:0712/130311.848650:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[20680:20680:0712/130311.860839:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[20680:20680:0712/130311.860968:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/130311.880688:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/130312.171415:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 418 0x7fc56b32c2e0 0x937b8c6fae0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/130312.172085:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0a71db061f78, , , var configData = {"googleBaseUrl":"https://www.google.com.hk/","isAccessibleBrowser":false,"isGoogle
[1:1:0712/130312.172234:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/130312.172800:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[20680:20680:0712/130312.197675:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/130312.198780:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x937b8a56820
[1:1:0712/130312.198928:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[20680:20680:0712/130312.200168:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/130312.205733:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/130312.205890:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[20680:20680:0712/130312.206707:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[20680:20680:0712/130312.210565:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[20680:20680:0712/130312.210982:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[20680:20692:0712/130312.215448:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[20680:20692:0712/130312.215501:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[20680:20680:0712/130312.215522:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[20680:20680:0712/130312.215560:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[20680:20680:0712/130312.215618:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,20727, 4
[1:7:0712/130312.216962:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/130312.465518:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/130312.573768:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 468 0x7fc56b32c2e0 0x937b8dde360 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/130312.574334:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0a71db061f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/130312.574489:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/130312.574843:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[20680:20680:0712/130312.710106:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[20680:20680:0712/130312.710198:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/130312.722172:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/130312.840896:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/130313.036806:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/130313.036958:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[20680:20680:0712/130313.086847:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[20680:20711:0712/130313.087093:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/130313.087212:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/130313.087339:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/130313.087521:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/130313.087595:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/130313.089577:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x17a84b60, 1
[1:1:0712/130313.089786:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x24036c68, 0
[1:1:0712/130313.089878:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x1c233f57, 3
[1:1:0712/130313.089956:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x12aab23c, 2
[1:1:0712/130313.090032:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 686c0324 604bffffffa817 3cffffffb2ffffffaa12 573f231c , 10104, 5
[1:1:0712/130313.090718:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[20680:20711:0712/130313.090880:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGhl$`K�<��W?#�Ά(
[20680:20711:0712/130313.090917:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is hl$`K�<��W?#�:�Ά(
[1:1:0712/130313.090881:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc57f9030a0, 3
[1:1:0712/130313.090963:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc57fa8f080, 2
[20680:20711:0712/130313.091056:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 20776, 5, 686c0324 604ba817 3cb2aa12 573f231c 
[1:1:0712/130313.091050:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc569751d20, -2
[1:1:0712/130313.100057:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/130313.100295:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 12aab23c
[1:1:0712/130313.100481:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 12aab23c
[1:1:0712/130313.100760:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 12aab23c
[1:1:0712/130313.104800:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 12aab23c
[1:1:0712/130313.104926:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 12aab23c
[1:1:0712/130313.105009:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 12aab23c
[1:1:0712/130313.105100:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 12aab23c
[1:1:0712/130313.105344:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 12aab23c
[1:1:0712/130313.105452:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fc5816c97ba
[1:1:0712/130313.105511:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fc5816c0def, 7fc5816c977a, 7fc5816cb0cf
[1:1:0712/130313.107171:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 12aab23c
[1:1:0712/130313.107342:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 12aab23c
[1:1:0712/130313.107637:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 12aab23c
[1:1:0712/130313.108379:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 12aab23c
[1:1:0712/130313.108490:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 12aab23c
[1:1:0712/130313.108590:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 12aab23c
[1:1:0712/130313.108688:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 12aab23c
[1:1:0712/130313.109190:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 12aab23c
[1:1:0712/130313.109385:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fc5816c97ba
[1:1:0712/130313.109485:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fc5816c0def, 7fc5816c977a, 7fc5816cb0cf
[1:1:0712/130313.112132:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/130313.112390:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/130313.112488:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffca62d5a48, 0x7ffca62d59c8)
[1:1:0712/130313.118240:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/130313.123785:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/130313.190335:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 535, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/130313.192029:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0a71db18e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/130313.192188:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/130313.194563:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/130313.218529:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x937b8a3b220
[1:1:0712/130313.218702:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[20680:20680:0712/130314.125783:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[20680:20680:0712/130314.138165:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 6
[20680:20711:0712/130314.138434:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 6
[3:3:0712/130314.138572:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/130314.139143:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/130314.139336:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/130314.139421:INFO:zygote_linux.cc(633)] 		cid is 6
[1:1:0712/130314.141297:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x1fa5b613, 1
[1:1:0712/130314.141582:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x274f86c1, 0
[1:1:0712/130314.141674:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x38a6bf57, 3
[1:1:0712/130314.141748:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x1018ecc7, 2
[1:1:0712/130314.141823:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffc1ffffff864f27 13ffffffb6ffffffa51f ffffffc7ffffffec1810 57ffffffbfffffffa638 , 10104, 6
[1:1:0712/130314.142523:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[20680:20711:0712/130314.142654:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING��O'����W��8҆(
[20680:20711:0712/130314.142695:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ��O'����W��8xL҆(
[20680:20711:0712/130314.142837:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 20788, 6, c1864f27 13b6a51f c7ec1810 57bfa638 
[1:1:0712/130314.143012:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc57f9030a0, 3
[1:1:0712/130314.143108:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc57fa8f080, 2
[1:1:0712/130314.143197:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc569751d20, -2
[1:1:0712/130314.152152:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[20680:20680:0712/130314.152349:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0712/130314.152365:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1018ecc7
[1:1:0712/130314.152492:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1018ecc7
[1:1:0712/130314.152715:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1018ecc7
[1:1:0712/130314.153220:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1018ecc7
[1:1:0712/130314.153318:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1018ecc7
[1:1:0712/130314.153411:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1018ecc7
[1:1:0712/130314.153498:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1018ecc7
[1:1:0712/130314.153748:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1018ecc7
[1:1:0712/130314.153873:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fc5816c97ba
[1:1:0712/130314.153945:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fc5816c0def, 7fc5816c977a, 7fc5816cb0cf
[1:1:0712/130314.155600:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1018ecc7
[1:1:0712/130314.155811:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1018ecc7
[1:1:0712/130314.156121:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1018ecc7
[1:1:0712/130314.156919:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1018ecc7
[1:1:0712/130314.157023:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1018ecc7
[1:1:0712/130314.157186:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1018ecc7
[1:1:0712/130314.157274:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1018ecc7
[1:1:0712/130314.157768:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1018ecc7
[1:1:0712/130314.157997:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fc5816c97ba
[1:1:0712/130314.158100:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fc5816c0def, 7fc5816c977a, 7fc5816cb0cf
[20680:20692:0712/130314.161495:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 6, 3
[1:1:0712/130314.161441:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[20680:20692:0712/130314.161551:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 6, 3, HandleIncomingMessage, HandleIncomingMessage
[20680:20680:0712/130314.161704:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://www.alibaba.com/
[20680:20680:0712/130314.161746:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:3_https://www.alibaba.com/, https://www.alibaba.com/, 1
[20680:20680:0712/130314.161807:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 6:3_https://www.alibaba.com/, HTTP/1.1 200 status:200 date:Fri, 12 Jul 2019 05:03:14 GMT content-type:text/html;charset=UTF-8 vary:Accept-Encoding server:Apache-Coyote/1.1 set-cookie:JSESSIONID=10A6330A70586A0CB4FDD77B66E8593F; Path=/; HttpOnly set-cookie:ali_apache_track=; Domain=.alibaba.com; Expires=Wed, 30-Jul-2087 08:17:21 GMT; Path=/ set-cookie:ali_apache_tracktmp=; Domain=.alibaba.com; Path=/ p3p:CP="CAO PSA OUR" cache-control:s-maxage=3600 resin-trace:ali_resin_trace=aisn_homepage_version=null|septemberPromotion=black content-language:en-US strict-transport-security:max-age=31536000 strict-transport-security:max-age=31536000 content-encoding:gzip timing-allow-origin:* eagleid:0bb3d9a015629077934787220ea4c7  ,0, 6
[1:1:0712/130314.161645:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/130314.162289:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffca62d5a48, 0x7ffca62d59c8)
[3:3:0712/130314.163747:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/130314.168115:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/130314.170150:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:7:0712/130314.196263:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/130314.269211:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x937b8a62220
[1:1:0712/130314.269353:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/130314.295066:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 6:3_https://www.alibaba.com/
[20680:20680:0712/130314.398960:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:3_https://www.alibaba.com/, https://www.alibaba.com/, 1
[20680:20680:0712/130314.400891:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://www.alibaba.com/, https://www.alibaba.com
[1:1:0712/130314.409974:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/130314.454899:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/130314.471342:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/130314.492523:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/130314.492681:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.alibaba.com/"
[1:1:0712/130314.496339:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 108 0x7fc569404070 0x937b8b29060 , "https://www.alibaba.com/"
[1:1:0712/130314.497088:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , , 
    var homeTimePage1 = +new Date();

[1:1:0712/130314.497311:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "www.alibaba.com", 3, 1, , , 0
[1:1:0712/130314.510827:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.018172, 58, 1
[1:1:0712/130314.511035:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/130314.730055:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/130314.730229:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.alibaba.com/"
[1:1:0712/130314.730616:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 167 0x7fc569404070 0x937b8b91fe0 , "https://www.alibaba.com/"
[1:1:0712/130314.731108:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , , 
    //pc
	try { document.domain = 'alibaba.com'; } catch(e) { }

[1:1:0712/130314.731230:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "www.alibaba.com", 3, 1, , , 0
[1:1:0712/130314.731739:INFO:document.cc(5190)] >>> Document::setDomain. [old, new] = "www.alibaba.com", "alibaba.com"
[1:1:0712/130314.732800:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 167 0x7fc569404070 0x937b8b91fe0 , "https://www.alibaba.com/"
[1:1:0712/130314.733924:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 167 0x7fc569404070 0x937b8b91fe0 , "https://www.alibaba.com/"
[1:1:0712/130314.749456:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 167 0x7fc569404070 0x937b8b91fe0 , "https://www.alibaba.com/"
[1:1:0712/130314.752948:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 167 0x7fc569404070 0x937b8b91fe0 , "https://www.alibaba.com/"
[1:1:0712/130314.754237:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/130314.760676:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 167 0x7fc569404070 0x937b8b91fe0 , "https://www.alibaba.com/"
[1:1:0712/130314.765643:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 167 0x7fc569404070 0x937b8b91fe0 , "https://www.alibaba.com/"
[1:1:0712/130314.773072:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 167 0x7fc569404070 0x937b8b91fe0 , "https://www.alibaba.com/"
[1:1:0712/130314.776598:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 167 0x7fc569404070 0x937b8b91fe0 , "https://www.alibaba.com/"
[1:1:0712/130314.818948:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.088711, 151, 1
[1:1:0712/130314.819125:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/130315.109239:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/130315.109508:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.alibaba.com/"
[1:1:0712/130315.109993:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 230 0x7fc569404070 0x937b8c9c2e0 , "https://www.alibaba.com/"
[1:1:0712/130315.111015:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , , (function(){try{if(localStorage){var b=localStorage.getItem("sc-header-login"),c=document.cookie.mat
[1:1:0712/130315.111188:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130318.379073:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[3:3:0712/130322.212036:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/130322.447700:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 7.33817, 0, 0
[1:1:0712/130322.447918:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/130322.506069:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 241 0x7fc56b32c2e0 0x937b8c9b960 , "https://www.alibaba.com/"
[1:1:0712/130322.507423:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , , /*! 2019-03-20 10:16:09 v0.0.27 */
!(function (e) { function n (t) { if (o[t]) return o[t].exports; 
[1:1:0712/130322.507578:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130322.637727:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 242 0x7fc56b32c2e0 0x937b8b51f60 , "https://www.alibaba.com/"
[1:1:0712/130322.642086:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , ,  !function(){function e(t,n,r){function i(o,s){if(!n[o]){if(!t[o]){var c="function"==typeof require&
[1:1:0712/130322.642248:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130322.721701:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/130322.721907:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130322.871315:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/130322.871506:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.alibaba.com/"
[1:1:0712/130322.876219:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.00466514, 71, 1
[1:1:0712/130322.876385:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/130322.877493:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , , (){!function(e){var t=Date.now()-e,r=n.querySelector("body");if(r){var i=0;i+=a(r,1,!1),c.push({scor
[1:1:0712/130322.877643:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130323.063862:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , , highWaterMark =>
new BuiltInCountQueuingStrategy(highWaterMark)
[1:1:0712/130323.064050:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130323.071458:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , SetUpReadableStreamDefaultController.thenPromise, () => {
controller[_readableStreamDefaultControllerBits] |= STARTED;
ReadableStreamDefaultController
[1:1:0712/130323.071628:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130323.087887:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , , document.readyState
[1:1:0712/130323.088084:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130323.157648:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/130323.157811:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.alibaba.com/"
[1:1:0712/130323.158517:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , , (){!function(e){var t=Date.now()-e,r=n.querySelector("body");if(r){var i=0;i+=a(r,1,!1),c.push({scor
[1:1:0712/130323.158624:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130323.171017:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 311 0x7fc569404070 0x937b8c96560 , "https://www.alibaba.com/"
[1:1:0712/130323.189595:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 311 0x7fc569404070 0x937b8c96560 , "https://www.alibaba.com/"
[1:1:0712/130323.203294:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 311 0x7fc569404070 0x937b8c96560 , "https://www.alibaba.com/"
[1:1:0712/130323.217672:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 311 0x7fc569404070 0x937b8c96560 , "https://www.alibaba.com/"
[1:1:0712/130323.230618:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 311 0x7fc569404070 0x937b8c96560 , "https://www.alibaba.com/"
[1:1:0712/130323.244789:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 311 0x7fc569404070 0x937b8c96560 , "https://www.alibaba.com/"
[1:1:0712/130323.258928:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 311 0x7fc569404070 0x937b8c96560 , "https://www.alibaba.com/"
[1:1:0712/130323.259840:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 2000, 0x222cab6029c8, 0x937b88b69b0
[1:1:0712/130323.259938:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 2000
[1:1:0712/130323.260100:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 356
[1:1:0712/130323.260207:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 356 0x7fc569404070 0x937b90e7c60 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 311 0x7fc569404070 0x937b8c96560 
[1:1:0712/130323.288387:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 311 0x7fc569404070 0x937b8c96560 , "https://www.alibaba.com/"
[1:1:0712/130323.322996:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 311 0x7fc569404070 0x937b8c96560 , "https://www.alibaba.com/"
[1:1:0712/130323.369186:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 311 0x7fc569404070 0x937b8c96560 , "https://www.alibaba.com/"
[1:1:0712/130323.385904:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 311 0x7fc569404070 0x937b8c96560 , "https://www.alibaba.com/"
[1:1:0712/130323.421295:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 311 0x7fc569404070 0x937b8c96560 , "https://www.alibaba.com/"
[1:1:0712/130323.431104:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.273306, 90, 1
[1:1:0712/130323.431304:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/130323.512046:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 319 0x7fc56b32c2e0 0x937b8f50d60 , "https://www.alibaba.com/"
[1:1:0712/130323.512761:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , , !function(t,a){var r=1e4,g_moduleConfig={uabModule:{stable:["AWSC/uab/117.js"],grey:["AWSC/uab/118.j
[1:1:0712/130323.512895:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130323.515402:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.alibaba.com/"
[1:1:0712/130323.517849:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x222cab6029c8, 0x937b88b6c40
[1:1:0712/130323.518009:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 5000
[1:1:0712/130323.518252:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 389
[1:1:0712/130323.518426:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 389 0x7fc569404070 0x937b91f99e0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 319 0x7fc56b32c2e0 0x937b8f50d60 
[1:1:0712/130323.567426:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , , document.readyState
[1:1:0712/130323.567632:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130323.721220:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "https://www.alibaba.com/"
[1:1:0712/130323.721667:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , , (){b()}
[1:1:0712/130323.721819:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130323.925260:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.alibaba.com/"
[1:1:0712/130323.925639:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , , () {
                                if(performance && performance.getEntriesByName) {
             
[1:1:0712/130323.925738:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130324.073443:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/130324.073614:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.alibaba.com/"
[1:1:0712/130324.074251:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , , (){!function(e){var t=Date.now()-e,r=n.querySelector("body");if(r){var i=0;i+=a(r,1,!1),c.push({scor
[1:1:0712/130324.074372:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130324.100418:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 386 0x7fc569404070 0x937b8672c60 , "https://www.alibaba.com/"
[1:1:0712/130324.105425:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 386 0x7fc569404070 0x937b8672c60 , "https://www.alibaba.com/"
[1:1:0712/130324.111726:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 386 0x7fc569404070 0x937b8672c60 , "https://www.alibaba.com/"
[1:1:0712/130324.117975:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 386 0x7fc569404070 0x937b8672c60 , "https://www.alibaba.com/"
[1:1:0712/130324.125945:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 386 0x7fc569404070 0x937b8672c60 , "https://www.alibaba.com/"
[1:1:0712/130324.137672:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0640309, 97, 1
[1:1:0712/130324.137856:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/130324.291812:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , , document.readyState
[1:1:0712/130324.292008:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130324.412856:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , startMeasureFMP, (){var metaNodes=Array.prototype.filter.call(document.getElementsByName("data-spm"),function(node){r
[1:1:0712/130324.413010:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130324.446040:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 409 0x7fc56b32c2e0 0x937b8c413e0 , "https://www.alibaba.com/"
[1:1:0712/130324.448339:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , , (function(){var e=function(){var e={},t={exports:e};var n=0;function r(){}function i(e,t,i){if("func
[1:1:0712/130324.448464:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130324.481921:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.alibaba.com/"
[1:1:0712/130324.483624:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x222cab6029c8, 0x937b88b6a10
[1:1:0712/130324.483760:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 1
[1:1:0712/130324.483914:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 451
[1:1:0712/130324.484064:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 451 0x7fc569404070 0x937b8f41ae0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 409 0x7fc56b32c2e0 0x937b8c413e0 
[1:1:0712/130324.500672:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 410 0x7fc56b32c2e0 0x937b8b50160 , "https://www.alibaba.com/"
[1:1:0712/130324.501236:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , , topBannerCallback({"code":500,"message":"no data "});
[1:1:0712/130324.501363:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130324.653014:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/130324.653179:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.alibaba.com/"
[1:1:0712/130324.653804:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , , (){!function(e){var t=Date.now()-e,r=n.querySelector("body");if(r){var i=0;i+=a(r,1,!1),c.push({scor
[1:1:0712/130324.653904:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130324.678345:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 429 0x7fc569404070 0x937b8e6d7e0 , "https://www.alibaba.com/"
[1:1:0712/130324.706715:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 429 0x7fc569404070 0x937b8e6d7e0 , "https://www.alibaba.com/"
[1:1:0712/130324.734887:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 429 0x7fc569404070 0x937b8e6d7e0 , "https://www.alibaba.com/"
[1:1:0712/130324.767770:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 429 0x7fc569404070 0x937b8e6d7e0 , "https://www.alibaba.com/"
[1:1:0712/130324.794047:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 429 0x7fc569404070 0x937b8e6d7e0 , "https://www.alibaba.com/"
[1:1:0712/130324.824978:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 429 0x7fc569404070 0x937b8e6d7e0 , "https://www.alibaba.com/"
[1:1:0712/130324.855616:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 429 0x7fc569404070 0x937b8e6d7e0 , "https://www.alibaba.com/"
[1:1:0712/130324.883086:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 429 0x7fc569404070 0x937b8e6d7e0 , "https://www.alibaba.com/"
[1:1:0712/130324.910534:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 429 0x7fc569404070 0x937b8e6d7e0 , "https://www.alibaba.com/"
[1:1:0712/130324.937780:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 429 0x7fc569404070 0x937b8e6d7e0 , "https://www.alibaba.com/"
[1:1:0712/130324.975801:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.32265, 353, 1
[1:1:0712/130324.976027:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/130325.189712:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , , (e){t(e)}
[1:1:0712/130325.189901:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130325.192998:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 437 0x7fc57c963bb0 0x937b95993c0 0 , "https://www.alibaba.com/"
[1:1:0712/130325.416136:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x222cab6029c8, 0x937b88b6e78
[1:1:0712/130325.416331:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 1000
[1:1:0712/130325.416555:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 502
[1:1:0712/130325.416699:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 502 0x7fc569404070 0x937b86737e0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 437 0x7fc57c963bb0 0x937b95993c0 0 
[1:1:0712/130325.502099:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x222cab6029c8, 0x937b88b6e78
[1:1:0712/130325.502288:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 5000
[1:1:0712/130325.502511:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 515
[1:1:0712/130325.502667:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 515 0x7fc569404070 0x937b88c00e0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 437 0x7fc57c963bb0 0x937b95993c0 0 
[1:1:0712/130325.511032:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x222cab6029c8, 0x937b88b6e78
[1:1:0712/130325.511201:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 3000
[1:1:0712/130325.511391:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 516
[1:1:0712/130325.511498:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 516 0x7fc569404070 0x937b88bf860 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 437 0x7fc57c963bb0 0x937b95993c0 0 
[1:1:0712/130325.521689:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x222cab6029c8, 0x937b88b6e78
[1:1:0712/130325.521842:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 500
[1:1:0712/130325.522004:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 517
[1:1:0712/130325.522111:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 517 0x7fc569404070 0x937b943ebe0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 437 0x7fc57c963bb0 0x937b95993c0 0 
[1:1:0712/130325.590264:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x222cab6029c8, 0x937b88b6e78
[1:1:0712/130325.590449:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 5000
[1:1:0712/130325.590694:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 527
[1:1:0712/130325.590859:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 527 0x7fc569404070 0x937b87a4f60 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 437 0x7fc57c963bb0 0x937b95993c0 0 
[1:1:0712/130325.610506:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x222cab6029c8, 0x937b88b6e78
[1:1:0712/130325.610702:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 3000
[1:1:0712/130325.610919:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 528
[1:1:0712/130325.611107:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 528 0x7fc569404070 0x937b8673b60 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 437 0x7fc57c963bb0 0x937b95993c0 0 
[1:1:0712/130325.613338:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0x222cab6029c8, 0x937b88b6e78
[1:1:0712/130325.613459:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 10
[1:1:0712/130325.613612:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 529
[1:1:0712/130325.613716:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 529 0x7fc569404070 0x937b8672760 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 437 0x7fc57c963bb0 0x937b95993c0 0 
[1:1:0712/130325.665236:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , , document.readyState
[1:1:0712/130325.665438:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130325.683068:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , rFACallBack, (){var hes=document.querySelectorAll(selector);if(hes.length>=config.minCount){var runTime=performan
[1:1:0712/130325.683254:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130325.686759:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x222cab6029c8, 0x937b88b6968
[1:1:0712/130325.686933:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 500
[1:1:0712/130325.687137:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 538
[1:1:0712/130325.687246:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 538 0x7fc569404070 0x937b94a1760 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 442 0x7fc578715960 0x937b88f9060 0x937b88f9070 
[1:1:0712/130325.806148:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 451, 7fc56bd49881
[1:1:0712/130325.815536:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"133b70722860","ptid":"409 0x7fc56b32c2e0 0x937b8c413e0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/130325.815765:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.alibaba.com/","ptid":"409 0x7fc56b32c2e0 0x937b8c413e0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/130325.815995:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.alibaba.com/"
[1:1:0712/130325.816296:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , , (){var t=e.modNames.join("^");try{e.callback()}catch(n){o({gmkey:"EXP",gokey:"pos=useCallbackError&c
[1:1:0712/130325.816465:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130326.258165:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/130326.258350:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.alibaba.com/"
[1:1:0712/130326.258996:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , , (){!function(e){var t=Date.now()-e,r=n.querySelector("body");if(r){var i=0;i+=a(r,1,!1),c.push({scor
[1:1:0712/130326.259158:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130326.507604:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 486 0x7fc569404070 0x937b90e72e0 , "https://www.alibaba.com/"
[1:1:0712/130326.512867:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x222cab6029c8, 0x937b88b69a0
[1:1:0712/130326.513012:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 3000
[1:1:0712/130326.513206:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 588
[1:1:0712/130326.513386:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 588 0x7fc569404070 0x937b8e6dbe0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 486 0x7fc569404070 0x937b90e72e0 
[1:1:0712/130326.533779:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 486 0x7fc569404070 0x937b90e72e0 , "https://www.alibaba.com/"
[1:1:0712/130326.545790:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 486 0x7fc569404070 0x937b90e72e0 , "https://www.alibaba.com/"
[1:1:0712/130326.557648:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 486 0x7fc569404070 0x937b90e72e0 , "https://www.alibaba.com/"
[1:1:0712/130326.589810:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 486 0x7fc569404070 0x937b90e72e0 , "https://www.alibaba.com/"
[1:1:0712/130326.600773:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 486 0x7fc569404070 0x937b90e72e0 , "https://www.alibaba.com/"
[1:1:0712/130326.613404:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 486 0x7fc569404070 0x937b90e72e0 , "https://www.alibaba.com/"
[1:1:0712/130326.860305:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.alibaba.com/"
[1:1:0712/130326.863020:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.604584, 0, 0
[1:1:0712/130326.863158:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/130327.258510:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "open", "https://www.alibaba.com/"
[1:1:0712/130327.258940:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , s.onopen, (){e.status="active";var t=e.getMsgQueue();t.length>0&&e.proessMsgQueue(t);var n="connTime="+((new D
[1:1:0712/130327.259088:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130327.304499:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 356, 7fc56bd49881
[1:1:0712/130327.314331:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"133b70722860","ptid":"311 0x7fc569404070 0x937b8c96560 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/130327.314557:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.alibaba.com/","ptid":"311 0x7fc569404070 0x937b8c96560 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/130327.314730:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.alibaba.com/"
[1:1:0712/130327.315016:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , , () {
            if(!window.TOP_BANNER_DATA) {
                window.topBannerCallback({});
       
[1:1:0712/130327.315128:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130327.315715:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 529, 7fc56bd49881
[1:1:0712/130327.325526:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"133b70722860","ptid":"437 0x7fc57c963bb0 0x937b95993c0 0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/130327.325702:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.alibaba.com/","ptid":"437 0x7fc57c963bb0 0x937b95993c0 0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/130327.325861:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.alibaba.com/"
[1:1:0712/130327.326118:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , , (){n&&"script"==n.tagName.toLowerCase()||r.addScript(p,"","aplus-sufei")}
[1:1:0712/130327.326215:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130327.378766:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , , document.readyState
[1:1:0712/130327.378934:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130327.706572:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 517, 7fc56bd49881
[1:1:0712/130327.718758:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"133b70722860","ptid":"437 0x7fc57c963bb0 0x937b95993c0 0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/130327.718932:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.alibaba.com/","ptid":"437 0x7fc57c963bb0 0x937b95993c0 0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/130327.719103:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.alibaba.com/"
[1:1:0712/130327.719392:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , t, (){e++,e>10&&(n=3e3),o(),setTimeout(t,n)}
[1:1:0712/130327.719622:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130327.720864:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x222cab6029c8, 0x937b88b6950
[1:1:0712/130327.720997:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 500
[1:1:0712/130327.721232:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 636
[1:1:0712/130327.721351:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 636 0x7fc569404070 0x937b9458060 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 517 0x7fc569404070 0x937b943ebe0 
[1:1:0712/130327.744913:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 538, 7fc56bd49881
[1:1:0712/130327.754941:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"133b70722860","ptid":"442 0x7fc578715960 0x937b88f9060 0x937b88f9070 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/130327.755112:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.alibaba.com/","ptid":"442 0x7fc578715960 0x937b88f9060 0x937b88f9070 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/130327.755274:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.alibaba.com/"
[1:1:0712/130327.755535:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , , (){trace(type,action)}
[1:1:0712/130327.755621:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130327.756050:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x222cab6029c8, 0x937b88b6950
[1:1:0712/130327.756129:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 500
[1:1:0712/130327.756278:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 642
[1:1:0712/130327.756368:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 642 0x7fc569404070 0x937ba0336e0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 538 0x7fc569404070 0x937b94a1760 
[1:1:0712/130328.182080:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/130328.195918:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.alibaba.com/"
[1:1:0712/130328.196332:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , imgLarge.onload, () {
            firstImage.src = imgLarge.src;
        }
[1:1:0712/130328.196454:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130328.207411:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/130328.207530:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.alibaba.com/"
[1:1:0712/130328.208211:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , , (){!function(e){var t=Date.now()-e,r=n.querySelector("body");if(r){var i=0;i+=a(r,1,!1),c.push({scor
[1:1:0712/130328.208310:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130328.365009:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 610 0x7fc569404070 0x937b95938e0 , "https://www.alibaba.com/"
[1:1:0712/130328.387171:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 610 0x7fc569404070 0x937b95938e0 , "https://www.alibaba.com/"
[1:1:0712/130328.665654:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 610 0x7fc569404070 0x937b95938e0 , "https://www.alibaba.com/"
[1:1:0712/130329.036776:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.829243, 0, 0
[1:1:0712/130329.036942:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/130329.059261:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 502, 7fc56bd49881
[1:1:0712/130329.068279:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"133b70722860","ptid":"437 0x7fc57c963bb0 0x937b95993c0 0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/130329.068418:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.alibaba.com/","ptid":"437 0x7fc57c963bb0 0x937b95993c0 0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/130329.068594:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.alibaba.com/"
[1:1:0712/130329.068841:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , , (){var e=r.getUrl(t.options.context.etag||{});a.loadScript(e,function(e){e&&"error"!==e.type&&o.setL
[1:1:0712/130329.068924:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130329.194558:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , , document.readyState
[1:1:0712/130329.194797:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130329.229308:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.alibaba.com/"
[1:1:0712/130329.229719:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , n.onload, (){i()}
[1:1:0712/130329.229857:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130329.260835:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.alibaba.com/"
[1:1:0712/130329.261308:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , n.onload, (){i()}
[1:1:0712/130329.261412:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130329.491618:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 651 0x7fc56b32c2e0 0x937b876a7e0 , "https://www.alibaba.com/"
[1:1:0712/130329.492276:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , , (function(){var e=function(){var e={},t={exports:e};(function(){var e=document.getElementsByTagName(
[1:1:0712/130329.492407:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130329.505598:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.alibaba.com/"
[1:1:0712/130329.529039:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 652 0x7fc56b32c2e0 0x937ba27de60 , "https://www.alibaba.com/"
[1:1:0712/130329.529846:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , , (function(a,e,t,i,o){var n=i.userAgent;var r=e.getElementsByTagName("head")[0];function c(a){var t=e
[1:1:0712/130329.529981:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130329.573964:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.alibaba.com/"
[1:1:0712/130329.574356:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , , () {
                                if(performance && performance.getEntriesByName) {
             
[1:1:0712/130329.574465:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130329.682706:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/130329.682843:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.alibaba.com/"
[1:1:0712/130329.683692:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , , (){!function(e){var t=Date.now()-e,r=n.querySelector("body");if(r){var i=0;i+=a(r,1,!1),c.push({scor
[1:1:0712/130329.683797:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130329.694440:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 661 0x7fc569404070 0x937bab66b60 , "https://www.alibaba.com/"
		remove user.e_b19e0139 -> 0
[1:1:0712/130329.703707:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.alibaba.com/"
[1:1:0712/130329.736832:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 661 0x7fc569404070 0x937bab66b60 , "https://www.alibaba.com/"
[1:1:0712/130329.750019:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 661 0x7fc569404070 0x937bab66b60 , "https://www.alibaba.com/"
[1:1:0712/130329.752371:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://www.alibaba.com/"
[1:1:0712/130329.792404:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x222cab6029c8, 0x937b88b6a10
[1:1:0712/130329.792595:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 5000
[1:1:0712/130329.792779:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 709
[1:1:0712/130329.792894:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 709 0x7fc569404070 0x937ba9d6ee0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 661 0x7fc569404070 0x937bab66b60 
[1:1:0712/130329.803063:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://www.alibaba.com/"
[1:1:0712/130329.803675:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x222cab6029c8, 0x937b88b69e0
[1:1:0712/130329.803820:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 1000
[1:1:0712/130329.804001:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 711
[1:1:0712/130329.804175:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 711 0x7fc569404070 0x937b8a872e0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 661 0x7fc569404070 0x937bab66b60 
[1:1:0712/130329.804430:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://www.alibaba.com/"
[1:1:0712/130329.822260:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://www.alibaba.com/"
[1:1:0712/130329.823339:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://www.alibaba.com/"
[1:1:0712/130329.843960:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://www.alibaba.com/"
[1:1:0712/130329.884295:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 636, 7fc56bd49881
[1:1:0712/130329.895657:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"133b70722860","ptid":"517 0x7fc569404070 0x937b943ebe0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/130329.895830:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.alibaba.com/","ptid":"517 0x7fc569404070 0x937b943ebe0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/130329.896005:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.alibaba.com/"
[1:1:0712/130329.896283:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , t, (){e++,e>10&&(n=3e3),o(),setTimeout(t,n)}
[1:1:0712/130329.896399:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130329.897095:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x222cab6029c8, 0x937b88b6950
[1:1:0712/130329.897205:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 500
[1:1:0712/130329.897378:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 730
[1:1:0712/130329.897499:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 730 0x7fc569404070 0x937babad760 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 636 0x7fc569404070 0x937b9458060 
[1:1:0712/130329.910392:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 642, 7fc56bd49881
[1:1:0712/130329.922452:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"133b70722860","ptid":"538 0x7fc569404070 0x937b94a1760 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/130329.922635:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.alibaba.com/","ptid":"538 0x7fc569404070 0x937b94a1760 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/130329.922847:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.alibaba.com/"
[1:1:0712/130329.923115:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , , (){trace(type,action)}
[1:1:0712/130329.923216:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130329.923557:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x222cab6029c8, 0x937b88b6950
[1:1:0712/130329.923651:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 500
[1:1:0712/130329.923805:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 734
[1:1:0712/130329.923898:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 734 0x7fc569404070 0x937b86798e0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 642 0x7fc569404070 0x937ba0336e0 
[1:1:0712/130329.924331:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 516, 7fc56bd49881
[1:1:0712/130329.935999:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"133b70722860","ptid":"437 0x7fc57c963bb0 0x937b95993c0 0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/130329.936216:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.alibaba.com/","ptid":"437 0x7fc57c963bb0 0x937b95993c0 0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/130329.936466:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.alibaba.com/"
[1:1:0712/130329.936740:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , , (){var n=t.wsHandler.getMsgQueue();if(t.dataInArray(n,e)){t.doSetRetryTimes(),t.changeToHttpRequest(
[1:1:0712/130329.936839:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130329.950914:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 389, 7fc56bd49881
[1:1:0712/130329.963334:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"133b70722860","ptid":"319 0x7fc56b32c2e0 0x937b8f50d60 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/130329.963572:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.alibaba.com/","ptid":"319 0x7fc56b32c2e0 0x937b8f50d60 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/130329.963830:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.alibaba.com/"
[1:1:0712/130329.964146:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , , (){S.state=b,x(S,r&&r.throwExceptionInCallback)}
[1:1:0712/130329.964281:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130330.002995:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x222cab6029c8, 0x937b88b6950
[1:1:0712/130330.003180:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 5000
[1:1:0712/130330.003353:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 741
[1:1:0712/130330.003448:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 741 0x7fc569404070 0x937ba99e8e0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 389 0x7fc569404070 0x937b91f99e0 
[1:1:0712/130330.022769:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 528, 7fc56bd49881
[1:1:0712/130330.034722:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"133b70722860","ptid":"437 0x7fc57c963bb0 0x937b95993c0 0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/130330.034916:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.alibaba.com/","ptid":"437 0x7fc57c963bb0 0x937b95993c0 0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/130330.035152:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.alibaba.com/"
[1:1:0712/130330.037364:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , , (){var n=t.wsHandler.getMsgQueue();if(t.dataInArray(n,e)){t.doSetRetryTimes(),t.changeToHttpRequest(
[1:1:0712/130330.037523:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130330.129729:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 674 0x7fc56b32c2e0 0x937b9dfdd60 , "https://www.alibaba.com/"
[1:1:0712/130330.132887:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , , define("sc-global/node_modules/@alife/alpha-security/security.js",[],function(require,e,t){var n={};
[1:1:0712/130330.132997:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130330.163208:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.alibaba.com/"
[1:1:0712/130331.190770:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x222cab6029c8, 0x937b88b6a10
[1:1:0712/130331.190996:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 3000
[1:1:0712/130331.191244:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 774
[1:1:0712/130331.191413:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 774 0x7fc569404070 0x937bb33c060 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 674 0x7fc56b32c2e0 0x937b9dfdd60 
[1:1:0712/130331.393495:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 4000, 0x222cab6029c8, 0x937b88b6a10
[1:1:0712/130331.393672:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 4000
[1:1:0712/130331.393903:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 775
[1:1:0712/130331.394057:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 775 0x7fc569404070 0x937baf02960 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 674 0x7fc56b32c2e0 0x937b9dfdd60 
[1:1:0712/130331.416385:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 4000, 0x222cab6029c8, 0x937b88b6a10
[1:1:0712/130331.416559:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 4000
[1:1:0712/130331.416770:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 779
[1:1:0712/130331.416864:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 779 0x7fc569404070 0x937bb6fd5e0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 674 0x7fc56b32c2e0 0x937b9dfdd60 
[1:1:0712/130331.434851:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 4000, 0x222cab6029c8, 0x937b88b6a10
[1:1:0712/130331.435069:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 4000
[1:1:0712/130331.435324:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 783
[1:1:0712/130331.435468:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 783 0x7fc569404070 0x937bb72a4e0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 674 0x7fc56b32c2e0 0x937b9dfdd60 
[1:1:0712/130331.449114:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 60000, 0x222cab6029c8, 0x937b88b6a10
[1:1:0712/130331.449262:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 60000
[1:1:0712/130331.449463:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 786
[1:1:0712/130331.449649:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 786 0x7fc569404070 0x937bb7ee3e0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 674 0x7fc56b32c2e0 0x937b9dfdd60 
[1:1:0712/130331.458458:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 60000, 0x222cab6029c8, 0x937b88b6a10
[1:1:0712/130331.458637:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 60000
[1:1:0712/130331.458806:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 788
[1:1:0712/130331.458912:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 788 0x7fc569404070 0x937bb6f1260 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 674 0x7fc56b32c2e0 0x937b9dfdd60 
[1:1:0712/130331.466744:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 60000, 0x222cab6029c8, 0x937b88b6a10
[1:1:0712/130331.466896:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 60000
[1:1:0712/130331.467082:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 790
[1:1:0712/130331.467193:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 790 0x7fc569404070 0x937bb84d760 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 674 0x7fc56b32c2e0 0x937b9dfdd60 
[1:1:0712/130331.474884:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 60000, 0x222cab6029c8, 0x937b88b6a10
[1:1:0712/130331.475044:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 60000
[1:1:0712/130331.475238:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 792
[1:1:0712/130331.475339:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 792 0x7fc569404070 0x937bb85dce0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 674 0x7fc56b32c2e0 0x937b9dfdd60 
[1:1:0712/130331.485812:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 60000, 0x222cab6029c8, 0x937b88b6a10
[1:1:0712/130331.486005:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 60000
[1:1:0712/130331.486192:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 795
[1:1:0712/130331.486317:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 795 0x7fc569404070 0x937bb862760 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 674 0x7fc56b32c2e0 0x937b9dfdd60 
[1:1:0712/130331.501497:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x222cab6029c8, 0x937b88b6a10
[1:1:0712/130331.501637:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 1000
[1:1:0712/130331.501811:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 797
[1:1:0712/130331.501917:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 797 0x7fc569404070 0x937bb7ee660 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 674 0x7fc56b32c2e0 0x937b9dfdd60 
[1:1:0712/130331.510106:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 60000, 0x222cab6029c8, 0x937b88b6a10
[1:1:0712/130331.510268:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 60000
[1:1:0712/130331.510457:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 798
[1:1:0712/130331.510580:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 798 0x7fc569404070 0x937bb74a360 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 674 0x7fc56b32c2e0 0x937b9dfdd60 
[1:1:0712/130331.517546:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 60000, 0x222cab6029c8, 0x937b88b6a10
[1:1:0712/130331.517706:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 60000
[1:1:0712/130331.517942:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 800
[1:1:0712/130331.518080:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 800 0x7fc569404070 0x937bb8a04e0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 674 0x7fc56b32c2e0 0x937b9dfdd60 
[1:1:0712/130331.700153:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 5000
[1:1:0712/130331.700488:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://www.alibaba.com/, 809
[1:1:0712/130331.700629:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 809 0x7fc569404070 0x937bb5ec560 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 674 0x7fc56b32c2e0 0x937b9dfdd60 
[1:1:0712/130332.315817:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 60000, 0x222cab6029c8, 0x937b88b6a10
[1:1:0712/130332.316003:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 60000
[1:1:0712/130332.316234:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 815
[1:1:0712/130332.316376:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 815 0x7fc569404070 0x937bbff9de0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 674 0x7fc56b32c2e0 0x937b9dfdd60 
[1:1:0712/130332.371899:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 60000, 0x222cab6029c8, 0x937b88b6a10
[1:1:0712/130332.372086:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 60000
[1:1:0712/130332.372292:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 817
[1:1:0712/130332.372430:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 817 0x7fc569404070 0x937bb684d60 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 674 0x7fc56b32c2e0 0x937b9dfdd60 
[1:1:0712/130332.704249:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/130335.198053:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 1000
[1:1:0712/130335.198325:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://www.alibaba.com/, 846
[1:1:0712/130335.198502:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 846 0x7fc569404070 0x937bdf2f160 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 674 0x7fc56b32c2e0 0x937b9dfdd60 
[1:1:0712/130335.338254:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 20000, 0x222cab6029c8, 0x937b88b6a10
[1:1:0712/130335.338444:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 20000
[1:1:0712/130335.338682:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 852
[1:1:0712/130335.338834:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 852 0x7fc569404070 0x937bde3abe0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 674 0x7fc56b32c2e0 0x937b9dfdd60 
[1:1:0712/130335.389314:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 675 0x7fc56b32c2e0 0x937bab66660 , "https://www.alibaba.com/"
[1:1:0712/130335.389859:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , , window.goldlog=(window.goldlog||{});goldlog.Etag="x72HFb6WgX0CAXlFE14b37jj";goldlog.stag=1;
[1:1:0712/130335.389965:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130335.390281:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.alibaba.com/"
[1:1:0712/130335.419599:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , , document.readyState
[1:1:0712/130335.419786:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130335.652918:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 588, 7fc56bd49881
[1:1:0712/130335.666704:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"133b70722860","ptid":"486 0x7fc569404070 0x937b90e72e0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/130335.666930:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.alibaba.com/","ptid":"486 0x7fc569404070 0x937b90e72e0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/130335.667192:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.alibaba.com/"
[1:1:0712/130335.667506:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , , (){
        useScript('//s.alicdn.com/@g/sc/footer/0.0.3/sc-footer/dist/footer-sync.js');
      }
[1:1:0712/130335.667642:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130335.815780:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 695 0x7fc56b32c2e0 0x937b8b241e0 , "https://www.alibaba.com/"
[1:1:0712/130335.818829:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , , !function(t){function e(r){if(n[r])return n[r].exports;var o=n[r]={i:r,l:!1,exports:{}};return t[r].
[1:1:0712/130335.818946:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130335.831129:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.alibaba.com/"
[1:1:0712/130335.836682:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x222cab6029c8, 0x937b88b6a10
[1:1:0712/130335.836816:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 1000
[1:1:0712/130335.836961:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 895
[1:1:0712/130335.837078:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 895 0x7fc569404070 0x937bdf2f360 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 695 0x7fc56b32c2e0 0x937b8b241e0 
[1:1:0712/130335.853342:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 696 0x7fc56b32c2e0 0x937b85b05e0 , "https://www.alibaba.com/"
[1:1:0712/130335.854416:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , , !function(n,t,i,r,a,o,e,c,u,f,s,l,m,h,v){var p,d=374,g="isg",y=c,b=!!y.addEventListener,w=u.getEleme
[1:1:0712/130335.854527:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130335.932589:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/130335.937737:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/130335.938402:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:17:0712/130335.941377:ERROR:adm_helpers.cc(73)] Failed to query stereo recording.
[1:1:0712/130335.948558:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x222cab6029c8, 0x937b88b6990
[1:1:0712/130335.949018:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 5000
[1:1:0712/130335.952333:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 909
[1:1:0712/130335.952488:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 909 0x7fc569404070 0x937bded1ee0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 696 0x7fc56b32c2e0 0x937b85b05e0 
[1:1:0712/130336.650076:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 747 0x7fc56b32c2e0 0x937b9e99fe0 , "https://www.alibaba.com/"
[1:1:0712/130336.650781:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , , jsonpCallback({"code":200,"data":{"nicheVoList":[{"materialVoList":[{"clickParam":"click_cid-3852#cl
[1:1:0712/130336.650920:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130336.715358:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 748 0x7fc56b32c2e0 0x937ba9c0ee0 , "https://www.alibaba.com/"
[1:1:0712/130336.721809:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , , !function(){function e(b,k,o,t,n){var h,d,p,v,u,f,l,C,g,w,m,S,j,A,x,y,E,_,R,O,T,D,P,M,I,B,L,N,V,W,z,
[1:1:0712/130336.721956:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:19:0712/130338.470103:WARNING:paced_sender.cc(261)] Elapsed time (2501 ms) longer than expected, limiting to 2000 ms
[1:19:0712/130338.971107:WARNING:paced_sender.cc(261)] Elapsed time (3002 ms) longer than expected, limiting to 2000 ms
[1:19:0712/130339.471506:WARNING:paced_sender.cc(261)] Elapsed time (3503 ms) longer than expected, limiting to 2000 ms
[1:19:0712/130339.971872:WARNING:paced_sender.cc(261)] Elapsed time (4003 ms) longer than expected, limiting to 2000 ms
[1:19:0712/130340.472320:WARNING:paced_sender.cc(261)] Elapsed time (4503 ms) longer than expected, limiting to 2000 ms
[1:1:0712/130340.545026:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 50, 0x222cab6029c8, 0x937b88b6988
[1:1:0712/130340.545253:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 50
[1:1:0712/130340.545448:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 942
[1:1:0712/130340.545583:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 942 0x7fc569404070 0x937bef6ed60 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 748 0x7fc56b32c2e0 0x937ba9c0ee0 
[1:19:0712/130340.972661:WARNING:paced_sender.cc(261)] Elapsed time (5004 ms) longer than expected, limiting to 2000 ms
[1:19:0712/130341.473052:WARNING:paced_sender.cc(261)] Elapsed time (5504 ms) longer than expected, limiting to 2000 ms
[1:19:0712/130341.973483:WARNING:paced_sender.cc(261)] Elapsed time (6005 ms) longer than expected, limiting to 2000 ms
[1:19:0712/130342.473956:WARNING:paced_sender.cc(261)] Elapsed time (6505 ms) longer than expected, limiting to 2000 ms
[1:21:0712/130342.545260:WARNING:paced_sender.cc(261)] Elapsed time (2006 ms) longer than expected, limiting to 2000 ms
[1:19:0712/130342.974579:WARNING:paced_sender.cc(261)] Elapsed time (7006 ms) longer than expected, limiting to 2000 ms
[1:21:0712/130343.045563:WARNING:paced_sender.cc(261)] Elapsed time (2506 ms) longer than expected, limiting to 2000 ms
[1:19:0712/130343.474826:WARNING:paced_sender.cc(261)] Elapsed time (7506 ms) longer than expected, limiting to 2000 ms
[1:21:0712/130343.546025:WARNING:paced_sender.cc(261)] Elapsed time (3006 ms) longer than expected, limiting to 2000 ms
[1:19:0712/130343.975094:WARNING:paced_sender.cc(261)] Elapsed time (8006 ms) longer than expected, limiting to 2000 ms
[1:21:0712/130344.047144:WARNING:paced_sender.cc(261)] Elapsed time (3508 ms) longer than expected, limiting to 2000 ms
[1:19:0712/130344.475491:WARNING:paced_sender.cc(261)] Elapsed time (8507 ms) longer than expected, limiting to 2000 ms
[1:21:0712/130344.547529:WARNING:paced_sender.cc(261)] Elapsed time (4008 ms) longer than expected, limiting to 2000 ms
[1:19:0712/130344.975907:WARNING:paced_sender.cc(261)] Elapsed time (9007 ms) longer than expected, limiting to 2000 ms
[1:21:0712/130345.048025:WARNING:paced_sender.cc(261)] Elapsed time (4508 ms) longer than expected, limiting to 2000 ms
[1:19:0712/130345.476354:WARNING:paced_sender.cc(261)] Elapsed time (9507 ms) longer than expected, limiting to 2000 ms
[1:21:0712/130345.549091:WARNING:paced_sender.cc(261)] Elapsed time (5010 ms) longer than expected, limiting to 2000 ms
		remove user.f_87e775a2 -> 0
		remove user.10_45413ac6 -> 0
		remove user.11_1c37ce8d -> 0
		remove user.12_46eb5a23 -> 0
		remove user.13_41ce6d97 -> 0
		remove user.14_e73a3d82 -> 0
[1:19:0712/130345.976944:WARNING:paced_sender.cc(261)] Elapsed time (10008 ms) longer than expected, limiting to 2000 ms
[1:21:0712/130346.049571:WARNING:paced_sender.cc(261)] Elapsed time (5510 ms) longer than expected, limiting to 2000 ms
[1:19:0712/130346.477287:WARNING:paced_sender.cc(261)] Elapsed time (10508 ms) longer than expected, limiting to 2000 ms
[1:21:0712/130346.549971:WARNING:paced_sender.cc(261)] Elapsed time (6010 ms) longer than expected, limiting to 2000 ms
[1:19:0712/130346.977709:WARNING:paced_sender.cc(261)] Elapsed time (11009 ms) longer than expected, limiting to 2000 ms
[1:21:0712/130347.050646:WARNING:paced_sender.cc(261)] Elapsed time (6511 ms) longer than expected, limiting to 2000 ms
[1:19:0712/130347.478066:WARNING:paced_sender.cc(261)] Elapsed time (11509 ms) longer than expected, limiting to 2000 ms
[1:21:0712/130347.551069:WARNING:paced_sender.cc(261)] Elapsed time (7012 ms) longer than expected, limiting to 2000 ms
[1:19:0712/130347.978329:WARNING:paced_sender.cc(261)] Elapsed time (12009 ms) longer than expected, limiting to 2000 ms
[1:21:0712/130348.051604:WARNING:paced_sender.cc(261)] Elapsed time (7512 ms) longer than expected, limiting to 2000 ms
[1:19:0712/130348.478586:WARNING:paced_sender.cc(261)] Elapsed time (12510 ms) longer than expected, limiting to 2000 ms
[1:21:0712/130348.551946:WARNING:paced_sender.cc(261)] Elapsed time (8012 ms) longer than expected, limiting to 2000 ms
[1:19:0712/130348.978975:WARNING:paced_sender.cc(261)] Elapsed time (13010 ms) longer than expected, limiting to 2000 ms
[1:21:0712/130349.052208:WARNING:paced_sender.cc(261)] Elapsed time (8513 ms) longer than expected, limiting to 2000 ms
[1:19:0712/130349.479358:WARNING:paced_sender.cc(261)] Elapsed time (13510 ms) longer than expected, limiting to 2000 ms
[1:21:0712/130349.552424:WARNING:paced_sender.cc(261)] Elapsed time (9013 ms) longer than expected, limiting to 2000 ms
[1:19:0712/130349.979710:WARNING:paced_sender.cc(261)] Elapsed time (14011 ms) longer than expected, limiting to 2000 ms
[1:21:0712/130350.052952:WARNING:paced_sender.cc(261)] Elapsed time (9513 ms) longer than expected, limiting to 2000 ms
[20680:20680:0712/130350.417951:INFO:CONSOLE(1)] "", source: https://aeis.alicdn.com/AWSC/WebUMID/1.73.2/um.js?d=12 (1)
[1:19:0712/130350.480056:WARNING:paced_sender.cc(261)] Elapsed time (14511 ms) longer than expected, limiting to 2000 ms
[1:1:0712/130350.492976:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 752 0x7fc56b32c2e0 0x937baa9dc60 , "https://www.alibaba.com/"
[1:1:0712/130350.494371:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , , !function(e){function t(n){if(o[n])return o[n].exports;var i=o[n]={i:n,l:!1,exports:{}};return e[n].
[1:1:0712/130350.494560:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130350.508598:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x222cab6029c8, 0x937b88b69b0
[1:1:0712/130350.508754:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 0
[1:1:0712/130350.509027:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 960
[1:1:0712/130350.509237:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 960 0x7fc569404070 0x937bf09cfe0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 752 0x7fc56b32c2e0 0x937baa9dc60 
[1:1:0712/130350.535427:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.alibaba.com/"
[1:21:0712/130350.553390:WARNING:paced_sender.cc(261)] Elapsed time (10014 ms) longer than expected, limiting to 2000 ms
[1:19:0712/130350.980469:WARNING:paced_sender.cc(261)] Elapsed time (15012 ms) longer than expected, limiting to 2000 ms
[1:21:0712/130351.053717:WARNING:paced_sender.cc(261)] Elapsed time (10514 ms) longer than expected, limiting to 2000 ms
[1:19:0712/130351.481049:WARNING:paced_sender.cc(261)] Elapsed time (15512 ms) longer than expected, limiting to 2000 ms
[1:21:0712/130351.554044:WARNING:paced_sender.cc(261)] Elapsed time (11015 ms) longer than expected, limiting to 2000 ms
[1:19:0712/130351.981212:WARNING:paced_sender.cc(261)] Elapsed time (16012 ms) longer than expected, limiting to 2000 ms
[1:21:0712/130352.054304:WARNING:paced_sender.cc(261)] Elapsed time (11515 ms) longer than expected, limiting to 2000 ms
[1:1:0712/130352.066262:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.alibaba.com/"
[1:1:0712/130352.066626:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , t.onload, (){try{localStorage.setItem(e,"available")}catch(t){}}
[1:1:0712/130352.066745:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130352.167864:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 730, 7fc56bd49881
[1:1:0712/130352.183547:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"133b70722860","ptid":"636 0x7fc569404070 0x937b9458060 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/130352.183713:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.alibaba.com/","ptid":"636 0x7fc569404070 0x937b9458060 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/130352.183911:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.alibaba.com/"
[1:1:0712/130352.184169:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , t, (){e++,e>10&&(n=3e3),o(),setTimeout(t,n)}
[1:1:0712/130352.184267:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130352.185096:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x222cab6029c8, 0x937b88b6950
[1:1:0712/130352.185190:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 500
[1:1:0712/130352.185344:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1013
[1:1:0712/130352.185447:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1013 0x7fc569404070 0x937bf05c060 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 730 0x7fc569404070 0x937babad760 
[1:1:0712/130352.185956:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 734, 7fc56bd49881
[1:1:0712/130352.202311:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"133b70722860","ptid":"642 0x7fc569404070 0x937ba0336e0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/130352.202484:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.alibaba.com/","ptid":"642 0x7fc569404070 0x937ba0336e0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/130352.202695:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.alibaba.com/"
[1:1:0712/130352.202949:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , , (){trace(type,action)}
[1:1:0712/130352.203047:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130352.203374:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x222cab6029c8, 0x937b88b6950
[1:1:0712/130352.203451:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 500
[1:1:0712/130352.203595:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1014
[1:1:0712/130352.203684:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1014 0x7fc569404070 0x937bde3a060 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 734 0x7fc569404070 0x937b86798e0 
[1:1:0712/130352.219033:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 515, 7fc56bd49881
[1:1:0712/130352.235381:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"133b70722860","ptid":"437 0x7fc57c963bb0 0x937b95993c0 0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/130352.235588:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.alibaba.com/","ptid":"437 0x7fc57c963bb0 0x937b95993c0 0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/130352.235849:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.alibaba.com/"
[1:1:0712/130352.236144:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , , (){window[r]&&(window[r].src="",i()),o.do_tracker_jserror({message:"loadTimeout",error:"",filename:"
[1:1:0712/130352.236247:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130352.257214:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 527, 7fc56bd49881
[1:1:0712/130352.272861:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"133b70722860","ptid":"437 0x7fc57c963bb0 0x937b95993c0 0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/130352.273059:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.alibaba.com/","ptid":"437 0x7fc57c963bb0 0x937b95993c0 0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/130352.273373:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.alibaba.com/"
[1:1:0712/130352.273701:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , , (){window[r]&&(window[r].src="",i()),o.do_tracker_jserror({message:"loadTimeout",error:"",filename:"
[1:1:0712/130352.273866:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130352.277027:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 711, 7fc56bd49881
[1:1:0712/130352.292906:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"133b70722860","ptid":"661 0x7fc569404070 0x937bab66b60 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/130352.293158:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.alibaba.com/","ptid":"661 0x7fc569404070 0x937bab66b60 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/130352.293385:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.alibaba.com/"
[1:1:0712/130352.293693:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , , () {
                window.SCHD_COMS.use(['globalTopBanner'], function () {
                    try
[1:1:0712/130352.293783:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130352.294960:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x222cab6029c8, 0x937b88b6950
[1:1:0712/130352.295077:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 1
[1:1:0712/130352.295251:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1015
[1:1:0712/130352.295373:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1015 0x7fc569404070 0x937bdeb99e0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 711 0x7fc569404070 0x937b8a872e0 
[1:1:0712/130352.312391:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 797, 7fc56bd49881
[1:1:0712/130352.328293:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"133b70722860","ptid":"674 0x7fc56b32c2e0 0x937b9dfdd60 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/130352.328485:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.alibaba.com/","ptid":"674 0x7fc56b32c2e0 0x937b9dfdd60 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/130352.328683:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.alibaba.com/"
[1:1:0712/130352.328933:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , , (){if(this.scrollTimer){clearTimeout(this.scrollTimer)}this._calculator();this._dot()}
[1:1:0712/130352.329026:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:19:0712/130352.481417:WARNING:paced_sender.cc(261)] Elapsed time (16512 ms) longer than expected, limiting to 2000 ms
[1:21:0712/130352.554470:WARNING:paced_sender.cc(261)] Elapsed time (12015 ms) longer than expected, limiting to 2000 ms
[1:1:0712/130352.751391:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x222cab6029c8, 0x937b88b6910
[1:1:0712/130352.751582:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 5000
[1:1:0712/130352.751817:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1024
[1:1:0712/130352.751967:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1024 0x7fc569404070 0x937bf8c4b60 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 797 0x7fc569404070 0x937bb7ee660 
[1:1:0712/130352.777958:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , , document.readyState
[1:1:0712/130352.778126:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130352.779511:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 774, 7fc56bd49881
[1:1:0712/130352.795755:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"133b70722860","ptid":"674 0x7fc56b32c2e0 0x937b9dfdd60 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/130352.795921:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.alibaba.com/","ptid":"674 0x7fc56b32c2e0 0x937b9dfdd60 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/130352.796112:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.alibaba.com/"
[1:1:0712/130352.796363:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , , (){if(n){window.clearTimeout(n)}if(!t){a.get();t=true}}
[1:1:0712/130352.796467:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130352.804883:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 50
[1:1:0712/130352.805155:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://www.alibaba.com/, 1032
[1:1:0712/130352.805281:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1032 0x7fc569404070 0x937bf125ee0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 774 0x7fc569404070 0x937bb33c060 
[20680:20680:0712/130352.812294:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/130352.813497:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x937b8b31a20
[1:1:0712/130352.813630:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[20680:20680:0712/130352.814675:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 4, 4, 
[1:1:0712/130352.822238:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/130352.822430:INFO:render_frame_impl.cc(7019)] 	 [url] = https://www.alibaba.com
[20680:20680:0712/130352.823250:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 6:3_https://www.alibaba.com/
[20680:20680:0712/130352.830699:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[20680:20680:0712/130352.832822:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0712/130352.841331:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 709, 7fc56bd49881
[20680:20692:0712/130352.845473:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 6, 4
[20680:20692:0712/130352.845539:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 6, 4, HandleIncomingMessage, HandleIncomingMessage
[20680:20680:0712/130352.845567:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://i.alicdn.com/
[20680:20680:0712/130352.845606:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:4_https://i.alicdn.com/, https://i.alicdn.com/g/sc/global-components/1.0.0/store-proxy.html?iframe_delete=true, 4
[20680:20680:0712/130352.845675:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 6:4_https://i.alicdn.com/, HTTP/1.1 200 status:200 server:Tengine content-type:text/html content-length:3298 date:Fri, 12 Jul 2019 04:51:17 GMT vary:Accept-Encoding vary:Accept-Encoding x-oss-request-id:5D280ACCDC9557EF4231DD9A x-oss-object-type:Normal x-oss-hash-crc64ecma:439327456095308131 x-oss-storage-class:Standard content-md5:maTxakUtjO2GgUl8aX1OqQ== x-oss-server-time:17 cache-control:max-age=2592000,s-maxage=3600 x-source-scheme:https ali-swift-global-savetime:1562905292 via:cache47.l2cm9[65,200-0,M], cache2.l2cm9[66,0], cache2.cn396[0,200-0,H], cache2.cn396[1,0], cache6.l2cn241[0,200-0,H], cache3.l2cn241[3,0], cache10.cn310[0,200-0,H], cache10.cn310[1,0] timing-allow-origin:* timing-allow-origin:*, * eagleid:2dfd119715629070777596026e eagleid:2dfd119715629070777596026e, 7cc1ebd215629076792372548e access-control-allow-origin:* content-encoding:gzip age:602 x-cache:HIT TCP_MEM_HIT dirn:-2:-2 x-swift-savetime:Fri, 12 Jul 2019 04:54:37 GMT x-swift-cachetime:3400 access-control-expose-headers:Via  ,20788, 6
[1:7:0712/130352.848001:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/130352.859502:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"133b70722860","ptid":"661 0x7fc569404070 0x937bab66b60 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/130352.859718:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.alibaba.com/","ptid":"661 0x7fc569404070 0x937bab66b60 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/130352.859986:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.alibaba.com/"
[1:1:0712/130352.860295:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , , (){window[r]&&(window[r].src="",i()),o.do_tracker_jserror({message:"loadTimeout",error:"",filename:"
[1:1:0712/130352.860873:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130352.882004:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 741, 7fc56bd49881
[1:1:0712/130352.898054:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"133b70722860","ptid":"389 0x7fc569404070 0x937b91f99e0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/130352.898221:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.alibaba.com/","ptid":"389 0x7fc569404070 0x937b91f99e0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/130352.898437:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.alibaba.com/"
[1:1:0712/130352.898699:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , , (){window[r]&&(window[r].src="",i()),o.do_tracker_jserror({message:"loadTimeout",error:"",filename:"
[1:1:0712/130352.898797:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:19:0712/130352.981656:WARNING:paced_sender.cc(261)] Elapsed time (17013 ms) longer than expected, limiting to 2000 ms
[1:21:0712/130353.054989:WARNING:paced_sender.cc(261)] Elapsed time (12515 ms) longer than expected, limiting to 2000 ms
[1:1:0712/130353.102598:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 775, 7fc56bd49881
[1:1:0712/130353.118755:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"133b70722860","ptid":"674 0x7fc56b32c2e0 0x937b9dfdd60 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/130353.118922:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.alibaba.com/","ptid":"674 0x7fc56b32c2e0 0x937b9dfdd60 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/130353.119135:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.alibaba.com/"
[1:1:0712/130353.119411:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , , (){f();if(a)a(new Error("Timeout"),null,e)}
[1:1:0712/130353.119513:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130353.122954:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "https://www.alibaba.com/"
[1:1:0712/130353.140647:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "https://www.alibaba.com/"
[20680:20680:0712/130353.143926:INFO:CONSOLE(4)] "Uncaught TypeError: Cannot read property 'map' of undefined", source: https://s.alicdn.com/@g/sc/aisn/0.0.7/??sc-aisn/hashmap.js,sc-aisn/home2019/common.js,sc-aisn/home2019/home.js (4)
[1:1:0712/130353.158749:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 779, 7fc56bd49881
[1:1:0712/130353.175631:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"133b70722860","ptid":"674 0x7fc56b32c2e0 0x937b9dfdd60 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/130353.175856:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.alibaba.com/","ptid":"674 0x7fc56b32c2e0 0x937b9dfdd60 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/130353.176104:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.alibaba.com/"
[1:1:0712/130353.176428:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , , (){f();if(a)a(new Error("Timeout"),null,e)}
[1:1:0712/130353.176530:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130353.209265:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 783, 7fc56bd49881
[1:1:0712/130353.225288:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"133b70722860","ptid":"674 0x7fc56b32c2e0 0x937b9dfdd60 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/130353.225497:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.alibaba.com/","ptid":"674 0x7fc56b32c2e0 0x937b9dfdd60 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/130353.225732:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.alibaba.com/"
[1:1:0712/130353.226066:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , , (){f();if(a)a(new Error("Timeout"),null,e)}
[1:1:0712/130353.226175:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130353.405046:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 885 0x7fc56b32c2e0 0x937bcf13d60 , "https://www.alibaba.com/"
[1:1:0712/130353.406242:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , , __jp74283({"encode":"UTF-8","ret":["SUCCESS::CALL SUCCESS"],"msg":"OK","code":200,"time":13,"data":{
[1:1:0712/130353.406371:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[20680:20680:0712/130353.409961:INFO:CONSOLE(3)] "jsonp timeout", source: https://s.alicdn.com/@g/sc/aisn/0.0.7/??sc-aisn/hashmap.js,sc-aisn/home2019/common.js,sc-aisn/home2019/home.js (3)
[1:1:0712/130353.425766:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 886 0x7fc56b32c2e0 0x937bbf864e0 , "https://www.alibaba.com/"
[1:1:0712/130353.426314:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , , __jp74284({"code":500,"message":"no data "});
[1:1:0712/130353.426437:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[20680:20680:0712/130353.428487:INFO:CONSOLE(3)] "jsonp timeout", source: https://s.alicdn.com/@g/sc/aisn/0.0.7/??sc-aisn/hashmap.js,sc-aisn/home2019/common.js,sc-aisn/home2019/home.js (3)
[1:19:0712/130353.482011:WARNING:paced_sender.cc(261)] Elapsed time (17513 ms) longer than expected, limiting to 2000 ms
[1:21:0712/130353.555211:WARNING:paced_sender.cc(261)] Elapsed time (13016 ms) longer than expected, limiting to 2000 ms
[1:1:0712/130353.580484:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 891 0x7fc56b32c2e0 0x937bdf29660 , "https://www.alibaba.com/"
[1:1:0712/130353.581215:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , , __jp74285({"code":200,"data":{"nicheVoList":[{"materialVoList":[{"extendMap":{"tracelog":"20190711_I
[1:1:0712/130353.581324:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[20680:20680:0712/130353.583189:INFO:CONSOLE(3)] "jsonp timeout", source: https://s.alicdn.com/@g/sc/aisn/0.0.7/??sc-aisn/hashmap.js,sc-aisn/home2019/common.js,sc-aisn/home2019/home.js (3)
[1:1:0712/130353.598949:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 892 0x7fc56b32c2e0 0x937b88c05e0 , "https://www.alibaba.com/"
[1:1:0712/130353.599609:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , , __jp74290({"code":200,"message":"success"});
[1:1:0712/130353.599751:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130353.973276:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , , (n){a.setLocalDescription(n,function(){},function(){})}
[1:1:0712/130353.973469:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:19:0712/130353.982345:WARNING:paced_sender.cc(261)] Elapsed time (18013 ms) longer than expected, limiting to 2000 ms
[1:21:0712/130354.055357:WARNING:paced_sender.cc(261)] Elapsed time (13516 ms) longer than expected, limiting to 2000 ms
[1:1:0712/130354.062879:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , n.observe.entryTypes, (t){if("function"==typeof t.getEntries){for(var n=t.getEntries(),r=0;r<n.length;r++){var o=n[r]||{},
[1:1:0712/130354.063044:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130354.119384:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x222cab6029c8, 0x937b88b6a78
[1:1:0712/130354.119544:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 5000
[1:1:0712/130354.119772:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1101
[1:1:0712/130354.119904:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1101 0x7fc569404070 0x937b9ffc660 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 916 0x7fc569404070 0x937be4e68e0 
[1:1:0712/130354.171230:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x222cab6029c8, 0x937b88b6a78
[1:1:0712/130354.171502:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 5000
[1:1:0712/130354.171737:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1109
[1:1:0712/130354.171893:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1109 0x7fc569404070 0x937bdeabce0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 916 0x7fc569404070 0x937be4e68e0 
[1:1:0712/130354.222282:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x222cab6029c8, 0x937b88b6a78
[1:1:0712/130354.222475:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 5000
[1:1:0712/130354.222702:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1117
[1:1:0712/130354.222867:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1117 0x7fc569404070 0x937bf35f9e0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 916 0x7fc569404070 0x937be4e68e0 
[1:1:0712/130354.272666:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x222cab6029c8, 0x937b88b6a78
[1:1:0712/130354.272847:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 5000
[1:1:0712/130354.272993:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1125
[1:1:0712/130354.273117:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1125 0x7fc569404070 0x937bdeba4e0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 916 0x7fc569404070 0x937be4e68e0 
[1:1:0712/130354.323593:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x222cab6029c8, 0x937b88b6a78
[1:1:0712/130354.323776:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 5000
[1:1:0712/130354.323985:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1133
[1:1:0712/130354.324131:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1133 0x7fc569404070 0x937bf166160 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 916 0x7fc569404070 0x937be4e68e0 
[1:1:0712/130354.373519:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x222cab6029c8, 0x937b88b6a78
[1:1:0712/130354.373691:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 5000
[1:1:0712/130354.374328:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1141
[1:1:0712/130354.374518:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1141 0x7fc569404070 0x937bdc8cf60 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 916 0x7fc569404070 0x937be4e68e0 
[1:1:0712/130354.424347:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x222cab6029c8, 0x937b88b6a78
[1:1:0712/130354.424519:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 5000
[1:1:0712/130354.424700:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1149
[1:1:0712/130354.424812:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1149 0x7fc569404070 0x937bfe58960 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 916 0x7fc569404070 0x937be4e68e0 
[1:1:0712/130354.475035:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x222cab6029c8, 0x937b88b6a78
[1:1:0712/130354.475241:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 5000
[1:1:0712/130354.475472:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1157
[1:1:0712/130354.475623:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1157 0x7fc569404070 0x937be979d60 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 916 0x7fc569404070 0x937be4e68e0 
[1:19:0712/130354.482728:WARNING:paced_sender.cc(261)] Elapsed time (18514 ms) longer than expected, limiting to 2000 ms
[1:1:0712/130354.525075:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x222cab6029c8, 0x937b88b6a78
[1:1:0712/130354.525253:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 5000
[1:1:0712/130354.525473:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1165
[1:1:0712/130354.525644:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1165 0x7fc569404070 0x937bcf13d60 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 916 0x7fc569404070 0x937be4e68e0 
[1:21:0712/130354.555388:WARNING:paced_sender.cc(261)] Elapsed time (14016 ms) longer than expected, limiting to 2000 ms
[1:1:0712/130354.576504:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x222cab6029c8, 0x937b88b6a78
[1:1:0712/130354.576679:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 5000
[1:1:0712/130354.576869:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1173
[1:1:0712/130354.576968:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1173 0x7fc569404070 0x937bf9748e0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 916 0x7fc569404070 0x937be4e68e0 
[1:1:0712/130354.626924:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x222cab6029c8, 0x937b88b6a78
[1:1:0712/130354.627076:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 5000
[1:1:0712/130354.627273:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1181
[1:1:0712/130354.627367:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1181 0x7fc569404070 0x937bfa84260 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 916 0x7fc569404070 0x937be4e68e0 
[1:1:0712/130354.676812:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x222cab6029c8, 0x937b88b6a78
[1:1:0712/130354.676987:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 5000
[1:1:0712/130354.677170:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1189
[1:1:0712/130354.677343:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1189 0x7fc569404070 0x937be097960 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 916 0x7fc569404070 0x937be4e68e0 
[1:1:0712/130354.729985:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x222cab6029c8, 0x937b88b6a78
[1:1:0712/130354.730165:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 5000
[1:1:0712/130354.730366:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1197
[1:1:0712/130354.730516:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1197 0x7fc569404070 0x937ba2901e0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 916 0x7fc569404070 0x937be4e68e0 
[1:1:0712/130354.781661:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x222cab6029c8, 0x937b88b6a78
[1:1:0712/130354.781868:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 5000
[1:1:0712/130354.782126:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1205
[1:1:0712/130354.782278:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1205 0x7fc569404070 0x937b8c3fae0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 916 0x7fc569404070 0x937be4e68e0 
[1:1:0712/130354.894773:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://www.alibaba.com/, 846, 7fc56bd498db
[1:1:0712/130354.917081:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"133b70722860","ptid":"674 0x7fc56b32c2e0 0x937b9dfdd60 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/130354.917271:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.alibaba.com/","ptid":"674 0x7fc56b32c2e0 0x937b9dfdd60 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/130354.917498:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://www.alibaba.com/, 1238
[1:1:0712/130354.917594:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1238 0x7fc569404070 0x937bf28efe0 , 6:3_https://www.alibaba.com/, 0, , 846 0x7fc569404070 0x937bdf2f160 
[1:1:0712/130354.917808:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.alibaba.com/"
[1:1:0712/130354.918122:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , , (){var e=i("[data-goldexpokey]");e.each(function(e,t){var n=i(t),a=n.data("goldexpokey"),r=n.data("g
[1:1:0712/130354.918239:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130354.963790:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x222cab6029c8, 0x937b88b6950
[1:1:0712/130354.963982:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 5000
[1:1:0712/130354.964185:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1246
[1:1:0712/130354.964349:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1246 0x7fc569404070 0x937bef6eee0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 846 0x7fc569404070 0x937bdf2f160 
[1:19:0712/130354.982915:WARNING:paced_sender.cc(261)] Elapsed time (19014 ms) longer than expected, limiting to 2000 ms
[1:1:0712/130355.008154:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x222cab6029c8, 0x937b88b6950
[1:1:0712/130355.008346:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 5000
[1:1:0712/130355.008518:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1252
[1:1:0712/130355.008644:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1252 0x7fc569404070 0x937bf015460 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 846 0x7fc569404070 0x937bdf2f160 
[1:21:0712/130355.055514:WARNING:paced_sender.cc(261)] Elapsed time (14516 ms) longer than expected, limiting to 2000 ms
[1:1:0712/130355.060915:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 921 0x7fc56b32c2e0 0x937bab38660 , "https://www.alibaba.com/"
[1:1:0712/130355.061720:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , , __jp74286({"ret":["SUCCESS::CALL SUCCESS"],"encode":"UTF-8","msg":"OK","code":200,"time":95,"data":{
[1:1:0712/130355.061879:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130355.102826:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x222cab6029c8, 0x937b88b6980
[1:1:0712/130355.102998:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 5000
[1:1:0712/130355.103205:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1264
[1:1:0712/130355.103363:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1264 0x7fc569404070 0x937bf09c0e0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 921 0x7fc56b32c2e0 0x937bab38660 
[1:1:0712/130355.118842:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x222cab6029c8, 0x937b88b6980
[1:1:0712/130355.119077:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 3000
[1:1:0712/130355.119379:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1265
[1:1:0712/130355.119568:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1265 0x7fc569404070 0x937bf015260 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 921 0x7fc56b32c2e0 0x937bab38660 
[1:1:0712/130355.129677:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3500, 0x222cab6029c8, 0x937b88b6980
[1:1:0712/130355.129850:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 3500
[1:1:0712/130355.130083:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1267
[1:1:0712/130355.130241:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1267 0x7fc569404070 0x937be8244e0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 921 0x7fc56b32c2e0 0x937bab38660 
[1:1:0712/130355.139134:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 4000, 0x222cab6029c8, 0x937b88b6980
[1:1:0712/130355.139278:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 4000
[1:1:0712/130355.139465:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1268
[1:1:0712/130355.139597:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1268 0x7fc569404070 0x937beb00b60 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 921 0x7fc56b32c2e0 0x937bab38660 
[1:1:0712/130355.149858:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 4500, 0x222cab6029c8, 0x937b88b6980
[1:1:0712/130355.150025:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 4500
[1:1:0712/130355.150207:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1269
[1:1:0712/130355.150332:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1269 0x7fc569404070 0x937be72ae60 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 921 0x7fc56b32c2e0 0x937bab38660 
[1:1:0712/130355.160208:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x222cab6029c8, 0x937b88b6980
[1:1:0712/130355.160416:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 5000
[1:1:0712/130355.160633:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1270
[1:1:0712/130355.160772:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1270 0x7fc569404070 0x937be958be0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 921 0x7fc56b32c2e0 0x937bab38660 
[1:1:0712/130355.169990:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5500, 0x222cab6029c8, 0x937b88b6980
[1:1:0712/130355.170197:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 5500
[1:1:0712/130355.170460:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1271
[1:1:0712/130355.170626:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1271 0x7fc569404070 0x937bf28ea60 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 921 0x7fc56b32c2e0 0x937bab38660 
[1:1:0712/130355.386962:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 5000
[1:1:0712/130355.387273:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://www.alibaba.com/, 1272
[1:1:0712/130355.387443:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1272 0x7fc569404070 0x937b9dccee0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 921 0x7fc56b32c2e0 0x937bab38660 
[1:19:0712/130355.484156:WARNING:paced_sender.cc(261)] Elapsed time (19515 ms) longer than expected, limiting to 2000 ms
[1:1:0712/130355.491676:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x222cab6029c8, 0x937b88b6980
[1:1:0712/130355.491849:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 5000
[1:1:0712/130355.492073:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1279
[1:1:0712/130355.492171:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1279 0x7fc569404070 0x937bf5592e0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 921 0x7fc56b32c2e0 0x937bab38660 
[1:21:0712/130355.555803:WARNING:paced_sender.cc(261)] Elapsed time (15016 ms) longer than expected, limiting to 2000 ms
[1:1:0712/130355.767495:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 931 0x7fc56b32c2e0 0x937bda8bb60 , "https://www.alibaba.com/"
[1:1:0712/130355.768281:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , , __jp74287({"ret":["SUCCESS::CALL SUCCESS"],"encode":"UTF-8","msg":"成功执行命令","code":200,"d
[1:1:0712/130355.768419:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130355.829855:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 932 0x7fc56b32c2e0 0x937bab663e0 , "https://www.alibaba.com/"
[1:1:0712/130355.830641:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , , __jp74289({"ret":["SUCCESS::CALL SUCCESS"],"encode":"UTF-8","msg":"成功执行命令","code":200,"d
[1:1:0712/130355.830748:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:19:0712/130355.984375:WARNING:paced_sender.cc(261)] Elapsed time (20015 ms) longer than expected, limiting to 2000 ms
[1:1:0712/130356.013772:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , Ma, (a){e(28,Qs,a)}
[1:1:0712/130356.013930:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:21:0712/130356.055491:WARNING:paced_sender.cc(261)] Elapsed time (15516 ms) longer than expected, limiting to 2000 ms
[1:19:0712/130356.484488:WARNING:paced_sender.cc(261)] Elapsed time (20516 ms) longer than expected, limiting to 2000 ms
[1:21:0712/130356.555847:WARNING:paced_sender.cc(261)] Elapsed time (16016 ms) longer than expected, limiting to 2000 ms
		remove user.15_22b59e9e -> 0
		remove user.16_f851a183 -> 0
[1:19:0712/130356.985010:WARNING:paced_sender.cc(261)] Elapsed time (21016 ms) longer than expected, limiting to 2000 ms
[1:21:0712/130357.057048:WARNING:paced_sender.cc(261)] Elapsed time (16517 ms) longer than expected, limiting to 2000 ms
[1:19:0712/130357.485419:WARNING:paced_sender.cc(261)] Elapsed time (21516 ms) longer than expected, limiting to 2000 ms
[1:21:0712/130357.557304:WARNING:paced_sender.cc(261)] Elapsed time (17018 ms) longer than expected, limiting to 2000 ms
[1:19:0712/130357.985902:WARNING:paced_sender.cc(261)] Elapsed time (22017 ms) longer than expected, limiting to 2000 ms
[1:21:0712/130358.058077:WARNING:paced_sender.cc(261)] Elapsed time (17519 ms) longer than expected, limiting to 2000 ms
[1:19:0712/130358.486872:WARNING:paced_sender.cc(261)] Elapsed time (22518 ms) longer than expected, limiting to 2000 ms
[1:21:0712/130358.559190:WARNING:paced_sender.cc(261)] Elapsed time (18020 ms) longer than expected, limiting to 2000 ms
[1:1:0712/130358.909147:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://www.alibaba.com/, 809, 7fc56bd498db
[1:1:0712/130358.929503:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"133b70722860","ptid":"674 0x7fc56b32c2e0 0x937b9dfdd60 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/130358.929728:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.alibaba.com/","ptid":"674 0x7fc56b32c2e0 0x937b9dfdd60 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/130358.930034:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://www.alibaba.com/, 1305
[1:1:0712/130358.930221:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1305 0x7fc569404070 0x937c210f260 , 6:3_https://www.alibaba.com/, 0, , 809 0x7fc569404070 0x937bb5ec560 
[1:1:0712/130358.930483:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.alibaba.com/"
[1:1:0712/130358.930746:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , , (){if(o.paused)return;o.next()}
[1:1:0712/130358.930837:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130358.934436:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 895, 7fc56bd49881
[1:1:0712/130358.953692:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"133b70722860","ptid":"695 0x7fc56b32c2e0 0x937b8b241e0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/130358.953912:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.alibaba.com/","ptid":"695 0x7fc56b32c2e0 0x937b8b241e0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/130358.954193:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.alibaba.com/"
[1:1:0712/130358.954514:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , , (){r(t,e,n)}
[1:1:0712/130358.954692:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130358.958136:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x222cab6029c8, 0x937b88b6950
[1:1:0712/130358.958308:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 1000
[1:1:0712/130358.958492:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1306
[1:1:0712/130358.958630:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1306 0x7fc569404070 0x937bf28e4e0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 895 0x7fc569404070 0x937bdf2f360 
[1:1:0712/130358.959198:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 942, 7fc56bd49881
[1:1:0712/130358.979423:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"133b70722860","ptid":"748 0x7fc56b32c2e0 0x937ba9c0ee0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/130358.979630:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.alibaba.com/","ptid":"748 0x7fc56b32c2e0 0x937ba9c0ee0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/130358.979874:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.alibaba.com/"
[1:1:0712/130358.980143:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , Ke, (){e(9)}
[1:1:0712/130358.980229:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:19:0712/130358.987202:WARNING:paced_sender.cc(261)] Elapsed time (23018 ms) longer than expected, limiting to 2000 ms
[1:21:0712/130359.059477:WARNING:paced_sender.cc(261)] Elapsed time (18520 ms) longer than expected, limiting to 2000 ms
[1:19:0712/130359.487360:WARNING:paced_sender.cc(261)] Elapsed time (23518 ms) longer than expected, limiting to 2000 ms
[1:21:0712/130359.559762:WARNING:paced_sender.cc(261)] Elapsed time (19020 ms) longer than expected, limiting to 2000 ms
[1:19:0712/130359.987704:WARNING:paced_sender.cc(261)] Elapsed time (24019 ms) longer than expected, limiting to 2000 ms
[1:21:0712/130400.059716:WARNING:paced_sender.cc(261)] Elapsed time (19520 ms) longer than expected, limiting to 2000 ms
[1:19:0712/130400.487421:WARNING:paced_sender.cc(261)] Elapsed time (24518 ms) longer than expected, limiting to 2000 ms
[1:21:0712/130400.560121:WARNING:paced_sender.cc(261)] Elapsed time (20021 ms) longer than expected, limiting to 2000 ms
[1:19:0712/130400.987950:WARNING:paced_sender.cc(261)] Elapsed time (25019 ms) longer than expected, limiting to 2000 ms
[1:21:0712/130401.061349:WARNING:paced_sender.cc(261)] Elapsed time (20522 ms) longer than expected, limiting to 2000 ms
[1:19:0712/130401.488385:WARNING:paced_sender.cc(261)] Elapsed time (25519 ms) longer than expected, limiting to 2000 ms
[1:21:0712/130401.561633:WARNING:paced_sender.cc(261)] Elapsed time (21022 ms) longer than expected, limiting to 2000 ms
[1:1:0712/130401.704351:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 909, 7fc56bd49881
[1:1:0712/130401.722898:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"133b70722860","ptid":"696 0x7fc56b32c2e0 0x937b85b05e0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/130401.723107:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.alibaba.com/","ptid":"696 0x7fc56b32c2e0 0x937b85b05e0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/130401.723365:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.alibaba.com/"
[1:1:0712/130401.723698:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , , (n){try{a.close()}catch(t){}}
[1:1:0712/130401.723843:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130401.855004:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 960, 7fc56bd49881
[1:1:0712/130401.873744:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"133b70722860","ptid":"752 0x7fc56b32c2e0 0x937baa9dc60 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/130401.873992:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.alibaba.com/","ptid":"752 0x7fc56b32c2e0 0x937baa9dc60 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/130401.874281:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.alibaba.com/"
[1:1:0712/130401.874575:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , e, (){D=null;var n=M.ra(!1,null);z.s(n),p.k(g,n)}
[1:1:0712/130401.874694:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130401.944752:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.alibaba.com/"
[1:1:0712/130401.945163:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , d.onload, (){dotBanner(a,b,c)}
[1:1:0712/130401.945284:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130401.983242:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x222cab6029c8, 0x937b88b6a10
[1:1:0712/130401.983433:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 5000
[1:1:0712/130401.983651:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1349
[1:1:0712/130401.983829:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1349 0x7fc569404070 0x937c2a15d60 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 965 0x7fc569404070 0x937bdeb1160 
[1:21:0712/130402.061709:WARNING:paced_sender.cc(261)] Elapsed time (21522 ms) longer than expected, limiting to 2000 ms
[1:1:0712/130402.063064:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 968 0x7fc56b32c2e0 0x937bebee860 , "https://www.alibaba.com/"
[1:1:0712/130402.063908:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , , __jp74288({"ret":["SUCCESS::CALL SUCCESS"],"encode":"UTF-8","msg":"成功执行命令","code":200,"d
[1:1:0712/130402.064048:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130402.147704:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 969 0x7fc56b32c2e0 0x937c0191660 , "https://www.alibaba.com/"
[1:1:0712/130402.148624:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , , __jp74292({"encode":"UTF-8","ret":["SUCCESS::CALL SUCCESS"],"msg":"OK","code":200,"time":140,"data":
[1:1:0712/130402.148775:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130402.210075:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 971 0x7fc56b32c2e0 0x937bf54d2e0 , "https://www.alibaba.com/"
[1:1:0712/130402.212190:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , , __jp74291({"code":200,"data":{"nicheVoList":[{"nicheCode":"ICBU_PC_THEME_BRAND_ZONE","subNicheVoList
[1:1:0712/130402.212322:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:21:0712/130402.562094:WARNING:paced_sender.cc(261)] Elapsed time (22023 ms) longer than expected, limiting to 2000 ms
[1:1:0712/130402.718253:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 972 0x7fc56b32c2e0 0x937be70a1e0 , "https://www.alibaba.com/"
[1:1:0712/130402.718915:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , , __jp74294({"encode":"UTF-8","ret":["SUCCESS::CALL SUCCESS"],"msg":"OK","code":200,"time":3,"data":{}
[1:1:0712/130402.719040:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130402.808252:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 974 0x7fc56b32c2e0 0x937bf09c060 , "https://www.alibaba.com/"
[1:1:0712/130402.812044:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , , __jp74293({"encode":"UTF-8","ret":["SUCCESS::CALL SUCCESS"],"msg":"OK","code":200,"time":161,"data":
[1:1:0712/130402.812218:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:21:0712/130403.062222:WARNING:paced_sender.cc(261)] Elapsed time (22523 ms) longer than expected, limiting to 2000 ms
[1:1:0712/130403.425329:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 975 0x7fc56b32c2e0 0x937bb7af560 , "https://www.alibaba.com/"
[1:1:0712/130403.426250:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , , (function(){var e=function(){var e={},o={exports:e};window.jsonpFooterCallback=function(e){if(e&&e.c
[1:1:0712/130403.426688:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130403.439229:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.alibaba.com/"
[1:1:0712/130403.507650:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 977 0x7fc56b32c2e0 0x937bb74a260 , "https://www.alibaba.com/"
[1:1:0712/130403.510212:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , ,  mtopjsonp1({"api":"mtop.alibaba.intl.localization.getmullangquantityunits","data":{"result":[{"quan
[1:1:0712/130403.510385:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:21:0712/130403.562478:WARNING:paced_sender.cc(261)] Elapsed time (23023 ms) longer than expected, limiting to 2000 ms
[1:21:0712/130404.062625:WARNING:paced_sender.cc(261)] Elapsed time (23523 ms) longer than expected, limiting to 2000 ms
[1:1:0712/130404.111575:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 978 0x7fc56b32c2e0 0x937be726960 , "https://www.alibaba.com/"
[1:1:0712/130404.127576:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , , (function(){var e=function(){var e={},t={exports:e};var n={};var r={};var i;o();function o(){var e=d
[1:1:0712/130404.127785:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130404.397999:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x222cab6029c8, 0x937b88b69a8
[1:1:0712/130404.398204:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 0
[1:1:0712/130404.398436:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1434
[1:1:0712/130404.398629:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1434 0x7fc569404070 0x937c2fa0660 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 978 0x7fc56b32c2e0 0x937be726960 
[1:1:0712/130404.519060:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.alibaba.com/"
[1:1:0712/130404.520129:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x222cab6029c8, 0x937b88b6a10
[1:1:0712/130404.520286:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 1
[1:1:0712/130404.520526:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1441
[1:1:0712/130404.520678:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1441 0x7fc569404070 0x937c34a4b60 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 978 0x7fc56b32c2e0 0x937be726960 
[1:1:0712/130404.557322:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x222cab6029c8, 0x937b88b6a10
[1:1:0712/130404.557485:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 5000
[1:1:0712/130404.557703:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1447
[1:1:0712/130404.557855:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1447 0x7fc569404070 0x937b8df9a60 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 978 0x7fc56b32c2e0 0x937be726960 
[1:21:0712/130404.562958:WARNING:paced_sender.cc(261)] Elapsed time (24023 ms) longer than expected, limiting to 2000 ms
[1:1:0712/130404.611888:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 980 0x7fc56b32c2e0 0x937be4f8f60 , "https://www.alibaba.com/"
[1:1:0712/130404.612477:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , , /**/GDPR_NOTICE_GET_INFO_FUN_1562907830498({"code":200,"data":{"needShow":false,"gdprNotice":"We use
[1:1:0712/130404.612560:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130404.659122:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 981 0x7fc56b32c2e0 0x937bf0ea0e0 , "https://www.alibaba.com/"
[1:1:0712/130404.674413:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , , !function(){var t="client/index.js",e=new Function("return this")();!function(t){var e={};function n
[1:1:0712/130404.674563:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130404.872636:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 50, 0x222cab6029c8, 0x937b88b69a8
[1:1:0712/130404.872786:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 50
[1:1:0712/130404.872956:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1454
[1:1:0712/130404.873061:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1454 0x7fc569404070 0x937c2f933e0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 981 0x7fc56b32c2e0 0x937bf0ea0e0 
[1:1:0712/130404.889125:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1e942a4347a8
[1:1:0712/130404.889544:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 50, 0x222cab6029c8, 0x937b88b69a8
[1:1:0712/130404.889671:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 50
[1:1:0712/130404.889875:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1455
[1:1:0712/130404.890012:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1455 0x7fc569404070 0x937c3767d60 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 981 0x7fc56b32c2e0 0x937bf0ea0e0 
[1:1:0712/130404.977855:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.alibaba.com/"
[1:1:0712/130404.979977:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x222cab6029c8, 0x937b88b6a10
[1:1:0712/130404.980137:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 500
[1:1:0712/130404.980375:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1461
[1:1:0712/130404.980547:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1461 0x7fc569404070 0x937bf0153e0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 981 0x7fc56b32c2e0 0x937bf0ea0e0 
[1:1:0712/130404.980924:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x222cab6029c8, 0x937b88b6a10
[1:1:0712/130404.981022:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 1000
[1:1:0712/130404.981209:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1462
[1:1:0712/130404.981300:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1462 0x7fc569404070 0x937bb74a260 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 981 0x7fc56b32c2e0 0x937bf0ea0e0 
[1:1:0712/130404.981642:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x222cab6029c8, 0x937b88b6a10
[1:1:0712/130404.981742:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 3000
[1:1:0712/130404.981900:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1463
[1:1:0712/130404.982011:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1463 0x7fc569404070 0x937c2f94e60 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 981 0x7fc56b32c2e0 0x937bf0ea0e0 
[1:1:0712/130404.982353:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x222cab6029c8, 0x937b88b6a10
[1:1:0712/130404.982438:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 5000
[1:1:0712/130404.982579:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1464
[1:1:0712/130404.982680:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1464 0x7fc569404070 0x937c37678e0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 981 0x7fc56b32c2e0 0x937bf0ea0e0 
[1:21:0712/130405.063363:WARNING:paced_sender.cc(261)] Elapsed time (24524 ms) longer than expected, limiting to 2000 ms
[1:21:0712/130405.563582:WARNING:paced_sender.cc(261)] Elapsed time (25024 ms) longer than expected, limiting to 2000 ms
[1:1:0712/130405.844873:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1015, 7fc56bd49881
[1:1:0712/130405.866914:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"133b70722860","ptid":"711 0x7fc569404070 0x937b8a872e0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/130405.867083:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.alibaba.com/","ptid":"711 0x7fc569404070 0x937b8a872e0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/130405.867267:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.alibaba.com/"
[1:1:0712/130405.867550:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , , (){n();o({gmkey:"EXP",gokey:"pos=loadSuccess&val=2&c_name="+g})}
[1:1:0712/130405.867640:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130405.870970:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 2000, 0x222cab6029c8, 0x937b88b6950
[1:1:0712/130405.871070:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 2000
[1:1:0712/130405.871208:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1472
[1:1:0712/130405.871287:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1472 0x7fc569404070 0x937c396fae0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 1015 0x7fc569404070 0x937bdeb99e0 
[1:1:0712/130405.919908:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x222cab6029c8, 0x937b88b6950
[1:1:0712/130405.920105:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 5000
[1:1:0712/130405.920326:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1480
[1:1:0712/130405.920469:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1480 0x7fc569404070 0x937c2efaa60 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 1015 0x7fc569404070 0x937bdeb99e0 
[1:21:0712/130406.064097:WARNING:paced_sender.cc(261)] Elapsed time (25525 ms) longer than expected, limiting to 2000 ms
[1:1:0712/130406.199121:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1013, 7fc56bd49881
[1:1:0712/130406.221793:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"133b70722860","ptid":"730 0x7fc569404070 0x937babad760 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/130406.222019:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.alibaba.com/","ptid":"730 0x7fc569404070 0x937babad760 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/130406.222281:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.alibaba.com/"
[1:1:0712/130406.222547:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , t, (){e++,e>10&&(n=3e3),o(),setTimeout(t,n)}
[1:1:0712/130406.222680:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130406.224123:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x222cab6029c8, 0x937b88b6950
[1:1:0712/130406.224205:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 500
[1:1:0712/130406.224366:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1487
[1:1:0712/130406.224473:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1487 0x7fc569404070 0x937bde3a560 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 1013 0x7fc569404070 0x937bf05c060 
[1:1:0712/130406.225239:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1014, 7fc56bd49881
[1:1:0712/130406.247812:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"133b70722860","ptid":"734 0x7fc569404070 0x937b86798e0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/130406.247990:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.alibaba.com/","ptid":"734 0x7fc569404070 0x937b86798e0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/130406.248182:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.alibaba.com/"
[1:1:0712/130406.248436:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , , (){trace(type,action)}
[1:1:0712/130406.248534:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130406.248851:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x222cab6029c8, 0x937b88b6950
[1:1:0712/130406.248931:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 500
[1:1:0712/130406.249092:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1488
[1:1:0712/130406.249182:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1488 0x7fc569404070 0x937c3977860 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 1014 0x7fc569404070 0x937bde3a060 
[1:1:0712/130406.316072:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , , document.readyState
[1:1:0712/130406.316226:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:21:0712/130406.564422:WARNING:paced_sender.cc(261)] Elapsed time (26025 ms) longer than expected, limiting to 2000 ms
[1:1:0712/130406.616740:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 6:4_https://i.alicdn.com/
[1:1:0712/130406.672371:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "https://www.alibaba.com/"
[1:1:0712/130406.672768:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , n.onerror, (){o.do_tracker_jserror({message:"loadError",error:"",filename:"sendImg"}),i()}
[1:1:0712/130406.672857:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130406.677004:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://www.alibaba.com/, 1032, 7fc56bd498db
[1:1:0712/130406.699611:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"133b70722860","ptid":"774 0x7fc569404070 0x937bb33c060 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/130406.699806:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.alibaba.com/","ptid":"774 0x7fc569404070 0x937bb33c060 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/130406.700050:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://www.alibaba.com/, 1496
[1:1:0712/130406.700172:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1496 0x7fc569404070 0x937c3a24c60 , 6:3_https://www.alibaba.com/, 0, , 1032 0x7fc569404070 0x937bf125ee0 
[1:1:0712/130406.700380:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.alibaba.com/"
[1:1:0712/130406.700733:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , , (){if(n[0]&&n[0].contentWindow&&n[0].Messenger){for(var e=0,t=l.length;e<t;e++){l[e](n)}l.length=0;w
[1:1:0712/130406.700876:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/130406.724104:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "https://www.alibaba.com/"
[1:1:0712/130406.724465:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , n.onerror, (){o.do_tracker_jserror({message:"loadError",error:"",filename:"sendImg"}),i()}
[1:1:0712/130406.724590:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:21:0712/130407.064804:WARNING:paced_sender.cc(261)] Elapsed time (26525 ms) longer than expected, limiting to 2000 ms
[1:1:0712/130407.377760:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1079 0x7fc56b32c2e0 0x937b9d935e0 , "https://www.alibaba.com/"
[1:1:0712/130407.380192:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 133b70722860, , , !function(){function e(e,a){for(var r=3;void 0!==r;){var s=-1&r,c=r>>-(1/0),b=-1&c;switch(s){case 0:
[1:1:0712/130407.380333:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:21:0712/130407.565157:WARNING:paced_sender.cc(261)] Elapsed time (27026 ms) longer than expected, limiting to 2000 ms
[1:21:0712/130408.065490:WARNING:paced_sender.cc(261)] Elapsed time (27526 ms) longer than expected, limiting to 2000 ms
[1:21:0712/130408.565921:WARNING:paced_sender.cc(261)] Elapsed time (28026 ms) longer than expected, limiting to 2000 ms
[1:1:0712/130408.575205:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x222cab6029c8, 0x937b88b6948
[1:1:0712/130408.575345:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 5000
[1:1:0712/130408.575572:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1519
[1:1:0712/130408.575727:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1519 0x7fc569404070 0x937bf18aa60 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 1079 0x7fc56b32c2e0 0x937b9d935e0 
[1:21:0712/130409.066473:WARNING:paced_sender.cc(261)] Elapsed time (28527 ms) longer than expected, limiting to 2000 ms
[1:21:0712/130409.566942:WARNING:paced_sender.cc(261)] Elapsed time (29027 ms) longer than expected, limiting to 2000 ms
[1:21:0712/130410.067272:WARNING:paced_sender.cc(261)] Elapsed time (29528 ms) longer than expected, limiting to 2000 ms
[1:21:0712/130410.567946:WARNING:paced_sender.cc(261)] Elapsed time (30028 ms) longer than expected, limiting to 2000 ms
[1:23:0712/130410.595682:WARNING:paced_sender.cc(261)] Elapsed time (2004 ms) longer than expected, limiting to 2000 ms
[1:21:0712/130411.068294:WARNING:paced_sender.cc(261)] Elapsed time (30529 ms) longer than expected, limiting to 2000 ms
[1:23:0712/130411.095976:WARNING:paced_sender.cc(261)] Elapsed time (2505 ms) longer than expected, limiting to 2000 ms
[1:21:0712/130411.568545:WARNING:paced_sender.cc(261)] Elapsed time (31029 ms) longer than expected, limiting to 2000 ms
[1:23:0712/130411.596283:WARNING:paced_sender.cc(261)] Elapsed time (3005 ms) longer than expected, limiting to 2000 ms
[1:21:0712/130412.068905:WARNING:paced_sender.cc(261)] Elapsed time (31529 ms) longer than expected, limiting to 2000 ms
[1:23:0712/130412.096610:WARNING:paced_sender.cc(261)] Elapsed time (3505 ms) longer than expected, limiting to 2000 ms
[1:21:0712/130412.569254:WARNING:paced_sender.cc(261)] Elapsed time (32030 ms) longer than expected, limiting to 2000 ms
[1:23:0712/130412.596848:WARNING:paced_sender.cc(261)] Elapsed time (4005 ms) longer than expected, limiting to 2000 ms
[1:21:0712/130413.069677:WARNING:paced_sender.cc(261)] Elapsed time (32530 ms) longer than expected, limiting to 2000 ms
[1:23:0712/130413.097412:WARNING:paced_sender.cc(261)] Elapsed time (4506 ms) longer than expected, limiting to 2000 ms
[1:21:0712/130413.569985:WARNING:paced_sender.cc(261)] Elapsed time (33030 ms) longer than expected, limiting to 2000 ms
[1:23:0712/130413.597831:WARNING:paced_sender.cc(261)] Elapsed time (5006 ms) longer than expected, limiting to 2000 ms
[1:21:0712/130414.070309:WARNING:paced_sender.cc(261)] Elapsed time (33531 ms) longer than expected, limiting to 2000 ms
[1:23:0712/130414.098295:WARNING:paced_sender.cc(261)] Elapsed time (5507 ms) longer than expected, limiting to 2000 ms
[1:21:0712/130414.570489:WARNING:paced_sender.cc(261)] Elapsed time (34031 ms) longer than expected, limiting to 2000 ms
[1:23:0712/130414.598555:WARNING:paced_sender.cc(261)] Elapsed time (6007 ms) longer than expected, limiting to 2000 ms
[1:21:0712/130415.070754:WARNING:paced_sender.cc(261)] Elapsed time (34531 ms) longer than expected, limiting to 2000 ms
[1:23:0712/130415.098788:WARNING:paced_sender.cc(261)] Elapsed time (6507 ms) longer than expected, limiting to 2000 ms
[1:21:0712/130415.571089:WARNING:paced_sender.cc(261)] Elapsed time (35032 ms) longer than expected, limiting to 2000 ms
[1:23:0712/130415.599113:WARNING:paced_sender.cc(261)] Elapsed time (7008 ms) longer than expected, limiting to 2000 ms
[1:21:0712/130416.071360:WARNING:paced_sender.cc(261)] Elapsed time (35532 ms) longer than expected, limiting to 2000 ms
[1:23:0712/130416.099388:WARNING:paced_sender.cc(261)] Elapsed time (7508 ms) longer than expected, limiting to 2000 ms
[1:21:0712/130416.571650:WARNING:paced_sender.cc(261)] Elapsed time (36032 ms) longer than expected, limiting to 2000 ms
[1:23:0712/130416.599715:WARNING:paced_sender.cc(261)] Elapsed time (8008 ms) longer than expected, limiting to 2000 ms
[1:17:0712/130416.842316:WARNING:stunport.cc(403)] Port[0x937bea7e620:data:1:0:local:Net[any:::/0:Unknown]]: StunPort: stun host lookup received error 0
[1:17:0712/130416.925175:WARNING:p2ptransportchannel.cc(714)] Port[0x937be24f6a0:data:1:0:local:Net[any:0.0.0.0/0:Unknown]]: SetOption(5, 0) failed: 0
[1:17:0712/130416.925719:WARNING:p2ptransportchannel.cc(714)] Port[0x937be24ffa0:data:1:0:local:Net[any:::/0:Unknown]]: SetOption(5, 0) failed: 0
[1:21:0712/130417.072009:WARNING:paced_sender.cc(261)] Elapsed time (36532 ms) longer than expected, limiting to 2000 ms
[1:23:0712/130417.099992:WARNING:paced_sender.cc(261)] Elapsed time (8509 ms) longer than expected, limiting to 2000 ms
[1:21:0712/130417.572399:WARNING:paced_sender.cc(261)] Elapsed time (37033 ms) longer than expected, limiting to 2000 ms
[1:23:0712/130417.601146:WARNING:paced_sender.cc(261)] Elapsed time (9010 ms) longer than expected, limiting to 2000 ms
