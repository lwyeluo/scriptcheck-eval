[0712/131845.839690:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/131845.839939:INFO:switcher_clone.cc(787)] backtrace rip is 7fab34a72891
[0712/131846.389347:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/131846.389596:INFO:switcher_clone.cc(787)] backtrace rip is 7f9f25d5a891
[1:1:0712/131846.393393:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/131846.393555:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/131846.396296:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[23054:23054:0712/131847.125606:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/0d21e54e-0711-46f4-ba43-7ae27a66cd6b
[0712/131847.235014:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/131847.235271:INFO:switcher_clone.cc(787)] backtrace rip is 7f84387ea891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[23054:23054:0712/131847.376381:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[23054:23084:0712/131847.376742:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/131847.376861:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/131847.377006:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/131847.377323:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/131847.377429:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/131847.379227:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x342c376e, 1
[1:1:0712/131847.379415:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x12334bb4, 0
[1:1:0712/131847.379482:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x2d50a809, 3
[1:1:0712/131847.379555:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x3b593ad5, 2
[1:1:0712/131847.379623:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffb44b3312 6e372c34 ffffffd53a593b 09ffffffa8502d , 10104, 4
[1:1:0712/131847.380282:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[23054:23084:0712/131847.380375:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�K3n7,4�:Y;	�P-To'
[23054:23084:0712/131847.380413:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �K3n7,4�:Y;	�P-8nTo'
[1:1:0712/131847.380376:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f9f23f940a0, 3
[23054:23084:0712/131847.380555:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[23054:23084:0712/131847.380589:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 23100, 4, b44b3312 6e372c34 d53a593b 09a8502d 
[1:1:0712/131847.380531:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f9f24120080, 2
[1:1:0712/131847.380914:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f9f0dde2d20, -2
[1:1:0712/131847.388383:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/131847.388814:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3b593ad5
[23086:23086:0712/131847.388996:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=23086
[23101:23101:0712/131847.389336:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=23101
[1:1:0712/131847.389277:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3b593ad5
[1:1:0712/131847.390063:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3b593ad5
[1:1:0712/131847.390613:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3b593ad5
[1:1:0712/131847.390710:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3b593ad5
[1:1:0712/131847.390807:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3b593ad5
[1:1:0712/131847.390897:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3b593ad5
[1:1:0712/131847.391145:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3b593ad5
[1:1:0712/131847.391286:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f9f25d5a7ba
[1:1:0712/131847.391358:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f9f25d51def, 7f9f25d5a77a, 7f9f25d5c0cf
[1:1:0712/131847.393060:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3b593ad5
[1:1:0712/131847.393233:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3b593ad5
[1:1:0712/131847.393524:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3b593ad5
[1:1:0712/131847.394299:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3b593ad5
[1:1:0712/131847.394400:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3b593ad5
[1:1:0712/131847.394493:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3b593ad5
[1:1:0712/131847.394583:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3b593ad5
[1:1:0712/131847.395075:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3b593ad5
[1:1:0712/131847.395238:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f9f25d5a7ba
[1:1:0712/131847.395309:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f9f25d51def, 7f9f25d5a77a, 7f9f25d5c0cf
[1:1:0712/131847.397982:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/131847.398168:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/131847.398250:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe07a7fba8, 0x7ffe07a7fb28)
[1:1:0712/131847.404631:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/131847.407332:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[23054:23054:0712/131847.819621:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[23054:23054:0712/131847.820447:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0712/131847.828238:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x1b9df0d63220
[1:1:0712/131847.828390:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[23054:23054:0712/131847.830287:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[23054:23054:0712/131847.830341:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[23054:23054:0712/131847.830417:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,23100, 4
[23054:23066:0712/131847.830740:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[23054:23066:0712/131847.830788:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[1:7:0712/131847.831406:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[23054:23078:0712/131847.904558:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/131848.106760:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0712/131848.778395:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/131848.779991:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[23054:23054:0712/131848.830226:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[23054:23054:0712/131848.830297:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/131849.203198:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/131849.265140:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1012ac5a1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/131849.265320:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/131849.270777:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1012ac5a1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/131849.270908:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/131849.322977:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/131849.323114:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/131849.457635:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 358, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/131849.460087:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1012ac5a1f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/131849.460222:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/131849.471941:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 359, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/131849.475155:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1012ac5a1f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/131849.475330:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/131849.479295:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[23054:23054:0712/131849.479968:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/131849.481140:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x1b9df0d61e20
[1:1:0712/131849.481995:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[23054:23054:0712/131849.482460:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[23054:23054:0712/131849.494658:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[23054:23054:0712/131849.494742:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/131849.514333:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/131849.802070:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 418 0x7f9f0f9bd2e0 0x1b9df0fe7260 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/131849.802705:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1012ac5a1f78, , , var configData = {"googleBaseUrl":"https://www.google.com.hk/","isAccessibleBrowser":false,"isGoogle
[1:1:0712/131849.802844:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/131849.803395:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/131849.829326:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x1b9df0d62820
[1:1:0712/131849.829467:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[23054:23054:0712/131849.831508:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[23054:23054:0712/131849.833842:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/131849.836168:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/131849.836569:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[23054:23054:0712/131849.839008:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[23054:23054:0712/131849.843384:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[23054:23054:0712/131849.843794:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[23054:23066:0712/131849.848553:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[23054:23066:0712/131849.848608:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[23054:23054:0712/131849.848629:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[23054:23054:0712/131849.848669:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[23054:23054:0712/131849.848732:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,23100, 4
[1:7:0712/131849.852982:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/131850.089907:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/131850.234547:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 467 0x7f9f0f9bd2e0 0x1b9df10f7460 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/131850.235213:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1012ac5a1f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/131850.235739:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/131850.236132:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[23054:23054:0712/131850.375025:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[23054:23054:0712/131850.375151:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/131850.384028:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/131850.519967:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/131850.721043:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/131850.721215:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[23054:23054:0712/131850.749151:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[23054:23084:0712/131850.749427:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/131850.749552:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/131850.749695:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/131850.749884:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/131850.749963:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/131850.752141:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x292e46ef, 1
[1:1:0712/131850.752391:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x2d55b4b1, 0
[1:1:0712/131850.752682:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x1782c6d9, 3
[1:1:0712/131850.752809:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x277d1c9c, 2
[1:1:0712/131850.752896:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffb1ffffffb4552d ffffffef462e29 ffffff9c1c7d27 ffffffd9ffffffc6ffffff8217 , 10104, 5
[1:1:0712/131850.753654:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[23054:23084:0712/131850.753854:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING��U-�F.)�}'�ƂVWo'
[23054:23084:0712/131850.753891:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ��U-�F.)�}'�Ƃ�VWo'
[1:1:0712/131850.753857:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f9f23f940a0, 3
[23054:23084:0712/131850.754026:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 23149, 5, b1b4552d ef462e29 9c1c7d27 d9c68217 
[1:1:0712/131850.754006:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f9f24120080, 2
[1:1:0712/131850.754300:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f9f0dde2d20, -2
[1:1:0712/131850.763540:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/131850.763718:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 277d1c9c
[1:1:0712/131850.763867:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 277d1c9c
[1:1:0712/131850.764115:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 277d1c9c
[1:1:0712/131850.764606:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 277d1c9c
[1:1:0712/131850.764694:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 277d1c9c
[1:1:0712/131850.764780:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 277d1c9c
[1:1:0712/131850.764858:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 277d1c9c
[1:1:0712/131850.765114:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 277d1c9c
[1:1:0712/131850.765231:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f9f25d5a7ba
[1:1:0712/131850.765294:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f9f25d51def, 7f9f25d5a77a, 7f9f25d5c0cf
[1:1:0712/131850.766963:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 277d1c9c
[1:1:0712/131850.767121:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 277d1c9c
[1:1:0712/131850.767470:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 277d1c9c
[1:1:0712/131850.768250:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 277d1c9c
[1:1:0712/131850.768366:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 277d1c9c
[1:1:0712/131850.768468:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 277d1c9c
[1:1:0712/131850.768568:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 277d1c9c
[1:1:0712/131850.769088:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 277d1c9c
[1:1:0712/131850.769278:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f9f25d5a7ba
[1:1:0712/131850.769375:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f9f25d51def, 7f9f25d5a77a, 7f9f25d5c0cf
[1:1:0712/131850.772015:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/131850.772239:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/131850.772338:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe07a7fba8, 0x7ffe07a7fb28)
[1:1:0712/131850.778583:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/131850.780557:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/131850.861991:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 532, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/131850.863845:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1012ac6ce5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/131850.864105:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/131850.866605:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/131850.866825:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x1b9df0d32220
[1:1:0712/131850.866950:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[23054:23054:0712/131851.582148:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[23054:23054:0712/131851.585353:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[23054:23066:0712/131851.600227:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[23054:23066:0712/131851.600301:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[23054:23054:0712/131851.600444:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://www.fliggy.com/
[23054:23054:0712/131851.600494:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://www.fliggy.com/, https://www.fliggy.com/, 1
[23054:23054:0712/131851.600550:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_https://www.fliggy.com/, HTTP/1.1 200 status:200 server:Tengine content-type:text/html; charset=utf-8 date:Fri, 12 Jul 2019 05:18:51 GMT vary:Accept-Encoding set-cookie:_tb_token_=Q58wUDQejCCuE5e69NUc; path=/; domain=.alitrip.com strict-transport-security:max-age=31536000 strict-transport-security:max-age=31536000 x-download-options:noopen x-content-type-options:nosniff x-xss-protection:1; mode=block x-frame-options:SAMEORIGIN x-readtime:26 content-encoding:gzip eagleeye-traceid:7cc8711e15629087313134801e timing-allow-origin:*, * ali-swift-global-savetime:1562908731 via:cache17.l2cn241[201,200-0,M], cache6.l2cn241[201,0], cache8.cn763[202,200-0,M], cache10.cn763[203,0] x-cache:MISS TCP_MISS dirn:-2:-2 x-swift-savetime:Fri, 12 Jul 2019 05:18:51 GMT x-swift-cachetime:0 eagleid:7cc8711e15629087313134801e  ,23149, 5
[1:7:0712/131851.602753:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/131851.616059:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_https://www.fliggy.com/
[23054:23054:0712/131851.673762:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://www.fliggy.com/, https://www.fliggy.com/, 1
[23054:23054:0712/131851.673823:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://www.fliggy.com/, https://www.fliggy.com
[1:1:0712/131851.684343:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/131851.726752:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/131851.746900:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/131851.747087:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.fliggy.com/"
[1:1:0712/131851.754881:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 132 0x7f9f0da95070 0x1b9df0dfff60 , "https://www.fliggy.com/"
[1:1:0712/131851.756054:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , , 
    try{
      var uniformChannel = {"defaultTTID":{"pc":"seo.000000573","mobile":"seo.000000358"},
[1:1:0712/131851.758155:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131851.759191:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/131851.888413:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/131851.923411:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/131851.954900:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/131852.018760:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/131852.142417:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 188 0x7f9f0da95070 0x1b9df0e485e0 , "https://www.fliggy.com/"
[1:1:0712/131852.143037:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , , 
    window.g_config = {
      assetsServer: "https://g.alicdn.com/",
      appVersion: "0.5.23",
  
[1:1:0712/131852.143184:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131852.144163:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 188 0x7f9f0da95070 0x1b9df0e485e0 , "https://www.fliggy.com/"
[1:1:0712/131852.145103:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x11fb421629c8, 0x1b9df0bb29a0
[1:1:0712/131852.145242:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.fliggy.com/", 500
[1:1:0712/131852.145445:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fliggy.com/, 192
[1:1:0712/131852.145572:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 192 0x7f9f0da95070 0x1b9df0946be0 , 5:3_https://www.fliggy.com/, 1, -5:3_https://www.fliggy.com/, 188 0x7f9f0da95070 0x1b9df0e485e0 
[1:1:0712/131852.160353:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 188 0x7f9f0da95070 0x1b9df0e485e0 , "https://www.fliggy.com/"
[1:1:0712/131852.167882:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 188 0x7f9f0da95070 0x1b9df0e485e0 , "https://www.fliggy.com/"
[1:1:0712/131852.175350:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 188 0x7f9f0da95070 0x1b9df0e485e0 , "https://www.fliggy.com/"
[1:1:0712/131852.178889:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 188 0x7f9f0da95070 0x1b9df0e485e0 , "https://www.fliggy.com/"
[1:1:0712/131852.180388:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 188 0x7f9f0da95070 0x1b9df0e485e0 , "https://www.fliggy.com/"
[1:1:0712/131852.182749:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 188 0x7f9f0da95070 0x1b9df0e485e0 , "https://www.fliggy.com/"
[1:1:0712/131852.203480:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.059844, 330, 1
[1:1:0712/131852.203636:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/131852.441873:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/131852.442025:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.fliggy.com/"
[1:1:0712/131852.553409:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.11136, 2265, 1
[1:1:0712/131852.553586:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/131852.657602:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/131852.657778:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.fliggy.com/"
[1:1:0712/131852.658298:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 259 0x7f9f0da95070 0x1b9df0e545e0 , "https://www.fliggy.com/"
[1:1:0712/131852.659801:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , , 
    window.__INITIAL_STATE__ = {"slider":{"list":[{"mid":19587,"link":"https://hilton.fliggy.com/p/
[1:1:0712/131852.659927:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131852.694715:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 267 0x7f9f0f9bd2e0 0x1b9df0f50a60 , "https://www.fliggy.com/"
[1:1:0712/131852.697358:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , , !function e(t,n,r){function a(i,u){if(!n[i]){if(!t[i]){var s="function"==typeof require&&require;if(
[1:1:0712/131852.697505:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131855.973871:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[3:3:0712/131900.110763:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/131900.278218:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 268 0x7f9f0f9bd2e0 0x1b9df0f25760 , "https://www.fliggy.com/"
[1:1:0712/131900.279680:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , ,  !function(){function e(t,n,r){function i(o,s){if(!n[o]){if(!t[o]){var c="function"==typeof require&
[1:1:0712/131900.279856:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131900.376454:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fliggy.com/, 192, 7f9f103da881
[1:1:0712/131900.381252:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2968d3ec2860","ptid":"188 0x7f9f0da95070 0x1b9df0e485e0 ","rf":"5:3_https://www.fliggy.com/"}
[1:1:0712/131900.381406:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.fliggy.com/","ptid":"188 0x7f9f0da95070 0x1b9df0e485e0 ","rf":"5:3_https://www.fliggy.com/"}
[1:1:0712/131900.381577:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.fliggy.com/"
[1:1:0712/131900.381846:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , , (){
        var showNode = document.getElementById('J_showTelephoneNum');
        var wrapNode = doc
[1:1:0712/131900.381938:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131900.434627:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/131900.663527:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/131900.663707:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131900.835275:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , , highWaterMark =>
new BuiltInCountQueuingStrategy(highWaterMark)
[1:1:0712/131900.835460:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131900.844190:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , SetUpReadableStreamDefaultController.thenPromise, () => {
controller[_readableStreamDefaultControllerBits] |= STARTED;
ReadableStreamDefaultController
[1:1:0712/131900.844357:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131902.070640:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , , document.readyState
[1:1:0712/131902.070814:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131902.122054:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 405 0x7f9f0ddfdbd0 0x1b9df0fc6758 , "https://www.fliggy.com/"
[1:1:0712/131902.128796:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , , /*
Copyright 2014, KISSY v1.4.14
MIT Licensed
build time: Dec 10 15:06
*/
var KISSY=function(a){func
[1:1:0712/131902.128973:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
		remove user.e_cb473ee4 -> 0
[1:1:0712/131902.461573:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x11fb421629c8, 0x1b9df0bb2960
[1:1:0712/131902.461754:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.fliggy.com/", 0
[1:1:0712/131902.461977:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fliggy.com/, 459
[1:1:0712/131902.462119:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 459 0x7f9f0da95070 0x1b9df1dface0 , 5:3_https://www.fliggy.com/, 1, -5:3_https://www.fliggy.com/, 405 0x7f9f0ddfdbd0 0x1b9df0fc6758 
[1:1:0712/131902.463854:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 405 0x7f9f0ddfdbd0 0x1b9df0fc6758 , "https://www.fliggy.com/"
[1:1:0712/131902.477327:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0140922, 243, 1
[1:1:0712/131902.477474:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/131903.307340:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , , document.readyState
[1:1:0712/131903.307519:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131903.319862:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , , (e){t(e)}
[1:1:0712/131903.320045:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131903.323821:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 447 0x7f9f20ff4bb0 0x1b9df14044e0 0 , "https://www.fliggy.com/"
[1:1:0712/131903.489929:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1500, 0x11fb421629c8, 0x1b9df0bb2d88
[1:1:0712/131903.490164:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.fliggy.com/", 1500
[1:1:0712/131903.490391:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fliggy.com/, 501
[1:1:0712/131903.490570:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 501 0x7f9f0da95070 0x1b9df0f45660 , 5:3_https://www.fliggy.com/, 1, -5:3_https://www.fliggy.com/, 447 0x7f9f20ff4bb0 0x1b9df14044e0 0 
[1:1:0712/131903.491078:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 2000, 0x11fb421629c8, 0x1b9df0bb2d88
[1:1:0712/131903.491201:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.fliggy.com/", 2000
[1:1:0712/131903.491365:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fliggy.com/, 502
[1:1:0712/131903.491464:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 502 0x7f9f0da95070 0x1b9df1483fe0 , 5:3_https://www.fliggy.com/, 1, -5:3_https://www.fliggy.com/, 447 0x7f9f20ff4bb0 0x1b9df14044e0 0 
[1:1:0712/131903.629058:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://www.fliggy.com/"
[1:1:0712/131903.629782:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , d.port1.onmessage, (){m=k;d.port1.onmessage=e;e()}
[1:1:0712/131903.629945:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131903.630330:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x3c0fc78c2050
[1:1:0712/131904.153867:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/131904.154112:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.fliggy.com/"
[1:1:0712/131904.154608:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 471 0x7f9f0da95070 0x1b9df1920ae0 , "https://www.fliggy.com/"
[1:1:0712/131904.155179:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , , 
    KISSY.config({combine:true});
  
[1:1:0712/131904.155307:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131904.157990:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 471 0x7f9f0da95070 0x1b9df1920ae0 , "https://www.fliggy.com/"
[1:1:0712/131904.227722:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fliggy.com/, 459, 7f9f103da881
[1:1:0712/131904.236088:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2968d3ec2860","ptid":"405 0x7f9f0ddfdbd0 0x1b9df0fc6758 ","rf":"5:3_https://www.fliggy.com/"}
[1:1:0712/131904.236248:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.fliggy.com/","ptid":"405 0x7f9f0ddfdbd0 0x1b9df0fc6758 ","rf":"5:3_https://www.fliggy.com/"}
[1:1:0712/131904.236441:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.fliggy.com/"
[1:1:0712/131904.236695:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , e, (){for(var a=0,b;b=h[a++];)try{b()}catch(d){setTimeout(function(){throw d;},0)}1<a&&(h=[]);l=0}
[1:1:0712/131904.236791:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131905.704901:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , , document.readyState
[1:1:0712/131905.705103:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131906.306423:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://www.fliggy.com/"
[1:1:0712/131906.306877:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , e, (){for(var a=0,b;b=h[a++];)try{b()}catch(d){setTimeout(function(){throw d;},0)}1<a&&(h=[]);l=0}
[1:1:0712/131906.307042:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131906.472759:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fliggy.com/, 501, 7f9f103da881
[1:1:0712/131906.482938:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2968d3ec2860","ptid":"447 0x7f9f20ff4bb0 0x1b9df14044e0 0 ","rf":"5:3_https://www.fliggy.com/"}
[1:1:0712/131906.483101:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.fliggy.com/","ptid":"447 0x7f9f20ff4bb0 0x1b9df14044e0 0 ","rf":"5:3_https://www.fliggy.com/"}
[1:1:0712/131906.483323:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.fliggy.com/"
[1:1:0712/131906.483693:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , , (){n.requesting=!1,n.setStag(-2),e()}
[1:1:0712/131906.483841:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131906.489733:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x11fb421629c8, 0x1b9df0bb2950
[1:1:0712/131906.489867:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.fliggy.com/", 1000
[1:1:0712/131906.490031:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fliggy.com/, 619
[1:1:0712/131906.490138:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 619 0x7f9f0da95070 0x1b9df3278660 , 5:3_https://www.fliggy.com/, 1, -5:3_https://www.fliggy.com/, 501 0x7f9f0da95070 0x1b9df0f45660 
[1:1:0712/131906.534157:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x11fb421629c8, 0x1b9df0bb2950
[1:1:0712/131906.534351:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.fliggy.com/", 500
[1:1:0712/131906.534551:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fliggy.com/, 621
[1:1:0712/131906.534686:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 621 0x7f9f0da95070 0x1b9df34599e0 , 5:3_https://www.fliggy.com/, 1, -5:3_https://www.fliggy.com/, 501 0x7f9f0da95070 0x1b9df0f45660 
[1:1:0712/131906.600334:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x11fb421629c8, 0x1b9df0bb2950
[1:1:0712/131906.600592:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.fliggy.com/", 5000
[1:1:0712/131906.600825:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fliggy.com/, 631
[1:1:0712/131906.600956:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 631 0x7f9f0da95070 0x1b9df373e860 , 5:3_https://www.fliggy.com/, 1, -5:3_https://www.fliggy.com/, 501 0x7f9f0da95070 0x1b9df0f45660 
[1:1:0712/131906.608946:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0x11fb421629c8, 0x1b9df0bb2950
[1:1:0712/131906.609117:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.fliggy.com/", 10
[1:1:0712/131906.609339:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fliggy.com/, 632
[1:1:0712/131906.609498:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 632 0x7f9f0da95070 0x1b9df0eb8fe0 , 5:3_https://www.fliggy.com/, 1, -5:3_https://www.fliggy.com/, 501 0x7f9f0da95070 0x1b9df0f45660 
[1:1:0712/131906.722349:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , , document.readyState
[1:1:0712/131906.722548:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131906.776398:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 568 0x7f9f0f9bd2e0 0x1b9df1c6e360 , "https://www.fliggy.com/"
[1:1:0712/131906.777017:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , , window.goldlog=(window.goldlog||{});goldlog.Etag="x72HFb6WgX0CAXlFE14b37jj";goldlog.stag=1;
[1:1:0712/131906.777175:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131906.777537:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.fliggy.com/"
[1:1:0712/131906.808133:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 569 0x7f9f0f9bd2e0 0x1b9df14847e0 , "https://www.fliggy.com/"
[1:1:0712/131906.809621:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , , /*
Copyright 2014, KISSY v1.49.10
MIT Licensed
build time: Dec 10 15:04
*/
KISSY.add("node/base",["d
[1:1:0712/131906.809789:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131906.817657:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.fliggy.com/"
[1:1:0712/131906.843008:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 571 0x7f9f0f9bd2e0 0x1b9df3664de0 , "https://www.fliggy.com/"
[1:1:0712/131906.847771:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , , /*
Copyright 2014, KISSY v1.49.10
MIT Licensed
build time: Dec 10 14:51
*/
KISSY.add("dom/base/api",
[1:1:0712/131906.847953:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131906.860835:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/131906.867049:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.fliggy.com/"
[1:1:0712/131906.880160:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 572 0x7f9f0f9bd2e0 0x1b9df3744360 , "https://www.fliggy.com/"
[1:1:0712/131906.882747:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , , /*
Copyright 2014, KISSY v1.49.10
MIT Licensed
build time: Dec 10 15:02
*/
KISSY.add("event/dom/base
[1:1:0712/131906.882882:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131906.900697:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.fliggy.com/"
[1:1:0712/131906.933427:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 574 0x7f9f0f9bd2e0 0x1b9df2625ce0 , "https://www.fliggy.com/"
[1:1:0712/131906.934646:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , , /*
Copyright 2014, KISSY v1.49.10
MIT Licensed
build time: Dec 10 15:02
*/
KISSY.add("event/base/uti
[1:1:0712/131906.934809:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131906.942340:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.fliggy.com/"
[1:1:0712/131906.954285:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 575 0x7f9f0f9bd2e0 0x1b9df32781e0 , "https://www.fliggy.com/"
[1:1:0712/131906.954909:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , , /*
Copyright 2014, KISSY v1.49.10
MIT Licensed
build time: Dec 10 15:02
*/
KISSY.add("event/dom/shak
[1:1:0712/131906.955047:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131906.956510:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.fliggy.com/"
[1:1:0712/131906.989508:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 577 0x7f9f0f9bd2e0 0x1b9df1c6e6e0 , "https://www.fliggy.com/"
[1:1:0712/131906.990175:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , , /*
Copyright 2014, KISSY v1.49.10
MIT Licensed
build time: Dec 10 15:02
*/
KISSY.add("event/dom/focu
[1:1:0712/131906.990297:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131906.991642:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.fliggy.com/"
[1:1:0712/131907.003770:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 578 0x7f9f0f9bd2e0 0x1b9df1e135e0 , "https://www.fliggy.com/"
[1:1:0712/131907.004513:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , , /*
Copyright 2014, KISSY v1.49.10
MIT Licensed
build time: Dec 10 14:46
*/
KISSY.add("anim",["anim/b
[1:1:0712/131907.004633:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131907.006905:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.fliggy.com/"
[1:1:0712/131907.030044:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 580 0x7f9f0f9bd2e0 0x1b9df26252e0 , "https://www.fliggy.com/"
[1:1:0712/131907.031359:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , , /*
Copyright 2014, KISSY v1.49.10
MIT Licensed
build time: Dec 10 14:46
*/
KISSY.add("anim/base/queu
[1:1:0712/131907.031483:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131907.035979:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.fliggy.com/"
[1:1:0712/131907.069185:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 581 0x7f9f0f9bd2e0 0x1b9df27449e0 , "https://www.fliggy.com/"
[1:1:0712/131907.070345:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , , /*
Copyright 2014, KISSY v1.49.10
MIT Licensed
build time: Dec 10 15:04
*/
KISSY.add("promise",[],fu
[1:1:0712/131907.070485:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131907.071948:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.fliggy.com/"
[1:1:0712/131907.096200:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 583 0x7f9f0f9bd2e0 0x1b9df1c6e1e0 , "https://www.fliggy.com/"
[1:1:0712/131907.098391:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , , /*
Copyright 2014, KISSY v1.49.10
MIT Licensed
build time: Dec 10 14:46
*/
KISSY.add("anim/timer/eas
[1:1:0712/131907.098572:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131907.109564:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.fliggy.com/"
[1:1:0712/131907.132924:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 584 0x7f9f0f9bd2e0 0x1b9df261b5e0 , "https://www.fliggy.com/"
[1:1:0712/131907.133925:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , , /*
Copyright 2014, KISSY v1.49.10
MIT Licensed
build time: Dec 10 14:46
*/
KISSY.add("anim/transitio
[1:1:0712/131907.134048:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131907.135578:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.fliggy.com/"
[1:1:0712/131907.159135:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 586 0x7f9f0f9bd2e0 0x1b9df0fca7e0 , "https://www.fliggy.com/"
[1:1:0712/131907.159719:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , , /*
Copyright 2014, KISSY v1.49.10
MIT Licensed
build time: Dec 10 15:03
*/
KISSY.add("event",["event
[1:1:0712/131907.159846:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131907.161235:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.fliggy.com/"
[1:1:0712/131907.173156:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 587 0x7f9f0f9bd2e0 0x1b9df36642e0 , "https://www.fliggy.com/"
[1:1:0712/131907.174290:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , , /*
Copyright 2014, KISSY v1.49.10
MIT Licensed
build time: Dec 10 15:02
*/
KISSY.add("event/custom/o
[1:1:0712/131907.174410:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131907.181530:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.fliggy.com/"
[1:1:0712/131907.955564:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 589 0x7f9f0f9bd2e0 0x1b9df2698a60 , "https://www.fliggy.com/"
[1:1:0712/131907.960111:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , , /*!build time : 2014-08-12 12:54:50 PM*/
KISSY.add("kg/slide/2.0.2/lib/slide-util",function(a){"use 
[1:1:0712/131907.960285:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131907.972019:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.fliggy.com/"
[1:1:0712/131907.987569:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 590 0x7f9f0f9bd2e0 0x1b9df147f7e0 , "https://www.fliggy.com/"
[1:1:0712/131907.993390:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , , /*! pi 2017-07-05 01:29:13 */
KISSY.add("pi/autocomplete/index",function(a,b,c,d,e){return b.extend(
[1:1:0712/131907.993833:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131908.006276:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.fliggy.com/"
[1:1:0712/131908.297902:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.fliggy.com/"
[1:1:0712/131908.298425:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , c, (){var a=o.readyState;if(!a||"loaded"===a||"complete"===a)o.onreadystatechange=o.onload=null,t(0)}
[1:1:0712/131908.298624:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131908.379292:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.fliggy.com/"
[1:1:0712/131908.379709:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , c, (){var a=o.readyState;if(!a||"loaded"===a||"complete"===a)o.onreadystatechange=o.onload=null,t(0)}
[1:1:0712/131908.379871:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131908.586799:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fliggy.com/, 632, 7f9f103da881
[1:1:0712/131908.598366:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2968d3ec2860","ptid":"501 0x7f9f0da95070 0x1b9df0f45660 ","rf":"5:3_https://www.fliggy.com/"}
[1:1:0712/131908.598544:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.fliggy.com/","ptid":"501 0x7f9f0da95070 0x1b9df0f45660 ","rf":"5:3_https://www.fliggy.com/"}
[1:1:0712/131908.598756:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.fliggy.com/"
[1:1:0712/131908.599028:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , , (){n&&"script"==n.tagName.toLowerCase()||r.addScript(p,"","aplus-sufei")}
[1:1:0712/131908.599141:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131908.706111:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 642 0x7f9f0f9bd2e0 0x1b9df1446660 , "https://www.fliggy.com/"
[1:1:0712/131908.713262:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , , /*! Generated by Clam: trip-home */

KISSY.add("trip-home/widgets/searcher/index",function(s,y,t,i,C
[1:1:0712/131908.713416:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131908.723371:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.fliggy.com/"
[1:1:0712/131908.741803:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 643 0x7f9f0f9bd2e0 0x1b9df373ee60 , "https://www.fliggy.com/"
[1:1:0712/131908.753300:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , , /*
Copyright 2014, KISSY v1.49.10
MIT Licensed
build time: Dec 10 14:47
*/
KISSY.add("base",["attrib
[1:1:0712/131908.753467:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131908.814021:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.fliggy.com/"
		remove user.f_aac24a19 -> 0
[1:1:0712/131910.126233:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , , document.readyState
[1:1:0712/131910.126430:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131910.172933:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fliggy.com/, 621, 7f9f103da881
[1:1:0712/131910.183459:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2968d3ec2860","ptid":"501 0x7f9f0da95070 0x1b9df0f45660 ","rf":"5:3_https://www.fliggy.com/"}
[1:1:0712/131910.183657:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.fliggy.com/","ptid":"501 0x7f9f0da95070 0x1b9df0f45660 ","rf":"5:3_https://www.fliggy.com/"}
[1:1:0712/131910.183896:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.fliggy.com/"
[1:1:0712/131910.184228:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , t, (){e++,e>10&&(n=3e3),o(),setTimeout(t,n)}
[1:1:0712/131910.184402:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131910.185840:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x11fb421629c8, 0x1b9df0bb2950
[1:1:0712/131910.185985:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.fliggy.com/", 500
[1:1:0712/131910.186196:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fliggy.com/, 693
[1:1:0712/131910.186351:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 693 0x7f9f0da95070 0x1b9df1c39360 , 5:3_https://www.fliggy.com/, 1, -5:3_https://www.fliggy.com/, 621 0x7f9f0da95070 0x1b9df34599e0 
[1:1:0712/131910.209433:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://www.fliggy.com/"
[1:1:0712/131910.209847:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , e, (){for(var a=0,b;b=h[a++];)try{b()}catch(d){setTimeout(function(){throw d;},0)}1<a&&(h=[]);l=0}
[1:1:0712/131910.210010:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131910.212576:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.fliggy.com/", 40
[1:1:0712/131910.212785:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.fliggy.com/, 695
[1:1:0712/131910.212881:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 695 0x7f9f0da95070 0x1b9df4d36c60 , 5:3_https://www.fliggy.com/, 1, -5:3_https://www.fliggy.com/, 659 0x7f9f24120080 0x1b9df4483740 1 0 0x1b9df4483758 
[1:1:0712/131914.894759:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "click", "https://www.fliggy.com/"
[1:1:0712/131914.901082:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "click", "https://www.fliggy.com/"
[1:1:0712/131914.910156:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "click", "https://www.fliggy.com/"
[1:1:0712/131914.967251:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fliggy.com/, 619, 7f9f103da881
[1:1:0712/131914.979284:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2968d3ec2860","ptid":"501 0x7f9f0da95070 0x1b9df0f45660 ","rf":"5:3_https://www.fliggy.com/"}
[1:1:0712/131914.979500:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.fliggy.com/","ptid":"501 0x7f9f0da95070 0x1b9df0f45660 ","rf":"5:3_https://www.fliggy.com/"}
[1:1:0712/131914.979758:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.fliggy.com/"
[1:1:0712/131914.980056:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , , (){var e=r.getUrl(t.options.context.etag||{});a.loadScript(e,function(e){e&&"error"!==e.type&&o.setL
[1:1:0712/131914.980209:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131915.190686:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 681 0x7f9f0f9bd2e0 0x1b9df3d3ede0 , "https://www.fliggy.com/"
[1:1:0712/131915.191195:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , , window.goldlog=(window.goldlog||{});goldlog.Etag="x72HFb6WgX0CAXlFE14b37jj";goldlog.stag=1;
[1:1:0712/131915.191335:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131915.191666:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.fliggy.com/"
[1:1:0712/131915.217545:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 682 0x7f9f0f9bd2e0 0x1b9df26c55e0 , "https://www.fliggy.com/"
[1:1:0712/131915.219123:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , , (function(a,e,t,i,o){var n=i.userAgent;var r=e.getElementsByTagName("head")[0];function c(a){var t=e
[1:1:0712/131915.219334:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131915.324941:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , , document.readyState
[1:1:0712/131915.325143:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131915.493317:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.fliggy.com/, 695, 7f9f103da8db
[1:1:0712/131915.505862:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2968d3ec2860","ptid":"659 0x7f9f24120080 0x1b9df4483740 1 0 0x1b9df4483758 ","rf":"5:3_https://www.fliggy.com/"}
[1:1:0712/131915.506083:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.fliggy.com/","ptid":"659 0x7f9f24120080 0x1b9df4483740 1 0 0x1b9df4483758 ","rf":"5:3_https://www.fliggy.com/"}
[1:1:0712/131915.506305:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.fliggy.com/, 742
[1:1:0712/131915.506403:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 742 0x7f9f0da95070 0x1b9df88d98e0 , 5:3_https://www.fliggy.com/, 0, , 695 0x7f9f0da95070 0x1b9df4d36c60 
[1:1:0712/131915.506538:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.fliggy.com/"
[1:1:0712/131915.506783:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , e, (){j.apply(d,b)}
[1:1:0712/131915.506872:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131915.729884:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fliggy.com/, 693, 7f9f103da881
[1:1:0712/131915.742589:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2968d3ec2860","ptid":"621 0x7f9f0da95070 0x1b9df34599e0 ","rf":"5:3_https://www.fliggy.com/"}
[1:1:0712/131915.742831:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.fliggy.com/","ptid":"621 0x7f9f0da95070 0x1b9df34599e0 ","rf":"5:3_https://www.fliggy.com/"}
[1:1:0712/131915.743094:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.fliggy.com/"
[1:1:0712/131915.743422:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , t, (){e++,e>10&&(n=3e3),o(),setTimeout(t,n)}
[1:1:0712/131915.743565:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131915.745114:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x11fb421629c8, 0x1b9df0bb2950
[1:1:0712/131915.745276:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.fliggy.com/", 500
[1:1:0712/131915.745483:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fliggy.com/, 744
[1:1:0712/131915.745593:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 744 0x7f9f0da95070 0x1b9df7f1b860 , 5:3_https://www.fliggy.com/, 1, -5:3_https://www.fliggy.com/, 693 0x7f9f0da95070 0x1b9df1c39360 
[1:1:0712/131915.746031:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fliggy.com/, 631, 7f9f103da881
[1:1:0712/131915.758793:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2968d3ec2860","ptid":"501 0x7f9f0da95070 0x1b9df0f45660 ","rf":"5:3_https://www.fliggy.com/"}
[1:1:0712/131915.758955:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.fliggy.com/","ptid":"501 0x7f9f0da95070 0x1b9df0f45660 ","rf":"5:3_https://www.fliggy.com/"}
[1:1:0712/131915.759154:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.fliggy.com/"
[1:1:0712/131915.759421:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , , (){window[r]&&(window[r].src="",i()),o.do_tracker_jserror({message:"loadTimeout",error:"",filename:"
[1:1:0712/131915.759523:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131915.826165:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 718 0x7f9f0ddfdbd0 0x1b9df8727258 , "https://www.fliggy.com/"
[1:1:0712/131915.839369:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , , !function(t){function e(r){if(n[r])return n[r].exports;var o=n[r]={i:r,l:!1,exports:{}};return t[r].
[1:1:0712/131915.839528:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131918.800225:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x11fb421629c8, 0x1b9df0bb2960
[1:1:0712/131918.800474:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.fliggy.com/", 3000
[1:1:0712/131918.800716:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fliggy.com/, 748
[1:1:0712/131918.800856:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 748 0x7f9f0da95070 0x1b9dfa5899e0 , 5:3_https://www.fliggy.com/, 1, -5:3_https://www.fliggy.com/, 718 0x7f9f0ddfdbd0 0x1b9df8727258 
[1:1:0712/131918.976885:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 718 0x7f9f0ddfdbd0 0x1b9df8727258 , "https://www.fliggy.com/"
[1:1:0712/131918.979915:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x11fb421629c8, 0x1b9df0bb2990
[1:1:0712/131918.980082:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.fliggy.com/", 3000
[1:1:0712/131918.980577:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fliggy.com/, 751
[1:1:0712/131918.980701:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 751 0x7f9f0da95070 0x1b9dfa19c8e0 , 5:3_https://www.fliggy.com/, 1, -5:3_https://www.fliggy.com/, 718 0x7f9f0ddfdbd0 0x1b9df8727258 
[1:1:0712/131918.984048:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://www.fliggy.com/"
[1:1:0712/131918.987344:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://www.fliggy.com/"
[1:1:0712/131919.497352:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , , document.readyState
[1:1:0712/131919.497536:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131919.568362:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "https://www.fliggy.com/"
[1:1:0712/131919.568879:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , n.onerror, (){o.do_tracker_jserror({message:"loadError",error:"",filename:"sendImg"}),i()}
[1:1:0712/131919.569014:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131919.602728:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fliggy.com/, 744, 7f9f103da881
[1:1:0712/131919.615907:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2968d3ec2860","ptid":"693 0x7f9f0da95070 0x1b9df1c39360 ","rf":"5:3_https://www.fliggy.com/"}
[1:1:0712/131919.616112:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.fliggy.com/","ptid":"693 0x7f9f0da95070 0x1b9df1c39360 ","rf":"5:3_https://www.fliggy.com/"}
[1:1:0712/131919.616332:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.fliggy.com/"
[1:1:0712/131919.616654:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , t, (){e++,e>10&&(n=3e3),o(),setTimeout(t,n)}
[1:1:0712/131919.616766:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131919.617232:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x11fb421629c8, 0x1b9df0bb2950
[1:1:0712/131919.617366:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.fliggy.com/", 500
[1:1:0712/131919.617807:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fliggy.com/, 786
[1:1:0712/131919.617931:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 786 0x7f9f0da95070 0x1b9df7ef8660 , 5:3_https://www.fliggy.com/, 1, -5:3_https://www.fliggy.com/, 744 0x7f9f0da95070 0x1b9df7f1b860 
[1:1:0712/131919.873743:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 776 0x7f9f0f9bd2e0 0x1b9df4c9a760 , "https://www.fliggy.com/"
[1:1:0712/131919.878523:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , , !function(n,t,i,r,a,o,e,c,u,f,s,l,m,h,v){var p,d=374,g="isg",y=c,b=!!y.addEventListener,w=u.getEleme
[1:1:0712/131919.878652:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131919.967701:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/131919.967938:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/131919.968889:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:17:0712/131919.971290:ERROR:adm_helpers.cc(73)] Failed to query stereo recording.
[1:1:0712/131919.978230:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x11fb421629c8, 0x1b9df0bb2990
[1:1:0712/131919.978405:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.fliggy.com/", 5000
[1:1:0712/131919.978630:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fliggy.com/, 808
[1:1:0712/131919.978787:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 808 0x7f9f0da95070 0x1b9df08adae0 , 5:3_https://www.fliggy.com/, 1, -5:3_https://www.fliggy.com/, 776 0x7f9f0f9bd2e0 0x1b9df4c9a760 
[1:1:0712/131920.169749:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , , document.readyState
[1:1:0712/131920.169950:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131920.448866:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , , (n){G=n}
[1:1:0712/131920.449273:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131920.592993:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , , (n){a.setLocalDescription(n,function(){},function(){})}
[1:1:0712/131920.593244:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131920.754006:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 819 0x7f9f0f9bd2e0 0x1b9dfaa257e0 , "https://www.fliggy.com/"
[1:1:0712/131920.754793:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , , var userCookie={"_nk_":"","_l_g_":"","ck1":"","tracknick":"","mt":"ci=-1_0","l":"cBIu2GtrqOnrcnNwBOC
[1:1:0712/131920.754985:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131920.755541:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.fliggy.com/"
[1:1:0712/131920.801112:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 2000, 0x11fb421629c8, 0x1b9df0bb2a10
[1:1:0712/131920.802084:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.fliggy.com/", 2000
[1:1:0712/131920.802326:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fliggy.com/, 844
[1:1:0712/131920.802491:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 844 0x7f9f0da95070 0x1b9dfafdd660 , 5:3_https://www.fliggy.com/, 1, -5:3_https://www.fliggy.com/, 819 0x7f9f0f9bd2e0 0x1b9dfaa257e0 
[1:1:0712/131920.877612:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 820 0x7f9f0f9bd2e0 0x1b9df3d2fee0 , "https://www.fliggy.com/"
[1:1:0712/131920.880070:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , , !function(){function e(e,a){for(var r=3;void 0!==r;){var s=-1&r,c=r>>-(1/0),b=-1&c;switch(s){case 0:
[1:1:0712/131920.880264:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:19:0712/131921.999121:WARNING:paced_sender.cc(261)] Elapsed time (2005 ms) longer than expected, limiting to 2000 ms
[1:19:0712/131922.499512:WARNING:paced_sender.cc(261)] Elapsed time (2505 ms) longer than expected, limiting to 2000 ms
[1:1:0712/131922.973447:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x11fb421629c8, 0x1b9df0bb2948
[1:1:0712/131922.973600:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.fliggy.com/", 5000
[1:1:0712/131922.973794:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fliggy.com/, 864
[1:1:0712/131922.973951:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 864 0x7f9f0da95070 0x1b9df8ada1e0 , 5:3_https://www.fliggy.com/, 1, -5:3_https://www.fliggy.com/, 820 0x7f9f0f9bd2e0 0x1b9df3d2fee0 
[1:19:0712/131923.000130:WARNING:paced_sender.cc(261)] Elapsed time (3006 ms) longer than expected, limiting to 2000 ms
[1:19:0712/131923.501087:WARNING:paced_sender.cc(261)] Elapsed time (3507 ms) longer than expected, limiting to 2000 ms
[1:19:0712/131924.001695:WARNING:paced_sender.cc(261)] Elapsed time (4007 ms) longer than expected, limiting to 2000 ms
[1:19:0712/131924.501414:WARNING:paced_sender.cc(261)] Elapsed time (4507 ms) longer than expected, limiting to 2000 ms
[1:21:0712/131924.993686:WARNING:paced_sender.cc(261)] Elapsed time (2004 ms) longer than expected, limiting to 2000 ms
[1:19:0712/131925.001677:WARNING:paced_sender.cc(261)] Elapsed time (5007 ms) longer than expected, limiting to 2000 ms
[1:21:0712/131925.493880:WARNING:paced_sender.cc(261)] Elapsed time (2504 ms) longer than expected, limiting to 2000 ms
[1:19:0712/131925.502008:WARNING:paced_sender.cc(261)] Elapsed time (5508 ms) longer than expected, limiting to 2000 ms
[1:21:0712/131925.995092:WARNING:paced_sender.cc(261)] Elapsed time (3005 ms) longer than expected, limiting to 2000 ms
[1:19:0712/131926.002320:WARNING:paced_sender.cc(261)] Elapsed time (6008 ms) longer than expected, limiting to 2000 ms
[1:21:0712/131926.495244:WARNING:paced_sender.cc(261)] Elapsed time (3506 ms) longer than expected, limiting to 2000 ms
[1:19:0712/131926.502606:WARNING:paced_sender.cc(261)] Elapsed time (6508 ms) longer than expected, limiting to 2000 ms
		remove user.10_e77b6437 -> 0
		remove user.11_64bda777 -> 0
		remove user.12_5d472903 -> 0
		remove user.13_16149dc4 -> 0
		remove user.14_c644d72d -> 0
[1:21:0712/131926.995294:WARNING:paced_sender.cc(261)] Elapsed time (4006 ms) longer than expected, limiting to 2000 ms
[1:19:0712/131927.002883:WARNING:paced_sender.cc(261)] Elapsed time (7009 ms) longer than expected, limiting to 2000 ms
[1:21:0712/131927.495421:WARNING:paced_sender.cc(261)] Elapsed time (4506 ms) longer than expected, limiting to 2000 ms
[1:19:0712/131927.503218:WARNING:paced_sender.cc(261)] Elapsed time (7509 ms) longer than expected, limiting to 2000 ms
[1:21:0712/131927.995557:WARNING:paced_sender.cc(261)] Elapsed time (5006 ms) longer than expected, limiting to 2000 ms
[1:19:0712/131928.003545:WARNING:paced_sender.cc(261)] Elapsed time (8009 ms) longer than expected, limiting to 2000 ms
[1:21:0712/131928.495759:WARNING:paced_sender.cc(261)] Elapsed time (5506 ms) longer than expected, limiting to 2000 ms
[1:19:0712/131928.503818:WARNING:paced_sender.cc(261)] Elapsed time (8510 ms) longer than expected, limiting to 2000 ms
[1:21:0712/131928.995986:WARNING:paced_sender.cc(261)] Elapsed time (6006 ms) longer than expected, limiting to 2000 ms
[1:19:0712/131929.004080:WARNING:paced_sender.cc(261)] Elapsed time (9010 ms) longer than expected, limiting to 2000 ms
[1:21:0712/131929.496220:WARNING:paced_sender.cc(261)] Elapsed time (6507 ms) longer than expected, limiting to 2000 ms
[1:19:0712/131929.504207:WARNING:paced_sender.cc(261)] Elapsed time (9510 ms) longer than expected, limiting to 2000 ms
[1:21:0712/131929.996421:WARNING:paced_sender.cc(261)] Elapsed time (7007 ms) longer than expected, limiting to 2000 ms
[1:19:0712/131930.004593:WARNING:paced_sender.cc(261)] Elapsed time (10010 ms) longer than expected, limiting to 2000 ms
[1:21:0712/131930.496587:WARNING:paced_sender.cc(261)] Elapsed time (7507 ms) longer than expected, limiting to 2000 ms
[1:19:0712/131930.504899:WARNING:paced_sender.cc(261)] Elapsed time (10511 ms) longer than expected, limiting to 2000 ms
[1:21:0712/131930.996820:WARNING:paced_sender.cc(261)] Elapsed time (8007 ms) longer than expected, limiting to 2000 ms
[1:19:0712/131931.005275:WARNING:paced_sender.cc(261)] Elapsed time (11011 ms) longer than expected, limiting to 2000 ms
[1:21:0712/131931.497059:WARNING:paced_sender.cc(261)] Elapsed time (8507 ms) longer than expected, limiting to 2000 ms
[1:19:0712/131931.505667:WARNING:paced_sender.cc(261)] Elapsed time (11511 ms) longer than expected, limiting to 2000 ms
[23054:23054:0712/131931.522239:INFO:CONSOLE(3)] "", source: https://g.alicdn.com/secdev/nsv/1.0.63/ns_c_74_3_f.js (3)
[1:1:0712/131931.550666:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fliggy.com/, 786, 7f9f103da881
[1:1:0712/131931.565676:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2968d3ec2860","ptid":"744 0x7f9f0da95070 0x1b9df7f1b860 ","rf":"5:3_https://www.fliggy.com/"}
[1:1:0712/131931.565924:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.fliggy.com/","ptid":"744 0x7f9f0da95070 0x1b9df7f1b860 ","rf":"5:3_https://www.fliggy.com/"}
[1:1:0712/131931.566207:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.fliggy.com/"
[1:1:0712/131931.566514:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , t, (){e++,e>10&&(n=3e3),o(),setTimeout(t,n)}
[1:1:0712/131931.566654:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131931.569000:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x11fb421629c8, 0x1b9df0bb2950
[1:1:0712/131931.569170:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.fliggy.com/", 500
[1:1:0712/131931.569362:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fliggy.com/, 882
[1:1:0712/131931.569495:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 882 0x7f9f0da95070 0x1b9dfc3d3460 , 5:3_https://www.fliggy.com/, 1, -5:3_https://www.fliggy.com/, 786 0x7f9f0da95070 0x1b9df7ef8660 
[1:1:0712/131931.584393:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , , document.readyState
[1:1:0712/131931.584606:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:17:0712/131931.877492:WARNING:stunport.cc(403)] Port[0x1b9dfab3f620:data:1:0:local:Net[any:::/0:Unknown]]: StunPort: stun host lookup received error 0
[1:1:0712/131931.903509:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , , (){}
[1:1:0712/131931.903724:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:17:0712/131931.973430:WARNING:p2ptransportchannel.cc(714)] Port[0x1b9df1b144a0:data:1:0:local:Net[any:0.0.0.0/0:Unknown]]: SetOption(5, 0) failed: 0
[1:17:0712/131931.973896:WARNING:p2ptransportchannel.cc(714)] Port[0x1b9dfacd7b20:data:1:0:local:Net[any:::/0:Unknown]]: SetOption(5, 0) failed: 0
[1:21:0712/131931.997281:WARNING:paced_sender.cc(261)] Elapsed time (9008 ms) longer than expected, limiting to 2000 ms
[1:19:0712/131932.005980:WARNING:paced_sender.cc(261)] Elapsed time (12012 ms) longer than expected, limiting to 2000 ms
[1:1:0712/131932.394266:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , S, (e){var a="se";a&&(a+="tLo"),a+="calDes",a+="cript",a+="io",a+="n",$a[a](e)}
[1:1:0712/131932.394432:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:21:0712/131932.497336:WARNING:paced_sender.cc(261)] Elapsed time (9508 ms) longer than expected, limiting to 2000 ms
[1:19:0712/131932.506257:WARNING:paced_sender.cc(261)] Elapsed time (12512 ms) longer than expected, limiting to 2000 ms
[1:1:0712/131932.534210:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , , document.readyState
[1:1:0712/131932.534466:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131932.566721:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fliggy.com/, 748, 7f9f103da881
[1:1:0712/131932.582010:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2968d3ec2860","ptid":"718 0x7f9f0ddfdbd0 0x1b9df8727258 ","rf":"5:3_https://www.fliggy.com/"}
[1:1:0712/131932.582220:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.fliggy.com/","ptid":"718 0x7f9f0ddfdbd0 0x1b9df8727258 ","rf":"5:3_https://www.fliggy.com/"}
[1:1:0712/131932.582491:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.fliggy.com/"
[1:1:0712/131932.582832:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , play, (){var t;if(this.props.rtl)t=this.state.currentSlide-this.props.slidesToScroll;else{if(!this.canGoNe
[1:1:0712/131932.582942:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131932.752676:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x11fb421629c8, 0x1b9df0bb2910
[1:1:0712/131932.752876:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.fliggy.com/", 500
[1:1:0712/131932.753080:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fliggy.com/, 929
[1:1:0712/131932.753227:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 929 0x7f9f0da95070 0x1b9dfa89d8e0 , 5:3_https://www.fliggy.com/, 1, -5:3_https://www.fliggy.com/, 748 0x7f9f0da95070 0x1b9dfa5899e0 
[1:1:0712/131932.753911:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x11fb421629c8, 0x1b9df0bb2910
[1:1:0712/131932.754941:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.fliggy.com/", 3000
[1:1:0712/131932.755121:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fliggy.com/, 930
[1:1:0712/131932.755226:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 930 0x7f9f0da95070 0x1b9df1c6e5e0 , 5:3_https://www.fliggy.com/, 1, -5:3_https://www.fliggy.com/, 748 0x7f9f0da95070 0x1b9dfa5899e0 
[1:1:0712/131932.755844:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fliggy.com/, 844, 7f9f103da881
[1:1:0712/131932.771534:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2968d3ec2860","ptid":"819 0x7f9f0f9bd2e0 0x1b9dfaa257e0 ","rf":"5:3_https://www.fliggy.com/"}
[1:1:0712/131932.771668:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.fliggy.com/","ptid":"819 0x7f9f0f9bd2e0 0x1b9dfaa257e0 ","rf":"5:3_https://www.fliggy.com/"}
[1:1:0712/131932.771856:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.fliggy.com/"
[1:1:0712/131932.772093:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , a, (){b.getScript(e+d+"/seed-min.js",function(){b.use("tripbar/main/mallbar",function(a,b){new b})})}
[1:1:0712/131932.772192:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131932.796349:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fliggy.com/, 808, 7f9f103da881
[1:1:0712/131932.811281:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2968d3ec2860","ptid":"776 0x7f9f0f9bd2e0 0x1b9df4c9a760 ","rf":"5:3_https://www.fliggy.com/"}
[1:1:0712/131932.811450:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.fliggy.com/","ptid":"776 0x7f9f0f9bd2e0 0x1b9df4c9a760 ","rf":"5:3_https://www.fliggy.com/"}
[1:1:0712/131932.811666:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.fliggy.com/"
[1:1:0712/131932.811944:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , , (n){try{a.close()}catch(t){}}
[1:1:0712/131932.812045:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131932.832492:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fliggy.com/, 864, 7f9f103da881
[1:1:0712/131932.847676:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2968d3ec2860","ptid":"820 0x7f9f0f9bd2e0 0x1b9df3d2fee0 ","rf":"5:3_https://www.fliggy.com/"}
[1:1:0712/131932.847876:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.fliggy.com/","ptid":"820 0x7f9f0f9bd2e0 0x1b9df3d2fee0 ","rf":"5:3_https://www.fliggy.com/"}
[1:1:0712/131932.848105:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.fliggy.com/"
[1:1:0712/131932.848463:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , Y, (e){try{for(var a="\u0441\u044a\u044d\u0451\u0443",r="",s=0;s<a.length;s++){var c=a.charCodeAt(s)-99
[1:1:0712/131932.848786:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131933.190763:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "deviceorientation", "https://www.fliggy.com/"
[1:1:0712/131933.191268:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , D, (n){cn=n.gamma,en||(en=s(function(n){removeEventListener("deviceorientation",D),s(A,470)},30))}
[1:1:0712/131933.191435:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131933.191930:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 30, 0x11fb421629c8, 0x1b9df0bb2a38
[1:1:0712/131933.192065:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.fliggy.com/", 30
[1:1:0712/131933.192277:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fliggy.com/, 954
[1:1:0712/131933.192420:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 954 0x7f9f0da95070 0x1b9df3d5b6e0 , 5:3_https://www.fliggy.com/, 1, -5:3_https://www.fliggy.com/, 905 0x7f9f25ff53d0 0x1b9dfa87a7e0 
[1:1:0712/131933.192605:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "deviceorientation", "https://www.fliggy.com/"
[1:1:0712/131933.294980:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fliggy.com/, 882, 7f9f103da881
[1:1:0712/131933.312057:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2968d3ec2860","ptid":"786 0x7f9f0da95070 0x1b9df7ef8660 ","rf":"5:3_https://www.fliggy.com/"}
[1:1:0712/131933.312242:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.fliggy.com/","ptid":"786 0x7f9f0da95070 0x1b9df7ef8660 ","rf":"5:3_https://www.fliggy.com/"}
[1:1:0712/131933.312460:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.fliggy.com/"
[1:1:0712/131933.312743:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , t, (){e++,e>10&&(n=3e3),o(),setTimeout(t,n)}
[1:1:0712/131933.312846:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131933.314264:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x11fb421629c8, 0x1b9df0bb2950
[1:1:0712/131933.314373:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.fliggy.com/", 500
[1:1:0712/131933.314549:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fliggy.com/, 961
[1:1:0712/131933.314672:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 961 0x7f9f0da95070 0x1b9dfc3d3ce0 , 5:3_https://www.fliggy.com/, 1, -5:3_https://www.fliggy.com/, 882 0x7f9f0da95070 0x1b9dfc3d3460 
[1:1:0712/131933.488375:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 916 0x7f9f0f9bd2e0 0x1b9df856f6e0 , "https://www.fliggy.com/"
[1:1:0712/131933.488999:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , , jsonp444({"TCART_234_67ee04042047c691725150187b3a65ac_q":-1});
[1:1:0712/131933.489150:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131933.494664:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.fliggy.com/"
[1:1:0712/131933.708293:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , , document.readyState
[1:1:0712/131933.708447:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131934.702936:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fliggy.com/, 954, 7f9f103da881
[1:1:0712/131934.720162:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2968d3ec2860","ptid":"905 0x7f9f25ff53d0 0x1b9dfa87a7e0 ","rf":"5:3_https://www.fliggy.com/"}
[1:1:0712/131934.720365:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.fliggy.com/","ptid":"905 0x7f9f25ff53d0 0x1b9dfa87a7e0 ","rf":"5:3_https://www.fliggy.com/"}
[1:1:0712/131934.720611:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.fliggy.com/"
[1:1:0712/131934.720875:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , , (n){removeEventListener("deviceorientation",D),s(A,470)}
[1:1:0712/131934.720964:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131934.721485:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 470, 0x11fb421629c8, 0x1b9df0bb2950
[1:1:0712/131934.721630:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.fliggy.com/", 470
[1:1:0712/131934.721832:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fliggy.com/, 1010
[1:1:0712/131934.721967:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1010 0x7f9f0da95070 0x1b9df1af46e0 , 5:3_https://www.fliggy.com/, 1, -5:3_https://www.fliggy.com/, 954 0x7f9f0da95070 0x1b9df3d5b6e0 
[1:1:0712/131934.722505:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fliggy.com/, 929, 7f9f103da881
[1:1:0712/131934.739902:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2968d3ec2860","ptid":"748 0x7f9f0da95070 0x1b9dfa5899e0 ","rf":"5:3_https://www.fliggy.com/"}
[1:1:0712/131934.740098:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.fliggy.com/","ptid":"748 0x7f9f0da95070 0x1b9dfa5899e0 ","rf":"5:3_https://www.fliggy.com/"}
[1:1:0712/131934.740346:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.fliggy.com/"
[1:1:0712/131934.741359:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , i, (){a.setState(l,function(){a.props.afterChange&&a.props.afterChange(n),delete a.animationEndCallback
[1:1:0712/131934.741505:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131934.983317:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , , document.readyState
[1:1:0712/131934.983474:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131935.075847:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fliggy.com/, 961, 7f9f103da881
[1:1:0712/131935.093549:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2968d3ec2860","ptid":"882 0x7f9f0da95070 0x1b9dfc3d3460 ","rf":"5:3_https://www.fliggy.com/"}
[1:1:0712/131935.093726:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.fliggy.com/","ptid":"882 0x7f9f0da95070 0x1b9dfc3d3460 ","rf":"5:3_https://www.fliggy.com/"}
[1:1:0712/131935.093943:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.fliggy.com/"
[1:1:0712/131935.094232:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , t, (){e++,e>10&&(n=3e3),o(),setTimeout(t,n)}
[1:1:0712/131935.094335:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131935.095695:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x11fb421629c8, 0x1b9df0bb2950
[1:1:0712/131935.095791:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.fliggy.com/", 500
[1:1:0712/131935.095940:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fliggy.com/, 1030
[1:1:0712/131935.096035:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1030 0x7f9f0da95070 0x1b9dfc6154e0 , 5:3_https://www.fliggy.com/, 1, -5:3_https://www.fliggy.com/, 961 0x7f9f0da95070 0x1b9dfc3d3ce0 
[1:1:0712/131935.555550:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1007 0x7f9f0f9bd2e0 0x1b9df0fd30e0 , "https://www.fliggy.com/"
[1:1:0712/131935.556610:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , , /*! tripbar 2017-11-08 05:34:14 */
!function(){var a=location.hostname,b=location.hostname.indexOf("
[1:1:0712/131935.556735:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131935.622969:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.fliggy.com/"
[1:1:0712/131935.645839:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1008 0x7f9f0f9bd2e0 0x1b9df0f254e0 , "https://www.fliggy.com/"
[1:1:0712/131935.646378:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , , 

jsonp420({"errmsg":"success!","result":{"name":"\u5317\u4eac","cityCode":"BJS"}})

[1:1:0712/131935.646500:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131935.647066:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.fliggy.com/"
[1:1:0712/131935.858272:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , navigator.geolocation.navigator.geolocation.getCurrentPosition.enableHighAccuracy, (e){s&&s("ERROR("+e.code+"): "+e.message)}
[1:1:0712/131935.858431:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131935.910139:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , , document.readyState
[1:1:0712/131935.910297:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131936.111017:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fliggy.com/, 1010, 7f9f103da881
[1:1:0712/131936.127932:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2968d3ec2860","ptid":"954 0x7f9f0da95070 0x1b9df3d5b6e0 ","rf":"5:3_https://www.fliggy.com/"}
[1:1:0712/131936.128120:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.fliggy.com/","ptid":"954 0x7f9f0da95070 0x1b9df3d5b6e0 ","rf":"5:3_https://www.fliggy.com/"}
[1:1:0712/131936.128342:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.fliggy.com/"
[1:1:0712/131936.128616:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , A, (){en=0,addEventListener("deviceorientation",D)}
[1:1:0712/131936.128719:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131936.202594:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://www.fliggy.com/"
[1:1:0712/131936.202995:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , e, (){for(var a=0,b;b=h[a++];)try{b()}catch(d){setTimeout(function(){throw d;},0)}1<a&&(h=[]);l=0}
[1:1:0712/131936.203134:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131937.126401:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fliggy.com/, 1030, 7f9f103da881
[1:1:0712/131937.144483:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2968d3ec2860","ptid":"961 0x7f9f0da95070 0x1b9dfc3d3ce0 ","rf":"5:3_https://www.fliggy.com/"}
[1:1:0712/131937.144687:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.fliggy.com/","ptid":"961 0x7f9f0da95070 0x1b9dfc3d3ce0 ","rf":"5:3_https://www.fliggy.com/"}
[1:1:0712/131937.144935:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.fliggy.com/"
[1:1:0712/131937.145249:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , t, (){e++,e>10&&(n=3e3),o(),setTimeout(t,n)}
[1:1:0712/131937.145401:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131937.146824:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x11fb421629c8, 0x1b9df0bb2950
[1:1:0712/131937.146960:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.fliggy.com/", 500
[1:1:0712/131937.147181:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fliggy.com/, 1060
[1:1:0712/131937.147293:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1060 0x7f9f0da95070 0x1b9df40fcfe0 , 5:3_https://www.fliggy.com/, 1, -5:3_https://www.fliggy.com/, 1030 0x7f9f0da95070 0x1b9dfc6154e0 
[1:1:0712/131937.203165:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fliggy.com/, 930, 7f9f103da881
[1:1:0712/131937.220985:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2968d3ec2860","ptid":"748 0x7f9f0da95070 0x1b9dfa5899e0 ","rf":"5:3_https://www.fliggy.com/"}
[1:1:0712/131937.221178:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.fliggy.com/","ptid":"748 0x7f9f0da95070 0x1b9dfa5899e0 ","rf":"5:3_https://www.fliggy.com/"}
[1:1:0712/131937.221393:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.fliggy.com/"
[1:1:0712/131937.221679:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , play, (){var t;if(this.props.rtl)t=this.state.currentSlide-this.props.slidesToScroll;else{if(!this.canGoNe
[1:1:0712/131937.221785:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131937.383411:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x11fb421629c8, 0x1b9df0bb2910
[1:1:0712/131937.383637:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.fliggy.com/", 500
[1:1:0712/131937.383861:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fliggy.com/, 1065
[1:1:0712/131937.384016:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1065 0x7f9f0da95070 0x1b9df8727a60 , 5:3_https://www.fliggy.com/, 1, -5:3_https://www.fliggy.com/, 930 0x7f9f0da95070 0x1b9df1c6e5e0 
[1:1:0712/131937.384709:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x11fb421629c8, 0x1b9df0bb2910
[1:1:0712/131937.384826:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.fliggy.com/", 3000
[1:1:0712/131937.384986:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fliggy.com/, 1066
[1:1:0712/131937.385116:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1066 0x7f9f0da95070 0x1b9df143c3e0 , 5:3_https://www.fliggy.com/, 1, -5:3_https://www.fliggy.com/, 930 0x7f9f0da95070 0x1b9df1c6e5e0 
[1:1:0712/131937.404007:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , , document.readyState
[1:1:0712/131937.404156:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131937.842088:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , , document.readyState
[1:1:0712/131937.842266:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131938.523582:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fliggy.com/, 1060, 7f9f103da881
[1:1:0712/131938.541780:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2968d3ec2860","ptid":"1030 0x7f9f0da95070 0x1b9dfc6154e0 ","rf":"5:3_https://www.fliggy.com/"}
[1:1:0712/131938.541994:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.fliggy.com/","ptid":"1030 0x7f9f0da95070 0x1b9dfc6154e0 ","rf":"5:3_https://www.fliggy.com/"}
[1:1:0712/131938.542256:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.fliggy.com/"
[1:1:0712/131938.542598:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , t, (){e++,e>10&&(n=3e3),o(),setTimeout(t,n)}
[1:1:0712/131938.542740:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131938.543157:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x11fb421629c8, 0x1b9df0bb2950
[1:1:0712/131938.543257:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.fliggy.com/", 500
[1:1:0712/131938.543425:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fliggy.com/, 1127
[1:1:0712/131938.543525:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1127 0x7f9f0da95070 0x1b9dff33f3e0 , 5:3_https://www.fliggy.com/, 1, -5:3_https://www.fliggy.com/, 1060 0x7f9f0da95070 0x1b9df40fcfe0 
[1:1:0712/131938.708877:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.fliggy.com/"
[1:1:0712/131938.709321:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , c, (){var a=o.readyState;if(!a||"loaded"===a||"complete"===a)o.onreadystatechange=o.onload=null,t(0)}
[1:1:0712/131938.709450:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131938.888338:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1094 0x7f9f0f9bd2e0 0x1b9df205eae0 , "https://www.fliggy.com/"
[1:1:0712/131938.889855:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , , /*
Copyright 2014, KISSY v1.49.10
MIT Licensed
build time: Dec 10 15:06
*/
KISSY.add("swf/ua",[],fun
[1:1:0712/131938.889984:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131938.894153:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.fliggy.com/"
[1:1:0712/131938.916939:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1095 0x7f9f0f9bd2e0 0x1b9df26a0de0 , "https://www.fliggy.com/"
[1:1:0712/131938.919666:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , , /*! tripbar 2017-11-08 05:34:14 */
KISSY.add("tripbar/main/mallbar",function(a,b,c,d,e,f,g,h,i,j,k,l
[1:1:0712/131938.919831:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131938.937999:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.fliggy.com/"
		remove user.15_aee2ef8c -> 0
		remove user.16_fea9ebb -> 0
[1:1:0712/131941.979794:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x11fb421629c8, 0x1b9df0bb2a10
[1:1:0712/131941.979964:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.fliggy.com/", 0
[1:1:0712/131941.980151:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fliggy.com/, 1139
[1:1:0712/131941.980277:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1139 0x7f9f0da95070 0x1b9dfc55dee0 , 5:3_https://www.fliggy.com/, 1, -5:3_https://www.fliggy.com/, 1095 0x7f9f0f9bd2e0 0x1b9df26a0de0 
[1:1:0712/131942.003630:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x11fb421629c8, 0x1b9df0bb2a10
[1:1:0712/131942.003796:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.fliggy.com/", 0
[1:1:0712/131942.004001:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fliggy.com/, 1140
[1:1:0712/131942.004134:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1140 0x7f9f0da95070 0x1b9df15d84e0 , 5:3_https://www.fliggy.com/, 1, -5:3_https://www.fliggy.com/, 1095 0x7f9f0f9bd2e0 0x1b9df26a0de0 
[1:1:0712/131944.208594:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , , document.readyState
[1:1:0712/131944.208812:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131944.715073:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fliggy.com/, 1065, 7f9f103da881
[1:1:0712/131944.733813:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2968d3ec2860","ptid":"930 0x7f9f0da95070 0x1b9df1c6e5e0 ","rf":"5:3_https://www.fliggy.com/"}
[1:1:0712/131944.734025:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.fliggy.com/","ptid":"930 0x7f9f0da95070 0x1b9df1c6e5e0 ","rf":"5:3_https://www.fliggy.com/"}
[1:1:0712/131944.734321:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.fliggy.com/"
[1:1:0712/131944.734677:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , i, (){a.setState(l,function(){a.props.afterChange&&a.props.afterChange(n),delete a.animationEndCallback
[1:1:0712/131944.734817:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131945.030568:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "deviceorientation", "https://www.fliggy.com/"
[1:1:0712/131945.032466:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , d, (e,c,b,k,C){var j,S,E,z,L,W,U,J,Q,X,q,F,G,H,$,K,V,Z,Y,ee,ae,re,se,ce,be,ke,oe,te,ie,ne,he,ve,de,ue,p
[1:1:0712/131945.032634:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131945.101716:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "deviceorientation", "https://www.fliggy.com/"
[1:1:0712/131945.102231:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 30, 0x11fb421629c8, 0x1b9df0bb29f0
[1:1:0712/131945.102402:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.fliggy.com/", 30
[1:1:0712/131945.102650:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fliggy.com/, 1161
[1:1:0712/131945.102828:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1161 0x7f9f0da95070 0x1b9dff9d9e60 , 5:3_https://www.fliggy.com/, 1, -5:3_https://www.fliggy.com/, 1128 0x7f9f25ff53d0 0x1b9dfafe3360 
[1:1:0712/131945.399771:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://www.fliggy.com/"
[1:1:0712/131945.400245:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , e, (){for(var a=0,b;b=h[a++];)try{b()}catch(d){setTimeout(function(){throw d;},0)}1<a&&(h=[]);l=0}
[1:1:0712/131945.400416:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131945.494545:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x11fb421629c8, 0x1b9df0bb2a10
[1:1:0712/131945.494735:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.fliggy.com/", 5000
[1:1:0712/131945.494978:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fliggy.com/, 1169
[1:1:0712/131945.495101:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1169 0x7f9f0da95070 0x1b9df0df6a60 , 5:3_https://www.fliggy.com/, 1, -5:3_https://www.fliggy.com/, 1144 0x7f9f24120080 0x1b9e026e1060 1 0 0x1b9e026e1078 
[1:1:0712/131945.789442:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x11fb421629c8, 0x1b9df0bb2a10
[1:1:0712/131945.789676:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.fliggy.com/", 3000
[1:1:0712/131945.789930:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fliggy.com/, 1170
[1:1:0712/131945.790117:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1170 0x7f9f0da95070 0x1b9dffa1c960 , 5:3_https://www.fliggy.com/, 1, -5:3_https://www.fliggy.com/, 1144 0x7f9f24120080 0x1b9e026e1060 1 0 0x1b9e026e1078 
[1:1:0712/131945.791530:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fliggy.com/, 1127, 7f9f103da881
[1:1:0712/131945.812560:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2968d3ec2860","ptid":"1060 0x7f9f0da95070 0x1b9df40fcfe0 ","rf":"5:3_https://www.fliggy.com/"}
[1:1:0712/131945.812734:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.fliggy.com/","ptid":"1060 0x7f9f0da95070 0x1b9df40fcfe0 ","rf":"5:3_https://www.fliggy.com/"}
[1:1:0712/131945.812932:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.fliggy.com/"
[1:1:0712/131945.813244:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , t, (){e++,e>10&&(n=3e3),o(),setTimeout(t,n)}
[1:1:0712/131945.813347:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131945.814710:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x11fb421629c8, 0x1b9df0bb2950
[1:1:0712/131945.814807:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.fliggy.com/", 500
[1:1:0712/131945.814955:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fliggy.com/, 1173
[1:1:0712/131945.815048:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1173 0x7f9f0da95070 0x1b9df46c2ae0 , 5:3_https://www.fliggy.com/, 1, -5:3_https://www.fliggy.com/, 1127 0x7f9f0da95070 0x1b9dff33f3e0 
[1:1:0712/131945.815793:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fliggy.com/, 1066, 7f9f103da881
[1:1:0712/131945.835316:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2968d3ec2860","ptid":"930 0x7f9f0da95070 0x1b9df1c6e5e0 ","rf":"5:3_https://www.fliggy.com/"}
[1:1:0712/131945.835513:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.fliggy.com/","ptid":"930 0x7f9f0da95070 0x1b9df1c6e5e0 ","rf":"5:3_https://www.fliggy.com/"}
[1:1:0712/131945.835793:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.fliggy.com/"
[1:1:0712/131945.836104:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , play, (){var t;if(this.props.rtl)t=this.state.currentSlide-this.props.slidesToScroll;else{if(!this.canGoNe
[1:1:0712/131945.836225:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131945.992118:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x11fb421629c8, 0x1b9df0bb2910
[1:1:0712/131945.992301:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.fliggy.com/", 500
[1:1:0712/131945.992501:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fliggy.com/, 1174
[1:1:0712/131945.992630:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1174 0x7f9f0da95070 0x1b9df14fbf60 , 5:3_https://www.fliggy.com/, 1, -5:3_https://www.fliggy.com/, 1066 0x7f9f0da95070 0x1b9df143c3e0 
[1:1:0712/131945.993196:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x11fb421629c8, 0x1b9df0bb2910
[1:1:0712/131945.993309:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.fliggy.com/", 3000
[1:1:0712/131945.993489:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fliggy.com/, 1175
[1:1:0712/131945.993600:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1175 0x7f9f0da95070 0x1b9dfa99b160 , 5:3_https://www.fliggy.com/, 1, -5:3_https://www.fliggy.com/, 1066 0x7f9f0da95070 0x1b9df143c3e0 
[1:1:0712/131945.994278:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fliggy.com/, 1139, 7f9f103da881
[1:1:0712/131946.014273:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2968d3ec2860","ptid":"1095 0x7f9f0f9bd2e0 0x1b9df26a0de0 ","rf":"5:3_https://www.fliggy.com/"}
[1:1:0712/131946.014485:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.fliggy.com/","ptid":"1095 0x7f9f0f9bd2e0 0x1b9df26a0de0 ","rf":"5:3_https://www.fliggy.com/"}
[1:1:0712/131946.014791:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.fliggy.com/"
[1:1:0712/131946.015183:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , ve, (e){B=0;var r=d(8,0),s="l",c=s.split("").reverse().join(""),b="/",k=b.split("").reverse().join("");a
[1:1:0712/131946.015350:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131947.784084:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , , document.readyState
[1:1:0712/131947.784322:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131947.786000:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fliggy.com/, 1140, 7f9f103da881
[1:1:0712/131947.805396:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2968d3ec2860","ptid":"1095 0x7f9f0f9bd2e0 0x1b9df26a0de0 ","rf":"5:3_https://www.fliggy.com/"}
[1:1:0712/131947.805618:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.fliggy.com/","ptid":"1095 0x7f9f0f9bd2e0 0x1b9df26a0de0 ","rf":"5:3_https://www.fliggy.com/"}
[1:1:0712/131947.805887:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.fliggy.com/"
[1:1:0712/131947.806225:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , e, (){D=null;var n=M.ra(!1,null);z.s(n),p.k(g,n)}
[1:1:0712/131947.806378:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131948.038215:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fliggy.com/, 1161, 7f9f103da881
[1:1:0712/131948.059692:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2968d3ec2860","ptid":"1128 0x7f9f25ff53d0 0x1b9dfafe3360 ","rf":"5:3_https://www.fliggy.com/"}
[1:1:0712/131948.059871:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.fliggy.com/","ptid":"1128 0x7f9f25ff53d0 0x1b9dfafe3360 ","rf":"5:3_https://www.fliggy.com/"}
[1:1:0712/131948.060095:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.fliggy.com/"
[1:1:0712/131948.060415:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , , (n){removeEventListener("deviceorientation",D),s(A,470)}
[1:1:0712/131948.060516:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131948.060868:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 470, 0x11fb421629c8, 0x1b9df0bb2950
[1:1:0712/131948.060961:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.fliggy.com/", 470
[1:1:0712/131948.061204:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fliggy.com/, 1197
[1:1:0712/131948.061329:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1197 0x7f9f0da95070 0x1b9dfbf65c60 , 5:3_https://www.fliggy.com/, 1, -5:3_https://www.fliggy.com/, 1161 0x7f9f0da95070 0x1b9dff9d9e60 
[1:1:0712/131948.119628:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1166 0x7f9f0f9bd2e0 0x1b9dff930060 , "https://www.fliggy.com/"
[1:1:0712/131948.120266:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , , 
try{jsonp469({"code":"100002","msg":"\u4eb2\uff0c\u60a8\u8fd8\u672a\u767b\u5f55\uff0c\u8bf7\u5148\
[1:1:0712/131948.120451:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131948.120991:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.fliggy.com/"
[1:1:0712/131948.313866:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fliggy.com/, 1173, 7f9f103da881
[1:1:0712/131948.336021:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2968d3ec2860","ptid":"1127 0x7f9f0da95070 0x1b9dff33f3e0 ","rf":"5:3_https://www.fliggy.com/"}
[1:1:0712/131948.336242:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.fliggy.com/","ptid":"1127 0x7f9f0da95070 0x1b9dff33f3e0 ","rf":"5:3_https://www.fliggy.com/"}
[1:1:0712/131948.336535:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.fliggy.com/"
[1:1:0712/131948.336826:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , t, (){e++,e>10&&(n=3e3),o(),setTimeout(t,n)}
[1:1:0712/131948.336926:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131948.337325:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x11fb421629c8, 0x1b9df0bb2950
[1:1:0712/131948.337438:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.fliggy.com/", 3000
[1:1:0712/131948.337619:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fliggy.com/, 1218
[1:1:0712/131948.337762:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1218 0x7f9f0da95070 0x1b9dff99d0e0 , 5:3_https://www.fliggy.com/, 1, -5:3_https://www.fliggy.com/, 1173 0x7f9f0da95070 0x1b9df46c2ae0 
[1:1:0712/131948.338327:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fliggy.com/, 1174, 7f9f103da881
[1:1:0712/131948.361363:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2968d3ec2860","ptid":"1066 0x7f9f0da95070 0x1b9df143c3e0 ","rf":"5:3_https://www.fliggy.com/"}
[1:1:0712/131948.361599:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.fliggy.com/","ptid":"1066 0x7f9f0da95070 0x1b9df143c3e0 ","rf":"5:3_https://www.fliggy.com/"}
[1:1:0712/131948.361865:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.fliggy.com/"
[1:1:0712/131948.362166:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , i, (){a.setState(l,function(){a.props.afterChange&&a.props.afterChange(n),delete a.animationEndCallback
[1:1:0712/131948.362294:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131948.556757:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , , document.readyState
[1:1:0712/131948.556911:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131948.974272:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://www.fliggy.com/"
[1:1:0712/131948.974705:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , e, (){for(var a=0,b;b=h[a++];)try{b()}catch(d){setTimeout(function(){throw d;},0)}1<a&&(h=[]);l=0}
[1:1:0712/131948.974884:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131949.218796:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1214 0x7f9f0f9bd2e0 0x1b9df1686760 , "https://www.fliggy.com/"
[1:1:0712/131949.219597:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , , 
	    window.__mallbarGetConf&&__mallbarGetConf(
		{"542448":{"value":{"moduleinfo":{"showVerCat":1
[1:1:0712/131949.219737:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131949.221301:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.fliggy.com/"
[1:1:0712/131949.632158:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.fliggy.com/", 200
[1:1:0712/131949.632443:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.fliggy.com/, 1241
[1:1:0712/131949.632574:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1241 0x7f9f0da95070 0x1b9df15d59e0 , 5:3_https://www.fliggy.com/, 1, -5:3_https://www.fliggy.com/, 1214 0x7f9f0f9bd2e0 0x1b9df1686760 
[1:1:0712/131949.914448:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15, 0x11fb421629c8, 0x1b9df0bb2a10
[1:1:0712/131949.914698:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.fliggy.com/", 15
[1:1:0712/131949.915236:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fliggy.com/, 1251
[1:1:0712/131949.915427:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1251 0x7f9f0da95070 0x1b9dff9e4060 , 5:3_https://www.fliggy.com/, 1, -5:3_https://www.fliggy.com/, 1214 0x7f9f0f9bd2e0 0x1b9df1686760 
[1:1:0712/131950.411294:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fliggy.com/, 1197, 7f9f103da881
[1:1:0712/131950.432630:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2968d3ec2860","ptid":"1161 0x7f9f0da95070 0x1b9dff9d9e60 ","rf":"5:3_https://www.fliggy.com/"}
[1:1:0712/131950.432827:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.fliggy.com/","ptid":"1161 0x7f9f0da95070 0x1b9dff9d9e60 ","rf":"5:3_https://www.fliggy.com/"}
[1:1:0712/131950.433077:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.fliggy.com/"
[1:1:0712/131950.433440:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , A, (){en=0,addEventListener("deviceorientation",D)}
[1:1:0712/131950.433555:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131950.479009:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , , document.readyState
[1:1:0712/131950.479180:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131950.624154:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fliggy.com/, 1170, 7f9f103da881
[1:1:0712/131950.645352:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2968d3ec2860","ptid":"1144 0x7f9f24120080 0x1b9e026e1060 1 0 0x1b9e026e1078 ","rf":"5:3_https://www.fliggy.com/"}
[1:1:0712/131950.645596:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.fliggy.com/","ptid":"1144 0x7f9f24120080 0x1b9e026e1060 1 0 0x1b9e026e1078 ","rf":"5:3_https://www.fliggy.com/"}
[1:1:0712/131950.645839:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.fliggy.com/"
[1:1:0712/131950.646152:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , , (){var a=window.devicePixelRatio>1;a&&Math.random()<d.SAM_PV&&e.sendLog(d.ARR.RETINA)}
[1:1:0712/131950.646292:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131950.668430:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fliggy.com/, 1175, 7f9f103da881
[1:1:0712/131950.689282:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2968d3ec2860","ptid":"1066 0x7f9f0da95070 0x1b9df143c3e0 ","rf":"5:3_https://www.fliggy.com/"}
[1:1:0712/131950.689455:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.fliggy.com/","ptid":"1066 0x7f9f0da95070 0x1b9df143c3e0 ","rf":"5:3_https://www.fliggy.com/"}
[1:1:0712/131950.689665:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.fliggy.com/"
[1:1:0712/131950.689940:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , play, (){var t;if(this.props.rtl)t=this.state.currentSlide-this.props.slidesToScroll;else{if(!this.canGoNe
[1:1:0712/131950.690050:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131950.842760:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x11fb421629c8, 0x1b9df0bb2910
[1:1:0712/131950.842907:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.fliggy.com/", 500
[1:1:0712/131950.843115:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fliggy.com/, 1280
[1:1:0712/131950.843223:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1280 0x7f9f0da95070 0x1b9df2230860 , 5:3_https://www.fliggy.com/, 1, -5:3_https://www.fliggy.com/, 1175 0x7f9f0da95070 0x1b9dfa99b160 
[1:1:0712/131950.843705:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x11fb421629c8, 0x1b9df0bb2910
[1:1:0712/131950.843797:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.fliggy.com/", 3000
[1:1:0712/131950.843929:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fliggy.com/, 1281
[1:1:0712/131950.844017:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1281 0x7f9f0da95070 0x1b9dff99dfe0 , 5:3_https://www.fliggy.com/, 1, -5:3_https://www.fliggy.com/, 1175 0x7f9f0da95070 0x1b9dfa99b160 
[1:1:0712/131950.950939:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://www.fliggy.com/"
[1:1:0712/131950.951343:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , e, (){for(var a=0,b;b=h[a++];)try{b()}catch(d){setTimeout(function(){throw d;},0)}1<a&&(h=[]);l=0}
[1:1:0712/131950.951484:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131951.461086:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.fliggy.com/, 1241, 7f9f103da8db
[1:1:0712/131951.482022:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2968d3ec2860","ptid":"1214 0x7f9f0f9bd2e0 0x1b9df1686760 ","rf":"5:3_https://www.fliggy.com/"}
[1:1:0712/131951.482245:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.fliggy.com/","ptid":"1214 0x7f9f0f9bd2e0 0x1b9df1686760 ","rf":"5:3_https://www.fliggy.com/"}
[1:1:0712/131951.482507:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.fliggy.com/, 1298
[1:1:0712/131951.482645:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1298 0x7f9f0da95070 0x1b9df1eea9e0 , 5:3_https://www.fliggy.com/, 0, , 1241 0x7f9f0da95070 0x1b9df15d59e0 
[1:1:0712/131951.482854:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.fliggy.com/"
[1:1:0712/131951.483149:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , , (){var a=parseInt(f.all(".mui-mbar-tabs-mask").css("height"));a>0&&v.showTabcontentBasedOnHash()}
[1:1:0712/131951.483282:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131951.921170:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fliggy.com/, 1251, 7f9f103da881
[1:1:0712/131951.942936:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2968d3ec2860","ptid":"1214 0x7f9f0f9bd2e0 0x1b9df1686760 ","rf":"5:3_https://www.fliggy.com/"}
[1:1:0712/131951.943134:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.fliggy.com/","ptid":"1214 0x7f9f0f9bd2e0 0x1b9df1686760 ","rf":"5:3_https://www.fliggy.com/"}
[1:1:0712/131951.943393:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.fliggy.com/"
[1:1:0712/131951.943734:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , l, (){b.runFrames()?
b.stopTimer():b.timer=g(l)}
[1:1:0712/131951.943883:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131952.738852:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fliggy.com/, 1218, 7f9f103da881
[1:1:0712/131952.762543:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2968d3ec2860","ptid":"1173 0x7f9f0da95070 0x1b9df46c2ae0 ","rf":"5:3_https://www.fliggy.com/"}
[1:1:0712/131952.762733:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.fliggy.com/","ptid":"1173 0x7f9f0da95070 0x1b9df46c2ae0 ","rf":"5:3_https://www.fliggy.com/"}
[1:1:0712/131952.762967:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.fliggy.com/"
[1:1:0712/131952.763286:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , t, (){e++,e>10&&(n=3e3),o(),setTimeout(t,n)}
[1:1:0712/131952.763413:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131952.764875:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x11fb421629c8, 0x1b9df0bb2950
[1:1:0712/131952.764975:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.fliggy.com/", 3000
[1:1:0712/131952.765238:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fliggy.com/, 1337
[1:1:0712/131952.765373:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1337 0x7f9f0da95070 0x1b9dfa8a19e0 , 5:3_https://www.fliggy.com/, 1, -5:3_https://www.fliggy.com/, 1218 0x7f9f0da95070 0x1b9dff99d0e0 
[1:1:0712/131952.789899:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fliggy.com/, 1280, 7f9f103da881
[1:1:0712/131952.813689:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2968d3ec2860","ptid":"1175 0x7f9f0da95070 0x1b9dfa99b160 ","rf":"5:3_https://www.fliggy.com/"}
[1:1:0712/131952.813885:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.fliggy.com/","ptid":"1175 0x7f9f0da95070 0x1b9dfa99b160 ","rf":"5:3_https://www.fliggy.com/"}
[1:1:0712/131952.814106:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.fliggy.com/"
[1:1:0712/131952.814391:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , i, (){a.setState(l,function(){a.props.afterChange&&a.props.afterChange(n),delete a.animationEndCallback
[1:1:0712/131952.814503:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131953.583178:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.fliggy.com/"
[1:1:0712/131953.583612:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , c, (){var a=o.readyState;if(!a||"loaded"===a||"complete"===a)o.onreadystatechange=o.onload=null,t(0)}
[1:1:0712/131953.583752:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131953.677078:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1327 0x7f9f0f9bd2e0 0x1b9dfae60860 , "https://www.fliggy.com/"
[1:1:0712/131953.678384:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , , /*! tripbar 2017-11-08 05:34:14 */
KISSY.add("tripbar/mods/hongbao/index",function(a,b,c,d,e,f,g){va
[1:1:0712/131953.678532:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131953.680225:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.fliggy.com/"
[1:1:0712/131954.471459:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "deviceorientation", "https://www.fliggy.com/"
[1:1:0712/131954.473154:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , d, (e,c,b,k,C){var j,S,E,z,L,W,U,J,Q,X,q,F,G,H,$,K,V,Z,Y,ee,ae,re,se,ce,be,ke,oe,te,ie,ne,he,ve,de,ue,p
[1:1:0712/131954.473280:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131954.539219:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "deviceorientation", "https://www.fliggy.com/"
[1:1:0712/131954.539612:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 30, 0x11fb421629c8, 0x1b9df0bb29f0
[1:1:0712/131954.539737:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.fliggy.com/", 30
[1:1:0712/131954.539916:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fliggy.com/, 1369
[1:1:0712/131954.540046:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1369 0x7f9f0da95070 0x1b9e046ce3e0 , 5:3_https://www.fliggy.com/, 1, -5:3_https://www.fliggy.com/, 1355 0x7f9f25ff53d0 0x1b9dff9c84e0 
[1:1:0712/131954.587648:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.fliggy.com/"
[1:1:0712/131954.588029:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fliggy.com/, 2968d3ec2860, , i, (a){r&&e.removeEventListener(t,i,!1),n.call(this,a)}
[1:1:0712/131954.588158:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fliggy.com/", "www.fliggy.com", 3, 1, , , 0
[1:1:0712/131954.626840:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.fliggy.com/"
[1:1:0712/131954.655555:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.fliggy.com/"
[1:1:0712/131954.985105:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.fliggy.com/"
[1:1:0712/131954.988714:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.fliggy.com/"
[1:1:0712/131954.989129:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.fliggy.com/"
[1:1:0712/131954.996242:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.fliggy.com/"
