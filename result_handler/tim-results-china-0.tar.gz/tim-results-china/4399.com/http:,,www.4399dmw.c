[0713/015000.982651:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/015000.982912:INFO:switcher_clone.cc(787)] backtrace rip is 7f45f9a45891
[0713/015001.533317:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/015001.533636:INFO:switcher_clone.cc(787)] backtrace rip is 7f3f75459891
[1:1:0713/015001.537473:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0713/015001.537646:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0713/015001.540489:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[0713/015002.360896:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/015002.361175:INFO:switcher_clone.cc(787)] backtrace rip is 7f57a1222891
[12674:12674:0713/015002.447386:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile
ATTENTION: default value of option force_s3tc_enable overridden by environment.

DevTools listening on ws://127.0.0.1:9222/devtools/browser/990590bf-353c-43cc-89f8-e35c2a40d310
[12705:12705:0713/015002.514530:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=12705
[12718:12718:0713/015002.514826:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=12718
[12674:12674:0713/015002.696560:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[12674:12703:0713/015002.696970:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0713/015002.697096:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0713/015002.697251:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0713/015002.697550:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0713/015002.697665:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0713/015002.699360:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0xaf15403, 1
[1:1:0713/015002.699579:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x35c1ef95, 0
[1:1:0713/015002.699734:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x70e0b3, 3
[1:1:0713/015002.699866:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x3d468e54, 2
[1:1:0713/015002.700008:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffff95ffffffefffffffc135 0354fffffff10a 54ffffff8e463d ffffffb3ffffffe07000 , 10104, 4
[1:1:0713/015002.700699:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[12674:12703:0713/015002.700819:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING���5T�
T�F=��p
[12674:12703:0713/015002.700859:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ���5T�
T�F=��p
[1:1:0713/015002.700819:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f3f736930a0, 3
[12674:12703:0713/015002.700992:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0713/015002.700976:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f3f7381f080, 2
[12674:12703:0713/015002.701047:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 12726, 4, 95efc135 0354f10a 548e463d b3e07000 
[1:1:0713/015002.701082:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f3f5d4e1d20, -2
[1:1:0713/015002.708941:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0713/015002.709405:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3d468e54
[1:1:0713/015002.709847:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3d468e54
[1:1:0713/015002.710557:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3d468e54
[1:1:0713/015002.711066:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3d468e54
[1:1:0713/015002.711166:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3d468e54
[1:1:0713/015002.711261:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3d468e54
[1:1:0713/015002.711330:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3d468e54
[1:1:0713/015002.711553:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3d468e54
[1:1:0713/015002.711673:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f3f754597ba
[1:1:0713/015002.711727:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f3f75450def, 7f3f7545977a, 7f3f7545b0cf
[1:1:0713/015002.713377:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3d468e54
[1:1:0713/015002.713555:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3d468e54
[1:1:0713/015002.713894:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3d468e54
[1:1:0713/015002.714670:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3d468e54
[1:1:0713/015002.714793:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3d468e54
[1:1:0713/015002.714909:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3d468e54
[1:1:0713/015002.715024:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3d468e54
[1:1:0713/015002.715547:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3d468e54
[1:1:0713/015002.715730:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f3f754597ba
[1:1:0713/015002.715815:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f3f75450def, 7f3f7545977a, 7f3f7545b0cf
[1:1:0713/015002.718338:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0713/015002.718539:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0713/015002.718652:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe78a97b88, 0x7ffe78a97b08)
[1:1:0713/015002.725308:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0713/015002.727857:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[12674:12674:0713/015003.134988:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[12674:12674:0713/015003.135476:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[12674:12674:0713/015003.144061:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[12674:12674:0713/015003.144117:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[12674:12674:0713/015003.144183:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,12726, 4
[12674:12685:0713/015003.144755:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[12674:12685:0713/015003.144809:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[1:7:0713/015003.146355:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/015003.195366:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x2f6b8e79220
[1:1:0713/015003.195538:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[12674:12698:0713/015003.204242:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0713/015003.399961:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0713/015004.113541:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/015004.115069:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[12674:12674:0713/015004.463663:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[12674:12674:0713/015004.463727:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0713/015004.598920:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/015004.698171:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2a2b429a1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0713/015004.698365:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/015004.708770:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2a2b429a1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0713/015004.708965:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/015004.742896:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/015004.743096:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/015004.893282:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 356, "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/015004.895797:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2a2b429a1f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0713/015004.895976:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/015004.907799:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 357, "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/015004.910778:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2a2b429a1f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0713/015004.910954:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/015004.914769:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[12674:12674:0713/015004.915442:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0713/015004.916593:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x2f6b8e77e20
[1:1:0713/015004.917478:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[12674:12674:0713/015004.917951:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[12674:12674:0713/015004.930161:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[12674:12674:0713/015004.930245:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0713/015004.950432:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/015005.273436:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 416 0x7f3f5f0bc2e0 0x2f6b90e6c60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/015005.274145:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2a2b429a1f78, , , var configData = {"googleBaseUrl":"https://www.google.com.hk/","isAccessibleBrowser":false,"isGoogle
[1:1:0713/015005.274334:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/015005.274950:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[12674:12674:0713/015005.301627:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0713/015005.302740:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x2f6b8e78820
[1:1:0713/015005.302891:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[12674:12674:0713/015005.303969:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0713/015005.310462:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0713/015005.310656:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[12674:12674:0713/015005.312947:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[12674:12674:0713/015005.316819:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[12674:12674:0713/015005.317246:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[12674:12685:0713/015005.321943:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[12674:12685:0713/015005.322010:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[12674:12674:0713/015005.322026:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[12674:12674:0713/015005.322070:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[12674:12674:0713/015005.322143:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,12726, 4
[1:7:0713/015005.326816:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/015005.586552:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0713/015005.696756:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 463 0x7f3f5f0bc2e0 0x2f6b92868e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/015005.697358:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2a2b429a1f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0713/015005.697539:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/015005.697911:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[12674:12674:0713/015005.864839:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[12674:12674:0713/015005.864924:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0713/015005.876442:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[12674:12674:0713/015005.980397:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[12674:12703:0713/015005.980675:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0713/015005.980815:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0713/015005.980969:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0713/015005.981194:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0713/015005.981286:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0713/015005.983407:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0xa2155ef, 1
[1:1:0713/015005.983611:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x415e957, 0
[1:1:0713/015005.983710:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x2c898b1, 3
[1:1:0713/015005.983796:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x1438917c, 2
[1:1:0713/015005.983875:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 57ffffffe91504 ffffffef55210a 7cffffff913814 ffffffb1ffffff98ffffffc802 , 10104, 5
[1:1:0713/015005.984590:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[12674:12703:0713/015005.984803:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGW��U!
|�8���,y[%
[12674:12703:0713/015005.984845:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is W��U!
|�8����,y[%
[1:1:0713/015005.984799:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f3f736930a0, 3
[12674:12703:0713/015005.984970:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 12768, 5, 57e91504 ef55210a 7c913814 b198c802 
[1:1:0713/015005.984972:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f3f7381f080, 2
[1:1:0713/015005.985099:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f3f5d4e1d20, -2
[1:1:0713/015005.994794:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0713/015005.994993:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1438917c
[1:1:0713/015005.995166:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1438917c
[1:1:0713/015005.995431:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1438917c
[1:1:0713/015005.995936:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1438917c
[1:1:0713/015005.996038:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1438917c
[1:1:0713/015005.996133:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1438917c
[1:1:0713/015005.996226:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1438917c
[1:1:0713/015005.996479:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1438917c
[1:1:0713/015005.996610:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f3f754597ba
[1:1:0713/015005.996686:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f3f75450def, 7f3f7545977a, 7f3f7545b0cf
[1:1:0713/015005.998394:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1438917c
[1:1:0713/015005.998600:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1438917c
[1:1:0713/015005.998942:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1438917c
[1:1:0713/015005.999719:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1438917c
[1:1:0713/015005.999837:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1438917c
[1:1:0713/015005.999951:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1438917c
[1:1:0713/015006.000055:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1438917c
[1:1:0713/015006.000550:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1438917c
[1:1:0713/015006.000722:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f3f754597ba
[1:1:0713/015006.000796:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f3f75450def, 7f3f7545977a, 7f3f7545b0cf
[1:1:0713/015006.003408:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0713/015006.003635:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0713/015006.003738:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe78a97b88, 0x7ffe78a97b08)
[1:1:0713/015006.009949:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0713/015006.011154:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/015006.011868:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0713/015006.102471:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x2f6b8e31220
[1:1:0713/015006.102728:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0713/015006.287850:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/015006.288059:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[12674:12674:0713/015006.385788:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[12674:12674:0713/015006.387717:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[12674:12674:0713/015006.408267:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://www.4399dmw.com/
[12674:12685:0713/015006.408297:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[12674:12674:0713/015006.408322:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://www.4399dmw.com/, http://www.4399dmw.com/, 1
[12674:12685:0713/015006.408358:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[12674:12674:0713/015006.408382:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://www.4399dmw.com/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 17:50:06 GMT Content-Type: text/html; charset=utf-8 Transfer-Encoding: chunked Connection: keep-alive Expires: Fri, 12 Jul 2019 18:21:59 GMT Server: nginx Cache-Control: max-age=3600 Content-Encoding: gzip X-Via: 1.1 PSbjsdBGPvu28:8 (Cdn Cache Server V2.0), 1.1 PSjsczsx2hc61:3 (Cdn Cache Server V2.0), 1.1 hangkuan194:6 (Cdn Cache Server V2.0), 1.1 bjdxtck19:0 (Cdn Cache Server V2.0)  ,12768, 5
[1:7:0713/015006.412423:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/015006.423813:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://www.4399dmw.com/
[1:1:0713/015006.437546:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 538, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/015006.439428:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2a2b42ace5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0713/015006.439602:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/015006.442168:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[12674:12674:0713/015006.476829:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://www.4399dmw.com/, http://www.4399dmw.com/, 1
[12674:12674:0713/015006.476892:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://www.4399dmw.com/, http://www.4399dmw.com
[1:1:0713/015006.492804:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/015006.538299:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/015006.556418:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/015006.556844:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2a2b429a1f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0713/015006.557000:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/015006.582920:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/015006.583126:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.4399dmw.com/"
[1:1:0713/015006.787960:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 161 0x7f3f5d194070 0x2f6b87d7b60 , "http://www.4399dmw.com/"
[1:1:0713/015006.788886:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.4399dmw.com/, 37aceda02860, , , //处理pc-移动端映射
function mobileMap(){
    if(location.href.indexOf("mtype=pc") != -1){
//
[1:1:0713/015006.788996:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 1, , , 0
[1:1:0713/015006.789837:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 161 0x7f3f5d194070 0x2f6b87d7b60 , "http://www.4399dmw.com/"
[1:1:0713/015006.804609:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 161 0x7f3f5d194070 0x2f6b87d7b60 , "http://www.4399dmw.com/"
[1:1:0713/015006.806219:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/015006.920149:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.13078, 1926, 1
[1:1:0713/015006.920353:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/015007.257656:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/015007.257845:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.4399dmw.com/"
[1:1:0713/015007.260267:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 221 0x7f3f5d194070 0x2f6b905ad60 , "http://www.4399dmw.com/"
[1:1:0713/015007.275026:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.4399dmw.com/, 37aceda02860, , , /*!
 * jQuery JavaScript Library v1.4.4
 * http://jquery.com/
 *
 * Copyright 2010, John Resig
 * Du
[1:1:0713/015007.275216:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 1, , , 0
[1:1:0713/015007.293887:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 221 0x7f3f5d194070 0x2f6b905ad60 , "http://www.4399dmw.com/"
[1:1:0713/015007.345270:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 221 0x7f3f5d194070 0x2f6b905ad60 , "http://www.4399dmw.com/"
[1:1:0713/015007.348525:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 221 0x7f3f5d194070 0x2f6b905ad60 , "http://www.4399dmw.com/"
[1:1:0713/015007.352149:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 221 0x7f3f5d194070 0x2f6b905ad60 , "http://www.4399dmw.com/"
[1:1:0713/015007.356644:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 221 0x7f3f5d194070 0x2f6b905ad60 , "http://www.4399dmw.com/"
[1:1:0713/015007.360251:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 221 0x7f3f5d194070 0x2f6b905ad60 , "http://www.4399dmw.com/"
[1:1:0713/015007.363830:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 221 0x7f3f5d194070 0x2f6b905ad60 , "http://www.4399dmw.com/"
[1:1:0713/015007.366361:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 221 0x7f3f5d194070 0x2f6b905ad60 , "http://www.4399dmw.com/"
[1:1:0713/015007.368898:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 221 0x7f3f5d194070 0x2f6b905ad60 , "http://www.4399dmw.com/"
[1:1:0713/015007.372523:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 221 0x7f3f5d194070 0x2f6b905ad60 , "http://www.4399dmw.com/"
[1:1:0713/015007.375969:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 221 0x7f3f5d194070 0x2f6b905ad60 , "http://www.4399dmw.com/"
[1:1:0713/015007.379670:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 221 0x7f3f5d194070 0x2f6b905ad60 , "http://www.4399dmw.com/"
[1:1:0713/015007.383430:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 221 0x7f3f5d194070 0x2f6b905ad60 , "http://www.4399dmw.com/"
[1:1:0713/015007.387813:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 221 0x7f3f5d194070 0x2f6b905ad60 , "http://www.4399dmw.com/"
[1:1:0713/015007.391209:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 221 0x7f3f5d194070 0x2f6b905ad60 , "http://www.4399dmw.com/"
[1:1:0713/015007.943304:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 313 0x7f3f5f0bc2e0 0x2f6b9044c60 , "http://www.4399dmw.com/"
[1:1:0713/015007.944022:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.4399dmw.com/, 37aceda02860, , , !function(){var e=/([http|https]:\/\/[a-zA-Z0-9\_\.]+\.baidu\.com)/gi,r=window.location.href,o=docum
[1:1:0713/015007.944148:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 1, , , 0
[1:1:0713/015007.975846:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 318, "http://www.4399dmw.com/"
[1:1:0713/015007.978282:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.4399dmw.com/, 37aceda02860, , , (function(){function p(){this.c="3217746";this.ca="z";this.Y="pic";this.V="";this.X="";this.D="15629
[1:1:0713/015007.978470:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 1, , , 0
[1:1:0713/015008.220571:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 353, "http://www.4399dmw.com/"
[1:1:0713/015008.221954:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.4399dmw.com/, 37aceda02860, , , !function(){var p,q,r,a=function(){var b,c,d,e,a=document.getElementsByTagName("script");for(b=0,c=a
[1:1:0713/015008.222125:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 1, , , 0
[1:1:0713/015009.357474:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/015009.476803:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "http://www.4399dmw.com/"
[1:1:0713/015009.477696:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.4399dmw.com/, 37aceda02860, , a.(anonymous function).e.(anonymous function).onload.e.(anonymous function).onerror.e.(anonymous function).onabort, (){try{this.onload=this.onerror=this.onabort=null,e[this.ka]=null}catch(f){}}
[1:1:0713/015009.477830:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 1, , , 0
[1:1:0713/015009.532874:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/015009.533073:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.4399dmw.com/"
[1:1:0713/015009.535056:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 409 0x7f3f5d194070 0x2f6b8fddbe0 , "http://www.4399dmw.com/"
[1:1:0713/015009.542849:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.4399dmw.com/, 37aceda02860, , , (function(){var h={},mt={},c={id:"6bed68d13e86775334dd3a113f40a535",dm:["dm.4399.com","4399.union.tu
[1:1:0713/015009.543022:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 1, , , 0
[1:1:0713/015009.556202:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x500731029c8, 0x2f6b8a4e9a8
[1:1:0713/015009.556375:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.4399dmw.com/", 100
[1:1:0713/015009.556557:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.4399dmw.com/, 421
[1:1:0713/015009.556679:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 421 0x7f3f5d194070 0x2f6b8fddde0 , 5:3_http://www.4399dmw.com/, 1, -5:3_http://www.4399dmw.com/, 409 0x7f3f5d194070 0x2f6b8fddbe0 
[1:1:0713/015011.349134:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[12674:12674:0713/015026.913367:INFO:CONSOLE(2)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://s16.cnzz.com/stat.php?id=3217746&web_id=3217746&show=pic, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://www.4399dmw.com/js/dmcount.js (2)
[12674:12674:0713/015026.914382:INFO:CONSOLE(2)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://s16.cnzz.com/stat.php?id=3217746&web_id=3217746&show=pic, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://www.4399dmw.com/js/dmcount.js (2)
[12674:12674:0713/015026.915106:INFO:CONSOLE(4)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://hm.baidu.com/h.js?6bed68d13e86775334dd3a113f40a535, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://www.4399dmw.com/js/dmcount.js (4)
[12674:12674:0713/015026.932416:INFO:CONSOLE(17)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://c.cnzz.com/core.php?web_id=3217746&show=pic&t=z, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://s16.cnzz.com/stat.php?id=3217746&web_id=3217746&show=pic (17)
[12674:12674:0713/015026.933278:INFO:CONSOLE(17)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://c.cnzz.com/core.php?web_id=3217746&show=pic&t=z, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://s16.cnzz.com/stat.php?id=3217746&web_id=3217746&show=pic (17)
[3:3:0713/015026.969239:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0713/015027.034718:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.4399dmw.com/", 600000
[1:1:0713/015027.034980:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.4399dmw.com/, 466
[1:1:0713/015027.035155:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 466 0x7f3f5d194070 0x2f6b904cd60 , 5:3_http://www.4399dmw.com/, 1, -5:3_http://www.4399dmw.com/, 409 0x7f3f5d194070 0x2f6b8fddbe0 
[1:1:0713/015027.035636:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.4399dmw.com/", 5000
[1:1:0713/015027.035850:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.4399dmw.com/, 467
[1:1:0713/015027.035994:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 467 0x7f3f5d194070 0x2f6b9061560 , 5:3_http://www.4399dmw.com/, 1, -5:3_http://www.4399dmw.com/, 409 0x7f3f5d194070 0x2f6b8fddbe0 
[1:1:0713/015027.060104:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 17.527, 0, 0
[1:1:0713/015027.060278:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/015027.203033:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.4399dmw.com/, 37aceda02860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0713/015027.221395:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 1, , , 0
[1:1:0713/015027.603660:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/015027.603865:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.4399dmw.com/"
[1:1:0713/015027.607236:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://www.4399dmw.com/"
[1:1:0713/015027.607630:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.4399dmw.com/, 37aceda02860, , u, (){t.removeEventListener("DOMContentLoaded",u,
false);b.ready()}
[1:1:0713/015027.607777:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 1, , , 0
[1:1:0713/015027.657552:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[12674:12674:0713/015027.659040:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0713/015027.660116:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x2f6b96f5820
[1:1:0713/015027.660226:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[12674:12674:0713/015027.661494:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: baidu_ad_frame_846418, 4, 4, 
[1:1:0713/015027.667776:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0713/015027.667942:INFO:render_frame_impl.cc(7019)] 	 [url] = http://www.4399dmw.com
[1:1:0713/015027.669278:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[12674:12674:0713/015027.673140:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://www.4399dmw.com/
[1:1:0713/015027.674286:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 5, 0x2f6b9681220
[1:1:0713/015027.674512:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 5
[12674:12674:0713/015027.676923:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[12674:12674:0713/015027.679152:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: baidu_ad_frame_2409097, 5, 5, 
[1:1:0713/015027.681920:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0713/015027.682093:INFO:render_frame_impl.cc(7019)] 	 [url] = http://www.4399dmw.com
[12674:12674:0713/015027.690400:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://www.4399dmw.com/
[12674:12674:0713/015027.762082:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[12674:12674:0713/015027.763863:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[12674:12685:0713/015027.772736:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 4
[12674:12685:0713/015027.772800:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 4, HandleIncomingMessage, HandleIncomingMessage
[12674:12674:0713/015027.772823:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://www.4399dmw.com/
[12674:12674:0713/015027.772865:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_http://www.4399dmw.com/, http://www.4399dmw.com/baiduad/proxy.html?id=846418, 4
[12674:12674:0713/015027.772928:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:4_http://www.4399dmw.com/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 17:50:27 GMT Content-Type: text/html; charset=utf-8 Transfer-Encoding: chunked Connection: keep-alive Expires: Fri, 12 Jul 2019 18:50:27 GMT Server: nginx Cache-Control: max-age=3600 Content-Encoding: gzip X-Via: 1.1 PSbjsdBGPvu28:1 (Cdn Cache Server V2.0), 1.1 PSjsczsx2hc61:10 (Cdn Cache Server V2.0), 1.1 PS-SHA-0152e213:4 (Cdn Cache Server V2.0), 1.1 bjdxtck18:6 (Cdn Cache Server V2.0)  ,12768, 5
[1:7:0713/015027.775319:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[12674:12674:0713/015027.777792:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[12674:12674:0713/015027.779575:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[12674:12685:0713/015027.788174:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 5
[12674:12685:0713/015027.788242:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 5, HandleIncomingMessage, HandleIncomingMessage
[12674:12674:0713/015027.788261:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://www.4399dmw.com/
[12674:12674:0713/015027.788305:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:5_http://www.4399dmw.com/, http://www.4399dmw.com/baiduad/proxy.html?id=2409097, 5
[12674:12674:0713/015027.788372:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:5_http://www.4399dmw.com/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 17:50:27 GMT Content-Type: text/html; charset=utf-8 Transfer-Encoding: chunked Connection: keep-alive Expires: Fri, 12 Jul 2019 18:30:23 GMT Server: nginx Cache-Control: max-age=3600 Content-Encoding: gzip X-Via: 1.1 PSbjsdBGPru29:9 (Cdn Cache Server V2.0), 1.1 PSjsczsx2zx66:7 (Cdn Cache Server V2.0), 1.1 PS-SHA-0152e213:4 (Cdn Cache Server V2.0), 1.1 bjdxtck18:6 (Cdn Cache Server V2.0)  ,12768, 5
[1:7:0713/015027.790763:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/015027.815428:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x500731029c8, 0x2f6b8a4ea10
[1:1:0713/015027.815632:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.4399dmw.com/", 0
[1:1:0713/015027.815850:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.4399dmw.com/, 532
[1:1:0713/015027.815953:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 532 0x7f3f5d194070 0x2f6b903fde0 , 5:3_http://www.4399dmw.com/, 1, -5:3_http://www.4399dmw.com/, 471 0x7f3f5d194070 0x2f6b9040ae0 
[1:1:0713/015027.871040:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.4399dmw.com/", 2500
[1:1:0713/015027.871351:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.4399dmw.com/, 533
[1:1:0713/015027.871468:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 533 0x7f3f5d194070 0x2f6b8ef22e0 , 5:3_http://www.4399dmw.com/, 1, -5:3_http://www.4399dmw.com/, 471 0x7f3f5d194070 0x2f6b9040ae0 
[1:1:0713/015028.043098:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://www.4399dmw.com/"
[1:1:0713/015028.146356:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.4399dmw.com/, 421, 7f3f5fad9881
[1:1:0713/015028.155115:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"37aceda02860","ptid":"409 0x7f3f5d194070 0x2f6b8fddbe0 ","rf":"5:3_http://www.4399dmw.com/"}
[1:1:0713/015028.155328:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.4399dmw.com/","ptid":"409 0x7f3f5d194070 0x2f6b8fddbe0 ","rf":"5:3_http://www.4399dmw.com/"}
[1:1:0713/015028.155585:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.4399dmw.com/"
[1:1:0713/015028.155879:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.4399dmw.com/, 37aceda02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/015028.155986:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 1, , , 0
[1:1:0713/015028.156353:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x500731029c8, 0x2f6b8a4e950
[1:1:0713/015028.156442:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.4399dmw.com/", 100
[1:1:0713/015028.156592:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.4399dmw.com/, 551
[1:1:0713/015028.156697:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 551 0x7f3f5d194070 0x2f6b9a1f1e0 , 5:3_http://www.4399dmw.com/, 1, -5:3_http://www.4399dmw.com/, 421 0x7f3f5d194070 0x2f6b8fddde0 
[1:1:0713/015028.278505:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.4399dmw.com/"
[1:1:0713/015028.279073:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.4399dmw.com/, 37aceda02860, , a.(anonymous function).e.(anonymous function).onload.e.(anonymous function).onerror.e.(anonymous function).onabort, (){try{this.onload=this.onerror=this.onabort=null,e[this.ka]=null}catch(f){}}
[1:1:0713/015028.279317:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 1, , , 0
[1:1:0713/015028.658948:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.4399dmw.com/, 37aceda02860, , , document.readyState
[1:1:0713/015028.659154:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 1, , , 0
[1:1:0713/015028.910249:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:4_http://www.4399dmw.com/
[1:1:0713/015028.962464:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:5_http://www.4399dmw.com/
[1:1:0713/015029.109417:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://www.4399dmw.com/"
[1:1:0713/015029.109824:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.4399dmw.com/, 37aceda02860, , w.onreadystatechange, (m){if(!w||w.readyState===0||m==="abort"){J||c.handleComplete(b,w,e,f);J=true;if(w)w.onreadystatecha
[1:1:0713/015029.109948:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 1, , , 0
[1:1:0713/015029.110525:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://www.4399dmw.com/"
[1:1:0713/015029.111857:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://www.4399dmw.com/"
[1:1:0713/015029.112208:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0xf7657209ef0
[1:1:0713/015029.163928:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.4399dmw.com/, 532, 7f3f5fad9881
[1:1:0713/015029.173743:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"37aceda02860","ptid":"471 0x7f3f5d194070 0x2f6b9040ae0 ","rf":"5:3_http://www.4399dmw.com/"}
[1:1:0713/015029.173942:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.4399dmw.com/","ptid":"471 0x7f3f5d194070 0x2f6b9040ae0 ","rf":"5:3_http://www.4399dmw.com/"}
[1:1:0713/015029.174128:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.4399dmw.com/"
[1:1:0713/015029.174403:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.4399dmw.com/, 37aceda02860, , , (){
                if(options.type === 'scroll'){
                    scrollImgs = imgs;
          
[1:1:0713/015029.174504:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 1, , , 0
[1:1:0713/015029.322371:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.4399dmw.com/, 551, 7f3f5fad9881
[1:1:0713/015029.331959:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"37aceda02860","ptid":"421 0x7f3f5d194070 0x2f6b8fddde0 ","rf":"5:3_http://www.4399dmw.com/"}
[1:1:0713/015029.332128:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.4399dmw.com/","ptid":"421 0x7f3f5d194070 0x2f6b8fddde0 ","rf":"5:3_http://www.4399dmw.com/"}
[1:1:0713/015029.332281:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.4399dmw.com/"
[1:1:0713/015029.332544:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.4399dmw.com/, 37aceda02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/015029.332618:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 1, , , 0
[1:1:0713/015029.332879:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x500731029c8, 0x2f6b8a4e950
[1:1:0713/015029.332966:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.4399dmw.com/", 100
[1:1:0713/015029.333137:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.4399dmw.com/, 617
[1:1:0713/015029.333273:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 617 0x7f3f5d194070 0x2f6b9c1e0e0 , 5:3_http://www.4399dmw.com/, 1, -5:3_http://www.4399dmw.com/, 551 0x7f3f5d194070 0x2f6b9a1f1e0 
[1:1:0713/015029.607144:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.4399dmw.com/, 37aceda02860, , , document.readyState
[1:1:0713/015029.607316:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 1, , , 0
[12674:12674:0713/015029.876938:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_http://www.4399dmw.com/, http://www.4399dmw.com/, 4
[12674:12674:0713/015029.877020:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, http://www.4399dmw.com/, http://www.4399dmw.com
[1:1:0713/015029.877601:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[12674:12674:0713/015029.906449:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:5_http://www.4399dmw.com/, http://www.4399dmw.com/, 5
[12674:12674:0713/015029.906508:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 5, 5, http://www.4399dmw.com/, http://www.4399dmw.com
[1:1:0713/015029.907229:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/015029.941352:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 596 0x7f3f5f0bc2e0 0x2f6b9aa7a60 , "http://www.4399dmw.com/"
[1:1:0713/015029.942472:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.4399dmw.com/, 37aceda02860, , , window._bd_share_main?window._bd_share_is_recently_loaded=!0:(window._bd_share_is_recently_loaded=!1
[1:1:0713/015029.942624:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 1, , , 0
[1:1:0713/015029.975312:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x500731029c8, 0x2f6b8a4e9c8
[1:1:0713/015029.975510:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.4399dmw.com/", 15000
[1:1:0713/015029.975768:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.4399dmw.com/, 650
[1:1:0713/015029.975950:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 650 0x7f3f5d194070 0x2f6b9ba28e0 , 5:3_http://www.4399dmw.com/, 1, -5:3_http://www.4399dmw.com/, 596 0x7f3f5f0bc2e0 0x2f6b9aa7a60 
[1:1:0713/015029.981628:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x500731029c8, 0x2f6b8a4e9c8
[1:1:0713/015029.982016:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.4399dmw.com/", 15000
[1:1:0713/015029.982208:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.4399dmw.com/, 652
[1:1:0713/015029.982337:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 652 0x7f3f5d194070 0x2f6b9c1e1e0 , 5:3_http://www.4399dmw.com/, 1, -5:3_http://www.4399dmw.com/, 596 0x7f3f5f0bc2e0 0x2f6b9aa7a60 
[1:1:0713/015029.985009:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x500731029c8, 0x2f6b8a4e9c8
[1:1:0713/015029.985171:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.4399dmw.com/", 3000
[1:1:0713/015029.985356:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.4399dmw.com/, 654
[1:1:0713/015029.985482:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 654 0x7f3f5d194070 0x2f6ba3e7660 , 5:3_http://www.4399dmw.com/, 1, -5:3_http://www.4399dmw.com/, 596 0x7f3f5f0bc2e0 0x2f6b9aa7a60 
[1:1:0713/015030.012779:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 597 0x7f3f5f0bc2e0 0x2f6b8fe8ce0 , "http://www.4399dmw.com/"
[1:1:0713/015030.015774:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.4399dmw.com/, 37aceda02860, , , window._bd_share_main?window._bd_share_is_recently_loaded=!0:(window._bd_share_is_recently_loaded=!1
[1:1:0713/015030.015945:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 1, , , 0
[1:1:0713/015030.101432:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "http://www.4399dmw.com/"
[1:1:0713/015030.101814:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.4399dmw.com/, 37aceda02860, , changeScreen, () {
        winWidth = document.documentElement.clientWidth;
        if (winWidth > 1340) {
       
[1:1:0713/015030.101919:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 1, , , 0
[1:1:0713/015030.104623:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "http://www.4399dmw.com/"
[1:1:0713/015030.113736:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 200, 0x500731029c8, 0x2f6b8a4e9f0
[1:1:0713/015030.113907:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.4399dmw.com/", 200
[1:1:0713/015030.114086:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.4399dmw.com/, 663
[1:1:0713/015030.114210:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 663 0x7f3f5d194070 0x2f6b901c760 , 5:3_http://www.4399dmw.com/, 1, -5:3_http://www.4399dmw.com/, 606 0x7f3f6c4a5960 0x2f6ba14c920 0x2f6ba14c930 
[1:1:0713/015030.231717:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.4399dmw.com/"
[1:1:0713/015030.232182:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.4399dmw.com/, 37aceda02860, , k.onload, (){k.onload=w;k=window[d]=w;a&&a(b)}
[1:1:0713/015030.232329:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 1, , , 0
[1:1:0713/015030.256949:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.4399dmw.com/, 617, 7f3f5fad9881
[1:1:0713/015030.267729:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"37aceda02860","ptid":"551 0x7f3f5d194070 0x2f6b9a1f1e0 ","rf":"5:3_http://www.4399dmw.com/"}
[1:1:0713/015030.267923:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.4399dmw.com/","ptid":"551 0x7f3f5d194070 0x2f6b9a1f1e0 ","rf":"5:3_http://www.4399dmw.com/"}
[1:1:0713/015030.268077:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.4399dmw.com/"
[1:1:0713/015030.268331:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.4399dmw.com/, 37aceda02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/015030.268438:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 1, , , 0
[1:1:0713/015030.268711:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x500731029c8, 0x2f6b8a4e950
[1:1:0713/015030.268790:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.4399dmw.com/", 100
[1:1:0713/015030.268944:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.4399dmw.com/, 673
[1:1:0713/015030.269021:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 673 0x7f3f5d194070 0x2f6b97dfee0 , 5:3_http://www.4399dmw.com/, 1, -5:3_http://www.4399dmw.com/, 617 0x7f3f5d194070 0x2f6b9c1e0e0 
[1:1:0713/015030.279177:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.4399dmw.com/, 37aceda02860, , , document.readyState
[1:1:0713/015030.279323:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 1, , , 0
[1:1:0713/015030.356517:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/015030.451375:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/015030.725888:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.4399dmw.com/, 37aceda02860, , , document.readyState
[1:1:0713/015030.726062:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 1, , , 0
[1:1:0713/015030.749291:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.4399dmw.com/, 663, 7f3f5fad9881
[1:1:0713/015030.760126:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"37aceda02860","ptid":"606 0x7f3f6c4a5960 0x2f6ba14c920 0x2f6ba14c930 ","rf":"5:3_http://www.4399dmw.com/"}
[1:1:0713/015030.760319:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.4399dmw.com/","ptid":"606 0x7f3f6c4a5960 0x2f6ba14c920 0x2f6ba14c930 ","rf":"5:3_http://www.4399dmw.com/"}
[1:1:0713/015030.760479:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.4399dmw.com/"
[1:1:0713/015030.760739:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.4399dmw.com/, 37aceda02860, , , (){that.loadByScroll()}
[1:1:0713/015030.760826:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 1, , , 0
[1:1:0713/015030.900776:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/015030.900938:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.4399dmw.com/baiduad/proxy.html?id=846418"
[1:1:0713/015030.916394:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.4399dmw.com/, 673, 7f3f5fad9881
[1:1:0713/015030.928160:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"37aceda02860","ptid":"617 0x7f3f5d194070 0x2f6b9c1e0e0 ","rf":"5:3_http://www.4399dmw.com/"}
[1:1:0713/015030.928387:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.4399dmw.com/","ptid":"617 0x7f3f5d194070 0x2f6b9c1e0e0 ","rf":"5:3_http://www.4399dmw.com/"}
[1:1:0713/015030.928569:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.4399dmw.com/"
[1:1:0713/015030.928869:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.4399dmw.com/, 37aceda02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/015030.929244:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 1, , , 0
[1:1:0713/015030.929551:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x500731029c8, 0x2f6b8a4e950
[1:1:0713/015030.929659:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.4399dmw.com/", 100
[1:1:0713/015030.929832:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.4399dmw.com/, 708
[1:1:0713/015030.929955:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 708 0x7f3f5d194070 0x2f6b9a41660 , 5:3_http://www.4399dmw.com/, 1, -5:3_http://www.4399dmw.com/, 673 0x7f3f5d194070 0x2f6b97dfee0 
[1:1:0713/015030.930435:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.4399dmw.com/, 533, 7f3f5fad98db
[1:1:0713/015030.941765:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"37aceda02860","ptid":"471 0x7f3f5d194070 0x2f6b9040ae0 ","rf":"5:3_http://www.4399dmw.com/"}
[1:1:0713/015030.941960:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.4399dmw.com/","ptid":"471 0x7f3f5d194070 0x2f6b9040ae0 ","rf":"5:3_http://www.4399dmw.com/"}
[1:1:0713/015030.942143:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.4399dmw.com/, 709
[1:1:0713/015030.942249:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 709 0x7f3f5d194070 0x2f6b97da7e0 , 5:3_http://www.4399dmw.com/, 0, , 533 0x7f3f5d194070 0x2f6b8ef22e0 
[1:1:0713/015030.942387:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.4399dmw.com/"
[1:1:0713/015030.942635:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.4399dmw.com/, 37aceda02860, , , (){
					_this.scroll();
				}
[1:1:0713/015030.942721:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 1, , , 0
[1:1:0713/015030.979630:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.4399dmw.com/", 13
[1:1:0713/015030.979857:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.4399dmw.com/, 712
[1:1:0713/015030.979964:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 712 0x7f3f5d194070 0x2f6ba544360 , 5:3_http://www.4399dmw.com/, 1, -5:3_http://www.4399dmw.com/, 533 0x7f3f5d194070 0x2f6b8ef22e0 
[1:1:0713/015031.014554:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/015031.014739:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.4399dmw.com/baiduad/proxy.html?id=2409097"
[1:1:0713/015031.064965:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 688 0x7f3f5f0bc2e0 0x2f6ba2a6060 , "http://www.4399dmw.com/"
[1:1:0713/015031.065667:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.4399dmw.com/, 37aceda02860, , , window._bd_share_main.F.module("share/share_api",function(e,t,n){var r=e("base/tangram").T,i=e("base
[1:1:0713/015031.065773:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 1, , , 0
[1:1:0713/015031.073462:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x500731029c8, 0x2f6b8a4e990
[1:1:0713/015031.073626:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.4399dmw.com/", 15000
[1:1:0713/015031.073820:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.4399dmw.com/, 724
[1:1:0713/015031.073965:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 724 0x7f3f5d194070 0x2f6b8ef8a60 , 5:3_http://www.4399dmw.com/, 1, -5:3_http://www.4399dmw.com/, 688 0x7f3f5f0bc2e0 0x2f6ba2a6060 
[1:1:0713/015031.085675:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x500731029c8, 0x2f6b8a4e990
[1:1:0713/015031.085855:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.4399dmw.com/", 15000
[1:1:0713/015031.086042:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.4399dmw.com/, 725
[1:1:0713/015031.086166:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 725 0x7f3f5d194070 0x2f6ba2b9e60 , 5:3_http://www.4399dmw.com/, 1, -5:3_http://www.4399dmw.com/, 688 0x7f3f5f0bc2e0 0x2f6ba2a6060 
[1:1:0713/015031.088552:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.4399dmw.com/"
[1:1:0713/015031.129120:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 689 0x7f3f5f0bc2e0 0x2f6b9b718e0 , "http://www.4399dmw.com/"
[1:1:0713/015031.129614:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.4399dmw.com/, 37aceda02860, , , window._bd_share_main.F.module("view/share_view",function(e,t,n){var r=e("base/tangram").T,i=e("base
[1:1:0713/015031.129736:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 1, , , 0
[1:1:0713/015031.141347:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x500731029c8, 0x2f6b8a4e990
[1:1:0713/015031.141545:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.4399dmw.com/", 15000
[1:1:0713/015031.141733:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.4399dmw.com/, 734
[1:1:0713/015031.141858:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 734 0x7f3f5d194070 0x2f6b9ba45e0 , 5:3_http://www.4399dmw.com/, 1, -5:3_http://www.4399dmw.com/, 689 0x7f3f5f0bc2e0 0x2f6b9b718e0 
[1:1:0713/015031.144319:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.4399dmw.com/"
[1:1:0713/015031.217741:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.4399dmw.com/, 37aceda02860, , , document.readyState
[1:1:0713/015031.217981:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 1, , , 0
[1:1:0713/015031.411367:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/015031.438557:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.4399dmw.com/, 712, 7f3f5fad98db
[1:1:0713/015031.450317:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"37aceda02860","ptid":"533 0x7f3f5d194070 0x2f6b8ef22e0 ","rf":"5:3_http://www.4399dmw.com/"}
[1:1:0713/015031.450549:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.4399dmw.com/","ptid":"533 0x7f3f5d194070 0x2f6b8ef22e0 ","rf":"5:3_http://www.4399dmw.com/"}
[1:1:0713/015031.450795:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.4399dmw.com/, 755
[1:1:0713/015031.450931:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 755 0x7f3f5d194070 0x2f6ba62c9e0 , 5:3_http://www.4399dmw.com/, 0, , 712 0x7f3f5d194070 0x2f6ba544360 
[1:1:0713/015031.451122:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.4399dmw.com/"
[1:1:0713/015031.451437:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.4399dmw.com/, 37aceda02860, , tick, (){for(var a=
c.timers,b=0;b<a.length;b++)a[b]()||a.splice(b--,1);a.length||c.fx.stop()}
[1:1:0713/015031.451543:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 1, , , 0
[1:1:0713/015031.521170:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.4399dmw.com/, 708, 7f3f5fad9881
[1:1:0713/015031.533254:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"37aceda02860","ptid":"673 0x7f3f5d194070 0x2f6b97dfee0 ","rf":"5:3_http://www.4399dmw.com/"}
[1:1:0713/015031.533481:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.4399dmw.com/","ptid":"673 0x7f3f5d194070 0x2f6b97dfee0 ","rf":"5:3_http://www.4399dmw.com/"}
[1:1:0713/015031.533737:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.4399dmw.com/"
[1:1:0713/015031.534079:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.4399dmw.com/, 37aceda02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/015031.534249:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 1, , , 0
[1:1:0713/015031.534579:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x500731029c8, 0x2f6b8a4e950
[1:1:0713/015031.534688:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.4399dmw.com/", 100
[1:1:0713/015031.534856:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.4399dmw.com/, 759
[1:1:0713/015031.534967:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 759 0x7f3f5d194070 0x2f6b9c192e0 , 5:3_http://www.4399dmw.com/, 1, -5:3_http://www.4399dmw.com/, 708 0x7f3f5d194070 0x2f6b9a41660 
[1:1:0713/015031.676449:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.4399dmw.com/, 37aceda02860, , , document.readyState
[1:1:0713/015031.676636:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 1, , , 0
[1:1:0713/015031.900140:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.4399dmw.com/, 755, 7f3f5fad98db
[1:1:0713/015031.913158:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"712 0x7f3f5d194070 0x2f6ba544360 ","rf":"5:3_http://www.4399dmw.com/"}
[1:1:0713/015031.913398:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"712 0x7f3f5d194070 0x2f6ba544360 ","rf":"5:3_http://www.4399dmw.com/"}
[1:1:0713/015031.913657:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.4399dmw.com/, 776
[1:1:0713/015031.913814:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 776 0x7f3f5d194070 0x2f6ba624be0 , 5:3_http://www.4399dmw.com/, 0, , 755 0x7f3f5d194070 0x2f6ba62c9e0 
[1:1:0713/015031.914023:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.4399dmw.com/"
[1:1:0713/015031.914327:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.4399dmw.com/, 37aceda02860, , tick, (){for(var a=
c.timers,b=0;b<a.length;b++)a[b]()||a.splice(b--,1);a.length||c.fx.stop()}
[1:1:0713/015031.914433:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 1, , , 0
[1:1:0713/015031.921932:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x500731029c8, 0x2f6b8a4e950
[1:1:0713/015031.922105:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.4399dmw.com/", 0
[1:1:0713/015031.922288:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.4399dmw.com/, 778
[1:1:0713/015031.922374:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 778 0x7f3f5d194070 0x2f6ba2b8fe0 , 5:3_http://www.4399dmw.com/, 1, -5:3_http://www.4399dmw.com/, 755 0x7f3f5d194070 0x2f6ba62c9e0 
[1:1:0713/015031.922668:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x500731029c8, 0x2f6b8a4e950
[1:1:0713/015031.922772:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.4399dmw.com/", 0
[1:1:0713/015031.922932:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.4399dmw.com/, 779
[1:1:0713/015031.923056:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 779 0x7f3f5d194070 0x2f6ba62bc60 , 5:3_http://www.4399dmw.com/, 1, -5:3_http://www.4399dmw.com/, 755 0x7f3f5d194070 0x2f6ba62c9e0 
[1:1:0713/015031.965363:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 762 0x7f3f5f0bc2e0 0x2f6ba5207e0 , "http://www.4399dmw.com/"
[1:1:0713/015031.965859:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.4399dmw.com/, 37aceda02860, , , window._bd_share_main.F.module("share/api_base",function(e,t,n){var r=e("base/tangram").T,i=e("base/
[1:1:0713/015031.965970:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 1, , , 0
[1:1:0713/015031.971391:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.4399dmw.com/"
[1:1:0713/015032.000109:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 763 0x7f3f5f0bc2e0 0x2f6ba2aed60 , "http://www.4399dmw.com/"
[1:1:0713/015032.000663:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.4399dmw.com/, 37aceda02860, , , window._bd_share_main.F.module("view/view_base",function(e,t,n){var r=e("base/tangram").T,i=e("conf/
[1:1:0713/015032.000792:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 1, , , 0
[1:1:0713/015032.008484:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.4399dmw.com/"
[1:1:0713/015032.025463:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.4399dmw.com/, 759, 7f3f5fad9881
[1:1:0713/015032.038382:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"37aceda02860","ptid":"708 0x7f3f5d194070 0x2f6b9a41660 ","rf":"5:3_http://www.4399dmw.com/"}
[1:1:0713/015032.038596:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.4399dmw.com/","ptid":"708 0x7f3f5d194070 0x2f6b9a41660 ","rf":"5:3_http://www.4399dmw.com/"}
[1:1:0713/015032.038825:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.4399dmw.com/"
[1:1:0713/015032.039144:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.4399dmw.com/, 37aceda02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/015032.039267:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 1, , , 0
[1:1:0713/015032.039586:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x500731029c8, 0x2f6b8a4e950
[1:1:0713/015032.039722:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.4399dmw.com/", 100
[1:1:0713/015032.039939:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.4399dmw.com/, 790
[1:1:0713/015032.040084:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 790 0x7f3f5d194070 0x2f6ba5a8560 , 5:3_http://www.4399dmw.com/, 1, -5:3_http://www.4399dmw.com/, 759 0x7f3f5d194070 0x2f6b9c192e0 
[1:1:0713/015032.080806:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 768 0x7f3f5f0bc2e0 0x2f6ba62ac60 , "http://www.4399dmw.com/"
[1:1:0713/015032.094858:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.4399dmw.com/, 37aceda02860, , , window._bd_share_main.F.module("base/tangram",function(e,t){var n,r=n=function(){var e,t=e=t||functi
[1:1:0713/015032.095068:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 1, , , 0
[1:1:0713/015032.286370:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/015032.390551:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x500731029c8, 0x2f6b8a4e990
[1:1:0713/015032.390789:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.4399dmw.com/", 15000
[1:1:0713/015032.391116:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.4399dmw.com/, 793
[1:1:0713/015032.391284:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 793 0x7f3f5d194070 0x2f6ba2b2c60 , 5:3_http://www.4399dmw.com/, 1, -5:3_http://www.4399dmw.com/, 768 0x7f3f5f0bc2e0 0x2f6ba62ac60 
[1:1:0713/015032.415339:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x500731029c8, 0x2f6b8a4e990
[1:1:0713/015032.415527:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.4399dmw.com/", 0
[1:1:0713/015032.415787:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.4399dmw.com/, 796
[1:1:0713/015032.415905:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 796 0x7f3f5d194070 0x2f6ba58d760 , 5:3_http://www.4399dmw.com/, 1, -5:3_http://www.4399dmw.com/, 768 0x7f3f5f0bc2e0 0x2f6ba62ac60 
[1:1:0713/015032.416130:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x500731029c8, 0x2f6b8a4e990
[1:1:0713/015032.416195:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.4399dmw.com/", 15000
[1:1:0713/015032.416317:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.4399dmw.com/, 797
[1:1:0713/015032.416394:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 797 0x7f3f5d194070 0x2f6b9ba2ce0 , 5:3_http://www.4399dmw.com/, 1, -5:3_http://www.4399dmw.com/, 768 0x7f3f5f0bc2e0 0x2f6ba62ac60 
[1:1:0713/015032.423984:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.4399dmw.com/"
[1:1:0713/015032.453864:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.4399dmw.com/, 37aceda02860, , , document.readyState
[1:1:0713/015032.454023:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 1, , , 0
[1:1:0713/015032.585864:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.4399dmw.com/, 778, 7f3f5fad9881
[1:1:0713/015032.600548:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"37aceda02860","ptid":"755 0x7f3f5d194070 0x2f6ba62c9e0 ","rf":"5:3_http://www.4399dmw.com/"}
[1:1:0713/015032.600744:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.4399dmw.com/","ptid":"755 0x7f3f5d194070 0x2f6ba62c9e0 ","rf":"5:3_http://www.4399dmw.com/"}
[1:1:0713/015032.600963:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.4399dmw.com/"
[1:1:0713/015032.601278:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.4399dmw.com/, 37aceda02860, , , (){
							options.afterNext.call(_this);
							options.afterSlide.call(_this);
						}
[1:1:0713/015032.601394:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 1, , , 0
[1:1:0713/015032.621628:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.4399dmw.com/", 13
[1:1:0713/015032.621907:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.4399dmw.com/, 815
[1:1:0713/015032.622087:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 815 0x7f3f5d194070 0x2f6bab705e0 , 5:3_http://www.4399dmw.com/, 1, -5:3_http://www.4399dmw.com/, 778 0x7f3f5d194070 0x2f6ba2b8fe0 
[1:1:0713/015032.666162:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 782 0x7f3f7381f080 0x2f6ba5d52e0 1 0 0x2f6ba5d52f8 , "http://www.4399dmw.com/baiduad/proxy.html?id=2409097"
[1:1:0713/015032.685022:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:5_http://www.4399dmw.com/, 37acedac99f0, , , try{!function(){window.___baidu_union_||(window.___baidu_union_={}),window.___baidu_union_dup_||(win
[1:1:0713/015032.685238:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=2409097", "www.4399dmw.com", 5, 1, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015033.229949:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac99f0, toString, 
[1:1:0713/015033.230116:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 2, , , 0
[1:1:0713/015033.230875:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getNotCrossDomainTopWindow (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getTopWindowUrl (http://cbjs.baidu.com/js/m.js:1:1)
	Object.value (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	Object.getPageSearchId (http://cbjs.baidu.com/js/m.js:1:1)
	Object.prepareApi (http://cbjs.baidu.com/js/m.js:1:1)
	Object.process (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015033.231044:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/, 37acedac99f0, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015033.231178:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=2409097", "www.4399dmw.com", 5, 3, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015033.231713:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getNotCrossDomainTopWindow (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getTopWindowUrl (http://cbjs.baidu.com/js/m.js:1:1)
	Object.value (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	Object.getPageSearchId (http://cbjs.baidu.com/js/m.js:1:1)
	Object.prepareApi (http://cbjs.baidu.com/js/m.js:1:1)
	Object.process (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://cbjs.baidu.com/js/m.js:1:1

		remove user.e_f5ebf504 -> 0
		remove user.f_76edad6e -> 0
[1:1:0713/015033.280862:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac99f0, toString, 
[1:1:0713/015033.281098:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 4, , , 0
[1:1:0713/015033.281647:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.value (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	Object.getOneParam (http://cbjs.baidu.com/js/m.js:1:1)
	Object.launch (http://cbjs.baidu.com/js/m.js:1:1)
	Object.process (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015033.281872:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 5, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/, 37acedac99f0, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015033.282055:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=2409097", "www.4399dmw.com", 5, 5, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015033.282526:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.value (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	Object.getOneParam (http://cbjs.baidu.com/js/m.js:1:1)
	Object.launch (http://cbjs.baidu.com/js/m.js:1:1)
	Object.process (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015033.283892:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 6, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac99f0, toString, 
[1:1:0713/015033.284038:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 6, , , 0
[1:1:0713/015033.284583:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getNotCrossDomainTopWindow (http://cbjs.baidu.com/js/m.js:1:1)
	Object.value (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	Object.getOneParam (http://cbjs.baidu.com/js/m.js:1:1)
	Object.launch (http://cbjs.baidu.com/js/m.js:1:1)
	Object.process (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015033.284785:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 7, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/, 37acedac99f0, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015033.284938:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=2409097", "www.4399dmw.com", 5, 7, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015033.285510:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getNotCrossDomainTopWindow (http://cbjs.baidu.com/js/m.js:1:1)
	Object.value (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	Object.getOneParam (http://cbjs.baidu.com/js/m.js:1:1)
	Object.launch (http://cbjs.baidu.com/js/m.js:1:1)
	Object.process (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015033.298321:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 782 0x7f3f7381f080 0x2f6ba5d52e0 1 0 0x2f6ba5d52f8 , "http://www.4399dmw.com/baiduad/proxy.html?id=2409097"
[1:1:0713/015033.306818:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 8, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac99f0, toString, 
[1:1:0713/015033.307043:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 8, , , 0
[1:1:0713/015033.307652:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.value (http://cbjs.baidu.com/js/m.js:1:1)
	Object.snap (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getParamObj (http://cbjs.baidu.com/js/m.js:1:1)
	Object.requestSlotInfo (http://cbjs.baidu.com/js/m.js:1:1)
	Object.process (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getClbFillSlot (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://www.4399dmw.com/baiduad/proxy.html?id=2409097:10:32
	http://www.4399dmw.com/baiduad/proxy.html?id=2409097:10:32

[1:1:0713/015033.307922:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 9, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/, 37acedac99f0, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015033.308152:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=2409097", "www.4399dmw.com", 5, 9, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015033.308732:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.value (http://cbjs.baidu.com/js/m.js:1:1)
	Object.snap (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getParamObj (http://cbjs.baidu.com/js/m.js:1:1)
	Object.requestSlotInfo (http://cbjs.baidu.com/js/m.js:1:1)
	Object.process (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getClbFillSlot (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://www.4399dmw.com/baiduad/proxy.html?id=2409097:10:32
	http://www.4399dmw.com/baiduad/proxy.html?id=2409097:10:32

[1:1:0713/015033.310345:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 10, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac99f0, toString, 
[1:1:0713/015033.310556:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 10, , , 0
[1:1:0713/015033.311167:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getNotCrossDomainTopWindow (http://cbjs.baidu.com/js/m.js:1:1)
	Object.value (http://cbjs.baidu.com/js/m.js:1:1)
	Object.snap (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getParamObj (http://cbjs.baidu.com/js/m.js:1:1)
	Object.requestSlotInfo (http://cbjs.baidu.com/js/m.js:1:1)
	Object.process (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getClbFillSlot (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://www.4399dmw.com/baiduad/proxy.html?id=2409097:10:32
	http://www.4399dmw.com/baiduad/proxy.html?id=2409097:10:32

[1:1:0713/015033.311381:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 11, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/, 37acedac99f0, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015033.311581:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=2409097", "www.4399dmw.com", 5, 11, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015033.312204:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getNotCrossDomainTopWindow (http://cbjs.baidu.com/js/m.js:1:1)
	Object.value (http://cbjs.baidu.com/js/m.js:1:1)
	Object.snap (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getParamObj (http://cbjs.baidu.com/js/m.js:1:1)
	Object.requestSlotInfo (http://cbjs.baidu.com/js/m.js:1:1)
	Object.process (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getClbFillSlot (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://www.4399dmw.com/baiduad/proxy.html?id=2409097:10:32
	http://www.4399dmw.com/baiduad/proxy.html?id=2409097:10:32

[1:1:0713/015033.319359:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 12, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac99f0, toString, 
[1:1:0713/015033.319610:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 12, , , 0
[1:1:0713/015033.320268:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getPosition (http://cbjs.baidu.com/js/m.js:1:1)
	Object.value (http://cbjs.baidu.com/js/m.js:1:1)
	Object.snap (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getParamObj (http://cbjs.baidu.com/js/m.js:1:1)
	Object.requestSlotInfo (http://cbjs.baidu.com/js/m.js:1:1)
	Object.process (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getClbFillSlot (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://www.4399dmw.com/baiduad/proxy.html?id=2409097:10:32
	http://www.4399dmw.com/baiduad/proxy.html?id=2409097:10:32

[1:1:0713/015033.320492:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 13, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/, 37acedac99f0, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015033.320701:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=2409097", "www.4399dmw.com", 5, 13, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015033.321332:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getPosition (http://cbjs.baidu.com/js/m.js:1:1)
	Object.value (http://cbjs.baidu.com/js/m.js:1:1)
	Object.snap (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getParamObj (http://cbjs.baidu.com/js/m.js:1:1)
	Object.requestSlotInfo (http://cbjs.baidu.com/js/m.js:1:1)
	Object.process (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getClbFillSlot (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://www.4399dmw.com/baiduad/proxy.html?id=2409097:10:32
	http://www.4399dmw.com/baiduad/proxy.html?id=2409097:10:32

[1:1:0713/015033.322668:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 14, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac99f0, getBoundingClientRect, 
[1:1:0713/015033.322885:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 14, , , 0
[1:1:0713/015033.323501:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getPositionCore (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getPosition (http://cbjs.baidu.com/js/m.js:1:1)
	Object.value (http://cbjs.baidu.com/js/m.js:1:1)
	Object.snap (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getParamObj (http://cbjs.baidu.com/js/m.js:1:1)
	Object.requestSlotInfo (http://cbjs.baidu.com/js/m.js:1:1)
	Object.process (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getClbFillSlot (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://www.4399dmw.com/baiduad/proxy.html?id=2409097:10:32
	http://www.4399dmw.com/baiduad/proxy.html?id=2409097:10:32

[1:1:0713/015033.323750:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 15, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/, 37acedac99f0, 37aceda02860, floor, 
[1:1:0713/015033.323976:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=2409097", "www.4399dmw.com", 5, 15, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015033.324560:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getPositionCore (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getPosition (http://cbjs.baidu.com/js/m.js:1:1)
	Object.value (http://cbjs.baidu.com/js/m.js:1:1)
	Object.snap (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getParamObj (http://cbjs.baidu.com/js/m.js:1:1)
	Object.requestSlotInfo (http://cbjs.baidu.com/js/m.js:1:1)
	Object.process (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getClbFillSlot (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://www.4399dmw.com/baiduad/proxy.html?id=2409097:10:32
	http://www.4399dmw.com/baiduad/proxy.html?id=2409097:10:32

[1:1:0713/015033.326001:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 16, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac99f0, getComputedStyle, 
[1:1:0713/015033.326184:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 16, , , 0
[1:1:0713/015033.326723:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getStyle (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getPositionCore (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getPosition (http://cbjs.baidu.com/js/m.js:1:1)
	Object.value (http://cbjs.baidu.com/js/m.js:1:1)
	Object.snap (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getParamObj (http://cbjs.baidu.com/js/m.js:1:1)
	Object.requestSlotInfo (http://cbjs.baidu.com/js/m.js:1:1)
	Object.process (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getClbFillSlot (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://www.4399dmw.com/baiduad/proxy.html?id=2409097:10:32
	http://www.4399dmw.com/baiduad/proxy.html?id=2409097:10:32

[1:1:0713/015033.327051:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 17, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/, 37acedac99f0, 37aceda02860, getStyle, (t,e){if(!t)return"";var i="";i=e.indexOf("-")>-1?e.replace(/[-][^-]{1}/g,function(t){return t.charA
[1:1:0713/015033.327231:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=2409097", "www.4399dmw.com", 5, 17, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015033.327735:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getPositionCore (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getPosition (http://cbjs.baidu.com/js/m.js:1:1)
	Object.value (http://cbjs.baidu.com/js/m.js:1:1)
	Object.snap (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getParamObj (http://cbjs.baidu.com/js/m.js:1:1)
	Object.requestSlotInfo (http://cbjs.baidu.com/js/m.js:1:1)
	Object.process (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getClbFillSlot (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://www.4399dmw.com/baiduad/proxy.html?id=2409097:10:32
	http://www.4399dmw.com/baiduad/proxy.html?id=2409097:10:32

[1:1:0713/015033.328422:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 18, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac99f0, getComputedStyle, 
[1:1:0713/015033.328664:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 18, , , 0
[1:1:0713/015033.329257:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getStyle (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getPositionCore (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getPosition (http://cbjs.baidu.com/js/m.js:1:1)
	Object.value (http://cbjs.baidu.com/js/m.js:1:1)
	Object.snap (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getParamObj (http://cbjs.baidu.com/js/m.js:1:1)
	Object.requestSlotInfo (http://cbjs.baidu.com/js/m.js:1:1)
	Object.process (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getClbFillSlot (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://www.4399dmw.com/baiduad/proxy.html?id=2409097:10:32
	http://www.4399dmw.com/baiduad/proxy.html?id=2409097:10:32

[1:1:0713/015033.329579:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 19, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/, 37acedac99f0, 37aceda02860, parseInt, 
[1:1:0713/015033.329796:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=2409097", "www.4399dmw.com", 5, 19, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015033.330393:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getPositionCore (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getPosition (http://cbjs.baidu.com/js/m.js:1:1)
	Object.value (http://cbjs.baidu.com/js/m.js:1:1)
	Object.snap (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getParamObj (http://cbjs.baidu.com/js/m.js:1:1)
	Object.requestSlotInfo (http://cbjs.baidu.com/js/m.js:1:1)
	Object.process (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getClbFillSlot (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://www.4399dmw.com/baiduad/proxy.html?id=2409097:10:32
	http://www.4399dmw.com/baiduad/proxy.html?id=2409097:10:32

[1:1:0713/015033.336428:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 20, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac99f0, toString, 
[1:1:0713/015033.336661:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 20, , , 0
[1:1:0713/015033.337285:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.value (http://cbjs.baidu.com/js/m.js:1:1)
	Object.snap (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getParamObj (http://cbjs.baidu.com/js/m.js:1:1)
	Object.requestSlotInfo (http://cbjs.baidu.com/js/m.js:1:1)
	Object.process (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getClbFillSlot (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://www.4399dmw.com/baiduad/proxy.html?id=2409097:10:32
	http://www.4399dmw.com/baiduad/proxy.html?id=2409097:10:32

[1:1:0713/015033.337466:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 21, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/, 37acedac99f0, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015033.337677:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=2409097", "www.4399dmw.com", 5, 21, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015033.338134:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.value (http://cbjs.baidu.com/js/m.js:1:1)
	Object.snap (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getParamObj (http://cbjs.baidu.com/js/m.js:1:1)
	Object.requestSlotInfo (http://cbjs.baidu.com/js/m.js:1:1)
	Object.process (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getClbFillSlot (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://www.4399dmw.com/baiduad/proxy.html?id=2409097:10:32
	http://www.4399dmw.com/baiduad/proxy.html?id=2409097:10:32

[1:1:0713/015033.343168:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 22, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac99f0, toString, 
[1:1:0713/015033.343446:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 22, , , 0
[1:1:0713/015033.344123:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getNotCrossDomainTopWindow (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getDocumentTitle (http://cbjs.baidu.com/js/m.js:1:1)
	Object.value (http://cbjs.baidu.com/js/m.js:1:1)
	Object.snap (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getParamObj (http://cbjs.baidu.com/js/m.js:1:1)
	Object.requestSlotInfo (http://cbjs.baidu.com/js/m.js:1:1)
	Object.process (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getClbFillSlot (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://www.4399dmw.com/baiduad/proxy.html?id=2409097:10:32
	http://www.4399dmw.com/baiduad/proxy.html?id=2409097:10:32

[1:1:0713/015033.344346:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 23, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/, 37acedac99f0, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015033.344600:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=2409097", "www.4399dmw.com", 5, 23, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015033.345290:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getNotCrossDomainTopWindow (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getDocumentTitle (http://cbjs.baidu.com/js/m.js:1:1)
	Object.value (http://cbjs.baidu.com/js/m.js:1:1)
	Object.snap (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getParamObj (http://cbjs.baidu.com/js/m.js:1:1)
	Object.requestSlotInfo (http://cbjs.baidu.com/js/m.js:1:1)
	Object.process (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getClbFillSlot (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://www.4399dmw.com/baiduad/proxy.html?id=2409097:10:32
	http://www.4399dmw.com/baiduad/proxy.html?id=2409097:10:32

[1:1:0713/015033.347518:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 24, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac99f0, toString, 
[1:1:0713/015033.347779:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 24, , , 0
[1:1:0713/015033.348446:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getNotCrossDomainTopWindow (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getTopWin (http://cbjs.baidu.com/js/m.js:1:1)
	Object.value (http://cbjs.baidu.com/js/m.js:1:1)
	Object.snap (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getParamObj (http://cbjs.baidu.com/js/m.js:1:1)
	Object.requestSlotInfo (http://cbjs.baidu.com/js/m.js:1:1)
	Object.process (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getClbFillSlot (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://www.4399dmw.com/baiduad/proxy.html?id=2409097:10:32
	http://www.4399dmw.com/baiduad/proxy.html?id=2409097:10:32

[1:1:0713/015033.348683:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 25, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/, 37acedac99f0, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015033.348959:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=2409097", "www.4399dmw.com", 5, 25, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015033.349665:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getNotCrossDomainTopWindow (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getTopWin (http://cbjs.baidu.com/js/m.js:1:1)
	Object.value (http://cbjs.baidu.com/js/m.js:1:1)
	Object.snap (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getParamObj (http://cbjs.baidu.com/js/m.js:1:1)
	Object.requestSlotInfo (http://cbjs.baidu.com/js/m.js:1:1)
	Object.process (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getClbFillSlot (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://www.4399dmw.com/baiduad/proxy.html?id=2409097:10:32
	http://www.4399dmw.com/baiduad/proxy.html?id=2409097:10:32

[1:1:0713/015033.359018:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 26, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac99f0, toString, 
[1:1:0713/015033.359297:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 26, , , 0
[1:1:0713/015033.360027:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getNotCrossDomainTopWindow (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getTopWindowUrl (http://cbjs.baidu.com/js/m.js:1:1)
	Object.value (http://cbjs.baidu.com/js/m.js:1:1)
	Object.snap (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getParamObj (http://cbjs.baidu.com/js/m.js:1:1)
	Object.requestSlotInfo (http://cbjs.baidu.com/js/m.js:1:1)
	Object.process (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getClbFillSlot (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://www.4399dmw.com/baiduad/proxy.html?id=2409097:10:32
	http://www.4399dmw.com/baiduad/proxy.html?id=2409097:10:32

[1:1:0713/015033.360239:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 27, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/, 37acedac99f0, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015033.360535:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=2409097", "www.4399dmw.com", 5, 27, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015033.361231:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getNotCrossDomainTopWindow (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getTopWindowUrl (http://cbjs.baidu.com/js/m.js:1:1)
	Object.value (http://cbjs.baidu.com/js/m.js:1:1)
	Object.snap (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getParamObj (http://cbjs.baidu.com/js/m.js:1:1)
	Object.requestSlotInfo (http://cbjs.baidu.com/js/m.js:1:1)
	Object.process (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getClbFillSlot (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://www.4399dmw.com/baiduad/proxy.html?id=2409097:10:32
	http://www.4399dmw.com/baiduad/proxy.html?id=2409097:10:32

[1:1:0713/015033.377487:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 28, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac99f0, toString, 
[1:1:0713/015033.377846:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 28, , , 0
[1:1:0713/015033.378575:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getNotCrossDomainTopWindow (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getTopWindowUrl (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getValue (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getInfo (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getSearchParams (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getParamObj (http://cbjs.baidu.com/js/m.js:1:1)
	Object.requestSlotInfo (http://cbjs.baidu.com/js/m.js:1:1)
	Object.process (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getClbFillSlot (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://www.4399dmw.com/baiduad/proxy.html?id=2409097:10:32
	http://www.4399dmw.com/baiduad/proxy.html?id=2409097:10:32

[1:1:0713/015033.378865:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 29, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/, 37acedac99f0, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015033.379242:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=2409097", "www.4399dmw.com", 5, 29, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015033.379905:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getNotCrossDomainTopWindow (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getTopWindowUrl (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getValue (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getInfo (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getSearchParams (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getParamObj (http://cbjs.baidu.com/js/m.js:1:1)
	Object.requestSlotInfo (http://cbjs.baidu.com/js/m.js:1:1)
	Object.process (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getClbFillSlot (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://www.4399dmw.com/baiduad/proxy.html?id=2409097:10:32
	http://www.4399dmw.com/baiduad/proxy.html?id=2409097:10:32

[1:1:0713/015033.382232:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 30, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac99f0, toString, 
[1:1:0713/015033.382562:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 30, , , 0
[1:1:0713/015033.383249:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getNotCrossDomainTopWindow (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getTopWindowUrl (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getValue (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getInfo (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getSearchParams (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getParamObj (http://cbjs.baidu.com/js/m.js:1:1)
	Object.requestSlotInfo (http://cbjs.baidu.com/js/m.js:1:1)
	Object.process (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getClbFillSlot (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://www.4399dmw.com/baiduad/proxy.html?id=2409097:10:32
	http://www.4399dmw.com/baiduad/proxy.html?id=2409097:10:32

[1:1:0713/015033.383504:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 31, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/, 37acedac99f0, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015033.383791:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=2409097", "www.4399dmw.com", 5, 31, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015033.384416:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getNotCrossDomainTopWindow (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getTopWindowUrl (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getValue (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getInfo (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getSearchParams (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getParamObj (http://cbjs.baidu.com/js/m.js:1:1)
	Object.requestSlotInfo (http://cbjs.baidu.com/js/m.js:1:1)
	Object.process (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getClbFillSlot (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://www.4399dmw.com/baiduad/proxy.html?id=2409097:10:32
	http://www.4399dmw.com/baiduad/proxy.html?id=2409097:10:32

[1:1:0713/015033.386444:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 32, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac99f0, toString, 
[1:1:0713/015033.386726:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 32, , , 0
[1:1:0713/015033.387391:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getNotCrossDomainTopWindow (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getTopWindowUrl (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getValue (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getInfo (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getSearchParams (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getParamObj (http://cbjs.baidu.com/js/m.js:1:1)
	Object.requestSlotInfo (http://cbjs.baidu.com/js/m.js:1:1)
	Object.process (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getClbFillSlot (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://www.4399dmw.com/baiduad/proxy.html?id=2409097:10:32
	http://www.4399dmw.com/baiduad/proxy.html?id=2409097:10:32

[1:1:0713/015033.387600:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 33, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/, 37acedac99f0, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015033.387913:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=2409097", "www.4399dmw.com", 5, 33, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015033.388538:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getNotCrossDomainTopWindow (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getTopWindowUrl (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getValue (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getInfo (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getSearchParams (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getParamObj (http://cbjs.baidu.com/js/m.js:1:1)
	Object.requestSlotInfo (http://cbjs.baidu.com/js/m.js:1:1)
	Object.process (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getClbFillSlot (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://www.4399dmw.com/baiduad/proxy.html?id=2409097:10:32
	http://www.4399dmw.com/baiduad/proxy.html?id=2409097:10:32

[1:1:0713/015033.390827:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 34, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac99f0, toString, 
[1:1:0713/015033.391191:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 34, , , 0
[1:1:0713/015033.391962:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getNotCrossDomainTopWindow (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getTopWindowUrl (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getValue (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getInfo (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getSearchParams (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getParamObj (http://cbjs.baidu.com/js/m.js:1:1)
	Object.requestSlotInfo (http://cbjs.baidu.com/js/m.js:1:1)
	Object.process (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getClbFillSlot (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://www.4399dmw.com/baiduad/proxy.html?id=2409097:10:32
	http://www.4399dmw.com/baiduad/proxy.html?id=2409097:10:32

[1:1:0713/015033.392222:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 35, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/, 37acedac99f0, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015033.392626:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=2409097", "www.4399dmw.com", 5, 35, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015033.393399:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getNotCrossDomainTopWindow (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getTopWindowUrl (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getValue (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getInfo (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getSearchParams (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getParamObj (http://cbjs.baidu.com/js/m.js:1:1)
	Object.requestSlotInfo (http://cbjs.baidu.com/js/m.js:1:1)
	Object.process (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getClbFillSlot (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://www.4399dmw.com/baiduad/proxy.html?id=2409097:10:32
	http://www.4399dmw.com/baiduad/proxy.html?id=2409097:10:32

[1:1:0713/015033.421216:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.4399dmw.com/, 779, 7f3f5fad9881
[1:1:0713/015033.434273:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"37aceda02860","ptid":"755 0x7f3f5d194070 0x2f6ba62c9e0 ","rf":"5:3_http://www.4399dmw.com/"}
[1:1:0713/015033.434508:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.4399dmw.com/","ptid":"755 0x7f3f5d194070 0x2f6ba62c9e0 ","rf":"5:3_http://www.4399dmw.com/"}
[1:1:0713/015033.434717:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.4399dmw.com/"
[1:1:0713/015033.434991:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.4399dmw.com/, 37aceda02860, , , (){
							_this.start()
						}
[1:1:0713/015033.435089:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 1, , , 0
[1:1:0713/015033.435658:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.4399dmw.com/", 2500
[1:1:0713/015033.435848:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.4399dmw.com/, 827
[1:1:0713/015033.435971:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 827 0x7f3f5d194070 0x2f6bab6f4e0 , 5:3_http://www.4399dmw.com/, 1, -5:3_http://www.4399dmw.com/, 779 0x7f3f5d194070 0x2f6ba62bc60 
[1:1:0713/015033.500174:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.4399dmw.com/, 467, 7f3f5fad98db
[1:1:0713/015033.512524:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"37aceda02860","ptid":"409 0x7f3f5d194070 0x2f6b8fddbe0 ","rf":"5:3_http://www.4399dmw.com/"}
[1:1:0713/015033.512722:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.4399dmw.com/","ptid":"409 0x7f3f5d194070 0x2f6b8fddbe0 ","rf":"5:3_http://www.4399dmw.com/"}
[1:1:0713/015033.512958:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.4399dmw.com/, 829
[1:1:0713/015033.513105:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 829 0x7f3f5d194070 0x2f6b8a5cb60 , 5:3_http://www.4399dmw.com/, 0, , 467 0x7f3f5d194070 0x2f6b9061560 
[1:1:0713/015033.513274:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.4399dmw.com/"
[1:1:0713/015033.513643:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.4399dmw.com/, 37aceda02860, , Wb, (){var a=d.O()+d.H();0<a-h.b.c.vl&&(h.b.c.vl=a)}
[1:1:0713/015033.513778:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 1, , , 0
[1:1:0713/015033.602081:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.4399dmw.com/, 790, 7f3f5fad9881
[1:1:0713/015033.615660:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"37aceda02860","ptid":"759 0x7f3f5d194070 0x2f6b9c192e0 ","rf":"5:3_http://www.4399dmw.com/"}
[1:1:0713/015033.615891:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.4399dmw.com/","ptid":"759 0x7f3f5d194070 0x2f6b9c192e0 ","rf":"5:3_http://www.4399dmw.com/"}
[1:1:0713/015033.616136:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.4399dmw.com/"
[1:1:0713/015033.616456:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.4399dmw.com/, 37aceda02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/015033.616565:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 1, , , 0
[1:1:0713/015033.616934:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x500731029c8, 0x2f6b8a4e950
[1:1:0713/015033.617057:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.4399dmw.com/", 100
[1:1:0713/015033.617265:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.4399dmw.com/, 836
[1:1:0713/015033.617387:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 836 0x7f3f5d194070 0x2f6b8a5c360 , 5:3_http://www.4399dmw.com/, 1, -5:3_http://www.4399dmw.com/, 790 0x7f3f5d194070 0x2f6ba5a8560 
[1:1:0713/015033.617854:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.4399dmw.com/, 796, 7f3f5fad9881
[1:1:0713/015033.630876:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"37aceda02860","ptid":"768 0x7f3f5f0bc2e0 0x2f6ba62ac60 ","rf":"5:3_http://www.4399dmw.com/"}
[1:1:0713/015033.631049:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.4399dmw.com/","ptid":"768 0x7f3f5f0bc2e0 0x2f6ba62ac60 ","rf":"5:3_http://www.4399dmw.com/"}
[1:1:0713/015033.631258:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.4399dmw.com/"
[1:1:0713/015033.631521:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.4399dmw.com/, 37aceda02860, , , (){l(e,t)}
[1:1:0713/015033.631623:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 1, , , 0
[1:1:0713/015033.632867:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x500731029c8, 0x2f6b8a4e950
[1:1:0713/015033.632952:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.4399dmw.com/", 1
[1:1:0713/015033.633135:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.4399dmw.com/, 837
[1:1:0713/015033.633261:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 837 0x7f3f5d194070 0x2f6bab71360 , 5:3_http://www.4399dmw.com/, 1, -5:3_http://www.4399dmw.com/, 796 0x7f3f5d194070 0x2f6ba58d760 
[1:1:0713/015033.660403:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.4399dmw.com/, 37aceda02860, , , document.readyState
[1:1:0713/015033.660583:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 1, , , 0
[1:1:0713/015033.703701:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 806 0x7f3f5d4fcbd0 0x2f6ba624558 , "http://www.4399dmw.com/baiduad/proxy.html?id=846418"
[1:1:0713/015033.705668:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://www.4399dmw.com/, 37acedac4648, , , try{!function(){window.___baidu_union_||(window.___baidu_union_={}),window.___baidu_union_dup_||(win
[1:1:0713/015033.705810:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=846418", "www.4399dmw.com", 4, 1, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015034.242698:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac4648, toString, 
[1:1:0713/015034.242924:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 2, , , 0
[1:1:0713/015034.243626:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getNotCrossDomainTopWindow (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getTopWindowUrl (http://cbjs.baidu.com/js/m.js:1:1)
	Object.value (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	Object.getPageSearchId (http://cbjs.baidu.com/js/m.js:1:1)
	Object.prepareApi (http://cbjs.baidu.com/js/m.js:1:1)
	Object.process (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015034.243862:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/, 37acedac4648, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015034.244020:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=846418", "www.4399dmw.com", 4, 3, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015034.244723:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getNotCrossDomainTopWindow (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getTopWindowUrl (http://cbjs.baidu.com/js/m.js:1:1)
	Object.value (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	Object.getPageSearchId (http://cbjs.baidu.com/js/m.js:1:1)
	Object.prepareApi (http://cbjs.baidu.com/js/m.js:1:1)
	Object.process (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015034.290024:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac4648, toString, 
[1:1:0713/015034.290261:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 4, , , 0
[1:1:0713/015034.290883:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.value (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	Object.getOneParam (http://cbjs.baidu.com/js/m.js:1:1)
	Object.launch (http://cbjs.baidu.com/js/m.js:1:1)
	Object.process (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015034.291158:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 5, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/, 37acedac4648, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015034.291358:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=846418", "www.4399dmw.com", 4, 5, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015034.291879:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.value (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	Object.getOneParam (http://cbjs.baidu.com/js/m.js:1:1)
	Object.launch (http://cbjs.baidu.com/js/m.js:1:1)
	Object.process (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015034.293247:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 6, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac4648, toString, 
[1:1:0713/015034.293376:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 6, , , 0
[1:1:0713/015034.293860:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getNotCrossDomainTopWindow (http://cbjs.baidu.com/js/m.js:1:1)
	Object.value (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	Object.getOneParam (http://cbjs.baidu.com/js/m.js:1:1)
	Object.launch (http://cbjs.baidu.com/js/m.js:1:1)
	Object.process (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015034.294037:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 7, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/, 37acedac4648, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015034.294182:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=846418", "www.4399dmw.com", 4, 7, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015034.294631:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getNotCrossDomainTopWindow (http://cbjs.baidu.com/js/m.js:1:1)
	Object.value (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	Object.getOneParam (http://cbjs.baidu.com/js/m.js:1:1)
	Object.launch (http://cbjs.baidu.com/js/m.js:1:1)
	Object.process (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015034.304413:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 806 0x7f3f5d4fcbd0 0x2f6ba624558 , "http://www.4399dmw.com/baiduad/proxy.html?id=846418"
[1:1:0713/015034.310981:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 8, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac4648, toString, 
[1:1:0713/015034.311203:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 8, , , 0
[1:1:0713/015034.311871:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.value (http://cbjs.baidu.com/js/m.js:1:1)
	Object.snap (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getParamObj (http://cbjs.baidu.com/js/m.js:1:1)
	Object.requestSlotInfo (http://cbjs.baidu.com/js/m.js:1:1)
	Object.process (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getClbFillSlot (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://www.4399dmw.com/baiduad/proxy.html?id=846418:10:32
	http://www.4399dmw.com/baiduad/proxy.html?id=846418:10:32

[1:1:0713/015034.312140:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 9, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/, 37acedac4648, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015034.312386:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=846418", "www.4399dmw.com", 4, 9, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015034.313012:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.value (http://cbjs.baidu.com/js/m.js:1:1)
	Object.snap (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getParamObj (http://cbjs.baidu.com/js/m.js:1:1)
	Object.requestSlotInfo (http://cbjs.baidu.com/js/m.js:1:1)
	Object.process (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getClbFillSlot (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://www.4399dmw.com/baiduad/proxy.html?id=846418:10:32
	http://www.4399dmw.com/baiduad/proxy.html?id=846418:10:32

[1:1:0713/015034.315019:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 10, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac4648, toString, 
[1:1:0713/015034.315253:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 10, , , 0
[1:1:0713/015034.315936:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getNotCrossDomainTopWindow (http://cbjs.baidu.com/js/m.js:1:1)
	Object.value (http://cbjs.baidu.com/js/m.js:1:1)
	Object.snap (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getParamObj (http://cbjs.baidu.com/js/m.js:1:1)
	Object.requestSlotInfo (http://cbjs.baidu.com/js/m.js:1:1)
	Object.process (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getClbFillSlot (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://www.4399dmw.com/baiduad/proxy.html?id=846418:10:32
	http://www.4399dmw.com/baiduad/proxy.html?id=846418:10:32

[1:1:0713/015034.316162:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 11, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/, 37acedac4648, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015034.316354:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=846418", "www.4399dmw.com", 4, 11, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015034.316955:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getNotCrossDomainTopWindow (http://cbjs.baidu.com/js/m.js:1:1)
	Object.value (http://cbjs.baidu.com/js/m.js:1:1)
	Object.snap (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getParamObj (http://cbjs.baidu.com/js/m.js:1:1)
	Object.requestSlotInfo (http://cbjs.baidu.com/js/m.js:1:1)
	Object.process (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getClbFillSlot (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://www.4399dmw.com/baiduad/proxy.html?id=846418:10:32
	http://www.4399dmw.com/baiduad/proxy.html?id=846418:10:32

[1:1:0713/015034.323272:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 12, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac4648, toString, 
[1:1:0713/015034.323522:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 12, , , 0
[1:1:0713/015034.324138:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getPosition (http://cbjs.baidu.com/js/m.js:1:1)
	Object.value (http://cbjs.baidu.com/js/m.js:1:1)
	Object.snap (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getParamObj (http://cbjs.baidu.com/js/m.js:1:1)
	Object.requestSlotInfo (http://cbjs.baidu.com/js/m.js:1:1)
	Object.process (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getClbFillSlot (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://www.4399dmw.com/baiduad/proxy.html?id=846418:10:32
	http://www.4399dmw.com/baiduad/proxy.html?id=846418:10:32

[1:1:0713/015034.324318:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 13, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/, 37acedac4648, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015034.324507:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=846418", "www.4399dmw.com", 4, 13, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015034.325097:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getPosition (http://cbjs.baidu.com/js/m.js:1:1)
	Object.value (http://cbjs.baidu.com/js/m.js:1:1)
	Object.snap (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getParamObj (http://cbjs.baidu.com/js/m.js:1:1)
	Object.requestSlotInfo (http://cbjs.baidu.com/js/m.js:1:1)
	Object.process (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getClbFillSlot (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://www.4399dmw.com/baiduad/proxy.html?id=846418:10:32
	http://www.4399dmw.com/baiduad/proxy.html?id=846418:10:32

[1:1:0713/015034.325849:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 14, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac4648, getBoundingClientRect, 
[1:1:0713/015034.326026:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 14, , , 0
[1:1:0713/015034.326524:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getPositionCore (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getPosition (http://cbjs.baidu.com/js/m.js:1:1)
	Object.value (http://cbjs.baidu.com/js/m.js:1:1)
	Object.snap (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getParamObj (http://cbjs.baidu.com/js/m.js:1:1)
	Object.requestSlotInfo (http://cbjs.baidu.com/js/m.js:1:1)
	Object.process (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getClbFillSlot (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://www.4399dmw.com/baiduad/proxy.html?id=846418:10:32
	http://www.4399dmw.com/baiduad/proxy.html?id=846418:10:32

[1:1:0713/015034.326766:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 15, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/, 37acedac4648, 37aceda02860, floor, 
[1:1:0713/015034.326939:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=846418", "www.4399dmw.com", 4, 15, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015034.327442:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getPositionCore (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getPosition (http://cbjs.baidu.com/js/m.js:1:1)
	Object.value (http://cbjs.baidu.com/js/m.js:1:1)
	Object.snap (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getParamObj (http://cbjs.baidu.com/js/m.js:1:1)
	Object.requestSlotInfo (http://cbjs.baidu.com/js/m.js:1:1)
	Object.process (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getClbFillSlot (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://www.4399dmw.com/baiduad/proxy.html?id=846418:10:32
	http://www.4399dmw.com/baiduad/proxy.html?id=846418:10:32

[1:1:0713/015034.328788:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 16, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac4648, getComputedStyle, 
[1:1:0713/015034.329042:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 16, , , 0
[1:1:0713/015034.329690:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getStyle (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getPositionCore (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getPosition (http://cbjs.baidu.com/js/m.js:1:1)
	Object.value (http://cbjs.baidu.com/js/m.js:1:1)
	Object.snap (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getParamObj (http://cbjs.baidu.com/js/m.js:1:1)
	Object.requestSlotInfo (http://cbjs.baidu.com/js/m.js:1:1)
	Object.process (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getClbFillSlot (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://www.4399dmw.com/baiduad/proxy.html?id=846418:10:32
	http://www.4399dmw.com/baiduad/proxy.html?id=846418:10:32

[1:1:0713/015034.330061:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 17, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/, 37acedac4648, 37aceda02860, getStyle, (t,e){if(!t)return"";var i="";i=e.indexOf("-")>-1?e.replace(/[-][^-]{1}/g,function(t){return t.charA
[1:1:0713/015034.330246:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=846418", "www.4399dmw.com", 4, 17, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015034.330850:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getPositionCore (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getPosition (http://cbjs.baidu.com/js/m.js:1:1)
	Object.value (http://cbjs.baidu.com/js/m.js:1:1)
	Object.snap (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getParamObj (http://cbjs.baidu.com/js/m.js:1:1)
	Object.requestSlotInfo (http://cbjs.baidu.com/js/m.js:1:1)
	Object.process (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getClbFillSlot (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://www.4399dmw.com/baiduad/proxy.html?id=846418:10:32
	http://www.4399dmw.com/baiduad/proxy.html?id=846418:10:32

[1:1:0713/015034.331490:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 18, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac4648, getComputedStyle, 
[1:1:0713/015034.331668:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 18, , , 0
[1:1:0713/015034.332197:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getStyle (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getPositionCore (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getPosition (http://cbjs.baidu.com/js/m.js:1:1)
	Object.value (http://cbjs.baidu.com/js/m.js:1:1)
	Object.snap (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getParamObj (http://cbjs.baidu.com/js/m.js:1:1)
	Object.requestSlotInfo (http://cbjs.baidu.com/js/m.js:1:1)
	Object.process (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getClbFillSlot (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://www.4399dmw.com/baiduad/proxy.html?id=846418:10:32
	http://www.4399dmw.com/baiduad/proxy.html?id=846418:10:32

[1:1:0713/015034.332465:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 19, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/, 37acedac4648, 37aceda02860, parseInt, 
[1:1:0713/015034.332667:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=846418", "www.4399dmw.com", 4, 19, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015034.333226:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getPositionCore (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getPosition (http://cbjs.baidu.com/js/m.js:1:1)
	Object.value (http://cbjs.baidu.com/js/m.js:1:1)
	Object.snap (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getParamObj (http://cbjs.baidu.com/js/m.js:1:1)
	Object.requestSlotInfo (http://cbjs.baidu.com/js/m.js:1:1)
	Object.process (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getClbFillSlot (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://www.4399dmw.com/baiduad/proxy.html?id=846418:10:32
	http://www.4399dmw.com/baiduad/proxy.html?id=846418:10:32

[1:1:0713/015034.337883:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 20, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac4648, toString, 
[1:1:0713/015034.338132:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 20, , , 0
[1:1:0713/015034.338715:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.value (http://cbjs.baidu.com/js/m.js:1:1)
	Object.snap (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getParamObj (http://cbjs.baidu.com/js/m.js:1:1)
	Object.requestSlotInfo (http://cbjs.baidu.com/js/m.js:1:1)
	Object.process (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getClbFillSlot (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://www.4399dmw.com/baiduad/proxy.html?id=846418:10:32
	http://www.4399dmw.com/baiduad/proxy.html?id=846418:10:32

[1:1:0713/015034.338909:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 21, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/, 37acedac4648, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015034.339142:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=846418", "www.4399dmw.com", 4, 21, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015034.339659:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.value (http://cbjs.baidu.com/js/m.js:1:1)
	Object.snap (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getParamObj (http://cbjs.baidu.com/js/m.js:1:1)
	Object.requestSlotInfo (http://cbjs.baidu.com/js/m.js:1:1)
	Object.process (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getClbFillSlot (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://www.4399dmw.com/baiduad/proxy.html?id=846418:10:32
	http://www.4399dmw.com/baiduad/proxy.html?id=846418:10:32

[1:1:0713/015034.344065:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 22, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac4648, toString, 
[1:1:0713/015034.344344:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 22, , , 0
[1:1:0713/015034.345120:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getNotCrossDomainTopWindow (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getDocumentTitle (http://cbjs.baidu.com/js/m.js:1:1)
	Object.value (http://cbjs.baidu.com/js/m.js:1:1)
	Object.snap (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getParamObj (http://cbjs.baidu.com/js/m.js:1:1)
	Object.requestSlotInfo (http://cbjs.baidu.com/js/m.js:1:1)
	Object.process (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getClbFillSlot (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://www.4399dmw.com/baiduad/proxy.html?id=846418:10:32
	http://www.4399dmw.com/baiduad/proxy.html?id=846418:10:32

[1:1:0713/015034.345362:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 23, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/, 37acedac4648, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015034.345622:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=846418", "www.4399dmw.com", 4, 23, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015034.346258:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getNotCrossDomainTopWindow (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getDocumentTitle (http://cbjs.baidu.com/js/m.js:1:1)
	Object.value (http://cbjs.baidu.com/js/m.js:1:1)
	Object.snap (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getParamObj (http://cbjs.baidu.com/js/m.js:1:1)
	Object.requestSlotInfo (http://cbjs.baidu.com/js/m.js:1:1)
	Object.process (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getClbFillSlot (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://www.4399dmw.com/baiduad/proxy.html?id=846418:10:32
	http://www.4399dmw.com/baiduad/proxy.html?id=846418:10:32

[1:1:0713/015034.347989:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 24, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac4648, toString, 
[1:1:0713/015034.348238:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 24, , , 0
[1:1:0713/015034.348964:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getNotCrossDomainTopWindow (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getTopWin (http://cbjs.baidu.com/js/m.js:1:1)
	Object.value (http://cbjs.baidu.com/js/m.js:1:1)
	Object.snap (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getParamObj (http://cbjs.baidu.com/js/m.js:1:1)
	Object.requestSlotInfo (http://cbjs.baidu.com/js/m.js:1:1)
	Object.process (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getClbFillSlot (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://www.4399dmw.com/baiduad/proxy.html?id=846418:10:32
	http://www.4399dmw.com/baiduad/proxy.html?id=846418:10:32

[1:1:0713/015034.349200:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 25, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/, 37acedac4648, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015034.349461:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=846418", "www.4399dmw.com", 4, 25, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015034.350073:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getNotCrossDomainTopWindow (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getTopWin (http://cbjs.baidu.com/js/m.js:1:1)
	Object.value (http://cbjs.baidu.com/js/m.js:1:1)
	Object.snap (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getParamObj (http://cbjs.baidu.com/js/m.js:1:1)
	Object.requestSlotInfo (http://cbjs.baidu.com/js/m.js:1:1)
	Object.process (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getClbFillSlot (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://www.4399dmw.com/baiduad/proxy.html?id=846418:10:32
	http://www.4399dmw.com/baiduad/proxy.html?id=846418:10:32

[1:1:0713/015034.357989:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 26, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac4648, toString, 
[1:1:0713/015034.358333:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 26, , , 0
[1:1:0713/015034.359092:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getNotCrossDomainTopWindow (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getTopWindowUrl (http://cbjs.baidu.com/js/m.js:1:1)
	Object.value (http://cbjs.baidu.com/js/m.js:1:1)
	Object.snap (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getParamObj (http://cbjs.baidu.com/js/m.js:1:1)
	Object.requestSlotInfo (http://cbjs.baidu.com/js/m.js:1:1)
	Object.process (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getClbFillSlot (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://www.4399dmw.com/baiduad/proxy.html?id=846418:10:32
	http://www.4399dmw.com/baiduad/proxy.html?id=846418:10:32

[1:1:0713/015034.359334:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 27, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/, 37acedac4648, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015034.359650:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=846418", "www.4399dmw.com", 4, 27, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015034.360244:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getNotCrossDomainTopWindow (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getTopWindowUrl (http://cbjs.baidu.com/js/m.js:1:1)
	Object.value (http://cbjs.baidu.com/js/m.js:1:1)
	Object.snap (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getParamObj (http://cbjs.baidu.com/js/m.js:1:1)
	Object.requestSlotInfo (http://cbjs.baidu.com/js/m.js:1:1)
	Object.process (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getClbFillSlot (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://www.4399dmw.com/baiduad/proxy.html?id=846418:10:32
	http://www.4399dmw.com/baiduad/proxy.html?id=846418:10:32

[1:1:0713/015034.374533:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 28, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac4648, toString, 
[1:1:0713/015034.374864:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 28, , , 0
[1:1:0713/015034.375660:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getNotCrossDomainTopWindow (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getTopWindowUrl (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getValue (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getInfo (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getSearchParams (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getParamObj (http://cbjs.baidu.com/js/m.js:1:1)
	Object.requestSlotInfo (http://cbjs.baidu.com/js/m.js:1:1)
	Object.process (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getClbFillSlot (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://www.4399dmw.com/baiduad/proxy.html?id=846418:10:32
	http://www.4399dmw.com/baiduad/proxy.html?id=846418:10:32

[1:1:0713/015034.375865:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 29, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/, 37acedac4648, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015034.376141:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=846418", "www.4399dmw.com", 4, 29, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015034.376758:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getNotCrossDomainTopWindow (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getTopWindowUrl (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getValue (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getInfo (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getSearchParams (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getParamObj (http://cbjs.baidu.com/js/m.js:1:1)
	Object.requestSlotInfo (http://cbjs.baidu.com/js/m.js:1:1)
	Object.process (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getClbFillSlot (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://www.4399dmw.com/baiduad/proxy.html?id=846418:10:32
	http://www.4399dmw.com/baiduad/proxy.html?id=846418:10:32

[1:1:0713/015034.378807:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 30, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac4648, toString, 
[1:1:0713/015034.379133:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 30, , , 0
[1:1:0713/015034.379786:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getNotCrossDomainTopWindow (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getTopWindowUrl (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getValue (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getInfo (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getSearchParams (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getParamObj (http://cbjs.baidu.com/js/m.js:1:1)
	Object.requestSlotInfo (http://cbjs.baidu.com/js/m.js:1:1)
	Object.process (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getClbFillSlot (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://www.4399dmw.com/baiduad/proxy.html?id=846418:10:32
	http://www.4399dmw.com/baiduad/proxy.html?id=846418:10:32

[1:1:0713/015034.380011:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 31, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/, 37acedac4648, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015034.380300:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=846418", "www.4399dmw.com", 4, 31, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015034.380910:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getNotCrossDomainTopWindow (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getTopWindowUrl (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getValue (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getInfo (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getSearchParams (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getParamObj (http://cbjs.baidu.com/js/m.js:1:1)
	Object.requestSlotInfo (http://cbjs.baidu.com/js/m.js:1:1)
	Object.process (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getClbFillSlot (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://www.4399dmw.com/baiduad/proxy.html?id=846418:10:32
	http://www.4399dmw.com/baiduad/proxy.html?id=846418:10:32

[1:1:0713/015034.382750:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 32, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac4648, toString, 
[1:1:0713/015034.383028:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 32, , , 0
[1:1:0713/015034.383655:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getNotCrossDomainTopWindow (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getTopWindowUrl (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getValue (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getInfo (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getSearchParams (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getParamObj (http://cbjs.baidu.com/js/m.js:1:1)
	Object.requestSlotInfo (http://cbjs.baidu.com/js/m.js:1:1)
	Object.process (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getClbFillSlot (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://www.4399dmw.com/baiduad/proxy.html?id=846418:10:32
	http://www.4399dmw.com/baiduad/proxy.html?id=846418:10:32

[1:1:0713/015034.383852:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 33, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/, 37acedac4648, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015034.384138:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=846418", "www.4399dmw.com", 4, 33, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015034.384752:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getNotCrossDomainTopWindow (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getTopWindowUrl (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getValue (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getInfo (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getSearchParams (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getParamObj (http://cbjs.baidu.com/js/m.js:1:1)
	Object.requestSlotInfo (http://cbjs.baidu.com/js/m.js:1:1)
	Object.process (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getClbFillSlot (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://www.4399dmw.com/baiduad/proxy.html?id=846418:10:32
	http://www.4399dmw.com/baiduad/proxy.html?id=846418:10:32

[1:1:0713/015034.386567:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 34, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac4648, toString, 
[1:1:0713/015034.386869:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 34, , , 0
[1:1:0713/015034.387523:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getNotCrossDomainTopWindow (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getTopWindowUrl (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getValue (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getInfo (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getSearchParams (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getParamObj (http://cbjs.baidu.com/js/m.js:1:1)
	Object.requestSlotInfo (http://cbjs.baidu.com/js/m.js:1:1)
	Object.process (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getClbFillSlot (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://www.4399dmw.com/baiduad/proxy.html?id=846418:10:32
	http://www.4399dmw.com/baiduad/proxy.html?id=846418:10:32

[1:1:0713/015034.387742:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 35, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/, 37acedac4648, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015034.388055:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=846418", "www.4399dmw.com", 4, 35, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015034.388750:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getNotCrossDomainTopWindow (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getTopWindowUrl (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getValue (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getInfo (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getSearchParams (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getParamObj (http://cbjs.baidu.com/js/m.js:1:1)
	Object.requestSlotInfo (http://cbjs.baidu.com/js/m.js:1:1)
	Object.process (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getClbFillSlot (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://www.4399dmw.com/baiduad/proxy.html?id=846418:10:32
	http://www.4399dmw.com/baiduad/proxy.html?id=846418:10:32

[1:1:0713/015034.572260:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.4399dmw.com/, 815, 7f3f5fad98db
[1:1:0713/015034.585736:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"37aceda02860","ptid":"778 0x7f3f5d194070 0x2f6ba2b8fe0 ","rf":"5:3_http://www.4399dmw.com/"}
[1:1:0713/015034.585944:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.4399dmw.com/","ptid":"778 0x7f3f5d194070 0x2f6ba2b8fe0 ","rf":"5:3_http://www.4399dmw.com/"}
[1:1:0713/015034.586192:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.4399dmw.com/, 855
[1:1:0713/015034.586314:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 855 0x7f3f5d194070 0x2f6b9a41fe0 , 5:3_http://www.4399dmw.com/, 0, , 815 0x7f3f5d194070 0x2f6bab705e0 
[1:1:0713/015034.586480:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.4399dmw.com/"
[1:1:0713/015034.586752:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.4399dmw.com/, 37aceda02860, , tick, (){for(var a=
c.timers,b=0;b<a.length;b++)a[b]()||a.splice(b--,1);a.length||c.fx.stop()}
[1:1:0713/015034.586868:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 1, , , 0
[1:1:0713/015034.682322:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.4399dmw.com/, 654, 7f3f5fad9881
[1:1:0713/015034.695554:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"37aceda02860","ptid":"596 0x7f3f5f0bc2e0 0x2f6b9aa7a60 ","rf":"5:3_http://www.4399dmw.com/"}
[1:1:0713/015034.695763:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.4399dmw.com/","ptid":"596 0x7f3f5f0bc2e0 0x2f6b9aa7a60 ","rf":"5:3_http://www.4399dmw.com/"}
[1:1:0713/015034.696020:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.4399dmw.com/"
[1:1:0713/015034.696314:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.4399dmw.com/, 37aceda02860, , , (){window._bd_share_main.F.use("trans/logger",function(e){e.nsClick(),e.back(),e.duration()})}
[1:1:0713/015034.696416:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 1, , , 0
[1:1:0713/015034.699232:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x500731029c8, 0x2f6b8a4e950
[1:1:0713/015034.699381:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.4399dmw.com/", 15000
[1:1:0713/015034.699571:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.4399dmw.com/, 858
[1:1:0713/015034.699717:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 858 0x7f3f5d194070 0x2f6b8b94de0 , 5:3_http://www.4399dmw.com/, 1, -5:3_http://www.4399dmw.com/, 654 0x7f3f5d194070 0x2f6ba3e7660 
[1:1:0713/015034.746282:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 828, "http://www.4399dmw.com/baiduad/proxy.html?id=2409097"
[1:1:0713/015034.747168:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:5_http://www.4399dmw.com/, 37acedac99f0, , , ___adblockplus({"queryid" : "702ad9769efe8832","tuid" : "2409097_0","placement" : {"basic" : {"sspId
[1:1:0713/015034.747321:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=2409097", "www.4399dmw.com", 5, 1, http://www.4399dmw.com, www.4399dmw.com, 3
[12674:12674:0713/015034.763577:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0713/015034.764678:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 6, 0x2f6b967fe20
[1:1:0713/015034.764849:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 6
[12674:12674:0713/015034.765930:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 6, 6, 
[12674:12674:0713/015034.781049:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:6_http://www.4399dmw.com/, http://www.4399dmw.com/, 6
[12674:12674:0713/015034.781140:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 6, 6, http://www.4399dmw.com/, http://www.4399dmw.com
[1:1:0713/015034.808599:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[12674:12674:0713/015034.812468:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[12674:12674:0713/015034.814648:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: iframe2409097_0, 7, 7, 
[1:1:0713/015034.814742:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 7, 0x2f6b8e2e020
[1:1:0713/015034.814938:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 7
[12674:12674:0713/015034.830750:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:7_http://www.4399dmw.com/, http://www.4399dmw.com/, 7
[12674:12674:0713/015034.830839:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 7, 7, http://www.4399dmw.com/, http://www.4399dmw.com
[1:1:0713/015034.836284:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.4399dmw.com/baiduad/proxy.html?id=2409097"
[1:1:0713/015034.852492:INFO:switcher_impl.cc(1369)] 			updated frame chain. [WARN] subject_frame does not exist in protected memory. [subject_frame, principals, url] = 37aceda85e98, 5:5_http://www.4399dmw.com/, 5:7_http://www.4399dmw.com/, about:blank
[1:1:0713/015034.852709:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:5_http://www.4399dmw.com/-5:7_http://www.4399dmw.com/, 37aceda85e98, 37acedac99f0, open, 
[1:1:0713/015034.852860:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "www.4399dmw.com", 7, 2, http://www.4399dmw.com, www.4399dmw.com, 5
[1:1:0713/015034.853955:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.renderFrame (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	HTMLIFrameElement.onload (http://www.4399dmw.com/baiduad/proxy.html?id=2409097:21:10)
	Object.render (http://cbjs.baidu.com/js/m.js:1:1)
	Object.painterLoadedCallback (http://cbjs.baidu.com/js/m.js:1:1)
	Object.callback (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://pos.baidu.com/bcsm?psi=31b2b10ca08846b9469675b131acc0f9&di=2409097&dri=0&dis=5&dai=0&ps=0x0&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562953833336&ti=4399%E5%8A%A8%E6%BC%AB%E7%BD%91%20-%20%E5%9B%BD%E5%86%85%E9%A2%86%E5%85%88%E7%9A%84%E5%8A%A8%E6%BC%AB%E5%9C%A8%E7%BA%BF%E5%AE%98%E6%96%B9%E7%BD%91%E7%AB%99&ari=2&dbv=2&drs=1&pcs=887x681&pss=980x3643&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562953833&rw=320&ltu=http%3A%2F%2Fwww.4399dmw.com%2F&liu=http%3A%2F%2Fwww.4399dmw.com%2Fbaiduad%2Fproxy.html%3Fid%3D2409097&ecd=1&uc=1855x1056&pis=0x0&sr=1920x1080&tcn=1562953833&exps=110011&lto=http%3A%2F%2Fwww.4399dmw.com&ltl=1:1:1

[1:1:0713/015034.860387:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:5_http://www.4399dmw.com/-5:7_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/, 37acedac99f0, 37aceda85e98, regisetViewWatch, (t){this.isEventInited||(this.initializeEvent(),this.isEventInited=!0),this.watchingList=this.watchi
[1:1:0713/015034.860636:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=2409097", "www.4399dmw.com", 5, 3, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015034.861013:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.render (http://cbjs.baidu.com/js/m.js:1:1)
	Object.painterLoadedCallback (http://cbjs.baidu.com/js/m.js:1:1)
	Object.callback (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://pos.baidu.com/bcsm?psi=31b2b10ca08846b9469675b131acc0f9&di=2409097&dri=0&dis=5&dai=0&ps=0x0&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562953833336&ti=4399%E5%8A%A8%E6%BC%AB%E7%BD%91%20-%20%E5%9B%BD%E5%86%85%E9%A2%86%E5%85%88%E7%9A%84%E5%8A%A8%E6%BC%AB%E5%9C%A8%E7%BA%BF%E5%AE%98%E6%96%B9%E7%BD%91%E7%AB%99&ari=2&dbv=2&drs=1&pcs=887x681&pss=980x3643&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562953833&rw=320&ltu=http%3A%2F%2Fwww.4399dmw.com%2F&liu=http%3A%2F%2Fwww.4399dmw.com%2Fbaiduad%2Fproxy.html%3Fid%3D2409097&ecd=1&uc=1855x1056&pis=0x0&sr=1920x1080&tcn=1562953833&exps=110011&lto=http%3A%2F%2Fwww.4399dmw.com&ltl=1:1:1

[1:1:0713/015034.864139:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.4399dmw.com/baiduad/proxy.html?id=2409097", 500
[1:1:0713/015034.864383:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:5_http://www.4399dmw.com/, 906
[1:1:0713/015034.864519:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 906 0x7f3f5d194070 0x2f6bb7e38e0 , 5:5_http://www.4399dmw.com/, 3, -5:5_http://www.4399dmw.com/-5:7_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/, 828
[1:1:0713/015034.866143:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.4399dmw.com/baiduad/proxy.html?id=2409097", 50
[1:1:0713/015034.866379:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:5_http://www.4399dmw.com/, 907
[1:1:0713/015034.866509:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 907 0x7f3f5d194070 0x2f6bb7ec3e0 , 5:5_http://www.4399dmw.com/, 3, -5:5_http://www.4399dmw.com/-5:7_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/, 828
[1:1:0713/015034.877440:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:5_http://www.4399dmw.com/-5:7_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac99f0, toString, 
[1:1:0713/015034.877641:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 4, , , 0
[1:1:0713/015034.878185:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getPosition (http://cbjs.baidu.com/js/m.js:1:1)
	Object.calculateClientParam (http://cbjs.baidu.com/js/m.js:1:1)
	Object.regisetViewWatch (http://cbjs.baidu.com/js/m.js:1:1)
	Object.render (http://cbjs.baidu.com/js/m.js:1:1)
	Object.painterLoadedCallback (http://cbjs.baidu.com/js/m.js:1:1)
	Object.callback (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://pos.baidu.com/bcsm?psi=31b2b10ca08846b9469675b131acc0f9&di=2409097&dri=0&dis=5&dai=0&ps=0x0&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562953833336&ti=4399%E5%8A%A8%E6%BC%AB%E7%BD%91%20-%20%E5%9B%BD%E5%86%85%E9%A2%86%E5%85%88%E7%9A%84%E5%8A%A8%E6%BC%AB%E5%9C%A8%E7%BA%BF%E5%AE%98%E6%96%B9%E7%BD%91%E7%AB%99&ari=2&dbv=2&drs=1&pcs=887x681&pss=980x3643&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562953833&rw=320&ltu=http%3A%2F%2Fwww.4399dmw.com%2F&liu=http%3A%2F%2Fwww.4399dmw.com%2Fbaiduad%2Fproxy.html%3Fid%3D2409097&ecd=1&uc=1855x1056&pis=0x0&sr=1920x1080&tcn=1562953833&exps=110011&lto=http%3A%2F%2Fwww.4399dmw.com&ltl=1:1:1

[1:1:0713/015034.878488:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 5, -5:5_http://www.4399dmw.com/-5:7_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/, 37acedac99f0, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015034.878691:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=2409097", "www.4399dmw.com", 5, 5, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015034.879228:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getPosition (http://cbjs.baidu.com/js/m.js:1:1)
	Object.calculateClientParam (http://cbjs.baidu.com/js/m.js:1:1)
	Object.regisetViewWatch (http://cbjs.baidu.com/js/m.js:1:1)
	Object.render (http://cbjs.baidu.com/js/m.js:1:1)
	Object.painterLoadedCallback (http://cbjs.baidu.com/js/m.js:1:1)
	Object.callback (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://pos.baidu.com/bcsm?psi=31b2b10ca08846b9469675b131acc0f9&di=2409097&dri=0&dis=5&dai=0&ps=0x0&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562953833336&ti=4399%E5%8A%A8%E6%BC%AB%E7%BD%91%20-%20%E5%9B%BD%E5%86%85%E9%A2%86%E5%85%88%E7%9A%84%E5%8A%A8%E6%BC%AB%E5%9C%A8%E7%BA%BF%E5%AE%98%E6%96%B9%E7%BD%91%E7%AB%99&ari=2&dbv=2&drs=1&pcs=887x681&pss=980x3643&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562953833&rw=320&ltu=http%3A%2F%2Fwww.4399dmw.com%2F&liu=http%3A%2F%2Fwww.4399dmw.com%2Fbaiduad%2Fproxy.html%3Fid%3D2409097&ecd=1&uc=1855x1056&pis=0x0&sr=1920x1080&tcn=1562953833&exps=110011&lto=http%3A%2F%2Fwww.4399dmw.com&ltl=1:1:1

[1:1:0713/015034.879850:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 6, -5:5_http://www.4399dmw.com/-5:7_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac99f0, getBoundingClientRect, 
[1:1:0713/015034.879998:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 6, , , 0
[1:1:0713/015034.880438:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getPositionCore (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getPosition (http://cbjs.baidu.com/js/m.js:1:1)
	Object.calculateClientParam (http://cbjs.baidu.com/js/m.js:1:1)
	Object.regisetViewWatch (http://cbjs.baidu.com/js/m.js:1:1)
	Object.render (http://cbjs.baidu.com/js/m.js:1:1)
	Object.painterLoadedCallback (http://cbjs.baidu.com/js/m.js:1:1)
	Object.callback (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://pos.baidu.com/bcsm?psi=31b2b10ca08846b9469675b131acc0f9&di=2409097&dri=0&dis=5&dai=0&ps=0x0&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562953833336&ti=4399%E5%8A%A8%E6%BC%AB%E7%BD%91%20-%20%E5%9B%BD%E5%86%85%E9%A2%86%E5%85%88%E7%9A%84%E5%8A%A8%E6%BC%AB%E5%9C%A8%E7%BA%BF%E5%AE%98%E6%96%B9%E7%BD%91%E7%AB%99&ari=2&dbv=2&drs=1&pcs=887x681&pss=980x3643&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562953833&rw=320&ltu=http%3A%2F%2Fwww.4399dmw.com%2F&liu=http%3A%2F%2Fwww.4399dmw.com%2Fbaiduad%2Fproxy.html%3Fid%3D2409097&ecd=1&uc=1855x1056&pis=0x0&sr=1920x1080&tcn=1562953833&exps=110011&lto=http%3A%2F%2Fwww.4399dmw.com&ltl=1:1:1

[1:1:0713/015034.880610:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 7, -5:5_http://www.4399dmw.com/-5:7_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/, 37acedac99f0, 37aceda02860, floor, 
[1:1:0713/015034.880748:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=2409097", "www.4399dmw.com", 5, 7, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015034.881252:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getPositionCore (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getPosition (http://cbjs.baidu.com/js/m.js:1:1)
	Object.calculateClientParam (http://cbjs.baidu.com/js/m.js:1:1)
	Object.regisetViewWatch (http://cbjs.baidu.com/js/m.js:1:1)
	Object.render (http://cbjs.baidu.com/js/m.js:1:1)
	Object.painterLoadedCallback (http://cbjs.baidu.com/js/m.js:1:1)
	Object.callback (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://pos.baidu.com/bcsm?psi=31b2b10ca08846b9469675b131acc0f9&di=2409097&dri=0&dis=5&dai=0&ps=0x0&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562953833336&ti=4399%E5%8A%A8%E6%BC%AB%E7%BD%91%20-%20%E5%9B%BD%E5%86%85%E9%A2%86%E5%85%88%E7%9A%84%E5%8A%A8%E6%BC%AB%E5%9C%A8%E7%BA%BF%E5%AE%98%E6%96%B9%E7%BD%91%E7%AB%99&ari=2&dbv=2&drs=1&pcs=887x681&pss=980x3643&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562953833&rw=320&ltu=http%3A%2F%2Fwww.4399dmw.com%2F&liu=http%3A%2F%2Fwww.4399dmw.com%2Fbaiduad%2Fproxy.html%3Fid%3D2409097&ecd=1&uc=1855x1056&pis=0x0&sr=1920x1080&tcn=1562953833&exps=110011&lto=http%3A%2F%2Fwww.4399dmw.com&ltl=1:1:1

[1:1:0713/015034.882174:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 8, -5:5_http://www.4399dmw.com/-5:7_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac99f0, getComputedStyle, 
[1:1:0713/015034.882315:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 8, , , 0
[1:1:0713/015034.882778:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getStyle (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getPositionCore (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getPosition (http://cbjs.baidu.com/js/m.js:1:1)
	Object.calculateClientParam (http://cbjs.baidu.com/js/m.js:1:1)
	Object.regisetViewWatch (http://cbjs.baidu.com/js/m.js:1:1)
	Object.render (http://cbjs.baidu.com/js/m.js:1:1)
	Object.painterLoadedCallback (http://cbjs.baidu.com/js/m.js:1:1)
	Object.callback (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://pos.baidu.com/bcsm?psi=31b2b10ca08846b9469675b131acc0f9&di=2409097&dri=0&dis=5&dai=0&ps=0x0&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562953833336&ti=4399%E5%8A%A8%E6%BC%AB%E7%BD%91%20-%20%E5%9B%BD%E5%86%85%E9%A2%86%E5%85%88%E7%9A%84%E5%8A%A8%E6%BC%AB%E5%9C%A8%E7%BA%BF%E5%AE%98%E6%96%B9%E7%BD%91%E7%AB%99&ari=2&dbv=2&drs=1&pcs=887x681&pss=980x3643&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562953833&rw=320&ltu=http%3A%2F%2Fwww.4399dmw.com%2F&liu=http%3A%2F%2Fwww.4399dmw.com%2Fbaiduad%2Fproxy.html%3Fid%3D2409097&ecd=1&uc=1855x1056&pis=0x0&sr=1920x1080&tcn=1562953833&exps=110011&lto=http%3A%2F%2Fwww.4399dmw.com&ltl=1:1:1

[1:1:0713/015034.883096:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 9, -5:5_http://www.4399dmw.com/-5:7_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/, 37acedac99f0, 37aceda02860, getStyle, (t,e){if(!t)return"";var i="";i=e.indexOf("-")>-1?e.replace(/[-][^-]{1}/g,function(t){return t.charA
[1:1:0713/015034.883260:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=2409097", "www.4399dmw.com", 5, 9, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015034.883742:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getPositionCore (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getPosition (http://cbjs.baidu.com/js/m.js:1:1)
	Object.calculateClientParam (http://cbjs.baidu.com/js/m.js:1:1)
	Object.regisetViewWatch (http://cbjs.baidu.com/js/m.js:1:1)
	Object.render (http://cbjs.baidu.com/js/m.js:1:1)
	Object.painterLoadedCallback (http://cbjs.baidu.com/js/m.js:1:1)
	Object.callback (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://pos.baidu.com/bcsm?psi=31b2b10ca08846b9469675b131acc0f9&di=2409097&dri=0&dis=5&dai=0&ps=0x0&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562953833336&ti=4399%E5%8A%A8%E6%BC%AB%E7%BD%91%20-%20%E5%9B%BD%E5%86%85%E9%A2%86%E5%85%88%E7%9A%84%E5%8A%A8%E6%BC%AB%E5%9C%A8%E7%BA%BF%E5%AE%98%E6%96%B9%E7%BD%91%E7%AB%99&ari=2&dbv=2&drs=1&pcs=887x681&pss=980x3643&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562953833&rw=320&ltu=http%3A%2F%2Fwww.4399dmw.com%2F&liu=http%3A%2F%2Fwww.4399dmw.com%2Fbaiduad%2Fproxy.html%3Fid%3D2409097&ecd=1&uc=1855x1056&pis=0x0&sr=1920x1080&tcn=1562953833&exps=110011&lto=http%3A%2F%2Fwww.4399dmw.com&ltl=1:1:1

[1:1:0713/015034.884401:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 10, -5:5_http://www.4399dmw.com/-5:7_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac99f0, getComputedStyle, 
[1:1:0713/015034.884574:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 10, , , 0
[1:1:0713/015034.885199:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getStyle (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getPositionCore (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getPosition (http://cbjs.baidu.com/js/m.js:1:1)
	Object.calculateClientParam (http://cbjs.baidu.com/js/m.js:1:1)
	Object.regisetViewWatch (http://cbjs.baidu.com/js/m.js:1:1)
	Object.render (http://cbjs.baidu.com/js/m.js:1:1)
	Object.painterLoadedCallback (http://cbjs.baidu.com/js/m.js:1:1)
	Object.callback (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://pos.baidu.com/bcsm?psi=31b2b10ca08846b9469675b131acc0f9&di=2409097&dri=0&dis=5&dai=0&ps=0x0&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562953833336&ti=4399%E5%8A%A8%E6%BC%AB%E7%BD%91%20-%20%E5%9B%BD%E5%86%85%E9%A2%86%E5%85%88%E7%9A%84%E5%8A%A8%E6%BC%AB%E5%9C%A8%E7%BA%BF%E5%AE%98%E6%96%B9%E7%BD%91%E7%AB%99&ari=2&dbv=2&drs=1&pcs=887x681&pss=980x3643&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562953833&rw=320&ltu=http%3A%2F%2Fwww.4399dmw.com%2F&liu=http%3A%2F%2Fwww.4399dmw.com%2Fbaiduad%2Fproxy.html%3Fid%3D2409097&ecd=1&uc=1855x1056&pis=0x0&sr=1920x1080&tcn=1562953833&exps=110011&lto=http%3A%2F%2Fwww.4399dmw.com&ltl=1:1:1

[1:1:0713/015034.885554:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 11, -5:5_http://www.4399dmw.com/-5:7_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/, 37acedac99f0, 37aceda02860, parseInt, 
[1:1:0713/015034.885768:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=2409097", "www.4399dmw.com", 5, 11, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015034.886252:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getPositionCore (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getPosition (http://cbjs.baidu.com/js/m.js:1:1)
	Object.calculateClientParam (http://cbjs.baidu.com/js/m.js:1:1)
	Object.regisetViewWatch (http://cbjs.baidu.com/js/m.js:1:1)
	Object.render (http://cbjs.baidu.com/js/m.js:1:1)
	Object.painterLoadedCallback (http://cbjs.baidu.com/js/m.js:1:1)
	Object.callback (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://pos.baidu.com/bcsm?psi=31b2b10ca08846b9469675b131acc0f9&di=2409097&dri=0&dis=5&dai=0&ps=0x0&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562953833336&ti=4399%E5%8A%A8%E6%BC%AB%E7%BD%91%20-%20%E5%9B%BD%E5%86%85%E9%A2%86%E5%85%88%E7%9A%84%E5%8A%A8%E6%BC%AB%E5%9C%A8%E7%BA%BF%E5%AE%98%E6%96%B9%E7%BD%91%E7%AB%99&ari=2&dbv=2&drs=1&pcs=887x681&pss=980x3643&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562953833&rw=320&ltu=http%3A%2F%2Fwww.4399dmw.com%2F&liu=http%3A%2F%2Fwww.4399dmw.com%2Fbaiduad%2Fproxy.html%3Fid%3D2409097&ecd=1&uc=1855x1056&pis=0x0&sr=1920x1080&tcn=1562953833&exps=110011&lto=http%3A%2F%2Fwww.4399dmw.com&ltl=1:1:1

[1:1:0713/015034.889870:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 12, -5:5_http://www.4399dmw.com/-5:7_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac99f0, toString, 
[1:1:0713/015034.890060:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 12, , , 0
[1:1:0713/015034.890576:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.value (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	Object.getOneParam (http://cbjs.baidu.com/js/m.js:1:1)
	Object.addDebugSign (http://cbjs.baidu.com/js/m.js:1:1)
	Object.painterLoadedCallback (http://cbjs.baidu.com/js/m.js:1:1)
	Object.callback (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://pos.baidu.com/bcsm?psi=31b2b10ca08846b9469675b131acc0f9&di=2409097&dri=0&dis=5&dai=0&ps=0x0&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562953833336&ti=4399%E5%8A%A8%E6%BC%AB%E7%BD%91%20-%20%E5%9B%BD%E5%86%85%E9%A2%86%E5%85%88%E7%9A%84%E5%8A%A8%E6%BC%AB%E5%9C%A8%E7%BA%BF%E5%AE%98%E6%96%B9%E7%BD%91%E7%AB%99&ari=2&dbv=2&drs=1&pcs=887x681&pss=980x3643&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562953833&rw=320&ltu=http%3A%2F%2Fwww.4399dmw.com%2F&liu=http%3A%2F%2Fwww.4399dmw.com%2Fbaiduad%2Fproxy.html%3Fid%3D2409097&ecd=1&uc=1855x1056&pis=0x0&sr=1920x1080&tcn=1562953833&exps=110011&lto=http%3A%2F%2Fwww.4399dmw.com&ltl=1:1:1

[1:1:0713/015034.890801:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 13, -5:5_http://www.4399dmw.com/-5:7_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/, 37acedac99f0, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015034.891063:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=2409097", "www.4399dmw.com", 5, 13, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015034.891710:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.value (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	Object.getOneParam (http://cbjs.baidu.com/js/m.js:1:1)
	Object.addDebugSign (http://cbjs.baidu.com/js/m.js:1:1)
	Object.painterLoadedCallback (http://cbjs.baidu.com/js/m.js:1:1)
	Object.callback (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://pos.baidu.com/bcsm?psi=31b2b10ca08846b9469675b131acc0f9&di=2409097&dri=0&dis=5&dai=0&ps=0x0&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562953833336&ti=4399%E5%8A%A8%E6%BC%AB%E7%BD%91%20-%20%E5%9B%BD%E5%86%85%E9%A2%86%E5%85%88%E7%9A%84%E5%8A%A8%E6%BC%AB%E5%9C%A8%E7%BA%BF%E5%AE%98%E6%96%B9%E7%BD%91%E7%AB%99&ari=2&dbv=2&drs=1&pcs=887x681&pss=980x3643&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562953833&rw=320&ltu=http%3A%2F%2Fwww.4399dmw.com%2F&liu=http%3A%2F%2Fwww.4399dmw.com%2Fbaiduad%2Fproxy.html%3Fid%3D2409097&ecd=1&uc=1855x1056&pis=0x0&sr=1920x1080&tcn=1562953833&exps=110011&lto=http%3A%2F%2Fwww.4399dmw.com&ltl=1:1:1

[1:1:0713/015034.892901:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 14, -5:5_http://www.4399dmw.com/-5:7_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac99f0, toString, 
[1:1:0713/015034.893121:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 14, , , 0
[1:1:0713/015034.896411:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getNotCrossDomainTopWindow (http://cbjs.baidu.com/js/m.js:1:1)
	Object.value (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	Object.getOneParam (http://cbjs.baidu.com/js/m.js:1:1)
	Object.addDebugSign (http://cbjs.baidu.com/js/m.js:1:1)
	Object.painterLoadedCallback (http://cbjs.baidu.com/js/m.js:1:1)
	Object.callback (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://pos.baidu.com/bcsm?psi=31b2b10ca08846b9469675b131acc0f9&di=2409097&dri=0&dis=5&dai=0&ps=0x0&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562953833336&ti=4399%E5%8A%A8%E6%BC%AB%E7%BD%91%20-%20%E5%9B%BD%E5%86%85%E9%A2%86%E5%85%88%E7%9A%84%E5%8A%A8%E6%BC%AB%E5%9C%A8%E7%BA%BF%E5%AE%98%E6%96%B9%E7%BD%91%E7%AB%99&ari=2&dbv=2&drs=1&pcs=887x681&pss=980x3643&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562953833&rw=320&ltu=http%3A%2F%2Fwww.4399dmw.com%2F&liu=http%3A%2F%2Fwww.4399dmw.com%2Fbaiduad%2Fproxy.html%3Fid%3D2409097&ecd=1&uc=1855x1056&pis=0x0&sr=1920x1080&tcn=1562953833&exps=110011&lto=http%3A%2F%2Fwww.4399dmw.com&ltl=1:1:1

[1:1:0713/015034.896783:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 15, -5:5_http://www.4399dmw.com/-5:7_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/, 37acedac99f0, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015034.896988:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=2409097", "www.4399dmw.com", 5, 15, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015034.897572:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getNotCrossDomainTopWindow (http://cbjs.baidu.com/js/m.js:1:1)
	Object.value (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	Object.getOneParam (http://cbjs.baidu.com/js/m.js:1:1)
	Object.addDebugSign (http://cbjs.baidu.com/js/m.js:1:1)
	Object.painterLoadedCallback (http://cbjs.baidu.com/js/m.js:1:1)
	Object.callback (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://pos.baidu.com/bcsm?psi=31b2b10ca08846b9469675b131acc0f9&di=2409097&dri=0&dis=5&dai=0&ps=0x0&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562953833336&ti=4399%E5%8A%A8%E6%BC%AB%E7%BD%91%20-%20%E5%9B%BD%E5%86%85%E9%A2%86%E5%85%88%E7%9A%84%E5%8A%A8%E6%BC%AB%E5%9C%A8%E7%BA%BF%E5%AE%98%E6%96%B9%E7%BD%91%E7%AB%99&ari=2&dbv=2&drs=1&pcs=887x681&pss=980x3643&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562953833&rw=320&ltu=http%3A%2F%2Fwww.4399dmw.com%2F&liu=http%3A%2F%2Fwww.4399dmw.com%2Fbaiduad%2Fproxy.html%3Fid%3D2409097&ecd=1&uc=1855x1056&pis=0x0&sr=1920x1080&tcn=1562953833&exps=110011&lto=http%3A%2F%2Fwww.4399dmw.com&ltl=1:1:1

[1:1:0713/015034.900026:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 16, -5:5_http://www.4399dmw.com/-5:7_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac99f0, toString, 
[1:1:0713/015034.900241:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 16, , , 0
[1:1:0713/015034.900866:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getNotCrossDomainTopWindow (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getTopWindowUrl (http://cbjs.baidu.com/js/m.js:1:1)
	Object.value (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	Object.getOneParam (http://cbjs.baidu.com/js/m.js:1:1)
	Object.addDebugSign (http://cbjs.baidu.com/js/m.js:1:1)
	Object.painterLoadedCallback (http://cbjs.baidu.com/js/m.js:1:1)
	Object.callback (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://pos.baidu.com/bcsm?psi=31b2b10ca08846b9469675b131acc0f9&di=2409097&dri=0&dis=5&dai=0&ps=0x0&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562953833336&ti=4399%E5%8A%A8%E6%BC%AB%E7%BD%91%20-%20%E5%9B%BD%E5%86%85%E9%A2%86%E5%85%88%E7%9A%84%E5%8A%A8%E6%BC%AB%E5%9C%A8%E7%BA%BF%E5%AE%98%E6%96%B9%E7%BD%91%E7%AB%99&ari=2&dbv=2&drs=1&pcs=887x681&pss=980x3643&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562953833&rw=320&ltu=http%3A%2F%2Fwww.4399dmw.com%2F&liu=http%3A%2F%2Fwww.4399dmw.com%2Fbaiduad%2Fproxy.html%3Fid%3D2409097&ecd=1&uc=1855x1056&pis=0x0&sr=1920x1080&tcn=1562953833&exps=110011&lto=http%3A%2F%2Fwww.4399dmw.com&ltl=1:1:1

[1:1:0713/015034.901099:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 17, -5:5_http://www.4399dmw.com/-5:7_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/, 37acedac99f0, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015034.901321:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=2409097", "www.4399dmw.com", 5, 17, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015034.901915:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getNotCrossDomainTopWindow (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getTopWindowUrl (http://cbjs.baidu.com/js/m.js:1:1)
	Object.value (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	Object.getOneParam (http://cbjs.baidu.com/js/m.js:1:1)
	Object.addDebugSign (http://cbjs.baidu.com/js/m.js:1:1)
	Object.painterLoadedCallback (http://cbjs.baidu.com/js/m.js:1:1)
	Object.callback (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://pos.baidu.com/bcsm?psi=31b2b10ca08846b9469675b131acc0f9&di=2409097&dri=0&dis=5&dai=0&ps=0x0&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562953833336&ti=4399%E5%8A%A8%E6%BC%AB%E7%BD%91%20-%20%E5%9B%BD%E5%86%85%E9%A2%86%E5%85%88%E7%9A%84%E5%8A%A8%E6%BC%AB%E5%9C%A8%E7%BA%BF%E5%AE%98%E6%96%B9%E7%BD%91%E7%AB%99&ari=2&dbv=2&drs=1&pcs=887x681&pss=980x3643&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562953833&rw=320&ltu=http%3A%2F%2Fwww.4399dmw.com%2F&liu=http%3A%2F%2Fwww.4399dmw.com%2Fbaiduad%2Fproxy.html%3Fid%3D2409097&ecd=1&uc=1855x1056&pis=0x0&sr=1920x1080&tcn=1562953833&exps=110011&lto=http%3A%2F%2Fwww.4399dmw.com&ltl=1:1:1

[1:1:0713/015034.906757:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://www.4399dmw.com/baiduad/proxy.html?id=2409097"
[1:1:0713/015034.908671:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 2000, 0x500731d01c8, 0x2f6b8a4ea10
[1:1:0713/015034.908905:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.4399dmw.com/baiduad/proxy.html?id=2409097", 2000
[1:1:0713/015034.909102:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:5_http://www.4399dmw.com/, 914
[1:1:0713/015034.909351:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 914 0x7f3f5d194070 0x2f6bb843e60 , 5:5_http://www.4399dmw.com/, 17, -5:5_http://www.4399dmw.com/-5:7_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/, 828
[1:1:0713/015034.911759:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.4399dmw.com/baiduad/proxy.html?id=2409097"
[12674:12674:0713/015034.916908:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0713/015034.918128:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 8, 0x2f6b967ea20
[1:1:0713/015034.918277:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 8
[12674:12674:0713/015034.919402:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 8, 8, 
[1:1:0713/015034.926110:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0713/015034.926268:INFO:render_frame_impl.cc(7019)] 	 [url] = http://www.4399dmw.com
[12674:12674:0713/015034.927074:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:5_http://www.4399dmw.com/
[1:1:0713/015034.927159:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.4399dmw.com/baiduad/proxy.html?id=2409097"
[12674:12674:0713/015034.934433:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[12674:12674:0713/015034.936898:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[12674:12685:0713/015034.955833:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 8
[12674:12685:0713/015034.955896:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 8, HandleIncomingMessage, HandleIncomingMessage
[12674:12674:0713/015034.955937:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://pos.baidu.com/
[12674:12674:0713/015034.955977:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:8_https://pos.baidu.com/, https://pos.baidu.com/wh/o.htm?ltr=, 8
[12674:12674:0713/015034.956040:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:8_https://pos.baidu.com/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 17:49:49 GMT Last-Modified: Fri, 12 Jul 2019 03:18:19 GMT P3p: CP=" OTI DSP COR IVA OUR IND COM " Server: nginx Accept-Ranges: bytes Content-Length: 553 Content-Type: text/html Etag: "5d27fbfb-229"  ,12768, 5
[1:7:0713/015034.960390:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/015034.960503:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 831 0x7f3f5f0bc2e0 0x2f6ba2b3360 , "http://www.4399dmw.com/"
[1:1:0713/015034.961467:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.4399dmw.com/, 37aceda02860, , , window._bd_share_main.F.module("component/partners",function(e,t){t.partners={evernotecn:{name:"\u53
[1:1:0713/015034.961746:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 1, , , 0
[1:1:0713/015034.970647:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.4399dmw.com/"
[1:1:0713/015035.030486:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.4399dmw.com/, 837, 7f3f5fad9881
[1:1:0713/015035.045113:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"37aceda02860","ptid":"796 0x7f3f5d194070 0x2f6ba58d760 ","rf":"5:3_http://www.4399dmw.com/"}
[1:1:0713/015035.045347:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.4399dmw.com/","ptid":"796 0x7f3f5d194070 0x2f6ba58d760 ","rf":"5:3_http://www.4399dmw.com/"}
[1:1:0713/015035.045648:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.4399dmw.com/"
[1:1:0713/015035.046003:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.4399dmw.com/, 37aceda02860, , , (){n?t&&t():l(e,t)}
[1:1:0713/015035.046165:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 1, , , 0
[1:1:0713/015035.076441:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.4399dmw.com/, 37aceda02860, , , document.readyState
[1:1:0713/015035.076609:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 1, , , 0
[1:1:0713/015035.150011:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.4399dmw.com/, 836, 7f3f5fad9881
[1:1:0713/015035.164194:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"37aceda02860","ptid":"790 0x7f3f5d194070 0x2f6ba5a8560 ","rf":"5:3_http://www.4399dmw.com/"}
[1:1:0713/015035.164373:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.4399dmw.com/","ptid":"790 0x7f3f5d194070 0x2f6ba5a8560 ","rf":"5:3_http://www.4399dmw.com/"}
[1:1:0713/015035.164572:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.4399dmw.com/"
[1:1:0713/015035.164832:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.4399dmw.com/, 37aceda02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/015035.164918:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 1, , , 0
[1:1:0713/015035.165221:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x500731029c8, 0x2f6b8a4e950
[1:1:0713/015035.165321:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.4399dmw.com/", 100
[1:1:0713/015035.165478:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.4399dmw.com/, 943
[1:1:0713/015035.165582:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 943 0x7f3f5d194070 0x2f6bb848b60 , 5:3_http://www.4399dmw.com/, 1, -5:3_http://www.4399dmw.com/, 836 0x7f3f5d194070 0x2f6b8a5c360 
[1:1:0713/015035.254392:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 851, "http://www.4399dmw.com/baiduad/proxy.html?id=846418"
[1:1:0713/015035.255264:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://www.4399dmw.com/, 37acedac4648, , , ___adblockplus({"queryid" : "570c28b0d2e29c09","tuid" : "846418_0","placement" : {"basic" : {"sspId"
[1:1:0713/015035.255424:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=846418", "www.4399dmw.com", 4, 1, http://www.4399dmw.com, www.4399dmw.com, 3
[12674:12674:0713/015035.266150:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0713/015035.267277:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 9, 0x2f6b96f4420
[1:1:0713/015035.268092:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 9
[12674:12674:0713/015035.268539:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 9, 9, 
[12674:12674:0713/015035.284011:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:9_http://www.4399dmw.com/, http://www.4399dmw.com/, 9
[12674:12674:0713/015035.284095:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 9, 9, http://www.4399dmw.com/, http://www.4399dmw.com
[1:1:0713/015035.309684:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0713/015035.312364:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 10, 0x2f6b96f3a20
[1:1:0713/015035.312509:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 10
[12674:12674:0713/015035.313021:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[12674:12674:0713/015035.315452:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: iframe846418_0, 10, 10, 
[12674:12674:0713/015035.328831:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:10_http://www.4399dmw.com/, http://www.4399dmw.com/, 10
[12674:12674:0713/015035.328918:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 10, 10, http://www.4399dmw.com/, http://www.4399dmw.com
[1:1:0713/015035.331483:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.4399dmw.com/baiduad/proxy.html?id=846418"
[1:1:0713/015035.346904:INFO:switcher_impl.cc(1369)] 			updated frame chain. [WARN] subject_frame does not exist in protected memory. [subject_frame, principals, url] = 37aceda9bd58, 5:4_http://www.4399dmw.com/, 5:10_http://www.4399dmw.com/, about:blank
[1:1:0713/015035.347118:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_http://www.4399dmw.com/-5:10_http://www.4399dmw.com/, 37aceda9bd58, 37acedac4648, open, 
[1:1:0713/015035.347293:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "www.4399dmw.com", 10, 2, http://www.4399dmw.com, www.4399dmw.com, 4
[1:1:0713/015035.348432:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.renderFrame (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	HTMLIFrameElement.onload (http://www.4399dmw.com/baiduad/proxy.html?id=846418:21:10)
	Object.render (http://cbjs.baidu.com/js/m.js:1:1)
	Object.painterLoadedCallback (http://cbjs.baidu.com/js/m.js:1:1)
	Object.callback (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://pos.baidu.com/ncem?psi=cc9fdc8d01c5d982eec4cdecd4e12a2c&di=846418&dri=0&dis=1&dai=0&ps=386x0&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562953833336&ti=4399%E5%8A%A8%E6%BC%AB%E7%BD%91%20-%20%E5%9B%BD%E5%86%85%E9%A2%86%E5%85%88%E7%9A%84%E5%8A%A8%E6%BC%AB%E5%9C%A8%E7%BA%BF%E5%AE%98%E6%96%B9%E7%BD%91%E7%AB%99&ari=2&dbv=2&drs=1&pcs=887x681&pss=980x3643&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562953834&rw=320&ltu=http%3A%2F%2Fwww.4399dmw.com%2F&liu=http%3A%2F%2Fwww.4399dmw.com%2Fbaiduad%2Fproxy.html%3Fid%3D846418&ecd=1&uc=1855x1056&pis=980x90&sr=1920x1080&tcn=1562953834&exps=110011&lto=http%3A%2F%2Fwww.4399dmw.com&ltl=1:1:1

[1:1:0713/015035.353782:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_http://www.4399dmw.com/-5:10_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/, 37acedac4648, 37aceda9bd58, regisetViewWatch, (t){this.isEventInited||(this.initializeEvent(),this.isEventInited=!0),this.watchingList=this.watchi
[1:1:0713/015035.353993:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=846418", "www.4399dmw.com", 4, 3, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015035.354386:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.render (http://cbjs.baidu.com/js/m.js:1:1)
	Object.painterLoadedCallback (http://cbjs.baidu.com/js/m.js:1:1)
	Object.callback (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://pos.baidu.com/ncem?psi=cc9fdc8d01c5d982eec4cdecd4e12a2c&di=846418&dri=0&dis=1&dai=0&ps=386x0&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562953833336&ti=4399%E5%8A%A8%E6%BC%AB%E7%BD%91%20-%20%E5%9B%BD%E5%86%85%E9%A2%86%E5%85%88%E7%9A%84%E5%8A%A8%E6%BC%AB%E5%9C%A8%E7%BA%BF%E5%AE%98%E6%96%B9%E7%BD%91%E7%AB%99&ari=2&dbv=2&drs=1&pcs=887x681&pss=980x3643&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562953834&rw=320&ltu=http%3A%2F%2Fwww.4399dmw.com%2F&liu=http%3A%2F%2Fwww.4399dmw.com%2Fbaiduad%2Fproxy.html%3Fid%3D846418&ecd=1&uc=1855x1056&pis=980x90&sr=1920x1080&tcn=1562953834&exps=110011&lto=http%3A%2F%2Fwww.4399dmw.com&ltl=1:1:1

[1:1:0713/015035.356271:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.4399dmw.com/baiduad/proxy.html?id=846418", 500
[1:1:0713/015035.356552:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:4_http://www.4399dmw.com/, 982
[1:1:0713/015035.356676:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 982 0x7f3f5d194070 0x2f6bb921c60 , 5:4_http://www.4399dmw.com/, 3, -5:4_http://www.4399dmw.com/-5:10_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/, 851
[1:1:0713/015035.358101:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.4399dmw.com/baiduad/proxy.html?id=846418", 50
[1:1:0713/015035.358393:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:4_http://www.4399dmw.com/, 983
[1:1:0713/015035.358551:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 983 0x7f3f5d194070 0x2f6bb925860 , 5:4_http://www.4399dmw.com/, 3, -5:4_http://www.4399dmw.com/-5:10_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/, 851
[1:1:0713/015035.368780:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_http://www.4399dmw.com/-5:10_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac4648, toString, 
[1:1:0713/015035.368973:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 4, , , 0
[1:1:0713/015035.369516:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getPosition (http://cbjs.baidu.com/js/m.js:1:1)
	Object.calculateClientParam (http://cbjs.baidu.com/js/m.js:1:1)
	Object.regisetViewWatch (http://cbjs.baidu.com/js/m.js:1:1)
	Object.render (http://cbjs.baidu.com/js/m.js:1:1)
	Object.painterLoadedCallback (http://cbjs.baidu.com/js/m.js:1:1)
	Object.callback (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://pos.baidu.com/ncem?psi=cc9fdc8d01c5d982eec4cdecd4e12a2c&di=846418&dri=0&dis=1&dai=0&ps=386x0&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562953833336&ti=4399%E5%8A%A8%E6%BC%AB%E7%BD%91%20-%20%E5%9B%BD%E5%86%85%E9%A2%86%E5%85%88%E7%9A%84%E5%8A%A8%E6%BC%AB%E5%9C%A8%E7%BA%BF%E5%AE%98%E6%96%B9%E7%BD%91%E7%AB%99&ari=2&dbv=2&drs=1&pcs=887x681&pss=980x3643&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562953834&rw=320&ltu=http%3A%2F%2Fwww.4399dmw.com%2F&liu=http%3A%2F%2Fwww.4399dmw.com%2Fbaiduad%2Fproxy.html%3Fid%3D846418&ecd=1&uc=1855x1056&pis=980x90&sr=1920x1080&tcn=1562953834&exps=110011&lto=http%3A%2F%2Fwww.4399dmw.com&ltl=1:1:1

[1:1:0713/015035.369726:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 5, -5:4_http://www.4399dmw.com/-5:10_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/, 37acedac4648, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015035.369876:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=846418", "www.4399dmw.com", 4, 5, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015035.370351:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getPosition (http://cbjs.baidu.com/js/m.js:1:1)
	Object.calculateClientParam (http://cbjs.baidu.com/js/m.js:1:1)
	Object.regisetViewWatch (http://cbjs.baidu.com/js/m.js:1:1)
	Object.render (http://cbjs.baidu.com/js/m.js:1:1)
	Object.painterLoadedCallback (http://cbjs.baidu.com/js/m.js:1:1)
	Object.callback (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://pos.baidu.com/ncem?psi=cc9fdc8d01c5d982eec4cdecd4e12a2c&di=846418&dri=0&dis=1&dai=0&ps=386x0&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562953833336&ti=4399%E5%8A%A8%E6%BC%AB%E7%BD%91%20-%20%E5%9B%BD%E5%86%85%E9%A2%86%E5%85%88%E7%9A%84%E5%8A%A8%E6%BC%AB%E5%9C%A8%E7%BA%BF%E5%AE%98%E6%96%B9%E7%BD%91%E7%AB%99&ari=2&dbv=2&drs=1&pcs=887x681&pss=980x3643&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562953834&rw=320&ltu=http%3A%2F%2Fwww.4399dmw.com%2F&liu=http%3A%2F%2Fwww.4399dmw.com%2Fbaiduad%2Fproxy.html%3Fid%3D846418&ecd=1&uc=1855x1056&pis=980x90&sr=1920x1080&tcn=1562953834&exps=110011&lto=http%3A%2F%2Fwww.4399dmw.com&ltl=1:1:1

[1:1:0713/015035.370924:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 6, -5:4_http://www.4399dmw.com/-5:10_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac4648, getBoundingClientRect, 
[1:1:0713/015035.371051:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 6, , , 0
[1:1:0713/015035.371484:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getPositionCore (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getPosition (http://cbjs.baidu.com/js/m.js:1:1)
	Object.calculateClientParam (http://cbjs.baidu.com/js/m.js:1:1)
	Object.regisetViewWatch (http://cbjs.baidu.com/js/m.js:1:1)
	Object.render (http://cbjs.baidu.com/js/m.js:1:1)
	Object.painterLoadedCallback (http://cbjs.baidu.com/js/m.js:1:1)
	Object.callback (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://pos.baidu.com/ncem?psi=cc9fdc8d01c5d982eec4cdecd4e12a2c&di=846418&dri=0&dis=1&dai=0&ps=386x0&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562953833336&ti=4399%E5%8A%A8%E6%BC%AB%E7%BD%91%20-%20%E5%9B%BD%E5%86%85%E9%A2%86%E5%85%88%E7%9A%84%E5%8A%A8%E6%BC%AB%E5%9C%A8%E7%BA%BF%E5%AE%98%E6%96%B9%E7%BD%91%E7%AB%99&ari=2&dbv=2&drs=1&pcs=887x681&pss=980x3643&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562953834&rw=320&ltu=http%3A%2F%2Fwww.4399dmw.com%2F&liu=http%3A%2F%2Fwww.4399dmw.com%2Fbaiduad%2Fproxy.html%3Fid%3D846418&ecd=1&uc=1855x1056&pis=980x90&sr=1920x1080&tcn=1562953834&exps=110011&lto=http%3A%2F%2Fwww.4399dmw.com&ltl=1:1:1

[1:1:0713/015035.371690:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 7, -5:4_http://www.4399dmw.com/-5:10_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/, 37acedac4648, 37aceda02860, floor, 
[1:1:0713/015035.371826:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=846418", "www.4399dmw.com", 4, 7, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015035.372256:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getPositionCore (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getPosition (http://cbjs.baidu.com/js/m.js:1:1)
	Object.calculateClientParam (http://cbjs.baidu.com/js/m.js:1:1)
	Object.regisetViewWatch (http://cbjs.baidu.com/js/m.js:1:1)
	Object.render (http://cbjs.baidu.com/js/m.js:1:1)
	Object.painterLoadedCallback (http://cbjs.baidu.com/js/m.js:1:1)
	Object.callback (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://pos.baidu.com/ncem?psi=cc9fdc8d01c5d982eec4cdecd4e12a2c&di=846418&dri=0&dis=1&dai=0&ps=386x0&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562953833336&ti=4399%E5%8A%A8%E6%BC%AB%E7%BD%91%20-%20%E5%9B%BD%E5%86%85%E9%A2%86%E5%85%88%E7%9A%84%E5%8A%A8%E6%BC%AB%E5%9C%A8%E7%BA%BF%E5%AE%98%E6%96%B9%E7%BD%91%E7%AB%99&ari=2&dbv=2&drs=1&pcs=887x681&pss=980x3643&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562953834&rw=320&ltu=http%3A%2F%2Fwww.4399dmw.com%2F&liu=http%3A%2F%2Fwww.4399dmw.com%2Fbaiduad%2Fproxy.html%3Fid%3D846418&ecd=1&uc=1855x1056&pis=980x90&sr=1920x1080&tcn=1562953834&exps=110011&lto=http%3A%2F%2Fwww.4399dmw.com&ltl=1:1:1

[1:1:0713/015035.373128:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 8, -5:4_http://www.4399dmw.com/-5:10_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac4648, getComputedStyle, 
[1:1:0713/015035.373264:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 8, , , 0
[1:1:0713/015035.373746:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getStyle (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getPositionCore (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getPosition (http://cbjs.baidu.com/js/m.js:1:1)
	Object.calculateClientParam (http://cbjs.baidu.com/js/m.js:1:1)
	Object.regisetViewWatch (http://cbjs.baidu.com/js/m.js:1:1)
	Object.render (http://cbjs.baidu.com/js/m.js:1:1)
	Object.painterLoadedCallback (http://cbjs.baidu.com/js/m.js:1:1)
	Object.callback (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://pos.baidu.com/ncem?psi=cc9fdc8d01c5d982eec4cdecd4e12a2c&di=846418&dri=0&dis=1&dai=0&ps=386x0&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562953833336&ti=4399%E5%8A%A8%E6%BC%AB%E7%BD%91%20-%20%E5%9B%BD%E5%86%85%E9%A2%86%E5%85%88%E7%9A%84%E5%8A%A8%E6%BC%AB%E5%9C%A8%E7%BA%BF%E5%AE%98%E6%96%B9%E7%BD%91%E7%AB%99&ari=2&dbv=2&drs=1&pcs=887x681&pss=980x3643&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562953834&rw=320&ltu=http%3A%2F%2Fwww.4399dmw.com%2F&liu=http%3A%2F%2Fwww.4399dmw.com%2Fbaiduad%2Fproxy.html%3Fid%3D846418&ecd=1&uc=1855x1056&pis=980x90&sr=1920x1080&tcn=1562953834&exps=110011&lto=http%3A%2F%2Fwww.4399dmw.com&ltl=1:1:1

[1:1:0713/015035.374057:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 9, -5:4_http://www.4399dmw.com/-5:10_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/, 37acedac4648, 37aceda02860, getStyle, (t,e){if(!t)return"";var i="";i=e.indexOf("-")>-1?e.replace(/[-][^-]{1}/g,function(t){return t.charA
[1:1:0713/015035.374235:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=846418", "www.4399dmw.com", 4, 9, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015035.374794:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getPositionCore (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getPosition (http://cbjs.baidu.com/js/m.js:1:1)
	Object.calculateClientParam (http://cbjs.baidu.com/js/m.js:1:1)
	Object.regisetViewWatch (http://cbjs.baidu.com/js/m.js:1:1)
	Object.render (http://cbjs.baidu.com/js/m.js:1:1)
	Object.painterLoadedCallback (http://cbjs.baidu.com/js/m.js:1:1)
	Object.callback (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://pos.baidu.com/ncem?psi=cc9fdc8d01c5d982eec4cdecd4e12a2c&di=846418&dri=0&dis=1&dai=0&ps=386x0&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562953833336&ti=4399%E5%8A%A8%E6%BC%AB%E7%BD%91%20-%20%E5%9B%BD%E5%86%85%E9%A2%86%E5%85%88%E7%9A%84%E5%8A%A8%E6%BC%AB%E5%9C%A8%E7%BA%BF%E5%AE%98%E6%96%B9%E7%BD%91%E7%AB%99&ari=2&dbv=2&drs=1&pcs=887x681&pss=980x3643&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562953834&rw=320&ltu=http%3A%2F%2Fwww.4399dmw.com%2F&liu=http%3A%2F%2Fwww.4399dmw.com%2Fbaiduad%2Fproxy.html%3Fid%3D846418&ecd=1&uc=1855x1056&pis=980x90&sr=1920x1080&tcn=1562953834&exps=110011&lto=http%3A%2F%2Fwww.4399dmw.com&ltl=1:1:1

[1:1:0713/015035.375479:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 10, -5:4_http://www.4399dmw.com/-5:10_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac4648, getComputedStyle, 
[1:1:0713/015035.375699:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 10, , , 0
[1:1:0713/015035.376243:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getStyle (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getPositionCore (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getPosition (http://cbjs.baidu.com/js/m.js:1:1)
	Object.calculateClientParam (http://cbjs.baidu.com/js/m.js:1:1)
	Object.regisetViewWatch (http://cbjs.baidu.com/js/m.js:1:1)
	Object.render (http://cbjs.baidu.com/js/m.js:1:1)
	Object.painterLoadedCallback (http://cbjs.baidu.com/js/m.js:1:1)
	Object.callback (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://pos.baidu.com/ncem?psi=cc9fdc8d01c5d982eec4cdecd4e12a2c&di=846418&dri=0&dis=1&dai=0&ps=386x0&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562953833336&ti=4399%E5%8A%A8%E6%BC%AB%E7%BD%91%20-%20%E5%9B%BD%E5%86%85%E9%A2%86%E5%85%88%E7%9A%84%E5%8A%A8%E6%BC%AB%E5%9C%A8%E7%BA%BF%E5%AE%98%E6%96%B9%E7%BD%91%E7%AB%99&ari=2&dbv=2&drs=1&pcs=887x681&pss=980x3643&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562953834&rw=320&ltu=http%3A%2F%2Fwww.4399dmw.com%2F&liu=http%3A%2F%2Fwww.4399dmw.com%2Fbaiduad%2Fproxy.html%3Fid%3D846418&ecd=1&uc=1855x1056&pis=980x90&sr=1920x1080&tcn=1562953834&exps=110011&lto=http%3A%2F%2Fwww.4399dmw.com&ltl=1:1:1

[1:1:0713/015035.376563:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 11, -5:4_http://www.4399dmw.com/-5:10_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/, 37acedac4648, 37aceda02860, parseInt, 
[1:1:0713/015035.376731:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=846418", "www.4399dmw.com", 4, 11, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015035.377357:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getPositionCore (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getPosition (http://cbjs.baidu.com/js/m.js:1:1)
	Object.calculateClientParam (http://cbjs.baidu.com/js/m.js:1:1)
	Object.regisetViewWatch (http://cbjs.baidu.com/js/m.js:1:1)
	Object.render (http://cbjs.baidu.com/js/m.js:1:1)
	Object.painterLoadedCallback (http://cbjs.baidu.com/js/m.js:1:1)
	Object.callback (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://pos.baidu.com/ncem?psi=cc9fdc8d01c5d982eec4cdecd4e12a2c&di=846418&dri=0&dis=1&dai=0&ps=386x0&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562953833336&ti=4399%E5%8A%A8%E6%BC%AB%E7%BD%91%20-%20%E5%9B%BD%E5%86%85%E9%A2%86%E5%85%88%E7%9A%84%E5%8A%A8%E6%BC%AB%E5%9C%A8%E7%BA%BF%E5%AE%98%E6%96%B9%E7%BD%91%E7%AB%99&ari=2&dbv=2&drs=1&pcs=887x681&pss=980x3643&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562953834&rw=320&ltu=http%3A%2F%2Fwww.4399dmw.com%2F&liu=http%3A%2F%2Fwww.4399dmw.com%2Fbaiduad%2Fproxy.html%3Fid%3D846418&ecd=1&uc=1855x1056&pis=980x90&sr=1920x1080&tcn=1562953834&exps=110011&lto=http%3A%2F%2Fwww.4399dmw.com&ltl=1:1:1

[1:1:0713/015035.380798:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 12, -5:4_http://www.4399dmw.com/-5:10_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac4648, toString, 
[1:1:0713/015035.381003:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 12, , , 0
[1:1:0713/015035.381566:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.value (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	Object.getOneParam (http://cbjs.baidu.com/js/m.js:1:1)
	Object.addDebugSign (http://cbjs.baidu.com/js/m.js:1:1)
	Object.painterLoadedCallback (http://cbjs.baidu.com/js/m.js:1:1)
	Object.callback (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://pos.baidu.com/ncem?psi=cc9fdc8d01c5d982eec4cdecd4e12a2c&di=846418&dri=0&dis=1&dai=0&ps=386x0&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562953833336&ti=4399%E5%8A%A8%E6%BC%AB%E7%BD%91%20-%20%E5%9B%BD%E5%86%85%E9%A2%86%E5%85%88%E7%9A%84%E5%8A%A8%E6%BC%AB%E5%9C%A8%E7%BA%BF%E5%AE%98%E6%96%B9%E7%BD%91%E7%AB%99&ari=2&dbv=2&drs=1&pcs=887x681&pss=980x3643&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562953834&rw=320&ltu=http%3A%2F%2Fwww.4399dmw.com%2F&liu=http%3A%2F%2Fwww.4399dmw.com%2Fbaiduad%2Fproxy.html%3Fid%3D846418&ecd=1&uc=1855x1056&pis=980x90&sr=1920x1080&tcn=1562953834&exps=110011&lto=http%3A%2F%2Fwww.4399dmw.com&ltl=1:1:1

[1:1:0713/015035.381814:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 13, -5:4_http://www.4399dmw.com/-5:10_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/, 37acedac4648, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015035.382019:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=846418", "www.4399dmw.com", 4, 13, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015035.382650:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.value (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	Object.getOneParam (http://cbjs.baidu.com/js/m.js:1:1)
	Object.addDebugSign (http://cbjs.baidu.com/js/m.js:1:1)
	Object.painterLoadedCallback (http://cbjs.baidu.com/js/m.js:1:1)
	Object.callback (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://pos.baidu.com/ncem?psi=cc9fdc8d01c5d982eec4cdecd4e12a2c&di=846418&dri=0&dis=1&dai=0&ps=386x0&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562953833336&ti=4399%E5%8A%A8%E6%BC%AB%E7%BD%91%20-%20%E5%9B%BD%E5%86%85%E9%A2%86%E5%85%88%E7%9A%84%E5%8A%A8%E6%BC%AB%E5%9C%A8%E7%BA%BF%E5%AE%98%E6%96%B9%E7%BD%91%E7%AB%99&ari=2&dbv=2&drs=1&pcs=887x681&pss=980x3643&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562953834&rw=320&ltu=http%3A%2F%2Fwww.4399dmw.com%2F&liu=http%3A%2F%2Fwww.4399dmw.com%2Fbaiduad%2Fproxy.html%3Fid%3D846418&ecd=1&uc=1855x1056&pis=980x90&sr=1920x1080&tcn=1562953834&exps=110011&lto=http%3A%2F%2Fwww.4399dmw.com&ltl=1:1:1

[1:1:0713/015035.383668:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 14, -5:4_http://www.4399dmw.com/-5:10_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac4648, toString, 
[1:1:0713/015035.383845:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 14, , , 0
[1:1:0713/015035.384384:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getNotCrossDomainTopWindow (http://cbjs.baidu.com/js/m.js:1:1)
	Object.value (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	Object.getOneParam (http://cbjs.baidu.com/js/m.js:1:1)
	Object.addDebugSign (http://cbjs.baidu.com/js/m.js:1:1)
	Object.painterLoadedCallback (http://cbjs.baidu.com/js/m.js:1:1)
	Object.callback (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://pos.baidu.com/ncem?psi=cc9fdc8d01c5d982eec4cdecd4e12a2c&di=846418&dri=0&dis=1&dai=0&ps=386x0&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562953833336&ti=4399%E5%8A%A8%E6%BC%AB%E7%BD%91%20-%20%E5%9B%BD%E5%86%85%E9%A2%86%E5%85%88%E7%9A%84%E5%8A%A8%E6%BC%AB%E5%9C%A8%E7%BA%BF%E5%AE%98%E6%96%B9%E7%BD%91%E7%AB%99&ari=2&dbv=2&drs=1&pcs=887x681&pss=980x3643&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562953834&rw=320&ltu=http%3A%2F%2Fwww.4399dmw.com%2F&liu=http%3A%2F%2Fwww.4399dmw.com%2Fbaiduad%2Fproxy.html%3Fid%3D846418&ecd=1&uc=1855x1056&pis=980x90&sr=1920x1080&tcn=1562953834&exps=110011&lto=http%3A%2F%2Fwww.4399dmw.com&ltl=1:1:1

[1:1:0713/015035.384589:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 15, -5:4_http://www.4399dmw.com/-5:10_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/, 37acedac4648, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015035.384781:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=846418", "www.4399dmw.com", 4, 15, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015035.385333:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getNotCrossDomainTopWindow (http://cbjs.baidu.com/js/m.js:1:1)
	Object.value (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	Object.getOneParam (http://cbjs.baidu.com/js/m.js:1:1)
	Object.addDebugSign (http://cbjs.baidu.com/js/m.js:1:1)
	Object.painterLoadedCallback (http://cbjs.baidu.com/js/m.js:1:1)
	Object.callback (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://pos.baidu.com/ncem?psi=cc9fdc8d01c5d982eec4cdecd4e12a2c&di=846418&dri=0&dis=1&dai=0&ps=386x0&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562953833336&ti=4399%E5%8A%A8%E6%BC%AB%E7%BD%91%20-%20%E5%9B%BD%E5%86%85%E9%A2%86%E5%85%88%E7%9A%84%E5%8A%A8%E6%BC%AB%E5%9C%A8%E7%BA%BF%E5%AE%98%E6%96%B9%E7%BD%91%E7%AB%99&ari=2&dbv=2&drs=1&pcs=887x681&pss=980x3643&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562953834&rw=320&ltu=http%3A%2F%2Fwww.4399dmw.com%2F&liu=http%3A%2F%2Fwww.4399dmw.com%2Fbaiduad%2Fproxy.html%3Fid%3D846418&ecd=1&uc=1855x1056&pis=980x90&sr=1920x1080&tcn=1562953834&exps=110011&lto=http%3A%2F%2Fwww.4399dmw.com&ltl=1:1:1

[1:1:0713/015035.387564:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 16, -5:4_http://www.4399dmw.com/-5:10_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac4648, toString, 
[1:1:0713/015035.387764:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 16, , , 0
[1:1:0713/015035.388408:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getNotCrossDomainTopWindow (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getTopWindowUrl (http://cbjs.baidu.com/js/m.js:1:1)
	Object.value (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	Object.getOneParam (http://cbjs.baidu.com/js/m.js:1:1)
	Object.addDebugSign (http://cbjs.baidu.com/js/m.js:1:1)
	Object.painterLoadedCallback (http://cbjs.baidu.com/js/m.js:1:1)
	Object.callback (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://pos.baidu.com/ncem?psi=cc9fdc8d01c5d982eec4cdecd4e12a2c&di=846418&dri=0&dis=1&dai=0&ps=386x0&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562953833336&ti=4399%E5%8A%A8%E6%BC%AB%E7%BD%91%20-%20%E5%9B%BD%E5%86%85%E9%A2%86%E5%85%88%E7%9A%84%E5%8A%A8%E6%BC%AB%E5%9C%A8%E7%BA%BF%E5%AE%98%E6%96%B9%E7%BD%91%E7%AB%99&ari=2&dbv=2&drs=1&pcs=887x681&pss=980x3643&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562953834&rw=320&ltu=http%3A%2F%2Fwww.4399dmw.com%2F&liu=http%3A%2F%2Fwww.4399dmw.com%2Fbaiduad%2Fproxy.html%3Fid%3D846418&ecd=1&uc=1855x1056&pis=980x90&sr=1920x1080&tcn=1562953834&exps=110011&lto=http%3A%2F%2Fwww.4399dmw.com&ltl=1:1:1

[1:1:0713/015035.388646:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 17, -5:4_http://www.4399dmw.com/-5:10_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/, 37acedac4648, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015035.388871:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=846418", "www.4399dmw.com", 4, 17, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015035.389629:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getNotCrossDomainTopWindow (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getTopWindowUrl (http://cbjs.baidu.com/js/m.js:1:1)
	Object.value (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	Object.getOneParam (http://cbjs.baidu.com/js/m.js:1:1)
	Object.addDebugSign (http://cbjs.baidu.com/js/m.js:1:1)
	Object.painterLoadedCallback (http://cbjs.baidu.com/js/m.js:1:1)
	Object.callback (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1
	http://pos.baidu.com/ncem?psi=cc9fdc8d01c5d982eec4cdecd4e12a2c&di=846418&dri=0&dis=1&dai=0&ps=386x0&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562953833336&ti=4399%E5%8A%A8%E6%BC%AB%E7%BD%91%20-%20%E5%9B%BD%E5%86%85%E9%A2%86%E5%85%88%E7%9A%84%E5%8A%A8%E6%BC%AB%E5%9C%A8%E7%BA%BF%E5%AE%98%E6%96%B9%E7%BD%91%E7%AB%99&ari=2&dbv=2&drs=1&pcs=887x681&pss=980x3643&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562953834&rw=320&ltu=http%3A%2F%2Fwww.4399dmw.com%2F&liu=http%3A%2F%2Fwww.4399dmw.com%2Fbaiduad%2Fproxy.html%3Fid%3D846418&ecd=1&uc=1855x1056&pis=980x90&sr=1920x1080&tcn=1562953834&exps=110011&lto=http%3A%2F%2Fwww.4399dmw.com&ltl=1:1:1

[1:1:0713/015035.394710:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://www.4399dmw.com/baiduad/proxy.html?id=846418"
[1:1:0713/015035.396182:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 2000, 0x500731cf3b0, 0x2f6b8a4ea10
[1:1:0713/015035.396322:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.4399dmw.com/baiduad/proxy.html?id=846418", 2000
[1:1:0713/015035.396520:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://www.4399dmw.com/, 990
[1:1:0713/015035.396710:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 990 0x7f3f5d194070 0x2f6bb9550e0 , 5:4_http://www.4399dmw.com/, 17, -5:4_http://www.4399dmw.com/-5:10_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/, 851
[1:1:0713/015035.398883:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.4399dmw.com/baiduad/proxy.html?id=846418"
[12674:12674:0713/015035.405990:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0713/015035.407785:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 11, 0x2f6b96f4e20
[1:1:0713/015035.407995:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 11
[12674:12674:0713/015035.408398:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 11, 11, 
[1:1:0713/015035.417153:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0713/015035.417336:INFO:render_frame_impl.cc(7019)] 	 [url] = http://www.4399dmw.com
[12674:12674:0713/015035.418090:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:4_http://www.4399dmw.com/
[1:1:0713/015035.418210:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.4399dmw.com/baiduad/proxy.html?id=846418"
[12674:12674:0713/015035.426423:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[12674:12674:0713/015035.428464:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[12674:12685:0713/015035.447060:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 11
[12674:12685:0713/015035.447124:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 11, HandleIncomingMessage, HandleIncomingMessage
[12674:12674:0713/015035.447151:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://pos.baidu.com/
[12674:12674:0713/015035.447192:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:11_https://pos.baidu.com/, https://pos.baidu.com/wh/o.htm?ltr=, 11
[12674:12674:0713/015035.447256:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:11_https://pos.baidu.com/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 17:49:49 GMT Last-Modified: Fri, 12 Jul 2019 03:18:19 GMT P3p: CP=" OTI DSP COR IVA OUR IND COM " Server: nginx Accept-Ranges: bytes Content-Length: 553 Content-Type: text/html Etag: "5d27fbfb-229"  ,12768, 5
[1:7:0713/015035.454789:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/015036.449839:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:8_https://pos.baidu.com/
[1:1:0713/015036.502137:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.4399dmw.com/, 37aceda02860, , , document.readyState
[1:1:0713/015036.502368:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 1, , , 0
[1:1:0713/015037.277267:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.4399dmw.com/, 943, 7f3f5fad9881
[1:1:0713/015037.292946:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"37aceda02860","ptid":"836 0x7f3f5d194070 0x2f6b8a5c360 ","rf":"5:3_http://www.4399dmw.com/"}
[1:1:0713/015037.293180:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.4399dmw.com/","ptid":"836 0x7f3f5d194070 0x2f6b8a5c360 ","rf":"5:3_http://www.4399dmw.com/"}
[1:1:0713/015037.293415:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.4399dmw.com/"
[1:1:0713/015037.293685:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.4399dmw.com/, 37aceda02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/015037.293788:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 1, , , 0
[1:1:0713/015037.294092:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x500731029c8, 0x2f6b8a4e950
[1:1:0713/015037.294201:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.4399dmw.com/", 100
[1:1:0713/015037.294368:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.4399dmw.com/, 1072
[1:1:0713/015037.294469:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1072 0x7f3f5d194070 0x2f6bba24360 , 5:3_http://www.4399dmw.com/, 1, -5:3_http://www.4399dmw.com/, 943 0x7f3f5d194070 0x2f6bb848b60 
[1:1:0713/015037.359722:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:5_http://www.4399dmw.com/, 906, 7f3f5fad98db
[1:1:0713/015037.376006:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"37acedac99f037aceda85e9837acedac99f0","ptid":"828","rf":"5:5_http://www.4399dmw.com/"}
[1:1:0713/015037.376219:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:5_http://www.4399dmw.com/-5:7_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/","ptid":"828","rf":"5:5_http://www.4399dmw.com/"}
[1:1:0713/015037.376470:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:5_http://www.4399dmw.com/, 1074
[1:1:0713/015037.376611:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1074 0x7f3f5d194070 0x2f6bba44b60 , 5:5_http://www.4399dmw.com/, 0, , 906 0x7f3f5d194070 0x2f6bb7e38e0 
[1:1:0713/015037.376818:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.4399dmw.com/baiduad/proxy.html?id=2409097"
[1:1:0713/015037.377322:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:5_http://www.4399dmw.com/, 37acedac99f0, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0713/015037.377854:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=2409097", "www.4399dmw.com", 5, 1, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015037.382780:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac99f0, toString, 
[1:1:0713/015037.382974:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 2, , , 0
[1:1:0713/015037.383452:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015037.383673:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/, 37acedac99f0, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015037.383825:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=2409097", "www.4399dmw.com", 5, 3, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015037.384275:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015037.384820:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac99f0, getComputedStyle, 
[1:1:0713/015037.384945:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 4, , , 0
[1:1:0713/015037.385373:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getOpacityInWin (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015037.386723:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 5, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/, 37acedac99f0, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015037.386887:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=2409097", "www.4399dmw.com", 5, 5, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015037.387281:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015037.389402:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 6, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac99f0, toString, 
[1:1:0713/015037.389562:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 6, , , 0
[1:1:0713/015037.390011:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015037.390213:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 7, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/, 37acedac99f0, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015037.390384:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=2409097", "www.4399dmw.com", 5, 7, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015037.390849:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015037.391304:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 8, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac99f0, getComputedStyle, 
[1:1:0713/015037.391463:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 8, , , 0
[1:1:0713/015037.391866:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getOpacityInWin (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015037.392554:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 9, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/, 37acedac99f0, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015037.392737:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=2409097", "www.4399dmw.com", 5, 9, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015037.393210:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015037.395890:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 10, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac99f0, toString, 
[1:1:0713/015037.396088:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 10, , , 0
[1:1:0713/015037.396540:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getVisibility (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015037.396726:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 11, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/, 37acedac99f0, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015037.396893:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=2409097", "www.4399dmw.com", 5, 11, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015037.397386:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getVisibility (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015037.397903:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 12, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac99f0, getComputedStyle, 
[1:1:0713/015037.398062:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 12, , , 0
[1:1:0713/015037.398452:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getVisibilityInWin (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getVisibility (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015037.399246:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 13, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/, 37acedac99f0, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015037.399428:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=2409097", "www.4399dmw.com", 5, 13, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015037.399775:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getVisibility (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015037.524998:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:11_https://pos.baidu.com/
[1:1:0713/015037.792778:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1033 0x7f3f5f0bc2e0 0x2f6bb8b5ae0 , "http://www.4399dmw.com/"
[1:1:0713/015037.793339:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.4399dmw.com/, 37aceda02860, , , window._bd_share_main.F.module("trans/logger",function(e,t){var n=e("base/tangram").T,r=e("component
[1:1:0713/015037.793444:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 1, , , 0
[1:1:0713/015037.813564:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.4399dmw.com/", 1000
[1:1:0713/015037.813813:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.4399dmw.com/, 1084
[1:1:0713/015037.813963:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1084 0x7f3f5d194070 0x2f6bba4b460 , 5:3_http://www.4399dmw.com/, 1, -5:3_http://www.4399dmw.com/, 1033 0x7f3f5f0bc2e0 0x2f6bb8b5ae0 
[1:1:0713/015037.824883:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.4399dmw.com/"
[1:1:0713/015038.015300:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:4_http://www.4399dmw.com/, 982, 7f3f5fad98db
[1:1:0713/015038.031798:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"37acedac464837aceda9bd5837acedac4648","ptid":"851","rf":"5:4_http://www.4399dmw.com/"}
[1:1:0713/015038.032011:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_http://www.4399dmw.com/-5:10_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/","ptid":"851","rf":"5:4_http://www.4399dmw.com/"}
[1:1:0713/015038.032242:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:4_http://www.4399dmw.com/, 1096
[1:1:0713/015038.032366:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1096 0x7f3f5d194070 0x2f6bbad24e0 , 5:4_http://www.4399dmw.com/, 0, , 982 0x7f3f5d194070 0x2f6bb921c60 
[1:1:0713/015038.032580:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.4399dmw.com/baiduad/proxy.html?id=846418"
[1:1:0713/015038.032866:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://www.4399dmw.com/, 37acedac4648, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0713/015038.032986:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=846418", "www.4399dmw.com", 4, 1, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015038.036400:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac4648, toString, 
[1:1:0713/015038.036553:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 2, , , 0
[1:1:0713/015038.037084:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015038.037278:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/, 37acedac4648, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015038.037411:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=846418", "www.4399dmw.com", 4, 3, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015038.037865:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015038.038504:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac4648, getComputedStyle, 
[1:1:0713/015038.038635:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 4, , , 0
[1:1:0713/015038.039092:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getOpacityInWin (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015038.040034:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 5, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/, 37acedac4648, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015038.040187:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=846418", "www.4399dmw.com", 4, 5, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015038.040571:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015038.042495:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 6, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac4648, toString, 
[1:1:0713/015038.042629:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 6, , , 0
[1:1:0713/015038.043038:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015038.043205:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 7, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/, 37acedac4648, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015038.043349:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=846418", "www.4399dmw.com", 4, 7, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015038.043739:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015038.044141:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 8, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac4648, getComputedStyle, 
[1:1:0713/015038.044268:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 8, , , 0
[1:1:0713/015038.044630:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getOpacityInWin (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015038.045571:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 9, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/, 37acedac4648, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015038.045821:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=846418", "www.4399dmw.com", 4, 9, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015038.046263:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015038.048451:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 10, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac4648, toString, 
[1:1:0713/015038.048678:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 10, , , 0
[1:1:0713/015038.049207:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getVisibility (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015038.049450:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 11, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/, 37acedac4648, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015038.049647:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=846418", "www.4399dmw.com", 4, 11, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015038.050097:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getVisibility (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015038.050648:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 12, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac4648, getComputedStyle, 
[1:1:0713/015038.050819:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 12, , , 0
[1:1:0713/015038.051213:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getVisibilityInWin (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getVisibility (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015038.052033:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 13, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/, 37acedac4648, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015038.052217:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=846418", "www.4399dmw.com", 4, 13, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015038.052584:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getVisibility (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015038.131310:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.4399dmw.com/, 827, 7f3f5fad98db
[1:1:0713/015038.147747:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"37aceda02860","ptid":"779 0x7f3f5d194070 0x2f6ba62bc60 ","rf":"5:3_http://www.4399dmw.com/"}
[1:1:0713/015038.147947:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.4399dmw.com/","ptid":"779 0x7f3f5d194070 0x2f6ba62bc60 ","rf":"5:3_http://www.4399dmw.com/"}
[1:1:0713/015038.148185:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.4399dmw.com/, 1101
[1:1:0713/015038.148304:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1101 0x7f3f5d194070 0x2f6bba82b60 , 5:3_http://www.4399dmw.com/, 0, , 827 0x7f3f5d194070 0x2f6bab6f4e0 
[1:1:0713/015038.148517:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.4399dmw.com/"
[1:1:0713/015038.148784:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.4399dmw.com/, 37aceda02860, , , (){
					_this.scroll();
				}
[1:1:0713/015038.148888:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 1, , , 0
[1:1:0713/015038.175616:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.4399dmw.com/", 13
[1:1:0713/015038.175853:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.4399dmw.com/, 1102
[1:1:0713/015038.175965:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1102 0x7f3f5d194070 0x2f6bb974de0 , 5:3_http://www.4399dmw.com/, 1, -5:3_http://www.4399dmw.com/, 827 0x7f3f5d194070 0x2f6bab6f4e0 
[1:1:0713/015038.381604:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[12674:12674:0713/015038.382408:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:8_https://pos.baidu.com/, https://pos.baidu.com/, 8
[12674:12674:0713/015038.382454:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 8, 8, https://pos.baidu.com/, https://pos.baidu.com
[1:1:0713/015038.420214:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.4399dmw.com/, 37aceda02860, , , document.readyState
[1:1:0713/015038.420372:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 1, , , 0
[1:1:0713/015038.542127:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:5_http://www.4399dmw.com/, 914, 7f3f5fad9881
[1:1:0713/015038.559317:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"37acedac99f037aceda85e9837acedac99f037aceda0286037acedac99f037aceda0286037acedac99f037aceda0286037acedac99f037aceda0286037acedac99f037aceda0286037acedac99f037aceda0286037acedac99f037aceda0286037acedac99f0","ptid":"828","rf":"5:5_http://www.4399dmw.com/"}
[1:1:0713/015038.559629:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:5_http://www.4399dmw.com/-5:7_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/","ptid":"828","rf":"5:5_http://www.4399dmw.com/"}
[1:1:0713/015038.559835:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.4399dmw.com/baiduad/proxy.html?id=2409097"
[1:1:0713/015038.560134:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:5_http://www.4399dmw.com/, 37acedac99f0, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0713/015038.560253:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=2409097", "www.4399dmw.com", 5, 1, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015038.564753:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac99f0, toString, 
[1:1:0713/015038.564917:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 2, , , 0
[1:1:0713/015038.565356:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getPosition (http://cbjs.baidu.com/js/m.js:1:1)
	Object.calculateClientParam (http://cbjs.baidu.com/js/m.js:1:1)
	Object.windowOnLoadDelay (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015038.565578:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/, 37acedac99f0, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015038.565733:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=2409097", "www.4399dmw.com", 5, 3, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015038.566136:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getPosition (http://cbjs.baidu.com/js/m.js:1:1)
	Object.calculateClientParam (http://cbjs.baidu.com/js/m.js:1:1)
	Object.windowOnLoadDelay (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015038.566869:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac99f0, getBoundingClientRect, 
[1:1:0713/015038.567015:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 4, , , 0
[1:1:0713/015038.567375:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getPositionCore (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getPosition (http://cbjs.baidu.com/js/m.js:1:1)
	Object.calculateClientParam (http://cbjs.baidu.com/js/m.js:1:1)
	Object.windowOnLoadDelay (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015038.567571:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 5, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/, 37acedac99f0, 37aceda02860, floor, 
[1:1:0713/015038.567703:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=2409097", "www.4399dmw.com", 5, 5, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015038.568047:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getPositionCore (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getPosition (http://cbjs.baidu.com/js/m.js:1:1)
	Object.calculateClientParam (http://cbjs.baidu.com/js/m.js:1:1)
	Object.windowOnLoadDelay (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015038.569018:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 6, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac99f0, getComputedStyle, 
[1:1:0713/015038.569205:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 6, , , 0
[1:1:0713/015038.569592:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getStyle (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getPositionCore (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getPosition (http://cbjs.baidu.com/js/m.js:1:1)
	Object.calculateClientParam (http://cbjs.baidu.com/js/m.js:1:1)
	Object.windowOnLoadDelay (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015038.569899:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 7, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/, 37acedac99f0, 37aceda02860, getStyle, (t,e){if(!t)return"";var i="";i=e.indexOf("-")>-1?e.replace(/[-][^-]{1}/g,function(t){return t.charA
[1:1:0713/015038.570042:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=2409097", "www.4399dmw.com", 5, 7, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015038.570368:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getPositionCore (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getPosition (http://cbjs.baidu.com/js/m.js:1:1)
	Object.calculateClientParam (http://cbjs.baidu.com/js/m.js:1:1)
	Object.windowOnLoadDelay (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015038.571000:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 8, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac99f0, getComputedStyle, 
[1:1:0713/015038.571124:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 8, , , 0
[1:1:0713/015038.571450:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getStyle (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getPositionCore (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getPosition (http://cbjs.baidu.com/js/m.js:1:1)
	Object.calculateClientParam (http://cbjs.baidu.com/js/m.js:1:1)
	Object.windowOnLoadDelay (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015038.571705:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 9, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/, 37acedac99f0, 37aceda02860, parseInt, 
[1:1:0713/015038.571854:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=2409097", "www.4399dmw.com", 5, 9, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015038.572169:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getPositionCore (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getPosition (http://cbjs.baidu.com/js/m.js:1:1)
	Object.calculateClientParam (http://cbjs.baidu.com/js/m.js:1:1)
	Object.windowOnLoadDelay (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015038.591996:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.4399dmw.com/, 829, 7f3f5fad98db
[1:1:0713/015038.608398:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"467 0x7f3f5d194070 0x2f6b9061560 ","rf":"5:3_http://www.4399dmw.com/"}
[1:1:0713/015038.608586:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"467 0x7f3f5d194070 0x2f6b9061560 ","rf":"5:3_http://www.4399dmw.com/"}
[1:1:0713/015038.608800:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.4399dmw.com/, 1132
[1:1:0713/015038.608899:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1132 0x7f3f5d194070 0x2f6bba0abe0 , 5:3_http://www.4399dmw.com/, 0, , 829 0x7f3f5d194070 0x2f6b8a5cb60 
[1:1:0713/015038.609092:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.4399dmw.com/"
[1:1:0713/015038.609368:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.4399dmw.com/, 37aceda02860, , Wb, (){var a=d.O()+d.H();0<a-h.b.c.vl&&(h.b.c.vl=a)}
[1:1:0713/015038.609472:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 1, , , 0
[1:1:0713/015038.831098:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.4399dmw.com/, 1072, 7f3f5fad9881
[1:1:0713/015038.848498:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"37aceda02860","ptid":"943 0x7f3f5d194070 0x2f6bb848b60 ","rf":"5:3_http://www.4399dmw.com/"}
[1:1:0713/015038.848685:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.4399dmw.com/","ptid":"943 0x7f3f5d194070 0x2f6bb848b60 ","rf":"5:3_http://www.4399dmw.com/"}
[1:1:0713/015038.848881:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.4399dmw.com/"
[1:1:0713/015038.849182:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.4399dmw.com/, 37aceda02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/015038.849283:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 1, , , 0
[1:1:0713/015038.849566:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x500731029c8, 0x2f6b8a4e950
[1:1:0713/015038.849658:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.4399dmw.com/", 100
[1:1:0713/015038.849818:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.4399dmw.com/, 1147
[1:1:0713/015038.849925:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1147 0x7f3f5d194070 0x2f6bbad5d60 , 5:3_http://www.4399dmw.com/, 1, -5:3_http://www.4399dmw.com/, 1072 0x7f3f5d194070 0x2f6bba24360 
[1:1:0713/015038.850452:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://www.4399dmw.com/, 990, 7f3f5fad9881
[1:1:0713/015038.867175:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"37acedac464837aceda9bd5837acedac464837aceda0286037acedac464837aceda0286037acedac464837aceda0286037acedac464837aceda0286037acedac464837aceda0286037acedac464837aceda0286037acedac464837aceda0286037acedac4648","ptid":"851","rf":"5:4_http://www.4399dmw.com/"}
[1:1:0713/015038.867494:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_http://www.4399dmw.com/-5:10_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/","ptid":"851","rf":"5:4_http://www.4399dmw.com/"}
[1:1:0713/015038.867732:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.4399dmw.com/baiduad/proxy.html?id=846418"
[1:1:0713/015038.868054:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://www.4399dmw.com/, 37acedac4648, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0713/015038.868180:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=846418", "www.4399dmw.com", 4, 1, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015038.872278:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac4648, toString, 
[1:1:0713/015038.872442:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 2, , , 0
[1:1:0713/015038.872851:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getPosition (http://cbjs.baidu.com/js/m.js:1:1)
	Object.calculateClientParam (http://cbjs.baidu.com/js/m.js:1:1)
	Object.windowOnLoadDelay (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015038.873084:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/, 37acedac4648, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015038.873247:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=846418", "www.4399dmw.com", 4, 3, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015038.873613:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getPosition (http://cbjs.baidu.com/js/m.js:1:1)
	Object.calculateClientParam (http://cbjs.baidu.com/js/m.js:1:1)
	Object.windowOnLoadDelay (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015038.874208:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac4648, getBoundingClientRect, 
[1:1:0713/015038.874341:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 4, , , 0
[1:1:0713/015038.874702:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getPositionCore (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getPosition (http://cbjs.baidu.com/js/m.js:1:1)
	Object.calculateClientParam (http://cbjs.baidu.com/js/m.js:1:1)
	Object.windowOnLoadDelay (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015038.874966:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 5, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/, 37acedac4648, 37aceda02860, floor, 
[1:1:0713/015038.875122:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=846418", "www.4399dmw.com", 4, 5, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015038.875469:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getPositionCore (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getPosition (http://cbjs.baidu.com/js/m.js:1:1)
	Object.calculateClientParam (http://cbjs.baidu.com/js/m.js:1:1)
	Object.windowOnLoadDelay (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015038.876477:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 6, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac4648, getComputedStyle, 
[1:1:0713/015038.876625:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 6, , , 0
[1:1:0713/015038.876996:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getStyle (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getPositionCore (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getPosition (http://cbjs.baidu.com/js/m.js:1:1)
	Object.calculateClientParam (http://cbjs.baidu.com/js/m.js:1:1)
	Object.windowOnLoadDelay (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015038.877360:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 7, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/, 37acedac4648, 37aceda02860, getStyle, (t,e){if(!t)return"";var i="";i=e.indexOf("-")>-1?e.replace(/[-][^-]{1}/g,function(t){return t.charA
[1:1:0713/015038.877538:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=846418", "www.4399dmw.com", 4, 7, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015038.877922:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getPositionCore (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getPosition (http://cbjs.baidu.com/js/m.js:1:1)
	Object.calculateClientParam (http://cbjs.baidu.com/js/m.js:1:1)
	Object.windowOnLoadDelay (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015038.878639:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 8, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac4648, getComputedStyle, 
[1:1:0713/015038.878779:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 8, , , 0
[1:1:0713/015038.879140:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getStyle (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getPositionCore (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getPosition (http://cbjs.baidu.com/js/m.js:1:1)
	Object.calculateClientParam (http://cbjs.baidu.com/js/m.js:1:1)
	Object.windowOnLoadDelay (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015038.879427:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 9, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/, 37acedac4648, 37aceda02860, parseInt, 
[1:1:0713/015038.879598:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=846418", "www.4399dmw.com", 4, 9, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015038.879930:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getPositionCore (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getPosition (http://cbjs.baidu.com/js/m.js:1:1)
	Object.calculateClientParam (http://cbjs.baidu.com/js/m.js:1:1)
	Object.windowOnLoadDelay (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[12674:12674:0713/015038.937609:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:11_https://pos.baidu.com/, https://pos.baidu.com/, 11
[12674:12674:0713/015038.937718:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 11, 11, https://pos.baidu.com/, https://pos.baidu.com
[1:1:0713/015038.937841:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/015039.105173:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:5_http://www.4399dmw.com/, 1074, 7f3f5fad98db
[1:1:0713/015039.123627:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"906 0x7f3f5d194070 0x2f6bb7e38e0 ","rf":"5:5_http://www.4399dmw.com/"}
[1:1:0713/015039.123811:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"906 0x7f3f5d194070 0x2f6bb7e38e0 ","rf":"5:5_http://www.4399dmw.com/"}
[1:1:0713/015039.124024:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:5_http://www.4399dmw.com/, 1169
[1:1:0713/015039.124121:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1169 0x7f3f5d194070 0x2f6bb83fce0 , 5:5_http://www.4399dmw.com/, 0, , 1074 0x7f3f5d194070 0x2f6bba44b60 
[1:1:0713/015039.124320:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.4399dmw.com/baiduad/proxy.html?id=2409097"
[1:1:0713/015039.124589:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:5_http://www.4399dmw.com/, 37acedac99f0, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0713/015039.124703:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=2409097", "www.4399dmw.com", 5, 1, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015039.127704:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac99f0, toString, 
[1:1:0713/015039.127814:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 2, , , 0
[1:1:0713/015039.128335:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015039.128578:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/, 37acedac99f0, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015039.128736:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=2409097", "www.4399dmw.com", 5, 3, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015039.129238:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015039.129711:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac99f0, getComputedStyle, 
[1:1:0713/015039.129842:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 4, , , 0
[1:1:0713/015039.130241:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getOpacityInWin (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015039.130914:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 5, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/, 37acedac99f0, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015039.131074:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=2409097", "www.4399dmw.com", 5, 5, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015039.131447:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015039.133214:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 6, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac99f0, toString, 
[1:1:0713/015039.133359:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 6, , , 0
[1:1:0713/015039.133763:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015039.133944:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 7, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/, 37acedac99f0, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015039.134092:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=2409097", "www.4399dmw.com", 5, 7, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015039.134495:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015039.134895:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 8, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac99f0, getComputedStyle, 
[1:1:0713/015039.135021:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 8, , , 0
[1:1:0713/015039.135379:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getOpacityInWin (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015039.136034:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 9, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/, 37acedac99f0, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015039.136225:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=2409097", "www.4399dmw.com", 5, 9, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015039.136664:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015039.138560:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 10, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac99f0, toString, 
[1:1:0713/015039.138733:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 10, , , 0
[1:1:0713/015039.139178:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getVisibility (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015039.139360:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 11, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/, 37acedac99f0, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015039.139533:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=2409097", "www.4399dmw.com", 5, 11, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015039.139967:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getVisibility (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015039.140444:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 12, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac99f0, getComputedStyle, 
[1:1:0713/015039.140649:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 12, , , 0
[1:1:0713/015039.141144:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getVisibilityInWin (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getVisibility (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015039.141935:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 13, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/, 37acedac99f0, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015039.142161:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=2409097", "www.4399dmw.com", 5, 13, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015039.142580:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getVisibility (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015039.223503:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.4399dmw.com/, 1102, 7f3f5fad98db
[1:1:0713/015039.241584:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"37aceda02860","ptid":"827 0x7f3f5d194070 0x2f6bab6f4e0 ","rf":"5:3_http://www.4399dmw.com/"}
[1:1:0713/015039.241801:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.4399dmw.com/","ptid":"827 0x7f3f5d194070 0x2f6bab6f4e0 ","rf":"5:3_http://www.4399dmw.com/"}
[1:1:0713/015039.242054:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.4399dmw.com/, 1174
[1:1:0713/015039.242203:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1174 0x7f3f5d194070 0x2f6bba88960 , 5:3_http://www.4399dmw.com/, 0, , 1102 0x7f3f5d194070 0x2f6bb974de0 
[1:1:0713/015039.242457:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.4399dmw.com/"
[1:1:0713/015039.242739:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.4399dmw.com/, 37aceda02860, , tick, (){for(var a=
c.timers,b=0;b<a.length;b++)a[b]()||a.splice(b--,1);a.length||c.fx.stop()}
[1:1:0713/015039.242860:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 1, , , 0
[1:1:0713/015039.255275:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x500731029c8, 0x2f6b8a4e950
[1:1:0713/015039.255426:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.4399dmw.com/", 0
[1:1:0713/015039.255589:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.4399dmw.com/, 1175
[1:1:0713/015039.255694:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1175 0x7f3f5d194070 0x2f6b9667fe0 , 5:3_http://www.4399dmw.com/, 1, -5:3_http://www.4399dmw.com/, 1102 0x7f3f5d194070 0x2f6bb974de0 
[1:1:0713/015039.255954:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x500731029c8, 0x2f6b8a4e950
[1:1:0713/015039.256039:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.4399dmw.com/", 0
[1:1:0713/015039.256168:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.4399dmw.com/, 1176
[1:1:0713/015039.256256:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1176 0x7f3f5d194070 0x2f6ba6126e0 , 5:3_http://www.4399dmw.com/, 1, -5:3_http://www.4399dmw.com/, 1102 0x7f3f5d194070 0x2f6bb974de0 
[1:1:0713/015039.256931:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:4_http://www.4399dmw.com/, 1096, 7f3f5fad98db
[1:1:0713/015039.275422:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"982 0x7f3f5d194070 0x2f6bb921c60 ","rf":"5:4_http://www.4399dmw.com/"}
[1:1:0713/015039.275603:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"982 0x7f3f5d194070 0x2f6bb921c60 ","rf":"5:4_http://www.4399dmw.com/"}
[1:1:0713/015039.275835:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:4_http://www.4399dmw.com/, 1177
[1:1:0713/015039.275942:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1177 0x7f3f5d194070 0x2f6ba054ee0 , 5:4_http://www.4399dmw.com/, 0, , 1096 0x7f3f5d194070 0x2f6bbad24e0 
[1:1:0713/015039.276132:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.4399dmw.com/baiduad/proxy.html?id=846418"
[1:1:0713/015039.276409:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://www.4399dmw.com/, 37acedac4648, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0713/015039.276533:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=846418", "www.4399dmw.com", 4, 1, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015039.279680:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac4648, toString, 
[1:1:0713/015039.279799:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 2, , , 0
[1:1:0713/015039.280245:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015039.280420:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/, 37acedac4648, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015039.280551:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=846418", "www.4399dmw.com", 4, 3, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015039.280959:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015039.281405:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac4648, getComputedStyle, 
[1:1:0713/015039.281523:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 4, , , 0
[1:1:0713/015039.281900:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getOpacityInWin (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015039.282578:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 5, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/, 37acedac4648, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015039.282716:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=846418", "www.4399dmw.com", 4, 5, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015039.283075:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015039.284739:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 6, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac4648, toString, 
[1:1:0713/015039.284848:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 6, , , 0
[1:1:0713/015039.285271:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015039.285434:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 7, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/, 37acedac4648, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015039.285571:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=846418", "www.4399dmw.com", 4, 7, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015039.285953:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015039.286338:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 8, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac4648, getComputedStyle, 
[1:1:0713/015039.286481:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 8, , , 0
[1:1:0713/015039.286839:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getOpacityInWin (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015039.287504:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 9, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/, 37acedac4648, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015039.287674:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=846418", "www.4399dmw.com", 4, 9, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015039.288043:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015039.290003:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 10, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac4648, toString, 
[1:1:0713/015039.290207:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 10, , , 0
[1:1:0713/015039.290777:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getVisibility (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015039.291016:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 11, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/, 37acedac4648, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015039.291202:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=846418", "www.4399dmw.com", 4, 11, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015039.291693:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getVisibility (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015039.292299:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 12, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac4648, getComputedStyle, 
[1:1:0713/015039.292493:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 12, , , 0
[1:1:0713/015039.292930:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getVisibilityInWin (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getVisibility (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015039.293771:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 13, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/, 37acedac4648, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015039.293994:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=846418", "www.4399dmw.com", 4, 13, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015039.294415:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getVisibility (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015039.381466:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/015039.488311:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.4399dmw.com/, 37aceda02860, , , document.readyState
[1:1:0713/015039.488491:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 1, , , 0
[1:1:0713/015039.795661:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.4399dmw.com/, 1084, 7f3f5fad98db
[1:1:0713/015039.813123:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"37aceda02860","ptid":"1033 0x7f3f5f0bc2e0 0x2f6bb8b5ae0 ","rf":"5:3_http://www.4399dmw.com/"}
[1:1:0713/015039.813329:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.4399dmw.com/","ptid":"1033 0x7f3f5f0bc2e0 0x2f6bb8b5ae0 ","rf":"5:3_http://www.4399dmw.com/"}
[1:1:0713/015039.813564:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.4399dmw.com/, 1192
[1:1:0713/015039.813691:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1192 0x7f3f5d194070 0x2f6bb74ba60 , 5:3_http://www.4399dmw.com/, 0, , 1084 0x7f3f5d194070 0x2f6bba4b460 
[1:1:0713/015039.813896:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.4399dmw.com/"
[1:1:0713/015039.814169:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.4399dmw.com/, 37aceda02860, , , (){document.hasFocus()&&s++}
[1:1:0713/015039.814287:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 1, , , 0
[1:1:0713/015039.945077:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/015040.114486:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.4399dmw.com/, 1147, 7f3f5fad9881
[1:1:0713/015040.132339:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"37aceda02860","ptid":"1072 0x7f3f5d194070 0x2f6bba24360 ","rf":"5:3_http://www.4399dmw.com/"}
[1:1:0713/015040.132521:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.4399dmw.com/","ptid":"1072 0x7f3f5d194070 0x2f6bba24360 ","rf":"5:3_http://www.4399dmw.com/"}
[1:1:0713/015040.132726:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.4399dmw.com/"
[1:1:0713/015040.133002:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.4399dmw.com/, 37aceda02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/015040.133128:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 1, , , 0
[1:1:0713/015040.133411:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x500731029c8, 0x2f6b8a4e950
[1:1:0713/015040.133503:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.4399dmw.com/", 100
[1:1:0713/015040.133674:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.4399dmw.com/, 1208
[1:1:0713/015040.133777:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1208 0x7f3f5d194070 0x2f6b9632060 , 5:3_http://www.4399dmw.com/, 1, -5:3_http://www.4399dmw.com/, 1147 0x7f3f5d194070 0x2f6bbad5d60 
[1:1:0713/015040.204565:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "http://www.4399dmw.com/"
[1:1:0713/015040.204969:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.4399dmw.com/, 37aceda02860, , t.onload.t.onerror.t.onabort, (){t.onload=t.onerror=t.onabort=null,window[n]=null,t=null}
[1:1:0713/015040.205116:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 1, , , 0
[1:1:0713/015040.259308:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "http://www.4399dmw.com/"
[1:1:0713/015040.259694:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.4399dmw.com/, 37aceda02860, , t.onload.t.onerror.t.onabort, (){t.onload=t.onerror=t.onabort=null,window[n]=null,t=null}
[1:1:0713/015040.259797:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 1, , , 0
[1:1:0713/015040.350362:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.4399dmw.com/, 1175, 7f3f5fad9881
[1:1:0713/015040.368017:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"37aceda02860","ptid":"1102 0x7f3f5d194070 0x2f6bb974de0 ","rf":"5:3_http://www.4399dmw.com/"}
[1:1:0713/015040.368267:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.4399dmw.com/","ptid":"1102 0x7f3f5d194070 0x2f6bb974de0 ","rf":"5:3_http://www.4399dmw.com/"}
[1:1:0713/015040.368513:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.4399dmw.com/"
[1:1:0713/015040.368797:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.4399dmw.com/, 37aceda02860, , , (){
							options.afterNext.call(_this);
							options.afterSlide.call(_this);
						}
[1:1:0713/015040.368895:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 1, , , 0
[1:1:0713/015040.384832:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.4399dmw.com/", 13
[1:1:0713/015040.385141:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.4399dmw.com/, 1214
[1:1:0713/015040.385270:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1214 0x7f3f5d194070 0x2f6b8ba28e0 , 5:3_http://www.4399dmw.com/, 1, -5:3_http://www.4399dmw.com/, 1175 0x7f3f5d194070 0x2f6b9667fe0 
[1:1:0713/015040.386554:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.4399dmw.com/, 1176, 7f3f5fad9881
[1:1:0713/015040.405650:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"37aceda02860","ptid":"1102 0x7f3f5d194070 0x2f6bb974de0 ","rf":"5:3_http://www.4399dmw.com/"}
[1:1:0713/015040.405866:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.4399dmw.com/","ptid":"1102 0x7f3f5d194070 0x2f6bb974de0 ","rf":"5:3_http://www.4399dmw.com/"}
[1:1:0713/015040.406090:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.4399dmw.com/"
[1:1:0713/015040.406357:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.4399dmw.com/, 37aceda02860, , , (){
							_this.start()
						}
[1:1:0713/015040.406458:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 1, , , 0
[1:1:0713/015040.406884:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.4399dmw.com/", 2500
[1:1:0713/015040.407064:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.4399dmw.com/, 1216
[1:1:0713/015040.407175:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1216 0x7f3f5d194070 0x2f6b9639c60 , 5:3_http://www.4399dmw.com/, 1, -5:3_http://www.4399dmw.com/, 1176 0x7f3f5d194070 0x2f6ba6126e0 
[1:1:0713/015040.407776:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:4_http://www.4399dmw.com/, 1177, 7f3f5fad98db
[1:1:0713/015040.425630:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1096 0x7f3f5d194070 0x2f6bbad24e0 ","rf":"5:4_http://www.4399dmw.com/"}
[1:1:0713/015040.425800:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1096 0x7f3f5d194070 0x2f6bbad24e0 ","rf":"5:4_http://www.4399dmw.com/"}
[1:1:0713/015040.426026:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:4_http://www.4399dmw.com/, 1219
[1:1:0713/015040.426153:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1219 0x7f3f5d194070 0x2f6b962c360 , 5:4_http://www.4399dmw.com/, 0, , 1177 0x7f3f5d194070 0x2f6ba054ee0 
[1:1:0713/015040.426356:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.4399dmw.com/baiduad/proxy.html?id=846418"
[1:1:0713/015040.426670:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://www.4399dmw.com/, 37acedac4648, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0713/015040.426809:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=846418", "www.4399dmw.com", 4, 1, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015040.429964:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac4648, toString, 
[1:1:0713/015040.430103:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 2, , , 0
[1:1:0713/015040.430615:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015040.430821:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/, 37acedac4648, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015040.430979:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=846418", "www.4399dmw.com", 4, 3, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015040.431431:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015040.431904:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac4648, getComputedStyle, 
[1:1:0713/015040.432035:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 4, , , 0
[1:1:0713/015040.432435:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getOpacityInWin (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015040.433215:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 5, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/, 37acedac4648, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015040.433375:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=846418", "www.4399dmw.com", 4, 5, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015040.433770:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015040.435532:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 6, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac4648, toString, 
[1:1:0713/015040.435701:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 6, , , 0
[1:1:0713/015040.436295:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015040.436495:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 7, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/, 37acedac4648, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015040.436656:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=846418", "www.4399dmw.com", 4, 7, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015040.437125:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015040.437574:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 8, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac4648, getComputedStyle, 
[1:1:0713/015040.437733:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 8, , , 0
[1:1:0713/015040.438157:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getOpacityInWin (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015040.438996:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 9, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/, 37acedac4648, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015040.439217:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=846418", "www.4399dmw.com", 4, 9, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015040.439653:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015040.441584:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 10, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac4648, toString, 
[1:1:0713/015040.441759:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 10, , , 0
[1:1:0713/015040.442215:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getVisibility (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015040.442403:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 11, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/, 37acedac4648, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015040.442576:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=846418", "www.4399dmw.com", 4, 11, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015040.442982:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getVisibility (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015040.443372:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 12, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac4648, getComputedStyle, 
[1:1:0713/015040.443511:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 12, , , 0
[1:1:0713/015040.443871:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getVisibilityInWin (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getVisibility (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015040.444577:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 13, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/, 37acedac4648, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015040.444841:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=846418", "www.4399dmw.com", 4, 13, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015040.445319:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getVisibility (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015040.498883:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/015040.499071:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://pos.baidu.com/wh/o.htm?ltr="
[1:1:0713/015040.517899:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:5_http://www.4399dmw.com/, 1169, 7f3f5fad98db
[1:1:0713/015040.537207:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1074 0x7f3f5d194070 0x2f6bba44b60 ","rf":"5:5_http://www.4399dmw.com/"}
[1:1:0713/015040.537433:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1074 0x7f3f5d194070 0x2f6bba44b60 ","rf":"5:5_http://www.4399dmw.com/"}
[1:1:0713/015040.537690:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:5_http://www.4399dmw.com/, 1232
[1:1:0713/015040.537850:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1232 0x7f3f5d194070 0x2f6bba5e660 , 5:5_http://www.4399dmw.com/, 0, , 1169 0x7f3f5d194070 0x2f6bb83fce0 
[1:1:0713/015040.538103:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.4399dmw.com/baiduad/proxy.html?id=2409097"
[1:1:0713/015040.538426:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:5_http://www.4399dmw.com/, 37acedac99f0, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0713/015040.538546:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=2409097", "www.4399dmw.com", 5, 1, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015040.541750:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac99f0, toString, 
[1:1:0713/015040.541923:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 2, , , 0
[1:1:0713/015040.542608:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015040.542824:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/, 37acedac99f0, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015040.542968:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=2409097", "www.4399dmw.com", 5, 3, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015040.543455:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015040.543954:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac99f0, getComputedStyle, 
[1:1:0713/015040.544077:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 4, , , 0
[1:1:0713/015040.544492:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getOpacityInWin (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015040.545273:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 5, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/, 37acedac99f0, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015040.545457:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=2409097", "www.4399dmw.com", 5, 5, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015040.545863:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015040.547622:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 6, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac99f0, toString, 
[1:1:0713/015040.547770:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 6, , , 0
[1:1:0713/015040.548206:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015040.548418:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 7, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/, 37acedac99f0, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015040.548573:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=2409097", "www.4399dmw.com", 5, 7, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015040.549079:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015040.549520:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 8, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac99f0, getComputedStyle, 
[1:1:0713/015040.549671:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 8, , , 0
[1:1:0713/015040.550069:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getOpacityInWin (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015040.550736:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 9, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/, 37acedac99f0, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015040.550957:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=2409097", "www.4399dmw.com", 5, 9, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015040.551342:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015040.553014:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 10, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac99f0, toString, 
[1:1:0713/015040.553225:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 10, , , 0
[1:1:0713/015040.553696:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getVisibility (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015040.553900:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 11, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/, 37acedac99f0, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015040.554090:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=2409097", "www.4399dmw.com", 5, 11, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015040.554533:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getVisibility (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015040.554968:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 12, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac99f0, getComputedStyle, 
[1:1:0713/015040.555134:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 12, , , 0
[1:1:0713/015040.555545:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getVisibilityInWin (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getVisibility (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015040.556308:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 13, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/, 37acedac99f0, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015040.556561:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=2409097", "www.4399dmw.com", 5, 13, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015040.556971:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getVisibility (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015040.584017:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.4399dmw.com/, 37aceda02860, , , document.readyState
[1:1:0713/015040.584204:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 1, , , 0
[1:1:0713/015040.714613:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.4399dmw.com/, 1192, 7f3f5fad98db
[1:1:0713/015040.732664:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1084 0x7f3f5d194070 0x2f6bba4b460 ","rf":"5:3_http://www.4399dmw.com/"}
[1:1:0713/015040.732858:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1084 0x7f3f5d194070 0x2f6bba4b460 ","rf":"5:3_http://www.4399dmw.com/"}
[1:1:0713/015040.733121:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.4399dmw.com/, 1237
[1:1:0713/015040.733245:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1237 0x7f3f5d194070 0x2f6bbc816e0 , 5:3_http://www.4399dmw.com/, 0, , 1192 0x7f3f5d194070 0x2f6bb74ba60 
[1:1:0713/015040.733450:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.4399dmw.com/"
[1:1:0713/015040.733721:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.4399dmw.com/, 37aceda02860, , , (){document.hasFocus()&&s++}
[1:1:0713/015040.733838:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 1, , , 0
[1:1:0713/015040.825265:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/015040.825422:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://pos.baidu.com/wh/o.htm?ltr="
[1:1:0713/015041.013420:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.4399dmw.com/, 1208, 7f3f5fad9881
[1:1:0713/015041.031909:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"37aceda02860","ptid":"1147 0x7f3f5d194070 0x2f6bbad5d60 ","rf":"5:3_http://www.4399dmw.com/"}
[1:1:0713/015041.032084:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.4399dmw.com/","ptid":"1147 0x7f3f5d194070 0x2f6bbad5d60 ","rf":"5:3_http://www.4399dmw.com/"}
[1:1:0713/015041.032281:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.4399dmw.com/"
[1:1:0713/015041.032570:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.4399dmw.com/, 37aceda02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/015041.032659:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 1, , , 0
[1:1:0713/015041.032936:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x500731029c8, 0x2f6b8a4e950
[1:1:0713/015041.033012:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.4399dmw.com/", 100
[1:1:0713/015041.033180:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.4399dmw.com/, 1253
[1:1:0713/015041.033290:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1253 0x7f3f5d194070 0x2f6b962c8e0 , 5:3_http://www.4399dmw.com/, 1, -5:3_http://www.4399dmw.com/, 1208 0x7f3f5d194070 0x2f6b9632060 
[1:1:0713/015041.216267:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.4399dmw.com/, 1214, 7f3f5fad98db
[1:1:0713/015041.234713:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"37aceda02860","ptid":"1175 0x7f3f5d194070 0x2f6b9667fe0 ","rf":"5:3_http://www.4399dmw.com/"}
[1:1:0713/015041.234896:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.4399dmw.com/","ptid":"1175 0x7f3f5d194070 0x2f6b9667fe0 ","rf":"5:3_http://www.4399dmw.com/"}
[1:1:0713/015041.235117:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.4399dmw.com/, 1267
[1:1:0713/015041.235222:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1267 0x7f3f5d194070 0x2f6bbcb3b60 , 5:3_http://www.4399dmw.com/, 0, , 1214 0x7f3f5d194070 0x2f6b8ba28e0 
[1:1:0713/015041.235408:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.4399dmw.com/"
[1:1:0713/015041.235666:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.4399dmw.com/, 37aceda02860, , tick, (){for(var a=
c.timers,b=0;b<a.length;b++)a[b]()||a.splice(b--,1);a.length||c.fx.stop()}
[1:1:0713/015041.235764:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 1, , , 0
[1:1:0713/015041.511024:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.4399dmw.com/, 37aceda02860, , , document.readyState
[1:1:0713/015041.511238:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 1, , , 0
[1:1:0713/015041.808080:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.4399dmw.com/, 1237, 7f3f5fad98db
[1:1:0713/015041.827677:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1192 0x7f3f5d194070 0x2f6bb74ba60 ","rf":"5:3_http://www.4399dmw.com/"}
[1:1:0713/015041.827927:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1192 0x7f3f5d194070 0x2f6bb74ba60 ","rf":"5:3_http://www.4399dmw.com/"}
[1:1:0713/015041.828184:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.4399dmw.com/, 1278
[1:1:0713/015041.828339:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1278 0x7f3f5d194070 0x2f6bbc72e60 , 5:3_http://www.4399dmw.com/, 0, , 1237 0x7f3f5d194070 0x2f6bbc816e0 
[1:1:0713/015041.828543:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.4399dmw.com/"
[1:1:0713/015041.828867:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.4399dmw.com/, 37aceda02860, , , (){document.hasFocus()&&s++}
[1:1:0713/015041.828966:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 1, , , 0
[1:1:0713/015041.829504:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:4_http://www.4399dmw.com/, 1219, 7f3f5fad98db
[1:1:0713/015041.848885:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1177 0x7f3f5d194070 0x2f6ba054ee0 ","rf":"5:4_http://www.4399dmw.com/"}
[1:1:0713/015041.849105:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1177 0x7f3f5d194070 0x2f6ba054ee0 ","rf":"5:4_http://www.4399dmw.com/"}
[1:1:0713/015041.849311:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:4_http://www.4399dmw.com/, 1279
[1:1:0713/015041.849404:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1279 0x7f3f5d194070 0x2f6bbc920e0 , 5:4_http://www.4399dmw.com/, 0, , 1219 0x7f3f5d194070 0x2f6b962c360 
[1:1:0713/015041.849570:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.4399dmw.com/baiduad/proxy.html?id=846418"
[1:1:0713/015041.849873:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://www.4399dmw.com/, 37acedac4648, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0713/015041.850007:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=846418", "www.4399dmw.com", 4, 1, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015041.853214:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac4648, toString, 
[1:1:0713/015041.853365:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 2, , , 0
[1:1:0713/015041.853866:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015041.854058:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/, 37acedac4648, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015041.854194:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=846418", "www.4399dmw.com", 4, 3, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015041.854668:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015041.855110:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac4648, getComputedStyle, 
[1:1:0713/015041.855229:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 4, , , 0
[1:1:0713/015041.855632:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getOpacityInWin (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015041.856319:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 5, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/, 37acedac4648, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015041.856466:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=846418", "www.4399dmw.com", 4, 5, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015041.856839:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015041.858873:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 6, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac4648, toString, 
[1:1:0713/015041.859050:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 6, , , 0
[1:1:0713/015041.859485:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015041.859661:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 7, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/, 37acedac4648, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015041.859820:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=846418", "www.4399dmw.com", 4, 7, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015041.860298:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015041.860771:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 8, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac4648, getComputedStyle, 
[1:1:0713/015041.860908:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 8, , , 0
[1:1:0713/015041.861348:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getOpacityInWin (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015041.862089:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 9, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/, 37acedac4648, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015041.862277:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=846418", "www.4399dmw.com", 4, 9, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015041.862687:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015041.864435:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 10, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac4648, toString, 
[1:1:0713/015041.864605:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 10, , , 0
[1:1:0713/015041.865128:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getVisibility (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015041.865370:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 11, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/, 37acedac4648, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015041.865579:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=846418", "www.4399dmw.com", 4, 11, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015041.866034:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getVisibility (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015041.866474:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 12, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac4648, getComputedStyle, 
[1:1:0713/015041.866651:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 12, , , 0
[1:1:0713/015041.867065:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getVisibilityInWin (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getVisibility (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015041.867798:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 13, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/, 37acedac4648, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015041.868017:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=846418", "www.4399dmw.com", 4, 13, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015041.868422:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getVisibility (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015041.900737:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:5_http://www.4399dmw.com/, 1232, 7f3f5fad98db
[1:1:0713/015041.920161:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1169 0x7f3f5d194070 0x2f6bb83fce0 ","rf":"5:5_http://www.4399dmw.com/"}
[1:1:0713/015041.920331:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1169 0x7f3f5d194070 0x2f6bb83fce0 ","rf":"5:5_http://www.4399dmw.com/"}
[1:1:0713/015041.920559:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:5_http://www.4399dmw.com/, 1283
[1:1:0713/015041.920655:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1283 0x7f3f5d194070 0x2f6bbcfbb60 , 5:5_http://www.4399dmw.com/, 0, , 1232 0x7f3f5d194070 0x2f6bba5e660 
[1:1:0713/015041.920831:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.4399dmw.com/baiduad/proxy.html?id=2409097"
[1:1:0713/015041.921132:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:5_http://www.4399dmw.com/, 37acedac99f0, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0713/015041.921270:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=2409097", "www.4399dmw.com", 5, 1, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015041.924249:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac99f0, toString, 
[1:1:0713/015041.924395:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 2, , , 0
[1:1:0713/015041.924946:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015041.925189:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/, 37acedac99f0, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015041.925351:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=2409097", "www.4399dmw.com", 5, 3, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015041.925825:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015041.926294:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac99f0, getComputedStyle, 
[1:1:0713/015041.926452:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 4, , , 0
[1:1:0713/015041.926881:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getOpacityInWin (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015041.927595:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 5, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/, 37acedac99f0, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015041.927778:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=2409097", "www.4399dmw.com", 5, 5, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015041.928211:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015041.930144:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 6, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac99f0, toString, 
[1:1:0713/015041.930301:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 6, , , 0
[1:1:0713/015041.930764:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015041.930967:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 7, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/, 37acedac99f0, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015041.931124:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=2409097", "www.4399dmw.com", 5, 7, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015041.931611:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015041.932064:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 8, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac99f0, getComputedStyle, 
[1:1:0713/015041.932210:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 8, , , 0
[1:1:0713/015041.932615:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getOpacityInWin (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015041.933342:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 9, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/, 37acedac99f0, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015041.933526:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=2409097", "www.4399dmw.com", 5, 9, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015041.933927:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015041.935741:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 10, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac99f0, toString, 
[1:1:0713/015041.935945:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 10, , , 0
[1:1:0713/015041.936459:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getVisibility (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015041.936697:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 11, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/, 37acedac99f0, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015041.936913:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=2409097", "www.4399dmw.com", 5, 11, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015041.937401:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getVisibility (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015041.937912:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 12, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac99f0, getComputedStyle, 
[1:1:0713/015041.938136:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 12, , , 0
[1:1:0713/015041.938619:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getVisibilityInWin (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getVisibility (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015041.939452:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 13, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/, 37acedac99f0, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015041.939677:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=2409097", "www.4399dmw.com", 5, 13, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015041.940117:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getVisibility (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015042.162657:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.4399dmw.com/, 1253, 7f3f5fad9881
[1:1:0713/015042.181519:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"37aceda02860","ptid":"1208 0x7f3f5d194070 0x2f6b9632060 ","rf":"5:3_http://www.4399dmw.com/"}
[1:1:0713/015042.181731:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.4399dmw.com/","ptid":"1208 0x7f3f5d194070 0x2f6b9632060 ","rf":"5:3_http://www.4399dmw.com/"}
[1:1:0713/015042.181955:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.4399dmw.com/"
[1:1:0713/015042.182241:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.4399dmw.com/, 37aceda02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/015042.182365:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 1, , , 0
[1:1:0713/015042.182667:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x500731029c8, 0x2f6b8a4e950
[1:1:0713/015042.182778:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.4399dmw.com/", 100
[1:1:0713/015042.182947:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.4399dmw.com/, 1289
[1:1:0713/015042.183057:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1289 0x7f3f5d194070 0x2f6bbc71b60 , 5:3_http://www.4399dmw.com/, 1, -5:3_http://www.4399dmw.com/, 1253 0x7f3f5d194070 0x2f6b962c8e0 
[1:1:0713/015042.299863:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1269 0x7f3f7381f080 0x2f6b8a01100 1 0 0x2f6b8a01118 , "https://pos.baidu.com/wh/o.htm?ltr="
[1:1:0713/015042.301599:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:8_https://pos.baidu.com/, 37aceda8f078, , , (function(){if(!PluginDetect)var PluginDetect={getNum:function(b,c){if(!this.num(b))return null;var 
[1:1:0713/015042.301737:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pos.baidu.com/wh/o.htm?ltr=", "pos.baidu.com", 8, 1, http://www.4399dmw.com, www.4399dmw.com, 5
[1:1:0713/015042.317988:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 2000, 0x500731a43e0, 0x2f6b8a4e9a8
[1:1:0713/015042.318194:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://pos.baidu.com/wh/o.htm?ltr=", 2000
[1:1:0713/015042.318435:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:8_https://pos.baidu.com/, 1298
[1:1:0713/015042.318604:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1298 0x7f3f5d194070 0x2f6bbc9e260 , 5:8_https://pos.baidu.com/, 1, -5:8_https://pos.baidu.com/, 1269 0x7f3f7381f080 0x2f6b8a01100 1 0 0x2f6b8a01118 
[1:1:0713/015042.319332:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 250, 0x500731a43e0, 0x2f6b8a4e9a8
[1:1:0713/015042.319473:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://pos.baidu.com/wh/o.htm?ltr=", 250
[1:1:0713/015042.319706:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:8_https://pos.baidu.com/, 1299
[1:1:0713/015042.319846:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1299 0x7f3f5d194070 0x2f6bbc71260 , 5:8_https://pos.baidu.com/, 1, -5:8_https://pos.baidu.com/, 1269 0x7f3f7381f080 0x2f6b8a01100 1 0 0x2f6b8a01118 
[1:1:0713/015042.321736:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1269 0x7f3f7381f080 0x2f6b8a01100 1 0 0x2f6b8a01118 , "https://pos.baidu.com/wh/o.htm?ltr="
[1:1:0713/015042.326503:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pos.baidu.com/wh/o.htm?ltr="
[1:1:0713/015042.452027:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.4399dmw.com/, 37aceda02860, , , document.readyState
[1:1:0713/015042.452253:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 1, , , 0
[1:1:0713/015042.475937:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1275 0x7f3f7381f080 0x2f6ba5bdf60 1 0 0x2f6ba5bdf78 , "https://pos.baidu.com/wh/o.htm?ltr="
[1:1:0713/015042.477251:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:11_https://pos.baidu.com/, 37aceda679a8, , , (function(){if(!PluginDetect)var PluginDetect={getNum:function(b,c){if(!this.num(b))return null;var 
[1:1:0713/015042.477409:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pos.baidu.com/wh/o.htm?ltr=", "pos.baidu.com", 11, 1, http://www.4399dmw.com, www.4399dmw.com, 4
[1:1:0713/015042.491055:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 2000, 0x500731a51f8, 0x2f6b8a4e998
[1:1:0713/015042.491268:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://pos.baidu.com/wh/o.htm?ltr=", 2000
[1:1:0713/015042.491517:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:11_https://pos.baidu.com/, 1319
[1:1:0713/015042.491677:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1319 0x7f3f5d194070 0x2f6bbd29b60 , 5:11_https://pos.baidu.com/, 1, -5:11_https://pos.baidu.com/, 1275 0x7f3f7381f080 0x2f6ba5bdf60 1 0 0x2f6ba5bdf78 
[1:1:0713/015042.492468:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 250, 0x500731a51f8, 0x2f6b8a4e998
[1:1:0713/015042.492577:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://pos.baidu.com/wh/o.htm?ltr=", 250
[1:1:0713/015042.492776:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:11_https://pos.baidu.com/, 1320
[1:1:0713/015042.492884:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1320 0x7f3f5d194070 0x2f6bbd776e0 , 5:11_https://pos.baidu.com/, 1, -5:11_https://pos.baidu.com/, 1275 0x7f3f7381f080 0x2f6ba5bdf60 1 0 0x2f6ba5bdf78 
[1:1:0713/015042.494856:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1275 0x7f3f7381f080 0x2f6ba5bdf60 1 0 0x2f6ba5bdf78 , "https://pos.baidu.com/wh/o.htm?ltr="
[1:1:0713/015042.499227:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pos.baidu.com/wh/o.htm?ltr="
[1:1:0713/015042.503927:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.4399dmw.com/"
[1:1:0713/015042.504301:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:11_https://pos.baidu.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37aceda679a8, ready, (j){j===true&&b.readyWait--;
if(!b.readyWait||j!==true&&!b.isReady){if(!t.body)return setTimeout(b.r
[1:1:0713/015042.504426:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 2, , , 0
[1:1:0713/015042.504597:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 

[1:1:0713/015042.504783:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.4399dmw.com/"
[1:1:0713/015042.505054:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.4399dmw.com/"
[1:1:0713/015042.523964:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "pageshow", "http://www.4399dmw.com/"
[1:1:0713/015042.524842:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x500731029c8, 0x2f6b8a4eaf0
[1:1:0713/015042.524957:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.4399dmw.com/", 100
[1:1:0713/015042.525154:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:11_https://pos.baidu.com/, 1329
[1:1:0713/015042.525264:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1329 0x7f3f5d194070 0x2f6bbd7d860 , 5:11_https://pos.baidu.com/, 2, -5:11_https://pos.baidu.com/-5:3_http://www.4399dmw.com/, 1275 0x7f3f7381f080 0x2f6ba5bdf60 1 0 0x2f6ba5bdf78 
[1:1:0713/015042.602105:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:4_http://www.4399dmw.com/, 1279, 7f3f5fad98db
[1:1:0713/015042.619879:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1219 0x7f3f5d194070 0x2f6b962c360 ","rf":"5:4_http://www.4399dmw.com/"}
[1:1:0713/015042.620052:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1219 0x7f3f5d194070 0x2f6b962c360 ","rf":"5:4_http://www.4399dmw.com/"}
[1:1:0713/015042.620261:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:4_http://www.4399dmw.com/, 1340
[1:1:0713/015042.620364:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1340 0x7f3f5d194070 0x2f6bbd12a60 , 5:4_http://www.4399dmw.com/, 0, , 1279 0x7f3f5d194070 0x2f6bbc920e0 
[1:1:0713/015042.620544:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.4399dmw.com/baiduad/proxy.html?id=846418"
[1:1:0713/015042.620816:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://www.4399dmw.com/, 37acedac4648, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0713/015042.620927:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=846418", "www.4399dmw.com", 4, 1, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015042.623737:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac4648, toString, 
[1:1:0713/015042.623845:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 2, , , 0
[1:1:0713/015042.624289:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015042.624482:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/, 37acedac4648, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015042.624596:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=846418", "www.4399dmw.com", 4, 3, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015042.625006:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015042.625443:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac4648, getComputedStyle, 
[1:1:0713/015042.625554:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 4, , , 0
[1:1:0713/015042.625922:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getOpacityInWin (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015042.626564:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 5, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/, 37acedac4648, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015042.626701:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=846418", "www.4399dmw.com", 4, 5, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015042.627044:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015042.628798:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 6, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac4648, toString, 
[1:1:0713/015042.628920:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 6, , , 0
[1:1:0713/015042.629318:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015042.629499:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 7, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/, 37acedac4648, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015042.629649:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=846418", "www.4399dmw.com", 4, 7, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015042.630035:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015042.630433:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 8, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac4648, getComputedStyle, 
[1:1:0713/015042.630552:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 8, , , 0
[1:1:0713/015042.630905:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getOpacityInWin (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015042.631543:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 9, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/, 37acedac4648, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015042.631689:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=846418", "www.4399dmw.com", 4, 9, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015042.632031:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015042.633643:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 10, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac4648, toString, 
[1:1:0713/015042.633790:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 10, , , 0
[1:1:0713/015042.634185:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getVisibility (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015042.634364:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 11, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/, 37acedac4648, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015042.634527:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=846418", "www.4399dmw.com", 4, 11, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015042.634900:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getVisibility (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015042.635281:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 12, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac4648, getComputedStyle, 
[1:1:0713/015042.635415:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 12, , , 0
[1:1:0713/015042.635761:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getVisibilityInWin (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getVisibility (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015042.636387:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 13, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/, 37acedac4648, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015042.636558:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=846418", "www.4399dmw.com", 4, 13, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015042.636894:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getVisibility (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015042.663708:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.4399dmw.com/, 1132, 7f3f5fad98db
[1:1:0713/015042.681004:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"829 0x7f3f5d194070 0x2f6b8a5cb60 ","rf":"5:3_http://www.4399dmw.com/"}
[1:1:0713/015042.681168:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"829 0x7f3f5d194070 0x2f6b8a5cb60 ","rf":"5:3_http://www.4399dmw.com/"}
[1:1:0713/015042.681379:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.4399dmw.com/, 1342
[1:1:0713/015042.681495:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1342 0x7f3f5d194070 0x2f6bbbd6ae0 , 5:3_http://www.4399dmw.com/, 0, , 1132 0x7f3f5d194070 0x2f6bba0abe0 
[1:1:0713/015042.681679:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.4399dmw.com/"
[1:1:0713/015042.681937:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.4399dmw.com/, 37aceda02860, , Wb, (){var a=d.O()+d.H();0<a-h.b.c.vl&&(h.b.c.vl=a)}
[1:1:0713/015042.682038:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 1, , , 0
[1:1:0713/015043.037164:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:5_http://www.4399dmw.com/, 1283, 7f3f5fad98db
[1:1:0713/015043.055166:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1232 0x7f3f5d194070 0x2f6bba5e660 ","rf":"5:5_http://www.4399dmw.com/"}
[1:1:0713/015043.055314:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1232 0x7f3f5d194070 0x2f6bba5e660 ","rf":"5:5_http://www.4399dmw.com/"}
[1:1:0713/015043.055507:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:5_http://www.4399dmw.com/, 1361
[1:1:0713/015043.055611:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1361 0x7f3f5d194070 0x2f6bba0a9e0 , 5:5_http://www.4399dmw.com/, 0, , 1283 0x7f3f5d194070 0x2f6bbcfbb60 
[1:1:0713/015043.055795:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.4399dmw.com/baiduad/proxy.html?id=2409097"
[1:1:0713/015043.056068:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:5_http://www.4399dmw.com/, 37acedac99f0, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0713/015043.056199:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=2409097", "www.4399dmw.com", 5, 1, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015043.059064:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac99f0, toString, 
[1:1:0713/015043.059172:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 2, , , 0
[1:1:0713/015043.059621:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015043.059807:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/, 37acedac99f0, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015043.059932:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=2409097", "www.4399dmw.com", 5, 3, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015043.060333:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015043.060732:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac99f0, getComputedStyle, 
[1:1:0713/015043.060842:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 4, , , 0
[1:1:0713/015043.061208:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getOpacityInWin (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015043.061894:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 5, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/, 37acedac99f0, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015043.062032:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=2409097", "www.4399dmw.com", 5, 5, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015043.062415:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015043.064036:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 6, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac99f0, toString, 
[1:1:0713/015043.064162:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 6, , , 0
[1:1:0713/015043.064556:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015043.064730:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 7, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/, 37acedac99f0, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015043.064861:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=2409097", "www.4399dmw.com", 5, 7, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015043.065236:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015043.065630:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 8, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac99f0, getComputedStyle, 
[1:1:0713/015043.065759:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 8, , , 0
[1:1:0713/015043.066139:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getOpacityInWin (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015043.066747:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 9, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/, 37acedac99f0, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015043.066907:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=2409097", "www.4399dmw.com", 5, 9, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015043.067248:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015043.068819:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 10, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac99f0, toString, 
[1:1:0713/015043.068947:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 10, , , 0
[1:1:0713/015043.069326:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getVisibility (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015043.069502:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 11, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/, 37acedac99f0, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015043.069664:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=2409097", "www.4399dmw.com", 5, 11, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015043.070049:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getVisibility (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015043.070448:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 12, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac99f0, getComputedStyle, 
[1:1:0713/015043.070601:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 12, , , 0
[1:1:0713/015043.070948:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getVisibilityInWin (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getVisibility (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015043.071575:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 13, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/, 37acedac99f0, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015043.071739:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=2409097", "www.4399dmw.com", 5, 13, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015043.072074:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getVisibility (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015043.098511:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.4399dmw.com/, 37aceda02860, , , document.readyState
[1:1:0713/015043.098665:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 1, , , 0
[1:1:0713/015043.288163:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:8_https://pos.baidu.com/, 1299, 7f3f5fad9881
[1:1:0713/015043.305100:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"37aceda8f078","ptid":"1269 0x7f3f7381f080 0x2f6b8a01100 1 0 0x2f6b8a01118 ","rf":"5:8_https://pos.baidu.com/"}
[1:1:0713/015043.305269:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:8_https://pos.baidu.com/","ptid":"1269 0x7f3f7381f080 0x2f6b8a01100 1 0 0x2f6b8a01118 ","rf":"5:8_https://pos.baidu.com/"}
[1:1:0713/015043.305459:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://pos.baidu.com/wh/o.htm?ltr="
[1:1:0713/015043.305732:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:8_https://pos.baidu.com/, 37aceda8f078, , F, (){if(!detectFlash(fname)&&
!isSend)return setTimeout(F,250)}
[1:1:0713/015043.305866:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pos.baidu.com/wh/o.htm?ltr=", "pos.baidu.com", 8, 1, http://www.4399dmw.com, www.4399dmw.com, 5
[1:1:0713/015043.306524:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 250, 0x500731a43e0, 0x2f6b8a4e950
[1:1:0713/015043.306641:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://pos.baidu.com/wh/o.htm?ltr=", 250
[1:1:0713/015043.306817:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:8_https://pos.baidu.com/, 1367
[1:1:0713/015043.306932:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1367 0x7f3f5d194070 0x2f6bbd77f60 , 5:8_https://pos.baidu.com/, 1, -5:8_https://pos.baidu.com/, 1299 0x7f3f5d194070 0x2f6bbc71260 
[1:1:0713/015043.324798:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:11_https://pos.baidu.com/, 1329, 7f3f5fad9881
[1:1:0713/015043.341471:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"37aceda679a837aceda02860","ptid":"1275 0x7f3f7381f080 0x2f6ba5bdf60 1 0 0x2f6ba5bdf78 ","rf":"5:11_https://pos.baidu.com/"}
[1:1:0713/015043.341640:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:11_https://pos.baidu.com/-5:3_http://www.4399dmw.com/","ptid":"1275 0x7f3f7381f080 0x2f6ba5bdf60 1 0 0x2f6ba5bdf78 ","rf":"5:11_https://pos.baidu.com/"}
[1:1:0713/015043.341823:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.4399dmw.com/"
[1:1:0713/015043.342094:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.4399dmw.com/, 37aceda02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/015043.342193:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 1, , , 0
[1:1:0713/015043.342469:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x500731029c8, 0x2f6b8a4e950
[1:1:0713/015043.342560:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.4399dmw.com/", 100
[1:1:0713/015043.342750:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:11_https://pos.baidu.com/, 1368
[1:1:0713/015043.342853:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1368 0x7f3f5d194070 0x2f6bbc6d9e0 , 5:11_https://pos.baidu.com/, 1, -5:3_http://www.4399dmw.com/, 1329 0x7f3f5d194070 0x2f6bbd7d860 
[1:1:0713/015043.377110:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:11_https://pos.baidu.com/, 1320, 7f3f5fad9881
[1:1:0713/015043.393650:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"37aceda679a8","ptid":"1275 0x7f3f7381f080 0x2f6ba5bdf60 1 0 0x2f6ba5bdf78 ","rf":"5:11_https://pos.baidu.com/"}
[1:1:0713/015043.393826:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:11_https://pos.baidu.com/","ptid":"1275 0x7f3f7381f080 0x2f6ba5bdf60 1 0 0x2f6ba5bdf78 ","rf":"5:11_https://pos.baidu.com/"}
[1:1:0713/015043.394008:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://pos.baidu.com/wh/o.htm?ltr="
[1:1:0713/015043.394266:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:11_https://pos.baidu.com/, 37aceda679a8, , F, (){if(!detectFlash(fname)&&
!isSend)return setTimeout(F,250)}
[1:1:0713/015043.394399:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pos.baidu.com/wh/o.htm?ltr=", "pos.baidu.com", 11, 1, http://www.4399dmw.com, www.4399dmw.com, 4
[1:1:0713/015043.394760:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 250, 0x500731a51f8, 0x2f6b8a4e950
[1:1:0713/015043.394869:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://pos.baidu.com/wh/o.htm?ltr=", 250
[1:1:0713/015043.395084:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:11_https://pos.baidu.com/, 1370
[1:1:0713/015043.395189:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1370 0x7f3f5d194070 0x2f6b9c28fe0 , 5:11_https://pos.baidu.com/, 1, -5:11_https://pos.baidu.com/, 1320 0x7f3f5d194070 0x2f6bbd776e0 
[1:1:0713/015043.412747:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.4399dmw.com/, 1278, 7f3f5fad98db
[1:1:0713/015043.429315:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1237 0x7f3f5d194070 0x2f6bbc816e0 ","rf":"5:3_http://www.4399dmw.com/"}
[1:1:0713/015043.429461:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1237 0x7f3f5d194070 0x2f6bbc816e0 ","rf":"5:3_http://www.4399dmw.com/"}
[1:1:0713/015043.429670:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.4399dmw.com/, 1371
[1:1:0713/015043.429784:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1371 0x7f3f5d194070 0x2f6bbc726e0 , 5:3_http://www.4399dmw.com/, 0, , 1278 0x7f3f5d194070 0x2f6bbc72e60 
[1:1:0713/015043.429964:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.4399dmw.com/"
[1:1:0713/015043.430203:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.4399dmw.com/, 37aceda02860, , , (){document.hasFocus()&&s++}
[1:1:0713/015043.430312:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 1, , , 0
[1:1:0713/015043.497569:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:4_http://www.4399dmw.com/, 1340, 7f3f5fad98db
[1:1:0713/015043.514073:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1279 0x7f3f5d194070 0x2f6bbc920e0 ","rf":"5:4_http://www.4399dmw.com/"}
[1:1:0713/015043.514227:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1279 0x7f3f5d194070 0x2f6bbc920e0 ","rf":"5:4_http://www.4399dmw.com/"}
[1:1:0713/015043.514437:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:4_http://www.4399dmw.com/, 1374
[1:1:0713/015043.514553:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1374 0x7f3f5d194070 0x2f6bbcecfe0 , 5:4_http://www.4399dmw.com/, 0, , 1340 0x7f3f5d194070 0x2f6bbd12a60 
[1:1:0713/015043.514738:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.4399dmw.com/baiduad/proxy.html?id=846418"
[1:1:0713/015043.515018:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://www.4399dmw.com/, 37acedac4648, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0713/015043.515158:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=846418", "www.4399dmw.com", 4, 1, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015043.517992:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac4648, toString, 
[1:1:0713/015043.518121:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 2, , , 0
[1:1:0713/015043.518568:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015043.518768:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/, 37acedac4648, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015043.518906:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=846418", "www.4399dmw.com", 4, 3, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015043.519324:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015043.519743:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac4648, getComputedStyle, 
[1:1:0713/015043.519841:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 4, , , 0
[1:1:0713/015043.520197:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getOpacityInWin (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015043.520821:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 5, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/, 37acedac4648, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015043.520970:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=846418", "www.4399dmw.com", 4, 5, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015043.521372:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015043.523100:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 6, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac4648, toString, 
[1:1:0713/015043.523238:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 6, , , 0
[1:1:0713/015043.523630:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015043.523807:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 7, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/, 37acedac4648, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015043.523952:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=846418", "www.4399dmw.com", 4, 7, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015043.524359:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015043.524745:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 8, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac4648, getComputedStyle, 
[1:1:0713/015043.524876:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 8, , , 0
[1:1:0713/015043.525264:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getOpacityInWin (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015043.525895:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 9, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/, 37acedac4648, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015043.526066:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=846418", "www.4399dmw.com", 4, 9, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015043.526417:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015043.527979:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 10, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac4648, toString, 
[1:1:0713/015043.528121:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 10, , , 0
[1:1:0713/015043.528545:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getVisibility (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015043.528731:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 11, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/, 37acedac4648, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015043.528891:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=846418", "www.4399dmw.com", 4, 11, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015043.529337:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getVisibility (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015043.529759:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 12, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac4648, getComputedStyle, 
[1:1:0713/015043.529927:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 12, , , 0
[1:1:0713/015043.530316:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getVisibilityInWin (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getVisibility (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015043.531021:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 13, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/, 37acedac4648, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015043.531263:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=846418", "www.4399dmw.com", 4, 13, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015043.531638:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getVisibility (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015043.539862:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.4399dmw.com/, 1216, 7f3f5fad98db
[1:1:0713/015043.558503:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"37aceda02860","ptid":"1176 0x7f3f5d194070 0x2f6ba6126e0 ","rf":"5:3_http://www.4399dmw.com/"}
[1:1:0713/015043.558674:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.4399dmw.com/","ptid":"1176 0x7f3f5d194070 0x2f6ba6126e0 ","rf":"5:3_http://www.4399dmw.com/"}
[1:1:0713/015043.558896:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.4399dmw.com/, 1377
[1:1:0713/015043.559011:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1377 0x7f3f5d194070 0x2f6b901d960 , 5:3_http://www.4399dmw.com/, 0, , 1216 0x7f3f5d194070 0x2f6b9639c60 
[1:1:0713/015043.559197:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.4399dmw.com/"
[1:1:0713/015043.559443:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.4399dmw.com/, 37aceda02860, , , (){
					_this.scroll();
				}
[1:1:0713/015043.559551:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 1, , , 0
[1:1:0713/015043.583376:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.4399dmw.com/", 13
[1:1:0713/015043.583629:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.4399dmw.com/, 1379
[1:1:0713/015043.583749:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1379 0x7f3f5d194070 0x2f6bbe340e0 , 5:3_http://www.4399dmw.com/, 1, -5:3_http://www.4399dmw.com/, 1216 0x7f3f5d194070 0x2f6b9639c60 
[1:1:0713/015043.788455:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:5_http://www.4399dmw.com/, 1361, 7f3f5fad98db
[1:1:0713/015043.807776:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1283 0x7f3f5d194070 0x2f6bbcfbb60 ","rf":"5:5_http://www.4399dmw.com/"}
[1:1:0713/015043.807958:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1283 0x7f3f5d194070 0x2f6bbcfbb60 ","rf":"5:5_http://www.4399dmw.com/"}
[1:1:0713/015043.808160:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:5_http://www.4399dmw.com/, 1392
[1:1:0713/015043.808283:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1392 0x7f3f5d194070 0x2f6bbdc0fe0 , 5:5_http://www.4399dmw.com/, 0, , 1361 0x7f3f5d194070 0x2f6bba0a9e0 
[1:1:0713/015043.808473:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.4399dmw.com/baiduad/proxy.html?id=2409097"
[1:1:0713/015043.808746:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:5_http://www.4399dmw.com/, 37acedac99f0, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0713/015043.808866:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=2409097", "www.4399dmw.com", 5, 1, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015043.811859:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac99f0, toString, 
[1:1:0713/015043.811967:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 2, , , 0
[1:1:0713/015043.812432:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015043.812627:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/, 37acedac99f0, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015043.812757:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=2409097", "www.4399dmw.com", 5, 3, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015043.813205:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015043.813617:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac99f0, getComputedStyle, 
[1:1:0713/015043.813747:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 4, , , 0
[1:1:0713/015043.814127:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getOpacityInWin (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015043.814773:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 5, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/, 37acedac99f0, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015043.814923:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=2409097", "www.4399dmw.com", 5, 5, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015043.815340:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015043.816939:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 6, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac99f0, toString, 
[1:1:0713/015043.817092:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 6, , , 0
[1:1:0713/015043.817494:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015043.817679:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 7, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/, 37acedac99f0, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015043.817835:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=2409097", "www.4399dmw.com", 5, 7, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015043.818223:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015043.818673:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 8, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac99f0, getComputedStyle, 
[1:1:0713/015043.818814:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 8, , , 0
[1:1:0713/015043.819174:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getOpacityInWin (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015043.819791:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 9, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/, 37acedac99f0, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015043.819947:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=2409097", "www.4399dmw.com", 5, 9, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015043.820294:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015043.821911:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 10, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac99f0, toString, 
[1:1:0713/015043.822064:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 10, , , 0
[1:1:0713/015043.822486:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getVisibility (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015043.822666:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 11, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/, 37acedac99f0, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015043.822823:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=2409097", "www.4399dmw.com", 5, 11, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015043.823194:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getVisibility (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015043.823592:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 12, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac99f0, getComputedStyle, 
[1:1:0713/015043.823739:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 12, , , 0
[1:1:0713/015043.824092:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getVisibilityInWin (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getVisibility (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015043.824710:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 13, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/, 37acedac99f0, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015043.824897:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=2409097", "www.4399dmw.com", 5, 13, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015043.825279:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getVisibility (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015043.871813:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:11_https://pos.baidu.com/, 1368, 7f3f5fad9881
[1:1:0713/015043.889687:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"37aceda02860","ptid":"1329 0x7f3f5d194070 0x2f6bbd7d860 ","rf":"5:11_https://pos.baidu.com/"}
[1:1:0713/015043.889858:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.4399dmw.com/","ptid":"1329 0x7f3f5d194070 0x2f6bbd7d860 ","rf":"5:11_https://pos.baidu.com/"}
[1:1:0713/015043.890045:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.4399dmw.com/"
[1:1:0713/015043.890309:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.4399dmw.com/, 37aceda02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/015043.890412:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 1, , , 0
[1:1:0713/015043.890696:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x500731029c8, 0x2f6b8a4e950
[1:1:0713/015043.890814:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.4399dmw.com/", 100
[1:1:0713/015043.890989:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:11_https://pos.baidu.com/, 1400
[1:1:0713/015043.891086:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1400 0x7f3f5d194070 0x2f6b8e90660 , 5:11_https://pos.baidu.com/, 1, -5:3_http://www.4399dmw.com/, 1368 0x7f3f5d194070 0x2f6bbc6d9e0 
[1:1:0713/015044.027896:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:8_https://pos.baidu.com/, 1367, 7f3f5fad9881
[1:1:0713/015044.049175:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"37aceda8f078","ptid":"1299 0x7f3f5d194070 0x2f6bbc71260 ","rf":"5:8_https://pos.baidu.com/"}
[1:1:0713/015044.049374:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:8_https://pos.baidu.com/","ptid":"1299 0x7f3f5d194070 0x2f6bbc71260 ","rf":"5:8_https://pos.baidu.com/"}
[1:1:0713/015044.049578:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://pos.baidu.com/wh/o.htm?ltr="
[1:1:0713/015044.049845:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:8_https://pos.baidu.com/, 37aceda8f078, , F, (){if(!detectFlash(fname)&&
!isSend)return setTimeout(F,250)}
[1:1:0713/015044.049991:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pos.baidu.com/wh/o.htm?ltr=", "pos.baidu.com", 8, 1, http://www.4399dmw.com, www.4399dmw.com, 5
[1:1:0713/015044.050410:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 250, 0x500731a43e0, 0x2f6b8a4e950
[1:1:0713/015044.050512:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://pos.baidu.com/wh/o.htm?ltr=", 250
[1:1:0713/015044.050693:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:8_https://pos.baidu.com/, 1408
[1:1:0713/015044.050809:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1408 0x7f3f5d194070 0x2f6bbd412e0 , 5:8_https://pos.baidu.com/, 1, -5:8_https://pos.baidu.com/, 1367 0x7f3f5d194070 0x2f6bbd77f60 
[1:1:0713/015044.051546:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.4399dmw.com/, 1379, 7f3f5fad98db
[1:1:0713/015044.070381:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"37aceda02860","ptid":"1216 0x7f3f5d194070 0x2f6b9639c60 ","rf":"5:3_http://www.4399dmw.com/"}
[1:1:0713/015044.070549:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.4399dmw.com/","ptid":"1216 0x7f3f5d194070 0x2f6b9639c60 ","rf":"5:3_http://www.4399dmw.com/"}
[1:1:0713/015044.070773:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.4399dmw.com/, 1410
[1:1:0713/015044.070890:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1410 0x7f3f5d194070 0x2f6b88cbfe0 , 5:3_http://www.4399dmw.com/, 0, , 1379 0x7f3f5d194070 0x2f6bbe340e0 
[1:1:0713/015044.071081:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.4399dmw.com/"
[1:1:0713/015044.071332:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.4399dmw.com/, 37aceda02860, , tick, (){for(var a=
c.timers,b=0;b<a.length;b++)a[b]()||a.splice(b--,1);a.length||c.fx.stop()}
[1:1:0713/015044.071448:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 1, , , 0
[1:1:0713/015044.078627:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:11_https://pos.baidu.com/, 1370, 7f3f5fad9881
[1:1:0713/015044.097654:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"37aceda679a8","ptid":"1320 0x7f3f5d194070 0x2f6bbd776e0 ","rf":"5:11_https://pos.baidu.com/"}
[1:1:0713/015044.097833:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:11_https://pos.baidu.com/","ptid":"1320 0x7f3f5d194070 0x2f6bbd776e0 ","rf":"5:11_https://pos.baidu.com/"}
[1:1:0713/015044.098034:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://pos.baidu.com/wh/o.htm?ltr="
[1:1:0713/015044.098316:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:11_https://pos.baidu.com/, 37aceda679a8, , F, (){if(!detectFlash(fname)&&
!isSend)return setTimeout(F,250)}
[1:1:0713/015044.098436:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pos.baidu.com/wh/o.htm?ltr=", "pos.baidu.com", 11, 1, http://www.4399dmw.com, www.4399dmw.com, 4
[1:1:0713/015044.098787:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 250, 0x500731a51f8, 0x2f6b8a4e950
[1:1:0713/015044.098878:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://pos.baidu.com/wh/o.htm?ltr=", 250
[1:1:0713/015044.099041:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:11_https://pos.baidu.com/, 1413
[1:1:0713/015044.099145:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1413 0x7f3f5d194070 0x2f6bbcf5c60 , 5:11_https://pos.baidu.com/, 1, -5:11_https://pos.baidu.com/, 1370 0x7f3f5d194070 0x2f6b9c28fe0 
[1:1:0713/015044.156099:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.4399dmw.com/, 1371, 7f3f5fad98db
[1:1:0713/015044.175249:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1278 0x7f3f5d194070 0x2f6bbc72e60 ","rf":"5:3_http://www.4399dmw.com/"}
[1:1:0713/015044.175430:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1278 0x7f3f5d194070 0x2f6bbc72e60 ","rf":"5:3_http://www.4399dmw.com/"}
[1:1:0713/015044.175648:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.4399dmw.com/, 1416
[1:1:0713/015044.175754:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1416 0x7f3f5d194070 0x2f6bbec6960 , 5:3_http://www.4399dmw.com/, 0, , 1371 0x7f3f5d194070 0x2f6bbc726e0 
[1:1:0713/015044.175941:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.4399dmw.com/"
[1:1:0713/015044.176182:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.4399dmw.com/, 37aceda02860, , , (){document.hasFocus()&&s++}
[1:1:0713/015044.176283:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 1, , , 0
[1:1:0713/015044.176810:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:4_http://www.4399dmw.com/, 1374, 7f3f5fad98db
[1:1:0713/015044.195336:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1340 0x7f3f5d194070 0x2f6bbd12a60 ","rf":"5:4_http://www.4399dmw.com/"}
[1:1:0713/015044.195492:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1340 0x7f3f5d194070 0x2f6bbd12a60 ","rf":"5:4_http://www.4399dmw.com/"}
[1:1:0713/015044.195706:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:4_http://www.4399dmw.com/, 1417
[1:1:0713/015044.195821:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1417 0x7f3f5d194070 0x2f6b8b01960 , 5:4_http://www.4399dmw.com/, 0, , 1374 0x7f3f5d194070 0x2f6bbcecfe0 
[1:1:0713/015044.196006:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.4399dmw.com/baiduad/proxy.html?id=846418"
[1:1:0713/015044.196275:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://www.4399dmw.com/, 37acedac4648, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0713/015044.196408:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=846418", "www.4399dmw.com", 4, 1, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015044.199277:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac4648, toString, 
[1:1:0713/015044.199400:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 2, , , 0
[1:1:0713/015044.199855:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015044.200049:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/, 37acedac4648, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015044.200175:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=846418", "www.4399dmw.com", 4, 3, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015044.200598:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015044.201004:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac4648, getComputedStyle, 
[1:1:0713/015044.201145:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 4, , , 0
[1:1:0713/015044.201525:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getOpacityInWin (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015044.202199:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 5, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/, 37acedac4648, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015044.202348:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=846418", "www.4399dmw.com", 4, 5, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015044.202712:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015044.204301:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 6, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac4648, toString, 
[1:1:0713/015044.204424:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 6, , , 0
[1:1:0713/015044.204812:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015044.204975:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 7, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/, 37acedac4648, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015044.205134:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=846418", "www.4399dmw.com", 4, 7, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015044.205521:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015044.205930:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 8, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac4648, getComputedStyle, 
[1:1:0713/015044.206069:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 8, , , 0
[1:1:0713/015044.206433:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getOpacityInWin (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015044.207100:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 9, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/, 37acedac4648, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015044.207258:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=846418", "www.4399dmw.com", 4, 9, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015044.207603:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015044.209207:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 10, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac4648, toString, 
[1:1:0713/015044.209359:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 10, , , 0
[1:1:0713/015044.209761:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getVisibility (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015044.209950:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 11, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/, 37acedac4648, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015044.210126:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=846418", "www.4399dmw.com", 4, 11, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015044.210517:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getVisibility (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015044.210912:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 12, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac4648, getComputedStyle, 
[1:1:0713/015044.211085:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 12, , , 0
[1:1:0713/015044.211593:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getVisibilityInWin (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getVisibility (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015044.212418:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 13, -5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:4_http://www.4399dmw.com/, 37acedac4648, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015044.212625:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=846418", "www.4399dmw.com", 4, 13, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015044.213027:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getVisibility (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015044.245946:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:5_http://www.4399dmw.com/, 1392, 7f3f5fad98db
[1:1:0713/015044.263791:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1361 0x7f3f5d194070 0x2f6bba0a9e0 ","rf":"5:5_http://www.4399dmw.com/"}
[1:1:0713/015044.263953:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1361 0x7f3f5d194070 0x2f6bba0a9e0 ","rf":"5:5_http://www.4399dmw.com/"}
[1:1:0713/015044.264163:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:5_http://www.4399dmw.com/, 1418
[1:1:0713/015044.264277:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1418 0x7f3f5d194070 0x2f6b8eba1e0 , 5:5_http://www.4399dmw.com/, 0, , 1392 0x7f3f5d194070 0x2f6bbdc0fe0 
[1:1:0713/015044.264468:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.4399dmw.com/baiduad/proxy.html?id=2409097"
[1:1:0713/015044.264748:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:5_http://www.4399dmw.com/, 37acedac99f0, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0713/015044.264869:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=2409097", "www.4399dmw.com", 5, 1, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015044.267652:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac99f0, toString, 
[1:1:0713/015044.267764:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 2, , , 0
[1:1:0713/015044.268190:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015044.268383:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/, 37acedac99f0, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015044.268523:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=2409097", "www.4399dmw.com", 5, 3, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015044.268931:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015044.269340:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac99f0, getComputedStyle, 
[1:1:0713/015044.269463:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 4, , , 0
[1:1:0713/015044.269837:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getOpacityInWin (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015044.270479:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 5, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/, 37acedac99f0, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015044.270627:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=2409097", "www.4399dmw.com", 5, 5, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015044.270990:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015044.272587:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 6, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac99f0, toString, 
[1:1:0713/015044.272717:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 6, , , 0
[1:1:0713/015044.273113:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015044.273299:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 7, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/, 37acedac99f0, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015044.273453:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=2409097", "www.4399dmw.com", 5, 7, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015044.273841:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015044.274255:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 8, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac99f0, getComputedStyle, 
[1:1:0713/015044.274388:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 8, , , 0
[1:1:0713/015044.274749:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getOpacityInWin (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015044.275382:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 9, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/, 37acedac99f0, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015044.275536:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=2409097", "www.4399dmw.com", 5, 9, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015044.275882:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getOpacity (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015044.277455:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 10, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac99f0, toString, 
[1:1:0713/015044.277617:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 10, , , 0
[1:1:0713/015044.278104:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getVisibility (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015044.278313:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 11, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/, 37acedac99f0, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015044.278504:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=2409097", "www.4399dmw.com", 5, 11, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015044.278949:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getVisibility (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015044.279392:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 12, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/, 37aceda02860, 37acedac99f0, getComputedStyle, 
[1:1:0713/015044.279538:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 12, , , 0
[1:1:0713/015044.279911:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getVisibilityInWin (http://cbjs.baidu.com/js/m.js:1:1)
	Object.getVisibility (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015044.280544:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 13, -5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/-5:3_http://www.4399dmw.com/-5:5_http://www.4399dmw.com/, 37acedac99f0, 37aceda02860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0713/015044.280718:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/baiduad/proxy.html?id=2409097", "www.4399dmw.com", 5, 13, http://www.4399dmw.com, www.4399dmw.com, 3
[1:1:0713/015044.281143:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getVisibility (http://cbjs.baidu.com/js/m.js:1:1)
	Object.isWatchDomVisible (http://cbjs.baidu.com/js/m.js:1:1)
	Object.computeViewStatus (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewableCompute (http://cbjs.baidu.com/js/m.js:1:1)
	Object.viewOnChange (http://cbjs.baidu.com/js/m.js:1:1)
	http://cbjs.baidu.com/js/m.js:1:1

[1:1:0713/015044.307565:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:11_https://pos.baidu.com/, 1400, 7f3f5fad9881
[1:1:0713/015044.325359:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"37aceda02860","ptid":"1368 0x7f3f5d194070 0x2f6bbc6d9e0 ","rf":"5:11_https://pos.baidu.com/"}
[1:1:0713/015044.325535:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.4399dmw.com/","ptid":"1368 0x7f3f5d194070 0x2f6bbc6d9e0 ","rf":"5:11_https://pos.baidu.com/"}
[1:1:0713/015044.325732:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.4399dmw.com/"
[1:1:0713/015044.325999:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.4399dmw.com/, 37aceda02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/015044.326117:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 1, , , 0
[1:1:0713/015044.326403:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x500731029c8, 0x2f6b8a4e950
[1:1:0713/015044.326505:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.4399dmw.com/", 100
[1:1:0713/015044.326671:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:11_https://pos.baidu.com/, 1421
[1:1:0713/015044.326784:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1421 0x7f3f5d194070 0x2f6bbd7d160 , 5:11_https://pos.baidu.com/, 1, -5:3_http://www.4399dmw.com/, 1400 0x7f3f5d194070 0x2f6b8e90660 
[1:1:0713/015044.490746:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.4399dmw.com/, 1410, 7f3f5fad98db
[1:1:0713/015044.512306:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1379 0x7f3f5d194070 0x2f6bbe340e0 ","rf":"5:3_http://www.4399dmw.com/"}
[1:1:0713/015044.512495:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1379 0x7f3f5d194070 0x2f6bbe340e0 ","rf":"5:3_http://www.4399dmw.com/"}
[1:1:0713/015044.512734:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.4399dmw.com/, 1432
[1:1:0713/015044.512822:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1432 0x7f3f5d194070 0x2f6bbe37b60 , 5:3_http://www.4399dmw.com/, 0, , 1410 0x7f3f5d194070 0x2f6b88cbfe0 
[1:1:0713/015044.512991:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.4399dmw.com/"
[1:1:0713/015044.513264:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.4399dmw.com/, 37aceda02860, , tick, (){for(var a=
c.timers,b=0;b<a.length;b++)a[b]()||a.splice(b--,1);a.length||c.fx.stop()}
[1:1:0713/015044.513374:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.4399dmw.com/", "www.4399dmw.com", 3, 1, , , 0
[1:1:0713/015044.520336:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x500731029c8, 0x2f6b8a4e950
[1:1:0713/015044.520509:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.4399dmw.com/", 0
[1:1:0713/015044.520683:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.4399dmw.com/, 1434
[1:1:0713/015044.520788:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1434 0x7f3f5d194070 0x2f6bbf5cd60 , 5:3_http://www.4399dmw.com/, 1, -5:3_http://www.4399dmw.com/, 1410 0x7f3f5d194070 0x2f6b88cbfe0 
[1:1:0713/015044.521133:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x500731029c8, 0x2f6b8a4e950
[1:1:0713/015044.521224:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.4399dmw.com/", 0
[1:1:0713/015044.521372:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.4399dmw.com/, 1435
[1:1:0713/015044.521492:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1435 0x7f3f5d194070 0x2f6bbf5c760 , 5:3_http://www.4399dmw.com/, 1, -5:3_http://www.4399dmw.com/, 1410 0x7f3f5d194070 0x2f6b88cbfe0 
[1:1:0713/015044.617295:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:8_https://pos.baidu.com/, 1408, 7f3f5fad9881
[1:1:0713/015044.640922:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"37aceda8f078","ptid":"1367 0x7f3f5d194070 0x2f6bbd77f60 ","rf":"5:8_https://pos.baidu.com/"}
[1:1:0713/015044.641183:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:8_https://pos.baidu.com/","ptid":"1367 0x7f3f5d194070 0x2f6bbd77f60 ","rf":"5:8_https://pos.baidu.com/"}
[1:1:0713/015044.641422:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://pos.baidu.com/wh/o.htm?ltr="
[1:1:0713/015044.641730:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:8_https://pos.baidu.com/, 37aceda8f078, , F, (){if(!detectFlash(fname)&&
!isSend)return setTimeout(F,250)}
[1:1:0713/015044.641877:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pos.baidu.com/wh/o.htm?ltr=", "pos.baidu.com", 8, 1, http://www.4399dmw.com, www.4399dmw.com, 5
[1:1:0713/015044.642272:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 250, 0x500731a43e0, 0x2f6b8a4e950
[1:1:0713/015044.642381:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://pos.baidu.com/wh/o.htm?ltr=", 250
[1:1:0713/015044.643068:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:8_https://pos.baidu.com/, 1445
[1:1:0713/015044.643212:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1445 0x7f3f5d194070 0x2f6bbf5c7e0 , 5:8_https://pos.baidu.com/, 1, -5:8_https://pos.baidu.com/, 1408 0x7f3f5d194070 0x2f6bbd412e0 
[1:1:0713/015044.668335:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:8_https://pos.baidu.com/, 1298, 7f3f5fad9881
[1:1:0713/015044.692805:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"37aceda8f078","ptid":"1269 0x7f3f7381f080 0x2f6b8a01100 1 0 0x2f6b8a01118 ","rf":"5:8_https://pos.baidu.com/"}
[1:1:0713/015044.692998:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:8_https://pos.baidu.com/","ptid":"1269 0x7f3f7381f080 0x2f6b8a01100 1 0 0x2f6b8a01118 ","rf":"5:8_https://pos.baidu.com/"}
[1:1:0713/015044.693235:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://pos.baidu.com/wh/o.htm?ltr="
[1:1:0713/015044.693526:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:8_https://pos.baidu.com/, 37aceda8f078, , , (){if(!isSend)send()}
[1:1:0713/015044.693632:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pos.baidu.com/wh/o.htm?ltr=", "pos.baidu.com", 8, 1, http://www.4399dmw.com, www.4399dmw.com, 5
