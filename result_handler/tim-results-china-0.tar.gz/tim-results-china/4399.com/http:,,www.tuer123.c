[0713/015618.704297:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/015618.704557:INFO:switcher_clone.cc(787)] backtrace rip is 7f8509166891
[0713/015619.242878:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/015619.243142:INFO:switcher_clone.cc(787)] backtrace rip is 7fac19548891
[1:1:0713/015619.247529:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0713/015619.247700:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0713/015619.250501:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[0713/015620.087521:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/015620.087794:INFO:switcher_clone.cc(787)] backtrace rip is 7f2c3dfd3891
[13615:13615:0713/015620.144063:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/c1237d9f-79a3-4e9e-8e9e-47fe1b3af3c1
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[13647:13647:0713/015620.245727:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=13647
[13660:13660:0713/015620.246955:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=13660
[13615:13615:0713/015620.398020:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[13615:13645:0713/015620.398458:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0713/015620.398592:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0713/015620.398758:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0713/015620.399046:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0713/015620.399181:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0713/015620.400871:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x1709e2be, 1
[1:1:0713/015620.401192:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x287c9e9c, 0
[1:1:0713/015620.401320:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x29942cf0, 3
[1:1:0713/015620.401402:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x2389fc19, 2
[1:1:0713/015620.401556:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffff9cffffff9e7c28 ffffffbeffffffe20917 19fffffffcffffff8923 fffffff02cffffff9429 , 10104, 4
[1:1:0713/015620.402272:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[13615:13645:0713/015620.402413:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING��|(��	��#�,�)P$&
[13615:13645:0713/015620.402458:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ��|(��	��#�,�)�mP$&
[1:1:0713/015620.402407:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fac177820a0, 3
[1:1:0713/015620.402507:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fac1790e080, 2
[13615:13645:0713/015620.402605:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0713/015620.402591:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fac015d0d20, -2
[13615:13645:0713/015620.402640:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 13668, 4, 9c9e7c28 bee20917 19fc8923 f02c9429 
[1:1:0713/015620.410561:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0713/015620.410978:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2389fc19
[1:1:0713/015620.411404:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2389fc19
[1:1:0713/015620.412142:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2389fc19
[1:1:0713/015620.412655:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2389fc19
[1:1:0713/015620.412756:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2389fc19
[1:1:0713/015620.412849:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2389fc19
[1:1:0713/015620.412919:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2389fc19
[1:1:0713/015620.413192:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2389fc19
[1:1:0713/015620.413350:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fac195487ba
[1:1:0713/015620.413446:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fac1953fdef, 7fac1954877a, 7fac1954a0cf
[1:1:0713/015620.415038:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2389fc19
[1:1:0713/015620.415210:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2389fc19
[1:1:0713/015620.415530:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2389fc19
[1:1:0713/015620.416281:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2389fc19
[1:1:0713/015620.416395:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2389fc19
[1:1:0713/015620.416498:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2389fc19
[1:1:0713/015620.416601:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2389fc19
[1:1:0713/015620.417125:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2389fc19
[1:1:0713/015620.417299:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fac195487ba
[1:1:0713/015620.417380:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fac1953fdef, 7fac1954877a, 7fac1954a0cf
[1:1:0713/015620.419836:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0713/015620.420052:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0713/015620.420138:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffd27bfac88, 0x7ffd27bfac08)
[1:1:0713/015620.426737:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0713/015620.429400:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[13615:13615:0713/015620.813816:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[13615:13615:0713/015620.814311:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[13615:13627:0713/015620.823062:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[13615:13627:0713/015620.823129:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[13615:13615:0713/015620.823169:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[13615:13615:0713/015620.823213:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[13615:13615:0713/015620.823279:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,13668, 4
[1:7:0713/015620.828936:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/015620.891402:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x37d6db5a8220
[1:1:0713/015620.891567:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[13615:13638:0713/015620.941600:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0713/015621.110231:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[13615:13627:0713/015621.439514:ERROR:ssl_client_socket_impl.cc(1046)] handshake failed; returned -1, SSL error code 1, net_error -101
[1:1:0713/015621.851774:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/015621.853603:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[13615:13615:0713/015622.123075:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[13615:13615:0713/015622.123185:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0713/015622.342941:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/015622.444373:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 09879e2c1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0713/015622.444594:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/015622.450088:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 09879e2c1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0713/015622.450238:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/015622.495456:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/015622.495620:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/015622.664331:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 365, "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/015622.666892:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 09879e2c1f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0713/015622.667029:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/015622.678887:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 366, "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/015622.681891:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 09879e2c1f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0713/015622.682021:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/015622.685775:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[13615:13615:0713/015622.686382:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0713/015622.687453:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x37d6db5a6e20
[1:1:0713/015622.687707:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[13615:13615:0713/015622.688839:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[13615:13615:0713/015622.700228:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[13615:13615:0713/015622.700316:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0713/015622.719669:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/015623.013814:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 426 0x7fac031ab2e0 0x37d6db81fee0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/015623.014503:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 09879e2c1f78, , , var configData = {"googleBaseUrl":"https://www.google.com.hk/","isAccessibleBrowser":false,"isGoogle
[1:1:0713/015623.014621:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/015623.015163:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[13615:13615:0713/015623.041375:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0713/015623.042489:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x37d6db5a7820
[1:1:0713/015623.042638:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[13615:13615:0713/015623.043798:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0713/015623.049705:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0713/015623.049915:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[13615:13615:0713/015623.051828:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[13615:13615:0713/015623.055945:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[13615:13615:0713/015623.056350:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[13615:13627:0713/015623.060671:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[13615:13627:0713/015623.060725:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[13615:13615:0713/015623.060744:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[13615:13615:0713/015623.060780:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[13615:13615:0713/015623.060835:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,13668, 4
[1:7:0713/015623.062180:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/015623.336757:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0713/015623.506644:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 478 0x7fac031ab2e0 0x37d6db7fa660 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/015623.507245:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 09879e2c1f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0713/015623.507404:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/015623.507752:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[13615:13615:0713/015623.592137:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[13615:13615:0713/015623.592199:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0713/015623.603841:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[13615:13615:0713/015623.719885:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[13615:13645:0713/015623.720185:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0713/015623.720311:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0713/015623.720446:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0713/015623.720630:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0713/015623.720709:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0713/015623.723117:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x2640f843, 1
[1:1:0713/015623.723381:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x24680e67, 0
[1:1:0713/015623.723536:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x3800c4ef, 3
[1:1:0713/015623.723663:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x6cb9555, 2
[1:1:0713/015623.723774:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 670e6824 43fffffff84026 55ffffff95ffffffcb06 ffffffefffffffc40038 , 10104, 5
[1:1:0713/015623.724505:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[13615:13645:0713/015623.724717:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGgh$C�@&U����
[13615:13645:0713/015623.724768:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is gh$C�@&U����
[13615:13645:0713/015623.724907:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 13710, 5, 670e6824 43f84026 5595cb06 efc40038 
[1:1:0713/015623.724712:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fac177820a0, 3
[1:1:0713/015623.725427:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fac1790e080, 2
[1:1:0713/015623.725539:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fac015d0d20, -2
[1:1:0713/015623.735183:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0713/015623.735392:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 6cb9555
[1:1:0713/015623.735571:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 6cb9555
[1:1:0713/015623.735834:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 6cb9555
[1:1:0713/015623.736340:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 6cb9555
[1:1:0713/015623.736438:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 6cb9555
[1:1:0713/015623.736531:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 6cb9555
[1:1:0713/015623.736620:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 6cb9555
[1:1:0713/015623.736872:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 6cb9555
[1:1:0713/015623.737006:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fac195487ba
[1:1:0713/015623.737101:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fac1953fdef, 7fac1954877a, 7fac1954a0cf
[1:1:0713/015623.738766:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 6cb9555
[1:1:0713/015623.738934:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 6cb9555
[1:1:0713/015623.739234:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 6cb9555
[1:1:0713/015623.740001:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 6cb9555
[1:1:0713/015623.740119:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 6cb9555
[1:1:0713/015623.740239:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 6cb9555
[1:1:0713/015623.740343:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 6cb9555
[1:1:0713/015623.740862:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 6cb9555
[1:1:0713/015623.741051:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fac195487ba
[1:1:0713/015623.741167:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fac1953fdef, 7fac1954877a, 7fac1954a0cf
[1:1:0713/015623.743718:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0713/015623.743929:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0713/015623.744041:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffd27bfac88, 0x7ffd27bfac08)
[1:1:0713/015623.750142:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0713/015623.750212:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/015623.752091:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0713/015623.862707:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x37d6db532220
[1:1:0713/015623.862925:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0713/015624.031989:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/015624.032198:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/015624.188898:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 545, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/015624.190587:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 09879e3ee5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0713/015624.190770:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/015624.193203:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/015624.243856:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/015624.244277:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 09879e2c1f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0713/015624.244426:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/015624.293724:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/015624.294781:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0713/015624.294935:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 09879e3ee5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0713/015624.295086:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/015624.358686:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/015624.359152:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0713/015624.359291:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 09879e3ee5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0713/015624.359417:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/015624.486021:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://m.vk.com/"
[1:1:0713/015624.625155:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.taobao.com/"
[1:1:0713/015624.719005:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.qq.com/"
[13615:13615:0713/015624.770895:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[13615:13615:0713/015624.772948:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0713/015624.773295:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://amazon.com/"
[13615:13627:0713/015624.790949:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[13615:13627:0713/015624.791016:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[13615:13615:0713/015624.791161:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://www.tuer123.com/
[13615:13615:0713/015624.791204:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://www.tuer123.com/, http://www.tuer123.com/gushi/tegs/8773.html, 1
[13615:13615:0713/015624.791269:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://www.tuer123.com/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 17:56:24 GMT Content-Type: text/html; charset=UTF-8 Transfer-Encoding: chunked Connection: keep-alive Server: openresty/1.11.2.5 Cache-Control: max-age=300 Content-Encoding: gzip X-Via: 1.1 PSjsczsx2hu62:10 (Cdn Cache Server V2.0), 1.1 PS-SHA-01IiS223:4 (Cdn Cache Server V2.0), 1.1 hkuan36:4 (Cdn Cache Server V2.0)  ,13710, 5
[1:7:0713/015624.792798:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/015624.801537:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://tmall.com/"
[1:1:0713/015624.807567:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://www.tuer123.com/
[1:1:0713/015624.838865:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://github.com/"
[13615:13615:0713/015624.867496:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://www.tuer123.com/, http://www.tuer123.com/, 1
[13615:13615:0713/015624.867562:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://www.tuer123.com/, http://www.tuer123.com
[1:1:0713/015624.873121:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/015624.890031:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.jd.com/"
[1:1:0713/015624.911792:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/015624.917787:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://yahoo.com/"
[1:1:0713/015624.940239:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/015624.940429:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015624.955092:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 121 0x7fac01283070 0x37d6db5b1660 , "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015624.956287:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.tuer123.com/, 16da934a2860, , ,  (function() { var ua = navigator.userAgent, loc = window.location.href, mUrl = '//m.tuer123.com', r
[1:1:0713/015624.956431:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.tuer123.com/gushi/tegs/8773.html", "www.tuer123.com", 3, 1, , , 0
[1:1:0713/015624.965730:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/015624.966324:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 09879e3ee5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0713/015624.966541:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/015624.991360:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/015624.991824:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 09879e3ee5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0713/015624.991998:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/015625.005480:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0649951, 706, 1
[1:1:0713/015625.005651:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/015625.029331:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/015625.029799:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 09879e3ee5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0713/015625.029971:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/015625.052139:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/015625.052677:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 09879e3ee5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0713/015625.052830:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/015625.099846:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/015625.100011:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015625.100088:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/015625.100502:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 09879e3ee5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0713/015625.100660:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/015625.135217:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/015625.135653:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 09879e3ee5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0713/015625.135832:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/015625.159960:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/015625.160415:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 09879e3ee5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0713/015625.160586:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/015625.215300:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/015625.215745:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 09879e3ee5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0713/015625.215915:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/015625.219443:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/015625.262595:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/015625.263059:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 09879e3ee5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0713/015625.263231:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/015625.264234:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 188 0x7fac015ebbd0 0x37d6db3bedd8 , "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015625.266853:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/015625.269399:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.tuer123.com/, 16da934a2860, , , /*! jQuery v1.7 jquery.com | jquery.org/license */
(function(a,b){function cA(a){return f.isWindow(a
[1:1:0713/015625.269536:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.tuer123.com/gushi/tegs/8773.html", "www.tuer123.com", 3, 1, , , 0
		remove user.d_e1219788 -> 0
[1:1:0713/015625.334461:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/015625.334923:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 09879e3ee5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0713/015625.335096:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/015625.370394:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/015625.370845:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 09879e3ee5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0713/015625.371017:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/015625.395348:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/015625.395817:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 09879e3ee5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0713/015625.395990:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/015625.994674:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 188 0x7fac015ebbd0 0x37d6db3bedd8 , "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015625.997460:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 188 0x7fac015ebbd0 0x37d6db3bedd8 , "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015626.001182:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 188 0x7fac015ebbd0 0x37d6db3bedd8 , "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015626.003592:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 188 0x7fac015ebbd0 0x37d6db3bedd8 , "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015626.010979:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 188 0x7fac015ebbd0 0x37d6db3bedd8 , "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015626.124222:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015626.143592:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x35e9535229c8, 0x37d6db14ea38
[1:1:0713/015626.143778:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.tuer123.com/gushi/tegs/8773.html", 0
[1:1:0713/015626.143989:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.tuer123.com/, 216
[1:1:0713/015626.144136:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 216 0x7fac01283070 0x37d6db236b60 , 5:3_http://www.tuer123.com/, 1, -5:3_http://www.tuer123.com/, 188 0x7fac015ebbd0 0x37d6db3bedd8 
[1:1:0713/015629.059936:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/015631.075819:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x35e9535229c8, 0x37d6db14ea38
[1:1:0713/015631.076107:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.tuer123.com/gushi/tegs/8773.html", 0
[1:1:0713/015631.076578:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.tuer123.com/, 218
[1:1:0713/015631.076745:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 218 0x7fac01283070 0x37d6dccd92e0 , 5:3_http://www.tuer123.com/, 1, -5:3_http://www.tuer123.com/, 188 0x7fac015ebbd0 0x37d6db3bedd8 
[1:1:0713/015631.079264:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.tuer123.com/gushi/tegs/8773.html", 13
[1:1:0713/015631.079549:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.tuer123.com/, 219
[1:1:0713/015631.079736:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 219 0x7fac01283070 0x37d6dcda7ee0 , 5:3_http://www.tuer123.com/, 1, -5:3_http://www.tuer123.com/, 188 0x7fac015ebbd0 0x37d6db3bedd8 
[1:1:0713/015631.324567:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/015631.387030:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.tuer123.com/, 216, 7fac03bc8881
[1:1:0713/015631.391813:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"16da934a2860","ptid":"188 0x7fac015ebbd0 0x37d6db3bedd8 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015631.392263:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.tuer123.com/","ptid":"188 0x7fac015ebbd0 0x37d6db3bedd8 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015631.392557:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015631.392876:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.tuer123.com/, 16da934a2860, , , (){t.fill()}
[1:1:0713/015631.392970:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.tuer123.com/gushi/tegs/8773.html", "www.tuer123.com", 3, 1, , , 0
[1:1:0713/015631.475588:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.tuer123.com/, 218, 7fac03bc8881
[1:1:0713/015631.480372:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"16da934a2860","ptid":"188 0x7fac015ebbd0 0x37d6db3bedd8 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015631.480548:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.tuer123.com/","ptid":"188 0x7fac015ebbd0 0x37d6db3bedd8 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015631.480755:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015631.481061:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.tuer123.com/, 16da934a2860, , cv, (){ct=b}
[1:1:0713/015631.481162:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.tuer123.com/gushi/tegs/8773.html", "www.tuer123.com", 3, 1, , , 0
[1:1:0713/015631.481764:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.tuer123.com/, 219, 7fac03bc88db
[1:1:0713/015631.486231:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"16da934a2860","ptid":"188 0x7fac015ebbd0 0x37d6db3bedd8 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015631.486431:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.tuer123.com/","ptid":"188 0x7fac015ebbd0 0x37d6db3bedd8 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015631.486671:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.tuer123.com/, 272
[1:1:0713/015631.486799:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 272 0x7fac01283070 0x37d6db263560 , 5:3_http://www.tuer123.com/, 0, , 219 0x7fac01283070 0x37d6dcda7ee0 
[1:1:0713/015631.486950:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015631.487215:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.tuer123.com/, 16da934a2860, , tick, (){var a,b=f.timers,c=0;for(;c<b.length;c++)a=b[c],!a()&&b[c]===a&&b.splice(c--,1);b.length||f.fx.st
[1:1:0713/015631.487312:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.tuer123.com/gushi/tegs/8773.html", "www.tuer123.com", 3, 1, , , 0
[1:1:0713/015631.487928:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x35e9535229c8, 0x37d6db14e950
[1:1:0713/015631.488028:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.tuer123.com/gushi/tegs/8773.html", 0
[1:1:0713/015631.488192:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.tuer123.com/, 273
[1:1:0713/015631.488306:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 273 0x7fac01283070 0x37d6dff92860 , 5:3_http://www.tuer123.com/, 1, -5:3_http://www.tuer123.com/, 219 0x7fac01283070 0x37d6dcda7ee0 
[1:1:0713/015631.519296:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "loadstart", "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015631.574838:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 257 0x7fac031ab2e0 0x37d6db57d660 , "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015631.578411:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.tuer123.com/, 16da934a2860, , , (function(){var h={},mt={},c={id:"7e4e17ab351f03d62789572d0da3f5ae",dm:["tuer123.com"],js:"tongji.ba
[1:1:0713/015631.578580:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.tuer123.com/gushi/tegs/8773.html", "www.tuer123.com", 3, 1, , , 0
[1:1:0713/015631.590792:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x35e9535229c8, 0x37d6db14e948
[1:1:0713/015631.590966:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.tuer123.com/gushi/tegs/8773.html", 100
[1:1:0713/015631.591172:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.tuer123.com/, 282
[1:1:0713/015631.591411:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 282 0x7fac01283070 0x37d6db6470e0 , 5:3_http://www.tuer123.com/, 1, -5:3_http://www.tuer123.com/, 257 0x7fac031ab2e0 0x37d6db57d660 
[13615:13615:0713/015645.512149:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -356
[13615:13615:0713/015645.537378:INFO:CONSOLE(1)] "Uncaught (in promise) NotAllowedError: play() failed because the user didn't interact with the document first. https://goo.gl/xX8pDD", source: http://www.tuer123.com/module/pc/resource/js/audio.a732b8.js (1)
[3:3:0713/015645.546577:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0713/015645.716055:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.tuer123.com/, 273, 7fac03bc8881
[1:1:0713/015645.721358:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"16da934a2860","ptid":"219 0x7fac01283070 0x37d6dcda7ee0 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015645.721584:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.tuer123.com/","ptid":"219 0x7fac01283070 0x37d6dcda7ee0 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015645.721849:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015645.722187:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.tuer123.com/, 16da934a2860, , cv, (){ct=b}
[1:1:0713/015645.722345:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.tuer123.com/gushi/tegs/8773.html", "www.tuer123.com", 3, 1, , , 0
[1:1:0713/015645.889190:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015645.889660:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.tuer123.com/, 16da934a2860, , d, (a,e){var j,k,l,m,n;try{if(d&&(e||h.readyState===4)){d=b,i&&(h.onreadystatechange=f.noop,ch&&delete 
[1:1:0713/015645.889777:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.tuer123.com/gushi/tegs/8773.html", "www.tuer123.com", 3, 1, , , 0
[1:1:0713/015645.890356:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015645.891746:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015645.892106:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x392da9a36ea8
[1:1:0713/015645.907144:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.tuer123.com/, 16da934a2860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0713/015645.907325:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.tuer123.com/gushi/tegs/8773.html", "www.tuer123.com", 3, 1, , , 0
[1:1:0713/015646.204220:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.tuer123.com/, 282, 7fac03bc8881
[1:1:0713/015646.210455:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"16da934a2860","ptid":"257 0x7fac031ab2e0 0x37d6db57d660 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015646.210649:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.tuer123.com/","ptid":"257 0x7fac031ab2e0 0x37d6db57d660 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015646.210862:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015646.211150:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.tuer123.com/, 16da934a2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/015646.211255:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.tuer123.com/gushi/tegs/8773.html", "www.tuer123.com", 3, 1, , , 0
[1:1:0713/015646.211615:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x35e9535229c8, 0x37d6db14e950
[1:1:0713/015646.211697:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.tuer123.com/gushi/tegs/8773.html", 100
[1:1:0713/015646.211868:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.tuer123.com/, 394
[1:1:0713/015646.211950:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 394 0x7fac01283070 0x37d6db771960 , 5:3_http://www.tuer123.com/, 1, -5:3_http://www.tuer123.com/, 282 0x7fac01283070 0x37d6db6470e0 
[1:1:0713/015646.313591:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015646.314042:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.tuer123.com/, 16da934a2860, , o.onload, (){o.onload=null,e.replaceImg(t,n)}
[1:1:0713/015646.314175:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.tuer123.com/gushi/tegs/8773.html", "www.tuer123.com", 3, 1, , , 0
[1:1:0713/015646.337268:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015646.337672:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.tuer123.com/, 16da934a2860, , o.onload, (){o.onload=null,e.replaceImg(t,n)}
[1:1:0713/015646.337792:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.tuer123.com/gushi/tegs/8773.html", "www.tuer123.com", 3, 1, , , 0
[1:1:0713/015646.354761:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015646.355235:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.tuer123.com/, 16da934a2860, , o.onload, (){o.onload=null,e.replaceImg(t,n)}
[1:1:0713/015646.355389:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.tuer123.com/gushi/tegs/8773.html", "www.tuer123.com", 3, 1, , , 0
[1:1:0713/015646.376948:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015646.377385:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.tuer123.com/, 16da934a2860, , o.onload, (){o.onload=null,e.replaceImg(t,n)}
[1:1:0713/015646.377509:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.tuer123.com/gushi/tegs/8773.html", "www.tuer123.com", 3, 1, , , 0
[1:1:0713/015646.393977:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015646.394361:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.tuer123.com/, 16da934a2860, , o.onload, (){o.onload=null,e.replaceImg(t,n)}
[1:1:0713/015646.394461:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.tuer123.com/gushi/tegs/8773.html", "www.tuer123.com", 3, 1, , , 0
[1:1:0713/015646.417362:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015646.417855:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.tuer123.com/, 16da934a2860, , o.onload, (){o.onload=null,e.replaceImg(t,n)}
[1:1:0713/015646.417976:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.tuer123.com/gushi/tegs/8773.html", "www.tuer123.com", 3, 1, , , 0
[1:1:0713/015646.433987:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015646.434438:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.tuer123.com/, 16da934a2860, , o.onload, (){o.onload=null,e.replaceImg(t,n)}
[1:1:0713/015646.434557:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.tuer123.com/gushi/tegs/8773.html", "www.tuer123.com", 3, 1, , , 0
[1:1:0713/015646.456690:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015646.457150:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.tuer123.com/, 16da934a2860, , o.onload, (){o.onload=null,e.replaceImg(t,n)}
[1:1:0713/015646.457269:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.tuer123.com/gushi/tegs/8773.html", "www.tuer123.com", 3, 1, , , 0
[1:1:0713/015646.473593:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015646.474038:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.tuer123.com/, 16da934a2860, , o.onload, (){o.onload=null,e.replaceImg(t,n)}
[1:1:0713/015646.474173:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.tuer123.com/gushi/tegs/8773.html", "www.tuer123.com", 3, 1, , , 0
[1:1:0713/015646.706326:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.tuer123.com/, 16da934a2860, , , document.readyState
[1:1:0713/015646.706501:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.tuer123.com/gushi/tegs/8773.html", "www.tuer123.com", 3, 1, , , 0
[1:1:0713/015646.771389:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015646.771847:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.tuer123.com/, 16da934a2860, , f.onload, (){f.onload=u;f=window[d]=u;a&&a(b)}
[1:1:0713/015646.771965:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.tuer123.com/gushi/tegs/8773.html", "www.tuer123.com", 3, 1, , , 0
[1:2:0713/015646.781169:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/015646.784981:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015646.785432:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.tuer123.com/, 16da934a2860, , i, (a){return typeof f!="undefined"&&(!a||f.event.triggered!==a.type)?f.event.dispatch.apply(i.elem,arg
[1:1:0713/015646.785748:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.tuer123.com/gushi/tegs/8773.html", "www.tuer123.com", 3, 1, , , 0
[1:1:0713/015646.795990:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.tuer123.com/, 394, 7fac03bc8881
[1:1:0713/015646.804650:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"16da934a2860","ptid":"282 0x7fac01283070 0x37d6db6470e0 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015646.805005:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.tuer123.com/","ptid":"282 0x7fac01283070 0x37d6db6470e0 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015646.809266:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015646.809614:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.tuer123.com/, 16da934a2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/015646.809717:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.tuer123.com/gushi/tegs/8773.html", "www.tuer123.com", 3, 1, , , 0
[1:1:0713/015646.810056:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x35e9535229c8, 0x37d6db14e950
[1:1:0713/015646.810148:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.tuer123.com/gushi/tegs/8773.html", 100
[1:1:0713/015646.810324:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.tuer123.com/, 448
[1:1:0713/015646.810431:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 448 0x7fac01283070 0x37d6e0100c60 , 5:3_http://www.tuer123.com/, 1, -5:3_http://www.tuer123.com/, 394 0x7fac01283070 0x37d6db771960 
[1:1:0713/015646.819587:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015646.820011:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.tuer123.com/, 16da934a2860, , i, (a){return typeof f!="undefined"&&(!a||f.event.triggered!==a.type)?f.event.dispatch.apply(i.elem,arg
[1:1:0713/015646.820136:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.tuer123.com/gushi/tegs/8773.html", "www.tuer123.com", 3, 1, , , 0
[1:1:0713/015646.841463:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015646.841920:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.tuer123.com/, 16da934a2860, , i, (a){return typeof f!="undefined"&&(!a||f.event.triggered!==a.type)?f.event.dispatch.apply(i.elem,arg
[1:1:0713/015646.842035:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.tuer123.com/gushi/tegs/8773.html", "www.tuer123.com", 3, 1, , , 0
[1:1:0713/015646.855348:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015646.855766:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.tuer123.com/, 16da934a2860, , i, (a){return typeof f!="undefined"&&(!a||f.event.triggered!==a.type)?f.event.dispatch.apply(i.elem,arg
[1:1:0713/015646.855868:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.tuer123.com/gushi/tegs/8773.html", "www.tuer123.com", 3, 1, , , 0
[1:1:0713/015646.875769:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015646.876168:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.tuer123.com/, 16da934a2860, , i, (a){return typeof f!="undefined"&&(!a||f.event.triggered!==a.type)?f.event.dispatch.apply(i.elem,arg
[1:1:0713/015646.876288:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.tuer123.com/gushi/tegs/8773.html", "www.tuer123.com", 3, 1, , , 0
[1:1:0713/015646.904558:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015646.904973:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.tuer123.com/, 16da934a2860, , i, (a){return typeof f!="undefined"&&(!a||f.event.triggered!==a.type)?f.event.dispatch.apply(i.elem,arg
[1:1:0713/015646.905351:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.tuer123.com/gushi/tegs/8773.html", "www.tuer123.com", 3, 1, , , 0
[1:1:0713/015646.918344:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015646.918753:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.tuer123.com/, 16da934a2860, , i, (a){return typeof f!="undefined"&&(!a||f.event.triggered!==a.type)?f.event.dispatch.apply(i.elem,arg
[1:1:0713/015646.918865:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.tuer123.com/gushi/tegs/8773.html", "www.tuer123.com", 3, 1, , , 0
[1:1:0713/015646.931781:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015646.932185:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.tuer123.com/, 16da934a2860, , i, (a){return typeof f!="undefined"&&(!a||f.event.triggered!==a.type)?f.event.dispatch.apply(i.elem,arg
[1:1:0713/015646.932299:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.tuer123.com/gushi/tegs/8773.html", "www.tuer123.com", 3, 1, , , 0
[1:1:0713/015646.952946:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015646.955858:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.tuer123.com/, 16da934a2860, , i, (a){return typeof f!="undefined"&&(!a||f.event.triggered!==a.type)?f.event.dispatch.apply(i.elem,arg
[1:1:0713/015646.955997:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.tuer123.com/gushi/tegs/8773.html", "www.tuer123.com", 3, 1, , , 0
[1:1:0713/015646.961668:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015646.962059:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015646.963116:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "pageshow", "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015646.963753:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x35e9535229c8, 0x37d6db14eaf0
[1:1:0713/015646.963890:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.tuer123.com/gushi/tegs/8773.html", 100
[1:1:0713/015646.964057:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.tuer123.com/, 453
[1:1:0713/015646.964173:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 453 0x7fac01283070 0x37d6e02a9660 , 5:3_http://www.tuer123.com/, 1, -5:3_http://www.tuer123.com/, 411 0x7fac01283070 0x37d6dffee2e0 
[1:1:0713/015647.134782:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.tuer123.com/, 16da934a2860, , , document.readyState
[1:1:0713/015647.134941:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.tuer123.com/gushi/tegs/8773.html", "www.tuer123.com", 3, 1, , , 0
[1:1:0713/015647.238950:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015647.239357:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.tuer123.com/, 16da934a2860, , i, (a){return typeof f!="undefined"&&(!a||f.event.triggered!==a.type)?f.event.dispatch.apply(i.elem,arg
[1:1:0713/015647.239460:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.tuer123.com/gushi/tegs/8773.html", "www.tuer123.com", 3, 1, , , 0
[1:1:0713/015647.255347:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x35e9535229c8, 0x37d6db14ea20
[1:1:0713/015647.255504:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.tuer123.com/gushi/tegs/8773.html", 0
[1:1:0713/015647.255689:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.tuer123.com/, 470
[1:1:0713/015647.255804:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 470 0x7fac01283070 0x37d6e084ca60 , 5:3_http://www.tuer123.com/, 1, -5:3_http://www.tuer123.com/, 441 0x7fac10594960 0x37d6e05f82e0 0x37d6e05f82f0 
[1:1:0713/015647.257160:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.tuer123.com/gushi/tegs/8773.html", 13
[1:1:0713/015647.257340:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.tuer123.com/, 471
[1:1:0713/015647.257454:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 471 0x7fac01283070 0x37d6e0982a60 , 5:3_http://www.tuer123.com/, 1, -5:3_http://www.tuer123.com/, 441 0x7fac10594960 0x37d6e05f82e0 0x37d6e05f82f0 
[1:1:0713/015647.397387:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "progress", "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015647.397846:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.tuer123.com/, 16da934a2860, , i, (a){return typeof f!="undefined"&&(!a||f.event.triggered!==a.type)?f.event.dispatch.apply(i.elem,arg
[1:1:0713/015647.397996:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.tuer123.com/gushi/tegs/8773.html", "www.tuer123.com", 3, 1, , , 0
		remove user.f_a13eb1a4 -> 0
		remove user.10_f4726bad -> 0
[1:1:0713/015647.428620:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.tuer123.com/, 453, 7fac03bc8881
[1:1:0713/015647.434501:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"16da934a2860","ptid":"411 0x7fac01283070 0x37d6dffee2e0 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015647.434658:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.tuer123.com/","ptid":"411 0x7fac01283070 0x37d6dffee2e0 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015647.434862:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015647.435162:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.tuer123.com/, 16da934a2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/015647.435272:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.tuer123.com/gushi/tegs/8773.html", "www.tuer123.com", 3, 1, , , 0
[1:1:0713/015647.435567:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x35e9535229c8, 0x37d6db14e950
[1:1:0713/015647.435667:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.tuer123.com/gushi/tegs/8773.html", 100
[1:1:0713/015647.435833:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.tuer123.com/, 483
[1:1:0713/015647.435914:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 483 0x7fac01283070 0x37d6db265260 , 5:3_http://www.tuer123.com/, 1, -5:3_http://www.tuer123.com/, 453 0x7fac01283070 0x37d6e02a9660 
[1:7:0713/015647.519464:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/015647.531328:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.tuer123.com/, 470, 7fac03bc8881
[1:1:0713/015647.538182:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"16da934a2860","ptid":"441 0x7fac10594960 0x37d6e05f82e0 0x37d6e05f82f0 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015647.538313:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.tuer123.com/","ptid":"441 0x7fac10594960 0x37d6e05f82e0 0x37d6e05f82f0 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015647.538502:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015647.538769:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.tuer123.com/, 16da934a2860, , cv, (){ct=b}
[1:1:0713/015647.538868:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.tuer123.com/gushi/tegs/8773.html", "www.tuer123.com", 3, 1, , , 0
[1:1:0713/015647.539294:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.tuer123.com/, 471, 7fac03bc88db
[1:1:0713/015647.546002:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"16da934a2860","ptid":"441 0x7fac10594960 0x37d6e05f82e0 0x37d6e05f82f0 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015647.546125:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.tuer123.com/","ptid":"441 0x7fac10594960 0x37d6e05f82e0 0x37d6e05f82f0 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015647.546311:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.tuer123.com/, 503
[1:1:0713/015647.546400:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 503 0x7fac01283070 0x37d6e0af0d60 , 5:3_http://www.tuer123.com/, 0, , 471 0x7fac01283070 0x37d6e0982a60 
[1:1:0713/015647.546516:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015647.546722:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.tuer123.com/, 16da934a2860, , tick, (){var a,b=f.timers,c=0;for(;c<b.length;c++)a=b[c],!a()&&b[c]===a&&b.splice(c--,1);b.length||f.fx.st
[1:1:0713/015647.546805:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.tuer123.com/gushi/tegs/8773.html", "www.tuer123.com", 3, 1, , , 0
[1:1:0713/015647.547284:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x35e9535229c8, 0x37d6db14e950
[1:1:0713/015647.547419:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.tuer123.com/gushi/tegs/8773.html", 0
[1:1:0713/015647.547576:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.tuer123.com/, 504
[1:1:0713/015647.547741:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 504 0x7fac01283070 0x37d6e09bb260 , 5:3_http://www.tuer123.com/, 1, -5:3_http://www.tuer123.com/, 471 0x7fac01283070 0x37d6e0982a60 
[1:1:0713/015647.616903:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "progress", "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015647.617311:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.tuer123.com/, 16da934a2860, , i, (a){return typeof f!="undefined"&&(!a||f.event.triggered!==a.type)?f.event.dispatch.apply(i.elem,arg
[1:1:0713/015647.617414:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.tuer123.com/gushi/tegs/8773.html", "www.tuer123.com", 3, 1, , , 0
[1:1:0713/015647.740163:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.tuer123.com/, 483, 7fac03bc8881
[1:1:0713/015647.747042:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"16da934a2860","ptid":"453 0x7fac01283070 0x37d6e02a9660 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015647.747188:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.tuer123.com/","ptid":"453 0x7fac01283070 0x37d6e02a9660 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015647.747381:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015647.747672:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.tuer123.com/, 16da934a2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/015647.747786:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.tuer123.com/gushi/tegs/8773.html", "www.tuer123.com", 3, 1, , , 0
[1:1:0713/015647.748090:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x35e9535229c8, 0x37d6db14e950
[1:1:0713/015647.748194:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.tuer123.com/gushi/tegs/8773.html", 100
[1:1:0713/015647.748362:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.tuer123.com/, 522
[1:1:0713/015647.748465:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 522 0x7fac01283070 0x37d6e0b4e260 , 5:3_http://www.tuer123.com/, 1, -5:3_http://www.tuer123.com/, 483 0x7fac01283070 0x37d6db265260 
[1:1:0713/015647.748860:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.tuer123.com/, 504, 7fac03bc8881
[1:1:0713/015647.755736:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"16da934a2860","ptid":"471 0x7fac01283070 0x37d6e0982a60 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015647.755897:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.tuer123.com/","ptid":"471 0x7fac01283070 0x37d6e0982a60 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015647.756108:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015647.756341:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.tuer123.com/, 16da934a2860, , cv, (){ct=b}
[1:1:0713/015647.756436:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.tuer123.com/gushi/tegs/8773.html", "www.tuer123.com", 3, 1, , , 0
[1:1:0713/015647.756876:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.tuer123.com/, 503, 7fac03bc88db
[1:1:0713/015647.763554:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"471 0x7fac01283070 0x37d6e0982a60 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015647.763678:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"471 0x7fac01283070 0x37d6e0982a60 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015647.763870:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.tuer123.com/, 524
[1:1:0713/015647.763981:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 524 0x7fac01283070 0x37d6e02a9e60 , 5:3_http://www.tuer123.com/, 0, , 503 0x7fac01283070 0x37d6e0af0d60 
[1:1:0713/015647.764122:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015647.764354:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.tuer123.com/, 16da934a2860, , tick, (){var a,b=f.timers,c=0;for(;c<b.length;c++)a=b[c],!a()&&b[c]===a&&b.splice(c--,1);b.length||f.fx.st
[1:1:0713/015647.764464:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.tuer123.com/gushi/tegs/8773.html", "www.tuer123.com", 3, 1, , , 0
[1:1:0713/015647.764867:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x35e9535229c8, 0x37d6db14e950
[1:1:0713/015647.764954:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.tuer123.com/gushi/tegs/8773.html", 0
[1:1:0713/015647.765114:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.tuer123.com/, 525
[1:1:0713/015647.765222:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 525 0x7fac01283070 0x37d6e0ad5d60 , 5:3_http://www.tuer123.com/, 1, -5:3_http://www.tuer123.com/, 503 0x7fac01283070 0x37d6e0af0d60 
[1:1:0713/015647.825910:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "loadedmetadata", "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015647.826290:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.tuer123.com/, 16da934a2860, , i, (a){return typeof f!="undefined"&&(!a||f.event.triggered!==a.type)?f.event.dispatch.apply(i.elem,arg
[1:1:0713/015647.826386:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.tuer123.com/gushi/tegs/8773.html", "www.tuer123.com", 3, 1, , , 0
[1:1:0713/015647.872584:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.tuer123.com/, 525, 7fac03bc8881
[1:1:0713/015647.881126:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"16da934a2860","ptid":"503 0x7fac01283070 0x37d6e0af0d60 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015647.881340:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.tuer123.com/","ptid":"503 0x7fac01283070 0x37d6e0af0d60 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015647.881582:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015647.881899:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.tuer123.com/, 16da934a2860, , cv, (){ct=b}
[1:1:0713/015647.882046:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.tuer123.com/gushi/tegs/8773.html", "www.tuer123.com", 3, 1, , , 0
[1:1:0713/015647.954984:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.tuer123.com/, 522, 7fac03bc8881
[1:1:0713/015647.964867:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"16da934a2860","ptid":"483 0x7fac01283070 0x37d6db265260 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015647.965086:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.tuer123.com/","ptid":"483 0x7fac01283070 0x37d6db265260 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015647.965274:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015647.965606:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.tuer123.com/, 16da934a2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/015647.965936:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.tuer123.com/gushi/tegs/8773.html", "www.tuer123.com", 3, 1, , , 0
[1:1:0713/015647.966279:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x35e9535229c8, 0x37d6db14e950
[1:1:0713/015647.966366:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.tuer123.com/gushi/tegs/8773.html", 100
[1:1:0713/015647.966656:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.tuer123.com/, 549
[1:1:0713/015647.967003:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 549 0x7fac01283070 0x37d6e0b208e0 , 5:3_http://www.tuer123.com/, 1, -5:3_http://www.tuer123.com/, 522 0x7fac01283070 0x37d6e0b4e260 
[1:1:0713/015648.017347:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "progress", "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015648.017755:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.tuer123.com/, 16da934a2860, , i, (a){return typeof f!="undefined"&&(!a||f.event.triggered!==a.type)?f.event.dispatch.apply(i.elem,arg
[1:1:0713/015648.017876:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.tuer123.com/gushi/tegs/8773.html", "www.tuer123.com", 3, 1, , , 0
[1:1:0713/015648.086908:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.tuer123.com/, 549, 7fac03bc8881
[1:1:0713/015648.094474:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"16da934a2860","ptid":"522 0x7fac01283070 0x37d6e0b4e260 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015648.094626:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.tuer123.com/","ptid":"522 0x7fac01283070 0x37d6e0b4e260 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015648.094821:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015648.095109:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.tuer123.com/, 16da934a2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/015648.095226:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.tuer123.com/gushi/tegs/8773.html", "www.tuer123.com", 3, 1, , , 0
[1:1:0713/015648.095536:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x35e9535229c8, 0x37d6db14e950
[1:1:0713/015648.095633:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.tuer123.com/gushi/tegs/8773.html", 100
[1:1:0713/015648.095780:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.tuer123.com/, 560
[1:1:0713/015648.095878:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 560 0x7fac01283070 0x37d6e09836e0 , 5:3_http://www.tuer123.com/, 1, -5:3_http://www.tuer123.com/, 549 0x7fac01283070 0x37d6e0b208e0 
[1:1:0713/015648.203112:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "progress", "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015648.203549:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.tuer123.com/, 16da934a2860, , i, (a){return typeof f!="undefined"&&(!a||f.event.triggered!==a.type)?f.event.dispatch.apply(i.elem,arg
[1:1:0713/015648.203671:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.tuer123.com/gushi/tegs/8773.html", "www.tuer123.com", 3, 1, , , 0
[1:1:0713/015648.245208:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.tuer123.com/, 560, 7fac03bc8881
[1:1:0713/015648.252756:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"16da934a2860","ptid":"549 0x7fac01283070 0x37d6e0b208e0 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015648.252910:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.tuer123.com/","ptid":"549 0x7fac01283070 0x37d6e0b208e0 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015648.253124:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015648.253417:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.tuer123.com/, 16da934a2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/015648.253555:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.tuer123.com/gushi/tegs/8773.html", "www.tuer123.com", 3, 1, , , 0
[1:1:0713/015648.253861:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x35e9535229c8, 0x37d6db14e950
[1:1:0713/015648.253960:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.tuer123.com/gushi/tegs/8773.html", 100
[1:1:0713/015648.254107:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.tuer123.com/, 583
[1:1:0713/015648.254184:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 583 0x7fac01283070 0x37d6e0ad2360 , 5:3_http://www.tuer123.com/, 1, -5:3_http://www.tuer123.com/, 560 0x7fac01283070 0x37d6e09836e0 
[1:1:0713/015648.392936:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.tuer123.com/, 583, 7fac03bc8881
[1:1:0713/015648.401381:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"16da934a2860","ptid":"560 0x7fac01283070 0x37d6e09836e0 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015648.401596:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.tuer123.com/","ptid":"560 0x7fac01283070 0x37d6e09836e0 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015648.401800:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015648.402167:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.tuer123.com/, 16da934a2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/015648.402281:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.tuer123.com/gushi/tegs/8773.html", "www.tuer123.com", 3, 1, , , 0
[1:1:0713/015648.402589:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x35e9535229c8, 0x37d6db14e950
[1:1:0713/015648.402697:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.tuer123.com/gushi/tegs/8773.html", 100
[1:1:0713/015648.402888:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.tuer123.com/, 603
[1:1:0713/015648.403008:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 603 0x7fac01283070 0x37d6db6cbce0 , 5:3_http://www.tuer123.com/, 1, -5:3_http://www.tuer123.com/, 583 0x7fac01283070 0x37d6e0ad2360 
[1:1:0713/015648.577625:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "progress", "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015648.578064:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.tuer123.com/, 16da934a2860, , i, (a){return typeof f!="undefined"&&(!a||f.event.triggered!==a.type)?f.event.dispatch.apply(i.elem,arg
[1:1:0713/015648.578187:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.tuer123.com/gushi/tegs/8773.html", "www.tuer123.com", 3, 1, , , 0
[1:1:0713/015648.580746:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.tuer123.com/, 603, 7fac03bc8881
[1:1:0713/015648.589481:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"16da934a2860","ptid":"583 0x7fac01283070 0x37d6e0ad2360 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015648.589635:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.tuer123.com/","ptid":"583 0x7fac01283070 0x37d6e0ad2360 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015648.589826:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015648.590124:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.tuer123.com/, 16da934a2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/015648.590264:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.tuer123.com/gushi/tegs/8773.html", "www.tuer123.com", 3, 1, , , 0
[1:1:0713/015648.590566:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x35e9535229c8, 0x37d6db14e950
[1:1:0713/015648.590666:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.tuer123.com/gushi/tegs/8773.html", 100
[1:1:0713/015648.590817:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.tuer123.com/, 629
[1:1:0713/015648.590894:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 629 0x7fac01283070 0x37d6db1f59e0 , 5:3_http://www.tuer123.com/, 1, -5:3_http://www.tuer123.com/, 603 0x7fac01283070 0x37d6db6cbce0 
[1:1:0713/015648.727899:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.tuer123.com/, 629, 7fac03bc8881
[1:1:0713/015648.737069:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"16da934a2860","ptid":"603 0x7fac01283070 0x37d6db6cbce0 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015648.737260:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.tuer123.com/","ptid":"603 0x7fac01283070 0x37d6db6cbce0 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015648.737453:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015648.737741:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.tuer123.com/, 16da934a2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/015648.737856:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.tuer123.com/gushi/tegs/8773.html", "www.tuer123.com", 3, 1, , , 0
[1:1:0713/015648.738171:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x35e9535229c8, 0x37d6db14e950
[1:1:0713/015648.738251:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.tuer123.com/gushi/tegs/8773.html", 100
[1:1:0713/015648.738435:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.tuer123.com/, 646
[1:1:0713/015648.738522:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 646 0x7fac01283070 0x37d6e0b4e6e0 , 5:3_http://www.tuer123.com/, 1, -5:3_http://www.tuer123.com/, 629 0x7fac01283070 0x37d6db1f59e0 
[1:1:0713/015648.908363:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.tuer123.com/, 646, 7fac03bc8881
[1:1:0713/015648.917710:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"16da934a2860","ptid":"629 0x7fac01283070 0x37d6db1f59e0 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015648.917915:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.tuer123.com/","ptid":"629 0x7fac01283070 0x37d6db1f59e0 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015648.918123:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015648.918415:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.tuer123.com/, 16da934a2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/015648.918532:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.tuer123.com/gushi/tegs/8773.html", "www.tuer123.com", 3, 1, , , 0
[1:1:0713/015648.918842:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x35e9535229c8, 0x37d6db14e950
[1:1:0713/015648.918949:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.tuer123.com/gushi/tegs/8773.html", 100
[1:1:0713/015648.919133:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.tuer123.com/, 669
[1:1:0713/015648.919214:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 669 0x7fac01283070 0x37d6e0100ee0 , 5:3_http://www.tuer123.com/, 1, -5:3_http://www.tuer123.com/, 646 0x7fac01283070 0x37d6e0b4e6e0 
[1:1:0713/015648.947891:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "progress", "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015648.948268:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.tuer123.com/, 16da934a2860, , i, (a){return typeof f!="undefined"&&(!a||f.event.triggered!==a.type)?f.event.dispatch.apply(i.elem,arg
[1:1:0713/015648.948389:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.tuer123.com/gushi/tegs/8773.html", "www.tuer123.com", 3, 1, , , 0
[1:1:0713/015649.058355:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.tuer123.com/, 669, 7fac03bc8881
[1:1:0713/015649.068071:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"16da934a2860","ptid":"646 0x7fac01283070 0x37d6e0b4e6e0 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015649.068244:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.tuer123.com/","ptid":"646 0x7fac01283070 0x37d6e0b4e6e0 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015649.068448:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015649.068732:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.tuer123.com/, 16da934a2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/015649.068834:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.tuer123.com/gushi/tegs/8773.html", "www.tuer123.com", 3, 1, , , 0
[1:1:0713/015649.069175:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x35e9535229c8, 0x37d6db14e950
[1:1:0713/015649.069283:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.tuer123.com/gushi/tegs/8773.html", 100
[1:1:0713/015649.069469:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.tuer123.com/, 685
[1:1:0713/015649.069592:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 685 0x7fac01283070 0x37d6e0b265e0 , 5:3_http://www.tuer123.com/, 1, -5:3_http://www.tuer123.com/, 669 0x7fac01283070 0x37d6e0100ee0 
[1:1:0713/015649.218007:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.tuer123.com/, 685, 7fac03bc8881
[1:1:0713/015649.227681:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"16da934a2860","ptid":"669 0x7fac01283070 0x37d6e0100ee0 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015649.227856:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.tuer123.com/","ptid":"669 0x7fac01283070 0x37d6e0100ee0 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015649.228061:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015649.228350:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.tuer123.com/, 16da934a2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/015649.228465:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.tuer123.com/gushi/tegs/8773.html", "www.tuer123.com", 3, 1, , , 0
[1:1:0713/015649.228763:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x35e9535229c8, 0x37d6db14e950
[1:1:0713/015649.228860:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.tuer123.com/gushi/tegs/8773.html", 100
[1:1:0713/015649.229025:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.tuer123.com/, 703
[1:1:0713/015649.229157:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 703 0x7fac01283070 0x37d6e02bb260 , 5:3_http://www.tuer123.com/, 1, -5:3_http://www.tuer123.com/, 685 0x7fac01283070 0x37d6e0b265e0 
[1:1:0713/015649.299753:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "progress", "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015649.300183:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.tuer123.com/, 16da934a2860, , i, (a){return typeof f!="undefined"&&(!a||f.event.triggered!==a.type)?f.event.dispatch.apply(i.elem,arg
[1:1:0713/015649.300323:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.tuer123.com/gushi/tegs/8773.html", "www.tuer123.com", 3, 1, , , 0
[1:1:0713/015649.393685:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.tuer123.com/, 703, 7fac03bc8881
[1:1:0713/015649.403484:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"16da934a2860","ptid":"685 0x7fac01283070 0x37d6e0b265e0 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015649.403658:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.tuer123.com/","ptid":"685 0x7fac01283070 0x37d6e0b265e0 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015649.403864:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015649.404156:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.tuer123.com/, 16da934a2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/015649.404263:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.tuer123.com/gushi/tegs/8773.html", "www.tuer123.com", 3, 1, , , 0
[1:1:0713/015649.404572:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x35e9535229c8, 0x37d6db14e950
[1:1:0713/015649.404670:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.tuer123.com/gushi/tegs/8773.html", 100
[1:1:0713/015649.404846:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.tuer123.com/, 721
[1:1:0713/015649.404944:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 721 0x7fac01283070 0x37d6e02e66e0 , 5:3_http://www.tuer123.com/, 1, -5:3_http://www.tuer123.com/, 703 0x7fac01283070 0x37d6e02bb260 
[1:1:0713/015649.559152:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.tuer123.com/, 721, 7fac03bc8881
[1:1:0713/015649.569275:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"16da934a2860","ptid":"703 0x7fac01283070 0x37d6e02bb260 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015649.569447:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.tuer123.com/","ptid":"703 0x7fac01283070 0x37d6e02bb260 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015649.569658:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015649.569951:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.tuer123.com/, 16da934a2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/015649.570067:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.tuer123.com/gushi/tegs/8773.html", "www.tuer123.com", 3, 1, , , 0
[1:1:0713/015649.570377:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x35e9535229c8, 0x37d6db14e950
[1:1:0713/015649.570483:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.tuer123.com/gushi/tegs/8773.html", 100
[1:1:0713/015649.570639:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.tuer123.com/, 740
[1:1:0713/015649.570761:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 740 0x7fac01283070 0x37d6e0b17860 , 5:3_http://www.tuer123.com/, 1, -5:3_http://www.tuer123.com/, 721 0x7fac01283070 0x37d6e02e66e0 
[1:1:0713/015649.666129:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "progress", "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015649.666667:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.tuer123.com/, 16da934a2860, , i, (a){return typeof f!="undefined"&&(!a||f.event.triggered!==a.type)?f.event.dispatch.apply(i.elem,arg
[1:1:0713/015649.666818:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.tuer123.com/gushi/tegs/8773.html", "www.tuer123.com", 3, 1, , , 0
[1:1:0713/015649.720941:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.tuer123.com/, 740, 7fac03bc8881
[1:1:0713/015649.730895:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"16da934a2860","ptid":"721 0x7fac01283070 0x37d6e02e66e0 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015649.731102:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.tuer123.com/","ptid":"721 0x7fac01283070 0x37d6e02e66e0 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015649.731347:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015649.731639:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.tuer123.com/, 16da934a2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/015649.731754:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.tuer123.com/gushi/tegs/8773.html", "www.tuer123.com", 3, 1, , , 0
[1:1:0713/015649.732065:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x35e9535229c8, 0x37d6db14e950
[1:1:0713/015649.732161:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.tuer123.com/gushi/tegs/8773.html", 100
[1:1:0713/015649.732337:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.tuer123.com/, 761
[1:1:0713/015649.732443:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 761 0x7fac01283070 0x37d6e09bb960 , 5:3_http://www.tuer123.com/, 1, -5:3_http://www.tuer123.com/, 740 0x7fac01283070 0x37d6e0b17860 
[1:1:0713/015649.780580:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "progress", "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015649.780948:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.tuer123.com/, 16da934a2860, , i, (a){return typeof f!="undefined"&&(!a||f.event.triggered!==a.type)?f.event.dispatch.apply(i.elem,arg
[1:1:0713/015649.781083:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.tuer123.com/gushi/tegs/8773.html", "www.tuer123.com", 3, 1, , , 0
[1:1:0713/015649.827273:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/015649.838638:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.tuer123.com/, 761, 7fac03bc8881
[1:1:0713/015649.848164:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"16da934a2860","ptid":"740 0x7fac01283070 0x37d6e0b17860 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015649.848328:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.tuer123.com/","ptid":"740 0x7fac01283070 0x37d6e0b17860 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015649.848540:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015649.848821:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.tuer123.com/, 16da934a2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/015649.848914:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.tuer123.com/gushi/tegs/8773.html", "www.tuer123.com", 3, 1, , , 0
[1:1:0713/015649.850114:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x35e9535229c8, 0x37d6db14e950
[1:1:0713/015649.850222:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.tuer123.com/gushi/tegs/8773.html", 100
[1:1:0713/015649.850411:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.tuer123.com/, 768
[1:1:0713/015649.850531:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 768 0x7fac01283070 0x37d6db5bf260 , 5:3_http://www.tuer123.com/, 1, -5:3_http://www.tuer123.com/, 761 0x7fac01283070 0x37d6e09bb960 
[1:1:0713/015649.960019:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.tuer123.com/, 768, 7fac03bc8881
[1:1:0713/015649.969642:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"16da934a2860","ptid":"761 0x7fac01283070 0x37d6e09bb960 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015649.969843:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.tuer123.com/","ptid":"761 0x7fac01283070 0x37d6e09bb960 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015649.970088:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015649.970419:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.tuer123.com/, 16da934a2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/015649.970571:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.tuer123.com/gushi/tegs/8773.html", "www.tuer123.com", 3, 1, , , 0
[1:1:0713/015649.970932:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x35e9535229c8, 0x37d6db14e950
[1:1:0713/015649.971043:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.tuer123.com/gushi/tegs/8773.html", 100
[1:1:0713/015649.971231:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.tuer123.com/, 774
[1:1:0713/015649.971354:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 774 0x7fac01283070 0x37d6e0ef9ae0 , 5:3_http://www.tuer123.com/, 1, -5:3_http://www.tuer123.com/, 768 0x7fac01283070 0x37d6db5bf260 
[1:1:0713/015650.081665:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.tuer123.com/, 774, 7fac03bc8881
[1:1:0713/015650.091403:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"16da934a2860","ptid":"768 0x7fac01283070 0x37d6db5bf260 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015650.091615:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.tuer123.com/","ptid":"768 0x7fac01283070 0x37d6db5bf260 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015650.091850:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015650.092156:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.tuer123.com/, 16da934a2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/015650.092270:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.tuer123.com/gushi/tegs/8773.html", "www.tuer123.com", 3, 1, , , 0
[1:1:0713/015650.092626:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x35e9535229c8, 0x37d6db14e950
[1:1:0713/015650.092736:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.tuer123.com/gushi/tegs/8773.html", 100
[1:1:0713/015650.092910:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.tuer123.com/, 776
[1:1:0713/015650.093010:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 776 0x7fac01283070 0x37d6db6cbde0 , 5:3_http://www.tuer123.com/, 1, -5:3_http://www.tuer123.com/, 774 0x7fac01283070 0x37d6e0ef9ae0 
[1:1:0713/015650.203260:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.tuer123.com/, 776, 7fac03bc8881
[1:1:0713/015650.212888:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"16da934a2860","ptid":"774 0x7fac01283070 0x37d6e0ef9ae0 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015650.213054:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.tuer123.com/","ptid":"774 0x7fac01283070 0x37d6e0ef9ae0 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015650.213315:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015650.213640:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.tuer123.com/, 16da934a2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/015650.213795:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.tuer123.com/gushi/tegs/8773.html", "www.tuer123.com", 3, 1, , , 0
[1:1:0713/015650.214151:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x35e9535229c8, 0x37d6db14e950
[1:1:0713/015650.214260:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.tuer123.com/gushi/tegs/8773.html", 100
[1:1:0713/015650.214490:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.tuer123.com/, 778
[1:1:0713/015650.214611:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 778 0x7fac01283070 0x37d6db600160 , 5:3_http://www.tuer123.com/, 1, -5:3_http://www.tuer123.com/, 776 0x7fac01283070 0x37d6db6cbde0 
[1:1:0713/015650.324311:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.tuer123.com/, 778, 7fac03bc8881
[1:1:0713/015650.333934:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"16da934a2860","ptid":"776 0x7fac01283070 0x37d6db6cbde0 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015650.334133:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.tuer123.com/","ptid":"776 0x7fac01283070 0x37d6db6cbde0 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015650.334384:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015650.334710:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.tuer123.com/, 16da934a2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/015650.334861:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.tuer123.com/gushi/tegs/8773.html", "www.tuer123.com", 3, 1, , , 0
[1:1:0713/015650.335217:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x35e9535229c8, 0x37d6db14e950
[1:1:0713/015650.335327:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.tuer123.com/gushi/tegs/8773.html", 100
[1:1:0713/015650.335511:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.tuer123.com/, 783
[1:1:0713/015650.335633:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 783 0x7fac01283070 0x37d6db5bfa60 , 5:3_http://www.tuer123.com/, 1, -5:3_http://www.tuer123.com/, 778 0x7fac01283070 0x37d6db600160 
[1:1:0713/015650.446442:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.tuer123.com/, 783, 7fac03bc8881
[1:1:0713/015650.456225:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"16da934a2860","ptid":"778 0x7fac01283070 0x37d6db600160 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015650.456426:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.tuer123.com/","ptid":"778 0x7fac01283070 0x37d6db600160 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015650.456658:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015650.456967:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.tuer123.com/, 16da934a2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/015650.457099:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.tuer123.com/gushi/tegs/8773.html", "www.tuer123.com", 3, 1, , , 0
[1:1:0713/015650.457452:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x35e9535229c8, 0x37d6db14e950
[1:1:0713/015650.457561:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.tuer123.com/gushi/tegs/8773.html", 100
[1:1:0713/015650.457752:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.tuer123.com/, 785
[1:1:0713/015650.457875:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 785 0x7fac01283070 0x37d6daee9560 , 5:3_http://www.tuer123.com/, 1, -5:3_http://www.tuer123.com/, 783 0x7fac01283070 0x37d6db5bfa60 
[1:1:0713/015650.568271:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.tuer123.com/, 785, 7fac03bc8881
[1:1:0713/015650.578242:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"16da934a2860","ptid":"783 0x7fac01283070 0x37d6db5bfa60 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015650.578438:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.tuer123.com/","ptid":"783 0x7fac01283070 0x37d6db5bfa60 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015650.578669:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015650.579031:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.tuer123.com/, 16da934a2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/015650.579185:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.tuer123.com/gushi/tegs/8773.html", "www.tuer123.com", 3, 1, , , 0
[1:1:0713/015650.579505:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x35e9535229c8, 0x37d6db14e950
[1:1:0713/015650.579613:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.tuer123.com/gushi/tegs/8773.html", 100
[1:1:0713/015650.579797:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.tuer123.com/, 787
[1:1:0713/015650.579915:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 787 0x7fac01283070 0x37d6db5be0e0 , 5:3_http://www.tuer123.com/, 1, -5:3_http://www.tuer123.com/, 785 0x7fac01283070 0x37d6daee9560 
[1:1:0713/015650.690448:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.tuer123.com/, 787, 7fac03bc8881
[1:1:0713/015650.700318:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"16da934a2860","ptid":"785 0x7fac01283070 0x37d6daee9560 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015650.700529:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.tuer123.com/","ptid":"785 0x7fac01283070 0x37d6daee9560 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015650.700757:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015650.701087:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.tuer123.com/, 16da934a2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/015650.701240:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.tuer123.com/gushi/tegs/8773.html", "www.tuer123.com", 3, 1, , , 0
[1:1:0713/015650.701598:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x35e9535229c8, 0x37d6db14e950
[1:1:0713/015650.701744:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.tuer123.com/gushi/tegs/8773.html", 100
[1:1:0713/015650.701938:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.tuer123.com/, 789
[1:1:0713/015650.702058:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 789 0x7fac01283070 0x37d6e02aec60 , 5:3_http://www.tuer123.com/, 1, -5:3_http://www.tuer123.com/, 787 0x7fac01283070 0x37d6db5be0e0 
[1:1:0713/015650.812722:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.tuer123.com/, 789, 7fac03bc8881
[1:1:0713/015650.822942:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"16da934a2860","ptid":"787 0x7fac01283070 0x37d6db5be0e0 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015650.823139:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.tuer123.com/","ptid":"787 0x7fac01283070 0x37d6db5be0e0 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015650.823394:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015650.823726:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.tuer123.com/, 16da934a2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/015650.823880:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.tuer123.com/gushi/tegs/8773.html", "www.tuer123.com", 3, 1, , , 0
[1:1:0713/015650.824237:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x35e9535229c8, 0x37d6db14e950
[1:1:0713/015650.824348:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.tuer123.com/gushi/tegs/8773.html", 100
[1:1:0713/015650.824535:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.tuer123.com/, 791
[1:1:0713/015650.824657:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 791 0x7fac01283070 0x37d6e0eacf60 , 5:3_http://www.tuer123.com/, 1, -5:3_http://www.tuer123.com/, 789 0x7fac01283070 0x37d6e02aec60 
[1:1:0713/015650.935741:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.tuer123.com/, 791, 7fac03bc8881
[1:1:0713/015650.945874:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"16da934a2860","ptid":"789 0x7fac01283070 0x37d6e02aec60 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015650.946077:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.tuer123.com/","ptid":"789 0x7fac01283070 0x37d6e02aec60 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015650.946328:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015650.946652:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.tuer123.com/, 16da934a2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/015650.946792:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.tuer123.com/gushi/tegs/8773.html", "www.tuer123.com", 3, 1, , , 0
[1:1:0713/015650.947138:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x35e9535229c8, 0x37d6db14e950
[1:1:0713/015650.947235:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.tuer123.com/gushi/tegs/8773.html", 100
[1:1:0713/015650.947430:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.tuer123.com/, 794
[1:1:0713/015650.947541:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 794 0x7fac01283070 0x37d6db643460 , 5:3_http://www.tuer123.com/, 1, -5:3_http://www.tuer123.com/, 791 0x7fac01283070 0x37d6e0eacf60 
[1:1:0713/015651.058384:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.tuer123.com/, 794, 7fac03bc8881
[1:1:0713/015651.068317:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"16da934a2860","ptid":"791 0x7fac01283070 0x37d6e0eacf60 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015651.068510:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.tuer123.com/","ptid":"791 0x7fac01283070 0x37d6e0eacf60 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015651.068749:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015651.069088:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.tuer123.com/, 16da934a2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/015651.069230:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.tuer123.com/gushi/tegs/8773.html", "www.tuer123.com", 3, 1, , , 0
[1:1:0713/015651.069567:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x35e9535229c8, 0x37d6db14e950
[1:1:0713/015651.069700:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.tuer123.com/gushi/tegs/8773.html", 100
[1:1:0713/015651.069877:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.tuer123.com/, 796
[1:1:0713/015651.070023:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 796 0x7fac01283070 0x37d6e026c660 , 5:3_http://www.tuer123.com/, 1, -5:3_http://www.tuer123.com/, 794 0x7fac01283070 0x37d6db643460 
[1:1:0713/015651.180472:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.tuer123.com/, 796, 7fac03bc8881
[1:1:0713/015651.190352:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"16da934a2860","ptid":"794 0x7fac01283070 0x37d6db643460 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015651.190553:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.tuer123.com/","ptid":"794 0x7fac01283070 0x37d6db643460 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015651.190798:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015651.191125:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.tuer123.com/, 16da934a2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/015651.191279:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.tuer123.com/gushi/tegs/8773.html", "www.tuer123.com", 3, 1, , , 0
[1:1:0713/015651.191637:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x35e9535229c8, 0x37d6db14e950
[1:1:0713/015651.191736:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.tuer123.com/gushi/tegs/8773.html", 100
[1:1:0713/015651.191906:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.tuer123.com/, 798
[1:1:0713/015651.192026:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 798 0x7fac01283070 0x37d6e0dd6be0 , 5:3_http://www.tuer123.com/, 1, -5:3_http://www.tuer123.com/, 796 0x7fac01283070 0x37d6e026c660 
[1:1:0713/015651.302256:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.tuer123.com/, 798, 7fac03bc8881
[1:1:0713/015651.312245:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"16da934a2860","ptid":"796 0x7fac01283070 0x37d6e026c660 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015651.312443:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.tuer123.com/","ptid":"796 0x7fac01283070 0x37d6e026c660 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015651.312682:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015651.312993:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.tuer123.com/, 16da934a2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/015651.313157:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.tuer123.com/gushi/tegs/8773.html", "www.tuer123.com", 3, 1, , , 0
[1:1:0713/015651.313516:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x35e9535229c8, 0x37d6db14e950
[1:1:0713/015651.313627:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.tuer123.com/gushi/tegs/8773.html", 100
[1:1:0713/015651.313815:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.tuer123.com/, 801
[1:1:0713/015651.313934:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 801 0x7fac01283070 0x37d6db57e560 , 5:3_http://www.tuer123.com/, 1, -5:3_http://www.tuer123.com/, 798 0x7fac01283070 0x37d6e0dd6be0 
[1:1:0713/015651.424579:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.tuer123.com/, 801, 7fac03bc8881
[1:1:0713/015651.434576:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"16da934a2860","ptid":"798 0x7fac01283070 0x37d6e0dd6be0 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015651.434775:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.tuer123.com/","ptid":"798 0x7fac01283070 0x37d6e0dd6be0 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015651.435020:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015651.435372:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.tuer123.com/, 16da934a2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/015651.435525:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.tuer123.com/gushi/tegs/8773.html", "www.tuer123.com", 3, 1, , , 0
[1:1:0713/015651.435883:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x35e9535229c8, 0x37d6db14e950
[1:1:0713/015651.435994:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.tuer123.com/gushi/tegs/8773.html", 100
[1:1:0713/015651.436180:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.tuer123.com/, 803
[1:1:0713/015651.436300:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 803 0x7fac01283070 0x37d6db5bed60 , 5:3_http://www.tuer123.com/, 1, -5:3_http://www.tuer123.com/, 801 0x7fac01283070 0x37d6db57e560 
[1:1:0713/015651.546964:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.tuer123.com/, 803, 7fac03bc8881
[1:1:0713/015651.556906:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"16da934a2860","ptid":"801 0x7fac01283070 0x37d6db57e560 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015651.557091:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.tuer123.com/","ptid":"801 0x7fac01283070 0x37d6db57e560 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015651.557337:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015651.557660:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.tuer123.com/, 16da934a2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/015651.557813:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.tuer123.com/gushi/tegs/8773.html", "www.tuer123.com", 3, 1, , , 0
[1:1:0713/015651.558170:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x35e9535229c8, 0x37d6db14e950
[1:1:0713/015651.558280:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.tuer123.com/gushi/tegs/8773.html", 100
[1:1:0713/015651.558468:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.tuer123.com/, 805
[1:1:0713/015651.558587:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 805 0x7fac01283070 0x37d6e0b4e3e0 , 5:3_http://www.tuer123.com/, 1, -5:3_http://www.tuer123.com/, 803 0x7fac01283070 0x37d6db5bed60 
[1:1:0713/015651.669397:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.tuer123.com/, 805, 7fac03bc8881
[1:1:0713/015651.679744:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"16da934a2860","ptid":"803 0x7fac01283070 0x37d6db5bed60 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015651.679948:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.tuer123.com/","ptid":"803 0x7fac01283070 0x37d6db5bed60 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015651.680202:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015651.680538:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.tuer123.com/, 16da934a2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/015651.680683:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.tuer123.com/gushi/tegs/8773.html", "www.tuer123.com", 3, 1, , , 0
[1:1:0713/015651.681009:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x35e9535229c8, 0x37d6db14e950
[1:1:0713/015651.681194:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.tuer123.com/gushi/tegs/8773.html", 100
[1:1:0713/015651.681436:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.tuer123.com/, 807
[1:1:0713/015651.681610:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 807 0x7fac01283070 0x37d6e02b59e0 , 5:3_http://www.tuer123.com/, 1, -5:3_http://www.tuer123.com/, 805 0x7fac01283070 0x37d6e0b4e3e0 
[1:1:0713/015651.792107:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.tuer123.com/, 807, 7fac03bc8881
[1:1:0713/015651.802582:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"16da934a2860","ptid":"805 0x7fac01283070 0x37d6e0b4e3e0 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015651.802793:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.tuer123.com/","ptid":"805 0x7fac01283070 0x37d6e0b4e3e0 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015651.803051:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015651.803382:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.tuer123.com/, 16da934a2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/015651.803535:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.tuer123.com/gushi/tegs/8773.html", "www.tuer123.com", 3, 1, , , 0
[1:1:0713/015651.803854:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x35e9535229c8, 0x37d6db14e950
[1:1:0713/015651.803962:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.tuer123.com/gushi/tegs/8773.html", 100
[1:1:0713/015651.804148:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.tuer123.com/, 810
[1:1:0713/015651.804268:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 810 0x7fac01283070 0x37d6e0b4e760 , 5:3_http://www.tuer123.com/, 1, -5:3_http://www.tuer123.com/, 807 0x7fac01283070 0x37d6e02b59e0 
[1:1:0713/015651.915070:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.tuer123.com/, 810, 7fac03bc8881
[1:1:0713/015651.925340:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"16da934a2860","ptid":"807 0x7fac01283070 0x37d6e02b59e0 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015651.925551:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.tuer123.com/","ptid":"807 0x7fac01283070 0x37d6e02b59e0 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015651.925799:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015651.926142:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.tuer123.com/, 16da934a2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/015651.926295:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.tuer123.com/gushi/tegs/8773.html", "www.tuer123.com", 3, 1, , , 0
[1:1:0713/015651.926654:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x35e9535229c8, 0x37d6db14e950
[1:1:0713/015651.926765:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.tuer123.com/gushi/tegs/8773.html", 100
[1:1:0713/015651.926951:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.tuer123.com/, 812
[1:1:0713/015651.927072:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 812 0x7fac01283070 0x37d6e013c3e0 , 5:3_http://www.tuer123.com/, 1, -5:3_http://www.tuer123.com/, 810 0x7fac01283070 0x37d6e0b4e760 
[1:1:0713/015652.037850:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.tuer123.com/, 812, 7fac03bc8881
[1:1:0713/015652.047967:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"16da934a2860","ptid":"810 0x7fac01283070 0x37d6e0b4e760 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015652.048170:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.tuer123.com/","ptid":"810 0x7fac01283070 0x37d6e0b4e760 ","rf":"5:3_http://www.tuer123.com/"}
[1:1:0713/015652.048425:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.tuer123.com/gushi/tegs/8773.html"
[1:1:0713/015652.048741:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.tuer123.com/, 16da934a2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/015652.048869:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.tuer123.com/gushi/tegs/8773.html", "www.tuer123.com", 3, 1, , , 0
[1:1:0713/015652.049215:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x35e9535229c8, 0x37d6db14e950
[1:1:0713/015652.049360:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.tuer123.com/gushi/tegs/8773.html", 100
[1:1:0713/015652.049651:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.tuer123.com/, 814
[1:1:0713/015652.049775:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 814 0x7fac01283070 0x37d6e09bbbe0 , 5:3_http://www.tuer123.com/, 1, -5:3_http://www.tuer123.com/, 812 0x7fac01283070 0x37d6e013c3e0 
