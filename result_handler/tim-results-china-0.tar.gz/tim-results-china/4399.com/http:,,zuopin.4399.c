[0713/020123.862662:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/020123.862907:INFO:switcher_clone.cc(787)] backtrace rip is 7f61d2911891
[0713/020124.399242:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/020124.399488:INFO:switcher_clone.cc(787)] backtrace rip is 7f2aa9b60891
[1:1:0713/020124.403344:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0713/020124.403511:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0713/020124.406311:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[0713/020125.230654:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/020125.230934:INFO:switcher_clone.cc(787)] backtrace rip is 7f8576a48891
[14434:14434:0713/020125.300877:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/2dc7d2f3-7055-4be8-b40a-e67996c5f838
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[14465:14465:0713/020125.374621:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=14465
[14478:14478:0713/020125.376258:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=14478
[14434:14434:0713/020125.541867:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[14434:14463:0713/020125.542321:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0713/020125.542466:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0713/020125.542661:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0713/020125.542988:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0713/020125.543160:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0713/020125.544874:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x3c3fa649, 1
[1:1:0713/020125.545075:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x1a4e0fc0, 0
[1:1:0713/020125.545191:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0xf930c, 3
[1:1:0713/020125.545297:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x18f9523d, 2
[1:1:0713/020125.545403:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffc00f4e1a 49ffffffa63f3c 3d52fffffff918 0cffffff930f00 , 10104, 4
[1:1:0713/020125.546053:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[14434:14463:0713/020125.546200:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�NI�?<=R��
[14434:14463:0713/020125.546257:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �NI�?<=R��
[1:1:0713/020125.546188:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f2aa7d9a0a0, 3
[1:1:0713/020125.546299:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f2aa7f26080, 2
[14434:14463:0713/020125.546413:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0713/020125.546399:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f2a91be8d20, -2
[14434:14463:0713/020125.546449:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 14486, 4, c00f4e1a 49a63f3c 3d52f918 0c930f00 
[1:1:0713/020125.553751:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0713/020125.554172:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 18f9523d
[1:1:0713/020125.554605:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 18f9523d
[1:1:0713/020125.555323:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 18f9523d
[1:1:0713/020125.555845:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 18f9523d
[1:1:0713/020125.555948:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 18f9523d
[1:1:0713/020125.556048:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 18f9523d
[1:1:0713/020125.556146:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 18f9523d
[1:1:0713/020125.556399:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 18f9523d
[1:1:0713/020125.556551:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f2aa9b607ba
[1:1:0713/020125.556633:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f2aa9b57def, 7f2aa9b6077a, 7f2aa9b620cf
[1:1:0713/020125.558223:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 18f9523d
[1:1:0713/020125.558412:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 18f9523d
[1:1:0713/020125.558749:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 18f9523d
[1:1:0713/020125.559485:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 18f9523d
[1:1:0713/020125.559604:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 18f9523d
[1:1:0713/020125.559726:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 18f9523d
[1:1:0713/020125.559834:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 18f9523d
[1:1:0713/020125.560373:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 18f9523d
[1:1:0713/020125.560526:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f2aa9b607ba
[1:1:0713/020125.560608:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f2aa9b57def, 7f2aa9b6077a, 7f2aa9b620cf
[1:1:0713/020125.563092:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0713/020125.563301:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0713/020125.563424:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffce36443a8, 0x7ffce3644328)
[1:1:0713/020125.572190:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0713/020125.574895:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[14434:14434:0713/020125.973121:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[14434:14434:0713/020125.973658:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[14434:14445:0713/020125.982132:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[14434:14445:0713/020125.982200:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[14434:14434:0713/020125.982218:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[14434:14434:0713/020125.982263:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[14434:14434:0713/020125.982335:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,14486, 4
[1:7:0713/020125.983530:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/020126.022745:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0xb0b43293220
[1:1:0713/020126.022923:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[14434:14457:0713/020126.062141:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0713/020126.243922:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0713/020126.970164:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/020126.971812:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[14434:14434:0713/020127.296951:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[14434:14434:0713/020127.297068:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0713/020127.459143:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/020127.565719:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0a08493a1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0713/020127.565950:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/020127.571865:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0a08493a1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0713/020127.572040:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/020127.603713:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/020127.603878:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/020127.754468:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 356, "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/020127.756959:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0a08493a1f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0713/020127.757128:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/020127.773456:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 357, "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/020127.776369:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0a08493a1f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0713/020127.776499:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/020127.780296:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[14434:14434:0713/020127.780918:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0713/020127.781951:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0xb0b43291e20
[14434:14434:0713/020127.783064:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[1:1:0713/020127.783010:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[14434:14434:0713/020127.798862:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[14434:14434:0713/020127.798941:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0713/020127.816912:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/020128.114174:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 417 0x7f2a937c32e0 0xb0b435039e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/020128.114840:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0a08493a1f78, , , var configData = {"googleBaseUrl":"https://www.google.com.hk/","isAccessibleBrowser":false,"isGoogle
[1:1:0713/020128.114987:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/020128.115633:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[14434:14434:0713/020128.141970:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0713/020128.143117:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0xb0b43292820
[1:1:0713/020128.143266:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[14434:14434:0713/020128.144346:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0713/020128.150582:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0713/020128.150719:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[14434:14434:0713/020128.153736:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[14434:14434:0713/020128.157946:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[14434:14434:0713/020128.158358:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[14434:14445:0713/020128.162834:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[14434:14445:0713/020128.162887:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[14434:14434:0713/020128.162911:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[14434:14434:0713/020128.162951:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[14434:14434:0713/020128.163011:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,14486, 4
[1:7:0713/020128.164528:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/020128.432435:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0713/020128.542709:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 464 0x7f2a937c32e0 0xb0b435c95e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/020128.543336:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0a08493a1f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0713/020128.543503:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/020128.543894:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[14434:14434:0713/020128.703882:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[14434:14434:0713/020128.703963:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0713/020128.715552:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[14434:14434:0713/020128.816321:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[14434:14463:0713/020128.816575:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0713/020128.816699:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0713/020128.816830:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0713/020128.817014:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0713/020128.817103:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0713/020128.819977:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x2eea3c9d, 1
[1:1:0713/020128.820213:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x1611aff4, 0
[1:1:0713/020128.820321:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0xeacbd88, 3
[1:1:0713/020128.820428:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x3b0d9e10, 2
[1:1:0713/020128.820522:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = fffffff4ffffffaf1116 ffffff9d3cffffffea2e 10ffffff9e0d3b ffffff88ffffffbdffffffac0e , 10104, 5
[1:1:0713/020128.821255:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[14434:14463:0713/020128.821402:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING���<�.�;����3
[14434:14463:0713/020128.821445:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ���<�.�;������3
[14434:14463:0713/020128.821580:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 14526, 5, f4af1116 9d3cea2e 109e0d3b 88bdac0e 
[1:1:0713/020128.821760:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f2aa7d9a0a0, 3
[1:1:0713/020128.821860:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f2aa7f26080, 2
[1:1:0713/020128.821937:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f2a91be8d20, -2
[1:1:0713/020128.831541:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0713/020128.831741:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3b0d9e10
[1:1:0713/020128.831895:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3b0d9e10
[1:1:0713/020128.832154:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3b0d9e10
[1:1:0713/020128.832668:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3b0d9e10
[1:1:0713/020128.832767:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3b0d9e10
[1:1:0713/020128.832859:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3b0d9e10
[1:1:0713/020128.832949:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3b0d9e10
[1:1:0713/020128.833213:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3b0d9e10
[1:1:0713/020128.833343:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f2aa9b607ba
[1:1:0713/020128.833416:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f2aa9b57def, 7f2aa9b6077a, 7f2aa9b620cf
[1:1:0713/020128.835063:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3b0d9e10
[1:1:0713/020128.835205:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3b0d9e10
[1:1:0713/020128.835502:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3b0d9e10
[1:1:0713/020128.836250:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3b0d9e10
[1:1:0713/020128.836363:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3b0d9e10
[1:1:0713/020128.836473:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3b0d9e10
[1:1:0713/020128.836575:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3b0d9e10
[1:1:0713/020128.837110:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3b0d9e10
[1:1:0713/020128.837284:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f2aa9b607ba
[1:1:0713/020128.837367:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f2aa9b57def, 7f2aa9b6077a, 7f2aa9b620cf
[1:1:0713/020128.839971:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0713/020128.840196:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0713/020128.840306:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffce36443a8, 0x7ffce3644328)
[1:1:0713/020128.846383:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0713/020128.847195:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/020128.848324:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0713/020128.933240:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0xb0b4326a220
[1:1:0713/020128.933414:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0713/020129.113392:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/020129.113616:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[14434:14434:0713/020129.205520:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[14434:14434:0713/020129.207368:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[14434:14445:0713/020129.228780:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[14434:14445:0713/020129.228842:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[14434:14434:0713/020129.228998:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://zuopin.4399.com/
[14434:14434:0713/020129.229049:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://zuopin.4399.com/, http://zuopin.4399.com/tyq/, 1
[14434:14434:0713/020129.229109:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://zuopin.4399.com/, HTTP/1.1 200 OK Server: nginx Date: Fri, 12 Jul 2019 18:01:29 GMT Content-Type: text/html Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding X-Powered-By: PHP/5.2.14 Content-Encoding: gzip  ,14526, 5
[1:7:0713/020129.231674:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/020129.241930:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://zuopin.4399.com/
[1:1:0713/020129.262674:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 537, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/020129.264516:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0a08494ce5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0713/020129.264742:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/020129.267265:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[14434:14434:0713/020129.299246:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://zuopin.4399.com/, http://zuopin.4399.com/, 1
[14434:14434:0713/020129.299307:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://zuopin.4399.com/, http://zuopin.4399.com
[1:1:0713/020129.307834:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/020129.348167:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/020129.382512:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/020129.382715:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://zuopin.4399.com/tyq/"
[1:1:0713/020129.386149:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/020129.386558:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0a08493a1f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0713/020129.386698:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/020129.509861:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/020129.558231:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 154 0x7f2a91c03bd0 0xb0b42e71b58 , "http://zuopin.4399.com/tyq/"
[1:1:0713/020129.560430:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zuopin.4399.com/, 0e64767e2860, , , uni_login_type_key = "loginType";
uni_login_username_key = "username";
uni_login_uid_key = "uid";
[1:1:0713/020129.560610:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zuopin.4399.com/tyq/", "zuopin.4399.com", 3, 1, , , 0
[1:1:0713/020129.562254:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/020129.583581:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 154 0x7f2a91c03bd0 0xb0b42e71b58 , "http://zuopin.4399.com/tyq/"
[1:1:0713/020129.642312:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0790322, 767, 1
[1:1:0713/020129.642467:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/020129.838516:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/020129.838668:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://zuopin.4399.com/tyq/"
[1:1:0713/020129.957670:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 212, "http://zuopin.4399.com/tyq/"
[1:1:0713/020129.958313:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zuopin.4399.com/, 0e64767e2860, , , var tj4399_aid = 107;var tj4399_109_resid = 107;document.write('<scr' + 'ipt src="//a.5054399.com/43
[1:1:0713/020129.958502:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zuopin.4399.com/tyq/", "zuopin.4399.com", 3, 1, , , 0
[1:1:0713/020130.261589:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 267, "http://zuopin.4399.com/tyq/"
[1:1:0713/020130.262406:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zuopin.4399.com/, 0e64767e2860, , , if(typeof(tj4399_aid) == "undefined") var tj4399_aid=0;if(typeof(tj4399_109_resid) == "undefined") v
[1:1:0713/020130.262601:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zuopin.4399.com/tyq/", "zuopin.4399.com", 3, 1, , , 0
[1:1:0713/020130.285419:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0151219, 379, 1
[1:1:0713/020130.285636:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/020130.331343:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/020130.331523:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://zuopin.4399.com/tyq/"
[1:1:0713/020130.332729:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 275 0x7f2a9189b070 0xb0b43499360 , "http://zuopin.4399.com/tyq/"
[1:1:0713/020130.333284:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zuopin.4399.com/, 0e64767e2860, , , var cyl_footer_str = '<a href="http://my.4399.com/joinus/index.html" rel="external nofollow" target=
[1:1:0713/020130.333415:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zuopin.4399.com/tyq/", "zuopin.4399.com", 3, 1, , , 0
[1:1:0713/020130.340893:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 275 0x7f2a9189b070 0xb0b43499360 , "http://zuopin.4399.com/tyq/"
		remove user.d_5fe12349 -> 0
[1:1:0713/020130.476778:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 281, "http://zuopin.4399.com/tyq/"
[1:1:0713/020130.478527:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zuopin.4399.com/, 0e64767e2860, , , (function(a){a.fn.udc_slider=function(b,c){if(a.isFunction(b)){c=b;b={}}else{c=c||function(){},b=b||
[1:1:0713/020130.478716:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zuopin.4399.com/tyq/", "zuopin.4399.com", 3, 1, , , 0
[1:1:0713/020130.480989:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 281, "http://zuopin.4399.com/tyq/"
[1:1:0713/020130.485887:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 281, "http://zuopin.4399.com/tyq/"
[1:1:0713/020130.520018:INFO:document.cc(5190)] >>> Document::setDomain. [old, new] = "zuopin.4399.com", "4399.com"
[1:1:0713/020130.566681:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 281, "http://zuopin.4399.com/tyq/"
[1:1:0713/020130.885470:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://zuopin.4399.com/tyq/"
[1:1:0713/020130.886454:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zuopin.4399.com/, 0e64767e2860, , r, (e,i){var u,f,l,c,h;try{if(r&&(i||a.readyState===4)){r=t,o&&(a.onreadystatechange=v.noop,Bn&&delete 
[1:1:0713/020130.886602:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zuopin.4399.com/tyq/", "4399.com", 3, 1, , , 0
[1:1:0713/020130.887222:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://zuopin.4399.com/tyq/"
[1:1:0713/020130.888532:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://zuopin.4399.com/tyq/"
[1:1:0713/020130.888997:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1ed21e790c58
[1:1:0713/020131.567525:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 426 0x7f2aa7f26080 0xb0b4322e6a0 1 0 0xb0b4322e6b8 , "http://zuopin.4399.com/tyq/"
[1:1:0713/020131.570252:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zuopin.4399.com/, 0e64767e2860, , , (function(){function p(){this.c="1257060591";this.ca="z";this.Y="";this.V="";this.X="";this.D="15629
[1:1:0713/020131.570409:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zuopin.4399.com/tyq/", "4399.com", 3, 1, , , 0
[1:1:0713/020132.003216:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 476, "http://zuopin.4399.com/tyq/"
[1:1:0713/020132.004561:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zuopin.4399.com/, 0e64767e2860, , , !function(){var p,q,r,a=function(){var b,c,d,e,a=document.getElementsByTagName("script");for(b=0,c=a
[1:1:0713/020132.004738:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zuopin.4399.com/tyq/", "4399.com", 3, 1, , , 0
[1:1:0713/020132.652379:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://zuopin.4399.com/tyq/"
[1:1:0713/020132.767783:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zuopin.4399.com/tyq/", 3000
[1:1:0713/020132.768122:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zuopin.4399.com/, 532
[1:1:0713/020132.768335:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 532 0x7f2a9189b070 0xb0b43db5e60 , 5:3_http://zuopin.4399.com/, 1, -5:3_http://zuopin.4399.com/, 476
[1:1:0713/020134.202843:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 606 0x7f2a937c32e0 0xb0b438afde0 , "http://zuopin.4399.com/tyq/"
[1:1:0713/020134.202943:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/020134.211794:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zuopin.4399.com/, 0e64767e2860, , , (function(){var h={},mt={},c={id:"c9ee39749a11515ded2eaf7997107cbe",dm:["zuopin.4399.com"],js:"tongj
[1:1:0713/020134.211974:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zuopin.4399.com/tyq/", "4399.com", 3, 1, , , 0
[1:1:0713/020134.224706:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x128a51d029c8, 0xb0b430e6188
[1:1:0713/020134.224898:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zuopin.4399.com/tyq/", 100
[1:1:0713/020134.225110:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 656
[1:1:0713/020134.225248:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 656 0x7f2a9189b070 0xb0b43de8e60 , 5:3_http://zuopin.4399.com/, 1, -5:3_http://zuopin.4399.com/, 606 0x7f2a937c32e0 0xb0b438afde0 
[14434:14434:0713/020150.229757:INFO:CONSOLE(1)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://a.5054399.com/4399_js/201701/res_109.js, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://a.5054399.com/4399_js/201701/107.js (1)
[14434:14434:0713/020150.230640:INFO:CONSOLE(1)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://a.5054399.com/4399_js/201701/res_109.js, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://a.5054399.com/4399_js/201701/107.js (1)
[14434:14434:0713/020150.245144:INFO:CONSOLE(8)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://s11.cnzz.com/stat.php?id=1257060591, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://zuopin.4399.com/tyq/js/tj.js (8)
[14434:14434:0713/020150.245973:INFO:CONSOLE(8)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://s11.cnzz.com/stat.php?id=1257060591, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://zuopin.4399.com/tyq/js/tj.js (8)
[14434:14434:0713/020150.265828:INFO:CONSOLE(17)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://c.cnzz.com/core.php?web_id=1257060591&t=z, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://s11.cnzz.com/stat.php?id=1257060591 (17)
[14434:14434:0713/020150.266841:INFO:CONSOLE(17)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://c.cnzz.com/core.php?web_id=1257060591&t=z, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://s11.cnzz.com/stat.php?id=1257060591 (17)
[3:3:0713/020150.311909:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0713/020151.054103:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zuopin.4399.com/, 0e64767e2860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0713/020151.054298:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zuopin.4399.com/tyq/", "4399.com", 3, 1, , , 0
[14434:14445:0713/020151.193333:ERROR:ssl_client_socket_impl.cc(1046)] handshake failed; returned -1, SSL error code 1, net_error -101
[1:1:0713/020151.665300:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 656, 7f2a941e0881
[1:1:0713/020151.677772:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e64767e2860","ptid":"606 0x7f2a937c32e0 0xb0b438afde0 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020151.677964:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zuopin.4399.com/","ptid":"606 0x7f2a937c32e0 0xb0b438afde0 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020151.678225:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zuopin.4399.com/tyq/"
[1:1:0713/020151.678552:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zuopin.4399.com/, 0e64767e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/020151.678682:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zuopin.4399.com/tyq/", "4399.com", 3, 1, , , 0
[1:1:0713/020151.679108:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x128a51d029c8, 0xb0b430e6150
[1:1:0713/020151.679231:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zuopin.4399.com/tyq/", 100
[1:1:0713/020151.679415:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 780
[1:1:0713/020151.679539:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 780 0x7f2a9189b070 0xb0b43700c60 , 5:3_http://zuopin.4399.com/, 1, -5:3_http://zuopin.4399.com/, 656 0x7f2a9189b070 0xb0b43de8e60 
[1:1:0713/020151.680031:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zuopin.4399.com/, 532, 7f2a941e08db
[1:1:0713/020151.692099:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e64767e2860","ptid":"476","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020151.692286:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zuopin.4399.com/","ptid":"476","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020151.692575:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zuopin.4399.com/, 781
[1:1:0713/020151.692695:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 781 0x7f2a9189b070 0xb0b4336c160 , 5:3_http://zuopin.4399.com/, 0, , 532 0x7f2a9189b070 0xb0b43db5e60 
[1:1:0713/020151.692866:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zuopin.4399.com/tyq/"
[1:1:0713/020151.693200:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zuopin.4399.com/, 0e64767e2860, , next, (i){if(!l.is(":animated")&&!k.is(":animated")){if(d.rollType<4){t();if(!w.setIndex("next")){return f
[1:1:0713/020151.693316:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zuopin.4399.com/tyq/", "4399.com", 3, 1, , , 0
[1:1:0713/020151.732896:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x128a51d029c8, 0xb0b430e6150
[1:1:0713/020151.733123:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zuopin.4399.com/tyq/", 0
[1:1:0713/020151.733371:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 783
[1:1:0713/020151.733564:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 783 0x7f2a9189b070 0xb0b438c1d60 , 5:3_http://zuopin.4399.com/, 1, -5:3_http://zuopin.4399.com/, 532 0x7f2a9189b070 0xb0b43db5e60 
[1:1:0713/020151.749548:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zuopin.4399.com/tyq/", 13
[1:1:0713/020151.749778:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zuopin.4399.com/, 784
[1:1:0713/020151.749900:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 784 0x7f2a9189b070 0xb0b43dbb2e0 , 5:3_http://zuopin.4399.com/, 1, -5:3_http://zuopin.4399.com/, 532 0x7f2a9189b070 0xb0b43db5e60 
[1:1:0713/020152.398764:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "http://zuopin.4399.com/tyq/"
[1:1:0713/020152.399240:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zuopin.4399.com/, 0e64767e2860, , a.(anonymous function).e.(anonymous function).onload.e.(anonymous function).onerror.e.(anonymous function).onabort, (){try{this.onload=this.onerror=this.onabort=null,e[this.ka]=null}catch(f){}}
[1:1:0713/020152.399387:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zuopin.4399.com/tyq/", "4399.com", 3, 1, , , 0
[1:1:0713/020152.413334:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zuopin.4399.com/, 0e64767e2860, , , document.readyState
[1:1:0713/020152.413486:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zuopin.4399.com/tyq/", "4399.com", 3, 1, , , 0
[1:1:0713/020152.915676:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 783, 7f2a941e0881
[1:1:0713/020152.931549:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e64767e2860","ptid":"532 0x7f2a9189b070 0xb0b43db5e60 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020152.931765:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zuopin.4399.com/","ptid":"532 0x7f2a9189b070 0xb0b43db5e60 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020152.932022:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zuopin.4399.com/tyq/"
[1:1:0713/020152.932362:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zuopin.4399.com/, 0e64767e2860, , , (){qn=t}
[1:1:0713/020152.932489:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zuopin.4399.com/tyq/", "4399.com", 3, 1, , , 0
[1:1:0713/020152.947826:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://zuopin.4399.com/tyq/"
[1:1:0713/020152.948391:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zuopin.4399.com/, 0e64767e2860, , f.onload, (){f.onload=u;f=window[d]=u;a&&a(b)}
[1:1:0713/020152.948516:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zuopin.4399.com/tyq/", "4399.com", 3, 1, , , 0
[1:1:0713/020152.952138:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zuopin.4399.com/, 784, 7f2a941e08db
[1:1:0713/020152.967045:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e64767e2860","ptid":"532 0x7f2a9189b070 0xb0b43db5e60 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020152.967240:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zuopin.4399.com/","ptid":"532 0x7f2a9189b070 0xb0b43db5e60 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020152.967511:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zuopin.4399.com/, 837
[1:1:0713/020152.967647:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 837 0x7f2a9189b070 0xb0b436efe60 , 5:3_http://zuopin.4399.com/, 0, , 784 0x7f2a9189b070 0xb0b43dbb2e0 
[1:1:0713/020152.967815:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zuopin.4399.com/tyq/"
[1:1:0713/020152.968095:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zuopin.4399.com/, 0e64767e2860, , v.fx.tick, (){var e,n=v.timers,r=0;qn=v.now();for(;r<n.length;r++)e=n[r],!e()&&n[r]===e&&n.splice(r--,1);n.leng
[1:1:0713/020152.968194:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zuopin.4399.com/tyq/", "4399.com", 3, 1, , , 0
[1:1:0713/020153.000886:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 780, 7f2a941e0881
[1:1:0713/020153.014954:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e64767e2860","ptid":"656 0x7f2a9189b070 0xb0b43de8e60 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020153.015186:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zuopin.4399.com/","ptid":"656 0x7f2a9189b070 0xb0b43de8e60 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020153.015435:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zuopin.4399.com/tyq/"
[1:1:0713/020153.015766:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zuopin.4399.com/, 0e64767e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/020153.015888:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zuopin.4399.com/tyq/", "4399.com", 3, 1, , , 0
[1:1:0713/020153.016200:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x128a51d029c8, 0xb0b430e6150
[1:1:0713/020153.016289:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zuopin.4399.com/tyq/", 100
[1:1:0713/020153.016463:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 838
[1:1:0713/020153.016566:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 838 0x7f2a9189b070 0xb0b42c407e0 , 5:3_http://zuopin.4399.com/, 1, -5:3_http://zuopin.4399.com/, 780 0x7f2a9189b070 0xb0b43700c60 
[1:1:0713/020153.253093:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zuopin.4399.com/, 0e64767e2860, , , document.readyState
[1:1:0713/020153.253273:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zuopin.4399.com/tyq/", "4399.com", 3, 1, , , 0
[1:1:0713/020153.548589:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "http://zuopin.4399.com/tyq/"
[1:1:0713/020153.549058:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zuopin.4399.com/, 0e64767e2860, , u, (e){return typeof v=="undefined"||!!e&&v.event.triggered===e.type?t:v.event.dispatch.apply(u.elem,ar
[1:1:0713/020153.549240:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zuopin.4399.com/tyq/", "4399.com", 3, 1, , , 0
[1:1:0713/020153.559720:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 400, 0x128a51d029c8, 0xb0b430e6220
[1:1:0713/020153.559875:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zuopin.4399.com/tyq/", 400
[1:1:0713/020153.560071:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 849
[1:1:0713/020153.560200:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 849 0x7f2a9189b070 0xb0b437ece60 , 5:3_http://zuopin.4399.com/, 1, -5:3_http://zuopin.4399.com/, 823 0x7f2aa0bac960 0xb0b44323b00 0xb0b44323b10 
[1:1:0713/020153.822191:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 838, 7f2a941e0881
[1:1:0713/020153.836025:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e64767e2860","ptid":"780 0x7f2a9189b070 0xb0b43700c60 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020153.836203:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zuopin.4399.com/","ptid":"780 0x7f2a9189b070 0xb0b43700c60 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020153.836403:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zuopin.4399.com/tyq/"
[1:1:0713/020153.836711:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zuopin.4399.com/, 0e64767e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/020153.836811:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zuopin.4399.com/tyq/", "4399.com", 3, 1, , , 0
[1:1:0713/020153.837147:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x128a51d029c8, 0xb0b430e6150
[1:1:0713/020153.837217:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zuopin.4399.com/tyq/", 100
[1:1:0713/020153.837405:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 860
[1:1:0713/020153.837512:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 860 0x7f2a9189b070 0xb0b438a6160 , 5:3_http://zuopin.4399.com/, 1, -5:3_http://zuopin.4399.com/, 838 0x7f2a9189b070 0xb0b42c407e0 
[1:1:0713/020153.881882:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://zuopin.4399.com/tyq/"
[1:1:0713/020153.882314:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zuopin.4399.com/, 0e64767e2860, , ready, (e){if(e===!0?--v.readyWait:v.isReady)return;if(!i.body)return setTimeout(v.ready,1);v.isReady=!0;if
[1:1:0713/020153.882472:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zuopin.4399.com/tyq/", "4399.com", 3, 1, , , 0
[1:1:0713/020153.882694:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://zuopin.4399.com/tyq/"
[1:1:0713/020153.883746:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "pageshow", "http://zuopin.4399.com/tyq/"
[1:1:0713/020153.884426:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x128a51d029c8, 0xb0b430e62f0
[1:1:0713/020153.884528:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zuopin.4399.com/tyq/", 100
[1:1:0713/020153.884692:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 861
[1:1:0713/020153.884793:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 861 0x7f2a9189b070 0xb0b43a00f60 , 5:3_http://zuopin.4399.com/, 1, -5:3_http://zuopin.4399.com/, 842 0x7f2a9189b070 0xb0b434c90e0 
[1:1:0713/020153.935615:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zuopin.4399.com/, 0e64767e2860, , , document.readyState
[1:1:0713/020153.935798:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zuopin.4399.com/tyq/", "4399.com", 3, 1, , , 0
[1:1:0713/020154.086283:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zuopin.4399.com/, 781, 7f2a941e08db
[1:1:0713/020154.097426:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"532 0x7f2a9189b070 0xb0b43db5e60 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020154.097586:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"532 0x7f2a9189b070 0xb0b43db5e60 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020154.097792:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zuopin.4399.com/, 872
[1:1:0713/020154.097914:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 872 0x7f2a9189b070 0xb0b43333e60 , 5:3_http://zuopin.4399.com/, 0, , 781 0x7f2a9189b070 0xb0b4336c160 
[1:1:0713/020154.098051:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zuopin.4399.com/tyq/"
[1:1:0713/020154.098355:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zuopin.4399.com/, 0e64767e2860, , next, (i){if(!l.is(":animated")&&!k.is(":animated")){if(d.rollType<4){t();if(!w.setIndex("next")){return f
[1:1:0713/020154.098470:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zuopin.4399.com/tyq/", "4399.com", 3, 1, , , 0
[1:1:0713/020154.122445:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x128a51d029c8, 0xb0b430e6150
[1:1:0713/020154.122583:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zuopin.4399.com/tyq/", 0
[1:1:0713/020154.122757:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 875
[1:1:0713/020154.122878:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 875 0x7f2a9189b070 0xb0b43de8060 , 5:3_http://zuopin.4399.com/, 1, -5:3_http://zuopin.4399.com/, 781 0x7f2a9189b070 0xb0b4336c160 
[1:1:0713/020154.132434:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zuopin.4399.com/tyq/", 13
[1:1:0713/020154.132646:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zuopin.4399.com/, 876
[1:1:0713/020154.132759:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 876 0x7f2a9189b070 0xb0b438f15e0 , 5:3_http://zuopin.4399.com/, 1, -5:3_http://zuopin.4399.com/, 781 0x7f2a9189b070 0xb0b4336c160 
[1:1:0713/020154.223137:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 849, 7f2a941e0881
[1:1:0713/020154.234862:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e64767e2860","ptid":"823 0x7f2aa0bac960 0xb0b44323b00 0xb0b44323b10 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020154.235027:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zuopin.4399.com/","ptid":"823 0x7f2aa0bac960 0xb0b44323b00 0xb0b44323b10 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020154.235218:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zuopin.4399.com/tyq/"
[1:1:0713/020154.235472:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zuopin.4399.com/, 0e64767e2860, , , (){
		   iswide();
		}
[1:1:0713/020154.235586:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zuopin.4399.com/tyq/", "4399.com", 3, 1, , , 0
[1:1:0713/020154.257147:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 400, 0x128a51d029c8, 0xb0b430e6150
[1:1:0713/020154.257303:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zuopin.4399.com/tyq/", 400
[1:1:0713/020154.257485:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 887
[1:1:0713/020154.257604:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 887 0x7f2a9189b070 0xb0b42dd0860 , 5:3_http://zuopin.4399.com/, 1, -5:3_http://zuopin.4399.com/, 849 0x7f2a9189b070 0xb0b437ece60 
[1:1:0713/020154.271848:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 861, 7f2a941e0881
[1:1:0713/020154.284317:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e64767e2860","ptid":"842 0x7f2a9189b070 0xb0b434c90e0 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020154.284462:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zuopin.4399.com/","ptid":"842 0x7f2a9189b070 0xb0b434c90e0 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020154.284647:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zuopin.4399.com/tyq/"
[1:1:0713/020154.284880:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zuopin.4399.com/, 0e64767e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/020154.284971:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zuopin.4399.com/tyq/", "4399.com", 3, 1, , , 0
[1:1:0713/020154.285260:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x128a51d029c8, 0xb0b430e6150
[1:1:0713/020154.285363:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zuopin.4399.com/tyq/", 100
[1:1:0713/020154.285534:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 888
[1:1:0713/020154.285648:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 888 0x7f2a9189b070 0xb0b43e58ae0 , 5:3_http://zuopin.4399.com/, 1, -5:3_http://zuopin.4399.com/, 861 0x7f2a9189b070 0xb0b43a00f60 
[1:1:0713/020154.374314:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 875, 7f2a941e0881
[1:1:0713/020154.388875:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e64767e2860","ptid":"781 0x7f2a9189b070 0xb0b4336c160 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020154.389107:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zuopin.4399.com/","ptid":"781 0x7f2a9189b070 0xb0b4336c160 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020154.389318:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zuopin.4399.com/tyq/"
[1:1:0713/020154.389594:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zuopin.4399.com/, 0e64767e2860, , , (){qn=t}
[1:1:0713/020154.389707:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zuopin.4399.com/tyq/", "4399.com", 3, 1, , , 0
[1:1:0713/020154.429896:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zuopin.4399.com/, 876, 7f2a941e08db
[1:1:0713/020154.443650:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e64767e2860","ptid":"781 0x7f2a9189b070 0xb0b4336c160 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020154.443817:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zuopin.4399.com/","ptid":"781 0x7f2a9189b070 0xb0b4336c160 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020154.444030:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zuopin.4399.com/, 897
[1:1:0713/020154.444140:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 897 0x7f2a9189b070 0xb0b43db5260 , 5:3_http://zuopin.4399.com/, 0, , 876 0x7f2a9189b070 0xb0b438f15e0 
[1:1:0713/020154.444285:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zuopin.4399.com/tyq/"
[1:1:0713/020154.444570:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zuopin.4399.com/, 0e64767e2860, , v.fx.tick, (){var e,n=v.timers,r=0;qn=v.now();for(;r<n.length;r++)e=n[r],!e()&&n[r]===e&&n.splice(r--,1);n.leng
[1:1:0713/020154.444665:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zuopin.4399.com/tyq/", "4399.com", 3, 1, , , 0
[1:1:0713/020154.571815:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 888, 7f2a941e0881
[1:1:0713/020154.585206:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e64767e2860","ptid":"861 0x7f2a9189b070 0xb0b43a00f60 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020154.585360:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zuopin.4399.com/","ptid":"861 0x7f2a9189b070 0xb0b43a00f60 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020154.585552:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zuopin.4399.com/tyq/"
[1:1:0713/020154.585831:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zuopin.4399.com/, 0e64767e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/020154.585941:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zuopin.4399.com/tyq/", "4399.com", 3, 1, , , 0
[1:1:0713/020154.586252:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x128a51d029c8, 0xb0b430e6150
[1:1:0713/020154.586351:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zuopin.4399.com/tyq/", 100
[1:1:0713/020154.586508:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 907
[1:1:0713/020154.586635:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 907 0x7f2a9189b070 0xb0b43e5ee60 , 5:3_http://zuopin.4399.com/, 1, -5:3_http://zuopin.4399.com/, 888 0x7f2a9189b070 0xb0b43e58ae0 
[1:1:0713/020154.612599:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zuopin.4399.com/, 897, 7f2a941e08db
[1:1:0713/020154.624490:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"876 0x7f2a9189b070 0xb0b438f15e0 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020154.624645:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"876 0x7f2a9189b070 0xb0b438f15e0 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020154.624865:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zuopin.4399.com/, 908
[1:1:0713/020154.624961:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 908 0x7f2a9189b070 0xb0b434cfa60 , 5:3_http://zuopin.4399.com/, 0, , 897 0x7f2a9189b070 0xb0b43db5260 
[1:1:0713/020154.625115:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zuopin.4399.com/tyq/"
[1:1:0713/020154.625368:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zuopin.4399.com/, 0e64767e2860, , v.fx.tick, (){var e,n=v.timers,r=0;qn=v.now();for(;r<n.length;r++)e=n[r],!e()&&n[r]===e&&n.splice(r--,1);n.leng
[1:1:0713/020154.625471:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zuopin.4399.com/tyq/", "4399.com", 3, 1, , , 0
[1:1:0713/020154.859534:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 887, 7f2a941e0881
[1:1:0713/020154.875708:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e64767e2860","ptid":"849 0x7f2a9189b070 0xb0b437ece60 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020154.875921:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zuopin.4399.com/","ptid":"849 0x7f2a9189b070 0xb0b437ece60 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020154.876172:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zuopin.4399.com/tyq/"
[1:1:0713/020154.876496:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zuopin.4399.com/, 0e64767e2860, , , (){
		   iswide();
		}
[1:1:0713/020154.876629:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zuopin.4399.com/tyq/", "4399.com", 3, 1, , , 0
[1:1:0713/020154.892444:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 400, 0x128a51d029c8, 0xb0b430e6150
[1:1:0713/020154.892606:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zuopin.4399.com/tyq/", 400
[1:1:0713/020154.892792:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 921
[1:1:0713/020154.892900:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 921 0x7f2a9189b070 0xb0b4336dc60 , 5:3_http://zuopin.4399.com/, 1, -5:3_http://zuopin.4399.com/, 887 0x7f2a9189b070 0xb0b42dd0860 
[1:1:0713/020154.909299:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 907, 7f2a941e0881
[1:1:0713/020154.922851:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e64767e2860","ptid":"888 0x7f2a9189b070 0xb0b43e58ae0 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020154.922989:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zuopin.4399.com/","ptid":"888 0x7f2a9189b070 0xb0b43e58ae0 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020154.923168:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zuopin.4399.com/tyq/"
[1:1:0713/020154.923422:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zuopin.4399.com/, 0e64767e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/020154.923523:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zuopin.4399.com/tyq/", "4399.com", 3, 1, , , 0
[1:1:0713/020154.923805:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x128a51d029c8, 0xb0b430e6150
[1:1:0713/020154.923900:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zuopin.4399.com/tyq/", 100
[1:1:0713/020154.924102:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 922
[1:1:0713/020154.924198:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 922 0x7f2a9189b070 0xb0b43472e60 , 5:3_http://zuopin.4399.com/, 1, -5:3_http://zuopin.4399.com/, 907 0x7f2a9189b070 0xb0b43e5ee60 
[1:1:0713/020155.048530:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 922, 7f2a941e0881
[1:1:0713/020155.060410:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e64767e2860","ptid":"907 0x7f2a9189b070 0xb0b43e5ee60 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020155.060572:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zuopin.4399.com/","ptid":"907 0x7f2a9189b070 0xb0b43e5ee60 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020155.060750:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zuopin.4399.com/tyq/"
[1:1:0713/020155.061558:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zuopin.4399.com/, 0e64767e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/020155.061677:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zuopin.4399.com/tyq/", "4399.com", 3, 1, , , 0
[1:1:0713/020155.062827:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x128a51d029c8, 0xb0b430e6150
[1:1:0713/020155.062936:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zuopin.4399.com/tyq/", 100
[1:1:0713/020155.063162:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 929
[1:1:0713/020155.063280:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 929 0x7f2a9189b070 0xb0b438a7660 , 5:3_http://zuopin.4399.com/, 1, -5:3_http://zuopin.4399.com/, 922 0x7f2a9189b070 0xb0b43472e60 
[1:1:0713/020155.175765:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 929, 7f2a941e0881
[1:1:0713/020155.187719:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e64767e2860","ptid":"922 0x7f2a9189b070 0xb0b43472e60 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020155.187901:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zuopin.4399.com/","ptid":"922 0x7f2a9189b070 0xb0b43472e60 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020155.188115:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zuopin.4399.com/tyq/"
[1:1:0713/020155.188405:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zuopin.4399.com/, 0e64767e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/020155.188508:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zuopin.4399.com/tyq/", "4399.com", 3, 1, , , 0
[1:1:0713/020155.188809:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x128a51d029c8, 0xb0b430e6150
[1:1:0713/020155.188895:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zuopin.4399.com/tyq/", 100
[1:1:0713/020155.189043:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 937
[1:1:0713/020155.189155:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 937 0x7f2a9189b070 0xb0b438a4f60 , 5:3_http://zuopin.4399.com/, 1, -5:3_http://zuopin.4399.com/, 929 0x7f2a9189b070 0xb0b438a7660 
[1:1:0713/020155.302651:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 937, 7f2a941e0881
[1:1:0713/020155.314272:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e64767e2860","ptid":"929 0x7f2a9189b070 0xb0b438a7660 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020155.314459:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zuopin.4399.com/","ptid":"929 0x7f2a9189b070 0xb0b438a7660 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020155.314685:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zuopin.4399.com/tyq/"
[1:1:0713/020155.315009:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zuopin.4399.com/, 0e64767e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/020155.315146:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zuopin.4399.com/tyq/", "4399.com", 3, 1, , , 0
[1:1:0713/020155.315470:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x128a51d029c8, 0xb0b430e6150
[1:1:0713/020155.315565:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zuopin.4399.com/tyq/", 100
[1:1:0713/020155.315715:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 940
[1:1:0713/020155.315799:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 940 0x7f2a9189b070 0xb0b435618e0 , 5:3_http://zuopin.4399.com/, 1, -5:3_http://zuopin.4399.com/, 937 0x7f2a9189b070 0xb0b438a4f60 
[1:1:0713/020155.316191:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 921, 7f2a941e0881
[1:1:0713/020155.327963:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e64767e2860","ptid":"887 0x7f2a9189b070 0xb0b42dd0860 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020155.328100:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zuopin.4399.com/","ptid":"887 0x7f2a9189b070 0xb0b42dd0860 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020155.328273:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zuopin.4399.com/tyq/"
[1:1:0713/020155.328489:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zuopin.4399.com/, 0e64767e2860, , , (){
		   iswide();
		}
[1:1:0713/020155.328559:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zuopin.4399.com/tyq/", "4399.com", 3, 1, , , 0
[1:1:0713/020155.341794:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 400, 0x128a51d029c8, 0xb0b430e6150
[1:1:0713/020155.341921:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zuopin.4399.com/tyq/", 400
[1:1:0713/020155.342091:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 941
[1:1:0713/020155.342207:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 941 0x7f2a9189b070 0xb0b43333b60 , 5:3_http://zuopin.4399.com/, 1, -5:3_http://zuopin.4399.com/, 921 0x7f2a9189b070 0xb0b4336dc60 
[1:1:0713/020155.429414:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 940, 7f2a941e0881
[1:1:0713/020155.440916:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e64767e2860","ptid":"937 0x7f2a9189b070 0xb0b438a4f60 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020155.441077:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zuopin.4399.com/","ptid":"937 0x7f2a9189b070 0xb0b438a4f60 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020155.441312:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zuopin.4399.com/tyq/"
[1:1:0713/020155.441647:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zuopin.4399.com/, 0e64767e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/020155.441805:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zuopin.4399.com/tyq/", "4399.com", 3, 1, , , 0
[1:1:0713/020155.442176:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x128a51d029c8, 0xb0b430e6150
[1:1:0713/020155.442273:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zuopin.4399.com/tyq/", 100
[1:1:0713/020155.442438:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 943
[1:1:0713/020155.442544:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 943 0x7f2a9189b070 0xb0b43db59e0 , 5:3_http://zuopin.4399.com/, 1, -5:3_http://zuopin.4399.com/, 940 0x7f2a9189b070 0xb0b435618e0 
[1:1:0713/020155.563766:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 943, 7f2a941e0881
[1:1:0713/020155.576141:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e64767e2860","ptid":"940 0x7f2a9189b070 0xb0b435618e0 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020155.576294:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zuopin.4399.com/","ptid":"940 0x7f2a9189b070 0xb0b435618e0 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020155.576489:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zuopin.4399.com/tyq/"
[1:1:0713/020155.576769:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zuopin.4399.com/, 0e64767e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/020155.576861:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zuopin.4399.com/tyq/", "4399.com", 3, 1, , , 0
[1:1:0713/020155.577160:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x128a51d029c8, 0xb0b430e6150
[1:1:0713/020155.577306:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zuopin.4399.com/tyq/", 100
[1:1:0713/020155.577483:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 945
[1:1:0713/020155.577603:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 945 0x7f2a9189b070 0xb0b438c06e0 , 5:3_http://zuopin.4399.com/, 1, -5:3_http://zuopin.4399.com/, 943 0x7f2a9189b070 0xb0b43db59e0 
[1:1:0713/020155.696171:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 945, 7f2a941e0881
[1:1:0713/020155.709506:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e64767e2860","ptid":"943 0x7f2a9189b070 0xb0b43db59e0 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020155.709702:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zuopin.4399.com/","ptid":"943 0x7f2a9189b070 0xb0b43db59e0 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020155.709939:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zuopin.4399.com/tyq/"
[1:1:0713/020155.710257:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zuopin.4399.com/, 0e64767e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/020155.710406:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zuopin.4399.com/tyq/", "4399.com", 3, 1, , , 0
[1:1:0713/020155.710786:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x128a51d029c8, 0xb0b430e6150
[1:1:0713/020155.710893:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zuopin.4399.com/tyq/", 100
[1:1:0713/020155.711072:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 947
[1:1:0713/020155.711187:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 947 0x7f2a9189b070 0xb0b434415e0 , 5:3_http://zuopin.4399.com/, 1, -5:3_http://zuopin.4399.com/, 945 0x7f2a9189b070 0xb0b438c06e0 
[1:1:0713/020155.756137:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 941, 7f2a941e0881
[1:1:0713/020155.768377:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e64767e2860","ptid":"921 0x7f2a9189b070 0xb0b4336dc60 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020155.768555:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zuopin.4399.com/","ptid":"921 0x7f2a9189b070 0xb0b4336dc60 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020155.768736:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zuopin.4399.com/tyq/"
[1:1:0713/020155.769009:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zuopin.4399.com/, 0e64767e2860, , , (){
		   iswide();
		}
[1:1:0713/020155.769135:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zuopin.4399.com/tyq/", "4399.com", 3, 1, , , 0
[1:1:0713/020155.782690:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 400, 0x128a51d029c8, 0xb0b430e6150
[1:1:0713/020155.782847:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zuopin.4399.com/tyq/", 400
[1:1:0713/020155.783063:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 949
[1:1:0713/020155.783216:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 949 0x7f2a9189b070 0xb0b43a00f60 , 5:3_http://zuopin.4399.com/, 1, -5:3_http://zuopin.4399.com/, 941 0x7f2a9189b070 0xb0b43333b60 
[1:1:0713/020155.825751:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 947, 7f2a941e0881
[1:1:0713/020155.839878:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e64767e2860","ptid":"945 0x7f2a9189b070 0xb0b438c06e0 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020155.840095:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zuopin.4399.com/","ptid":"945 0x7f2a9189b070 0xb0b438c06e0 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020155.840343:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zuopin.4399.com/tyq/"
[1:1:0713/020155.840654:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zuopin.4399.com/, 0e64767e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/020155.840753:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zuopin.4399.com/tyq/", "4399.com", 3, 1, , , 0
[1:1:0713/020155.841097:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x128a51d029c8, 0xb0b430e6150
[1:1:0713/020155.841240:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zuopin.4399.com/tyq/", 100
[1:1:0713/020155.841457:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 951
[1:1:0713/020155.841577:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 951 0x7f2a9189b070 0xb0b43e4bae0 , 5:3_http://zuopin.4399.com/, 1, -5:3_http://zuopin.4399.com/, 947 0x7f2a9189b070 0xb0b434415e0 
[1:1:0713/020155.956288:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 951, 7f2a941e0881
[1:1:0713/020155.968269:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e64767e2860","ptid":"947 0x7f2a9189b070 0xb0b434415e0 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020155.968446:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zuopin.4399.com/","ptid":"947 0x7f2a9189b070 0xb0b434415e0 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020155.968665:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zuopin.4399.com/tyq/"
[1:1:0713/020155.968981:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zuopin.4399.com/, 0e64767e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/020155.969111:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zuopin.4399.com/tyq/", "4399.com", 3, 1, , , 0
[1:1:0713/020155.969442:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x128a51d029c8, 0xb0b430e6150
[1:1:0713/020155.969549:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zuopin.4399.com/tyq/", 100
[1:1:0713/020155.969720:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 953
[1:1:0713/020155.969837:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 953 0x7f2a9189b070 0xb0b432f13e0 , 5:3_http://zuopin.4399.com/, 1, -5:3_http://zuopin.4399.com/, 951 0x7f2a9189b070 0xb0b43e4bae0 
[1:1:0713/020156.084071:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 953, 7f2a941e0881
[1:1:0713/020156.095956:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e64767e2860","ptid":"951 0x7f2a9189b070 0xb0b43e4bae0 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020156.096126:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zuopin.4399.com/","ptid":"951 0x7f2a9189b070 0xb0b43e4bae0 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020156.096342:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zuopin.4399.com/tyq/"
[1:1:0713/020156.096616:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zuopin.4399.com/, 0e64767e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/020156.096714:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zuopin.4399.com/tyq/", "4399.com", 3, 1, , , 0
[1:1:0713/020156.097004:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x128a51d029c8, 0xb0b430e6150
[1:1:0713/020156.097111:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zuopin.4399.com/tyq/", 100
[1:1:0713/020156.097272:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 956
[1:1:0713/020156.097393:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 956 0x7f2a9189b070 0xb0b438aa9e0 , 5:3_http://zuopin.4399.com/, 1, -5:3_http://zuopin.4399.com/, 953 0x7f2a9189b070 0xb0b432f13e0 
[1:1:0713/020156.196807:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 949, 7f2a941e0881
[1:1:0713/020156.208561:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e64767e2860","ptid":"941 0x7f2a9189b070 0xb0b43333b60 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020156.208707:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zuopin.4399.com/","ptid":"941 0x7f2a9189b070 0xb0b43333b60 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020156.208885:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zuopin.4399.com/tyq/"
[1:1:0713/020156.209172:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zuopin.4399.com/, 0e64767e2860, , , (){
		   iswide();
		}
[1:1:0713/020156.209287:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zuopin.4399.com/tyq/", "4399.com", 3, 1, , , 0
[1:1:0713/020156.222204:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 400, 0x128a51d029c8, 0xb0b430e6150
[1:1:0713/020156.222328:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zuopin.4399.com/tyq/", 400
[1:1:0713/020156.222500:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 959
[1:1:0713/020156.222615:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 959 0x7f2a9189b070 0xb0b43499260 , 5:3_http://zuopin.4399.com/, 1, -5:3_http://zuopin.4399.com/, 949 0x7f2a9189b070 0xb0b43a00f60 
[1:1:0713/020156.223394:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 956, 7f2a941e0881
[1:1:0713/020156.236327:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e64767e2860","ptid":"953 0x7f2a9189b070 0xb0b432f13e0 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020156.236479:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zuopin.4399.com/","ptid":"953 0x7f2a9189b070 0xb0b432f13e0 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020156.236667:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zuopin.4399.com/tyq/"
[1:1:0713/020156.236908:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zuopin.4399.com/, 0e64767e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/020156.236993:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zuopin.4399.com/tyq/", "4399.com", 3, 1, , , 0
[1:1:0713/020156.237301:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x128a51d029c8, 0xb0b430e6150
[1:1:0713/020156.237392:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zuopin.4399.com/tyq/", 100
[1:1:0713/020156.237565:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 961
[1:1:0713/020156.237781:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 961 0x7f2a9189b070 0xb0b43463ae0 , 5:3_http://zuopin.4399.com/, 1, -5:3_http://zuopin.4399.com/, 956 0x7f2a9189b070 0xb0b438aa9e0 
[1:1:0713/020156.351571:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 961, 7f2a941e0881
[1:1:0713/020156.363218:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e64767e2860","ptid":"956 0x7f2a9189b070 0xb0b438aa9e0 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020156.363409:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zuopin.4399.com/","ptid":"956 0x7f2a9189b070 0xb0b438aa9e0 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020156.363643:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zuopin.4399.com/tyq/"
[1:1:0713/020156.363996:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zuopin.4399.com/, 0e64767e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/020156.364135:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zuopin.4399.com/tyq/", "4399.com", 3, 1, , , 0
[1:1:0713/020156.364492:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x128a51d029c8, 0xb0b430e6150
[1:1:0713/020156.364632:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zuopin.4399.com/tyq/", 100
[1:1:0713/020156.364796:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 963
[1:1:0713/020156.364896:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 963 0x7f2a9189b070 0xb0b438aace0 , 5:3_http://zuopin.4399.com/, 1, -5:3_http://zuopin.4399.com/, 961 0x7f2a9189b070 0xb0b43463ae0 
[1:1:0713/020156.478839:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 963, 7f2a941e0881
[1:1:0713/020156.490743:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e64767e2860","ptid":"961 0x7f2a9189b070 0xb0b43463ae0 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020156.490926:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zuopin.4399.com/","ptid":"961 0x7f2a9189b070 0xb0b43463ae0 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020156.491190:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zuopin.4399.com/tyq/"
[1:1:0713/020156.491521:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zuopin.4399.com/, 0e64767e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/020156.491684:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zuopin.4399.com/tyq/", "4399.com", 3, 1, , , 0
[1:1:0713/020156.492020:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x128a51d029c8, 0xb0b430e6150
[1:1:0713/020156.492114:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zuopin.4399.com/tyq/", 100
[1:1:0713/020156.492274:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 965
[1:1:0713/020156.492377:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 965 0x7f2a9189b070 0xb0b43899460 , 5:3_http://zuopin.4399.com/, 1, -5:3_http://zuopin.4399.com/, 963 0x7f2a9189b070 0xb0b438aace0 
[1:1:0713/020156.606840:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 965, 7f2a941e0881
[1:1:0713/020156.618532:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e64767e2860","ptid":"963 0x7f2a9189b070 0xb0b438aace0 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020156.618717:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zuopin.4399.com/","ptid":"963 0x7f2a9189b070 0xb0b438aace0 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020156.618959:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zuopin.4399.com/tyq/"
[1:1:0713/020156.619293:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zuopin.4399.com/, 0e64767e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/020156.619443:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zuopin.4399.com/tyq/", "4399.com", 3, 1, , , 0
[1:1:0713/020156.619825:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x128a51d029c8, 0xb0b430e6150
[1:1:0713/020156.619933:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zuopin.4399.com/tyq/", 100
[1:1:0713/020156.620101:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 967
[1:1:0713/020156.620200:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 967 0x7f2a9189b070 0xb0b43278260 , 5:3_http://zuopin.4399.com/, 1, -5:3_http://zuopin.4399.com/, 965 0x7f2a9189b070 0xb0b43899460 
[1:1:0713/020156.635002:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 959, 7f2a941e0881
[1:1:0713/020156.646895:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e64767e2860","ptid":"949 0x7f2a9189b070 0xb0b43a00f60 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020156.647044:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zuopin.4399.com/","ptid":"949 0x7f2a9189b070 0xb0b43a00f60 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020156.647227:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zuopin.4399.com/tyq/"
[1:1:0713/020156.647505:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zuopin.4399.com/, 0e64767e2860, , , (){
		   iswide();
		}
[1:1:0713/020156.647617:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zuopin.4399.com/tyq/", "4399.com", 3, 1, , , 0
[1:1:0713/020156.660855:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 400, 0x128a51d029c8, 0xb0b430e6150
[1:1:0713/020156.660976:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zuopin.4399.com/tyq/", 400
[1:1:0713/020156.661143:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 969
[1:1:0713/020156.661264:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 969 0x7f2a9189b070 0xb0b43317d60 , 5:3_http://zuopin.4399.com/, 1, -5:3_http://zuopin.4399.com/, 959 0x7f2a9189b070 0xb0b43499260 
[1:1:0713/020156.737520:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 967, 7f2a941e0881
[1:1:0713/020156.752035:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e64767e2860","ptid":"965 0x7f2a9189b070 0xb0b43899460 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020156.752219:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zuopin.4399.com/","ptid":"965 0x7f2a9189b070 0xb0b43899460 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020156.752428:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zuopin.4399.com/tyq/"
[1:1:0713/020156.752745:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zuopin.4399.com/, 0e64767e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/020156.752836:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zuopin.4399.com/tyq/", "4399.com", 3, 1, , , 0
[1:1:0713/020156.753133:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x128a51d029c8, 0xb0b430e6150
[1:1:0713/020156.753284:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zuopin.4399.com/tyq/", 100
[1:1:0713/020156.753456:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 972
[1:1:0713/020156.753567:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 972 0x7f2a9189b070 0xb0b43db5560 , 5:3_http://zuopin.4399.com/, 1, -5:3_http://zuopin.4399.com/, 967 0x7f2a9189b070 0xb0b43278260 
[1:1:0713/020156.781906:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zuopin.4399.com/, 872, 7f2a941e08db
[1:1:0713/020156.794774:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"781 0x7f2a9189b070 0xb0b4336c160 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020156.794952:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"781 0x7f2a9189b070 0xb0b4336c160 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020156.795196:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zuopin.4399.com/, 974
[1:1:0713/020156.795352:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 974 0x7f2a9189b070 0xb0b43e6c6e0 , 5:3_http://zuopin.4399.com/, 0, , 872 0x7f2a9189b070 0xb0b43333e60 
[1:1:0713/020156.795542:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zuopin.4399.com/tyq/"
[1:1:0713/020156.795860:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zuopin.4399.com/, 0e64767e2860, , next, (i){if(!l.is(":animated")&&!k.is(":animated")){if(d.rollType<4){t();if(!w.setIndex("next")){return f
[1:1:0713/020156.795977:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zuopin.4399.com/tyq/", "4399.com", 3, 1, , , 0
[1:1:0713/020156.818844:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x128a51d029c8, 0xb0b430e6150
[1:1:0713/020156.818987:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zuopin.4399.com/tyq/", 0
[1:1:0713/020156.819146:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 977
[1:1:0713/020156.819249:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 977 0x7f2a9189b070 0xb0b43a73be0 , 5:3_http://zuopin.4399.com/, 1, -5:3_http://zuopin.4399.com/, 872 0x7f2a9189b070 0xb0b43333e60 
[1:1:0713/020156.829815:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zuopin.4399.com/tyq/", 13
[1:1:0713/020156.830022:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zuopin.4399.com/, 978
[1:1:0713/020156.830142:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 978 0x7f2a9189b070 0xb0b436febe0 , 5:3_http://zuopin.4399.com/, 1, -5:3_http://zuopin.4399.com/, 872 0x7f2a9189b070 0xb0b43333e60 
[1:1:0713/020156.925432:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 977, 7f2a941e0881
[1:1:0713/020156.939838:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e64767e2860","ptid":"872 0x7f2a9189b070 0xb0b43333e60 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020156.940016:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zuopin.4399.com/","ptid":"872 0x7f2a9189b070 0xb0b43333e60 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020156.940234:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zuopin.4399.com/tyq/"
[1:1:0713/020156.940543:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zuopin.4399.com/, 0e64767e2860, , , (){qn=t}
[1:1:0713/020156.940667:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zuopin.4399.com/tyq/", "4399.com", 3, 1, , , 0
[1:1:0713/020156.955209:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zuopin.4399.com/, 978, 7f2a941e08db
[1:1:0713/020156.968660:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e64767e2860","ptid":"872 0x7f2a9189b070 0xb0b43333e60 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020156.968810:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zuopin.4399.com/","ptid":"872 0x7f2a9189b070 0xb0b43333e60 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020156.969010:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zuopin.4399.com/, 985
[1:1:0713/020156.969160:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 985 0x7f2a9189b070 0xb0b44bb04e0 , 5:3_http://zuopin.4399.com/, 0, , 978 0x7f2a9189b070 0xb0b436febe0 
[1:1:0713/020156.969313:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zuopin.4399.com/tyq/"
[1:1:0713/020156.969572:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zuopin.4399.com/, 0e64767e2860, , v.fx.tick, (){var e,n=v.timers,r=0;qn=v.now();for(;r<n.length;r++)e=n[r],!e()&&n[r]===e&&n.splice(r--,1);n.leng
[1:1:0713/020156.969691:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zuopin.4399.com/tyq/", "4399.com", 3, 1, , , 0
[1:1:0713/020156.971094:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 972, 7f2a941e0881
[1:1:0713/020156.984952:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e64767e2860","ptid":"967 0x7f2a9189b070 0xb0b43278260 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020156.985125:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zuopin.4399.com/","ptid":"967 0x7f2a9189b070 0xb0b43278260 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020156.985286:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zuopin.4399.com/tyq/"
[1:1:0713/020156.985527:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zuopin.4399.com/, 0e64767e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/020156.985645:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zuopin.4399.com/tyq/", "4399.com", 3, 1, , , 0
[1:1:0713/020156.985944:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x128a51d029c8, 0xb0b430e6150
[1:1:0713/020156.986053:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zuopin.4399.com/tyq/", 100
[1:1:0713/020156.986226:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 986
[1:1:0713/020156.986348:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 986 0x7f2a9189b070 0xb0b437b8e60 , 5:3_http://zuopin.4399.com/, 1, -5:3_http://zuopin.4399.com/, 972 0x7f2a9189b070 0xb0b43db5560 
[1:1:0713/020156.986760:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zuopin.4399.com/, 985, 7f2a941e08db
[1:1:0713/020157.000070:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"978 0x7f2a9189b070 0xb0b436febe0 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020157.000206:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"978 0x7f2a9189b070 0xb0b436febe0 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020157.000417:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zuopin.4399.com/, 988
[1:1:0713/020157.000541:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 988 0x7f2a9189b070 0xb0b432a0960 , 5:3_http://zuopin.4399.com/, 0, , 985 0x7f2a9189b070 0xb0b44bb04e0 
[1:1:0713/020157.000670:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zuopin.4399.com/tyq/"
[1:1:0713/020157.000883:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zuopin.4399.com/, 0e64767e2860, , v.fx.tick, (){var e,n=v.timers,r=0;qn=v.now();for(;r<n.length;r++)e=n[r],!e()&&n[r]===e&&n.splice(r--,1);n.leng
[1:1:0713/020157.000976:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zuopin.4399.com/tyq/", "4399.com", 3, 1, , , 0
[1:1:0713/020157.025682:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zuopin.4399.com/, 988, 7f2a941e08db
[1:1:0713/020157.038872:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"985 0x7f2a9189b070 0xb0b44bb04e0 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020157.039052:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"985 0x7f2a9189b070 0xb0b44bb04e0 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020157.039301:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zuopin.4399.com/, 990
[1:1:0713/020157.039461:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 990 0x7f2a9189b070 0xb0b432cc3e0 , 5:3_http://zuopin.4399.com/, 0, , 988 0x7f2a9189b070 0xb0b432a0960 
[1:1:0713/020157.039638:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zuopin.4399.com/tyq/"
[1:1:0713/020157.039913:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zuopin.4399.com/, 0e64767e2860, , v.fx.tick, (){var e,n=v.timers,r=0;qn=v.now();for(;r<n.length;r++)e=n[r],!e()&&n[r]===e&&n.splice(r--,1);n.leng
[1:1:0713/020157.040030:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zuopin.4399.com/tyq/", "4399.com", 3, 1, , , 0
[1:1:0713/020157.064576:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zuopin.4399.com/, 990, 7f2a941e08db
[1:1:0713/020157.077791:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"988 0x7f2a9189b070 0xb0b432a0960 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020157.077968:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"988 0x7f2a9189b070 0xb0b432a0960 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020157.078224:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zuopin.4399.com/, 993
[1:1:0713/020157.078386:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 993 0x7f2a9189b070 0xb0b42fbdbe0 , 5:3_http://zuopin.4399.com/, 0, , 990 0x7f2a9189b070 0xb0b432cc3e0 
[1:1:0713/020157.078571:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zuopin.4399.com/tyq/"
[1:1:0713/020157.078863:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zuopin.4399.com/, 0e64767e2860, , v.fx.tick, (){var e,n=v.timers,r=0;qn=v.now();for(;r<n.length;r++)e=n[r],!e()&&n[r]===e&&n.splice(r--,1);n.leng
[1:1:0713/020157.078993:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zuopin.4399.com/tyq/", "4399.com", 3, 1, , , 0
[1:1:0713/020157.080339:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 969, 7f2a941e0881
[1:1:0713/020157.093756:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e64767e2860","ptid":"959 0x7f2a9189b070 0xb0b43499260 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020157.093907:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zuopin.4399.com/","ptid":"959 0x7f2a9189b070 0xb0b43499260 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020157.094128:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zuopin.4399.com/tyq/"
[1:1:0713/020157.094357:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zuopin.4399.com/, 0e64767e2860, , , (){
		   iswide();
		}
[1:1:0713/020157.094476:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zuopin.4399.com/tyq/", "4399.com", 3, 1, , , 0
[1:1:0713/020157.113572:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 400, 0x128a51d029c8, 0xb0b430e6150
[1:1:0713/020157.113739:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zuopin.4399.com/tyq/", 400
[1:1:0713/020157.113934:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 994
[1:1:0713/020157.114050:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 994 0x7f2a9189b070 0xb0b43d4aa60 , 5:3_http://zuopin.4399.com/, 1, -5:3_http://zuopin.4399.com/, 969 0x7f2a9189b070 0xb0b43317d60 
[1:1:0713/020157.114899:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 986, 7f2a941e0881
[1:1:0713/020157.129874:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e64767e2860","ptid":"972 0x7f2a9189b070 0xb0b43db5560 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020157.130025:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zuopin.4399.com/","ptid":"972 0x7f2a9189b070 0xb0b43db5560 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020157.130232:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zuopin.4399.com/tyq/"
[1:1:0713/020157.130499:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zuopin.4399.com/, 0e64767e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/020157.130616:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zuopin.4399.com/tyq/", "4399.com", 3, 1, , , 0
[1:1:0713/020157.130909:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x128a51d029c8, 0xb0b430e6150
[1:1:0713/020157.131018:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zuopin.4399.com/tyq/", 100
[1:1:0713/020157.131190:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 998
[1:1:0713/020157.131309:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 998 0x7f2a9189b070 0xb0b43e56760 , 5:3_http://zuopin.4399.com/, 1, -5:3_http://zuopin.4399.com/, 986 0x7f2a9189b070 0xb0b437b8e60 
[1:1:0713/020157.131737:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zuopin.4399.com/, 993, 7f2a941e08db
[1:1:0713/020157.145509:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"990 0x7f2a9189b070 0xb0b432cc3e0 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020157.145640:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"990 0x7f2a9189b070 0xb0b432cc3e0 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020157.145843:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zuopin.4399.com/, 999
[1:1:0713/020157.145962:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 999 0x7f2a9189b070 0xb0b434bb6e0 , 5:3_http://zuopin.4399.com/, 0, , 993 0x7f2a9189b070 0xb0b42fbdbe0 
[1:1:0713/020157.146102:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zuopin.4399.com/tyq/"
[1:1:0713/020157.146329:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zuopin.4399.com/, 0e64767e2860, , v.fx.tick, (){var e,n=v.timers,r=0;qn=v.now();for(;r<n.length;r++)e=n[r],!e()&&n[r]===e&&n.splice(r--,1);n.leng
[1:1:0713/020157.146443:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zuopin.4399.com/tyq/", "4399.com", 3, 1, , , 0
[1:1:0713/020157.174744:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zuopin.4399.com/, 999, 7f2a941e08db
[1:1:0713/020157.187793:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"993 0x7f2a9189b070 0xb0b42fbdbe0 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020157.187934:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"993 0x7f2a9189b070 0xb0b42fbdbe0 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020157.188141:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zuopin.4399.com/, 1002
[1:1:0713/020157.188263:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1002 0x7f2a9189b070 0xb0b44bb08e0 , 5:3_http://zuopin.4399.com/, 0, , 999 0x7f2a9189b070 0xb0b434bb6e0 
[1:1:0713/020157.188453:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zuopin.4399.com/tyq/"
[1:1:0713/020157.188696:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zuopin.4399.com/, 0e64767e2860, , v.fx.tick, (){var e,n=v.timers,r=0;qn=v.now();for(;r<n.length;r++)e=n[r],!e()&&n[r]===e&&n.splice(r--,1);n.leng
[1:1:0713/020157.188800:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zuopin.4399.com/tyq/", "4399.com", 3, 1, , , 0
[1:1:0713/020157.207555:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zuopin.4399.com/, 1002, 7f2a941e08db
[1:1:0713/020157.220546:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"999 0x7f2a9189b070 0xb0b434bb6e0 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020157.220683:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"999 0x7f2a9189b070 0xb0b434bb6e0 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020157.220872:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zuopin.4399.com/, 1004
[1:1:0713/020157.220972:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1004 0x7f2a9189b070 0xb0b438f1960 , 5:3_http://zuopin.4399.com/, 0, , 1002 0x7f2a9189b070 0xb0b44bb08e0 
[1:1:0713/020157.221145:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zuopin.4399.com/tyq/"
[1:1:0713/020157.221382:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zuopin.4399.com/, 0e64767e2860, , v.fx.tick, (){var e,n=v.timers,r=0;qn=v.now();for(;r<n.length;r++)e=n[r],!e()&&n[r]===e&&n.splice(r--,1);n.leng
[1:1:0713/020157.221499:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zuopin.4399.com/tyq/", "4399.com", 3, 1, , , 0
[1:1:0713/020157.244766:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 998, 7f2a941e0881
[1:1:0713/020157.257882:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e64767e2860","ptid":"986 0x7f2a9189b070 0xb0b437b8e60 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020157.258069:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zuopin.4399.com/","ptid":"986 0x7f2a9189b070 0xb0b437b8e60 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020157.258301:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zuopin.4399.com/tyq/"
[1:1:0713/020157.258596:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zuopin.4399.com/, 0e64767e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/020157.258750:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zuopin.4399.com/tyq/", "4399.com", 3, 1, , , 0
[1:1:0713/020157.259105:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x128a51d029c8, 0xb0b430e6150
[1:1:0713/020157.259217:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zuopin.4399.com/tyq/", 100
[1:1:0713/020157.259391:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 1007
[1:1:0713/020157.259518:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1007 0x7f2a9189b070 0xb0b43a1e0e0 , 5:3_http://zuopin.4399.com/, 1, -5:3_http://zuopin.4399.com/, 998 0x7f2a9189b070 0xb0b43e56760 
[1:1:0713/020157.259954:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zuopin.4399.com/, 1004, 7f2a941e08db
[1:1:0713/020157.273254:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1002 0x7f2a9189b070 0xb0b44bb08e0 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020157.273389:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1002 0x7f2a9189b070 0xb0b44bb08e0 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020157.273592:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zuopin.4399.com/, 1008
[1:1:0713/020157.273712:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1008 0x7f2a9189b070 0xb0b438aa760 , 5:3_http://zuopin.4399.com/, 0, , 1004 0x7f2a9189b070 0xb0b438f1960 
[1:1:0713/020157.273895:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zuopin.4399.com/tyq/"
[1:1:0713/020157.274126:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zuopin.4399.com/, 0e64767e2860, , v.fx.tick, (){var e,n=v.timers,r=0;qn=v.now();for(;r<n.length;r++)e=n[r],!e()&&n[r]===e&&n.splice(r--,1);n.leng
[1:1:0713/020157.274239:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zuopin.4399.com/tyq/", "4399.com", 3, 1, , , 0
[1:1:0713/020157.298786:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zuopin.4399.com/, 1008, 7f2a941e08db
[1:1:0713/020157.312210:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1004 0x7f2a9189b070 0xb0b438f1960 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020157.312352:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1004 0x7f2a9189b070 0xb0b438f1960 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020157.312559:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zuopin.4399.com/, 1010
[1:1:0713/020157.312680:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1010 0x7f2a9189b070 0xb0b43dbe160 , 5:3_http://zuopin.4399.com/, 0, , 1008 0x7f2a9189b070 0xb0b438aa760 
[1:1:0713/020157.312852:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zuopin.4399.com/tyq/"
[1:1:0713/020157.313103:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zuopin.4399.com/, 0e64767e2860, , v.fx.tick, (){var e,n=v.timers,r=0;qn=v.now();for(;r<n.length;r++)e=n[r],!e()&&n[r]===e&&n.splice(r--,1);n.leng
[1:1:0713/020157.313222:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zuopin.4399.com/tyq/", "4399.com", 3, 1, , , 0
[1:1:0713/020157.338006:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zuopin.4399.com/, 1010, 7f2a941e08db
[1:1:0713/020157.351291:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1008 0x7f2a9189b070 0xb0b438aa760 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020157.351470:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1008 0x7f2a9189b070 0xb0b438aa760 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020157.351725:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zuopin.4399.com/, 1012
[1:1:0713/020157.351887:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1012 0x7f2a9189b070 0xb0b438c1ee0 , 5:3_http://zuopin.4399.com/, 0, , 1010 0x7f2a9189b070 0xb0b43dbe160 
[1:1:0713/020157.352096:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zuopin.4399.com/tyq/"
[1:1:0713/020157.352348:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zuopin.4399.com/, 0e64767e2860, , v.fx.tick, (){var e,n=v.timers,r=0;qn=v.now();for(;r<n.length;r++)e=n[r],!e()&&n[r]===e&&n.splice(r--,1);n.leng
[1:1:0713/020157.352465:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zuopin.4399.com/tyq/", "4399.com", 3, 1, , , 0
[1:1:0713/020157.361916:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 1007, 7f2a941e0881
[1:1:0713/020157.376318:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e64767e2860","ptid":"998 0x7f2a9189b070 0xb0b43e56760 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020157.376482:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zuopin.4399.com/","ptid":"998 0x7f2a9189b070 0xb0b43e56760 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020157.376681:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zuopin.4399.com/tyq/"
[1:1:0713/020157.376935:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zuopin.4399.com/, 0e64767e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/020157.377042:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zuopin.4399.com/tyq/", "4399.com", 3, 1, , , 0
[1:1:0713/020157.377348:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x128a51d029c8, 0xb0b430e6150
[1:1:0713/020157.377457:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zuopin.4399.com/tyq/", 100
[1:1:0713/020157.377631:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 1014
[1:1:0713/020157.377753:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1014 0x7f2a9189b070 0xb0b43e56760 , 5:3_http://zuopin.4399.com/, 1, -5:3_http://zuopin.4399.com/, 1007 0x7f2a9189b070 0xb0b43a1e0e0 
[1:1:0713/020157.491915:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 1014, 7f2a941e0881
[1:1:0713/020157.505575:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e64767e2860","ptid":"1007 0x7f2a9189b070 0xb0b43a1e0e0 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020157.505764:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zuopin.4399.com/","ptid":"1007 0x7f2a9189b070 0xb0b43a1e0e0 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020157.506000:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zuopin.4399.com/tyq/"
[1:1:0713/020157.506302:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zuopin.4399.com/, 0e64767e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/020157.506465:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zuopin.4399.com/tyq/", "4399.com", 3, 1, , , 0
[1:1:0713/020157.506815:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x128a51d029c8, 0xb0b430e6150
[1:1:0713/020157.506926:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zuopin.4399.com/tyq/", 100
[1:1:0713/020157.507099:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 1016
[1:1:0713/020157.507235:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1016 0x7f2a9189b070 0xb0b434431e0 , 5:3_http://zuopin.4399.com/, 1, -5:3_http://zuopin.4399.com/, 1014 0x7f2a9189b070 0xb0b43e56760 
[1:1:0713/020157.527742:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 994, 7f2a941e0881
[1:1:0713/020157.541144:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e64767e2860","ptid":"969 0x7f2a9189b070 0xb0b43317d60 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020157.541330:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zuopin.4399.com/","ptid":"969 0x7f2a9189b070 0xb0b43317d60 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020157.541577:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zuopin.4399.com/tyq/"
[1:1:0713/020157.541881:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zuopin.4399.com/, 0e64767e2860, , , (){
		   iswide();
		}
[1:1:0713/020157.542035:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zuopin.4399.com/tyq/", "4399.com", 3, 1, , , 0
[1:1:0713/020157.560708:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 400, 0x128a51d029c8, 0xb0b430e6150
[1:1:0713/020157.560876:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zuopin.4399.com/tyq/", 400
[1:1:0713/020157.561103:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 1018
[1:1:0713/020157.561233:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1018 0x7f2a9189b070 0xb0b438991e0 , 5:3_http://zuopin.4399.com/, 1, -5:3_http://zuopin.4399.com/, 994 0x7f2a9189b070 0xb0b43d4aa60 
[1:1:0713/020157.622616:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 1016, 7f2a941e0881
[1:1:0713/020157.636615:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e64767e2860","ptid":"1014 0x7f2a9189b070 0xb0b43e56760 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020157.636772:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zuopin.4399.com/","ptid":"1014 0x7f2a9189b070 0xb0b43e56760 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020157.636957:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zuopin.4399.com/tyq/"
[1:1:0713/020157.637222:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zuopin.4399.com/, 0e64767e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/020157.637380:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zuopin.4399.com/tyq/", "4399.com", 3, 1, , , 0
[1:1:0713/020157.637779:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x128a51d029c8, 0xb0b430e6150
[1:1:0713/020157.637894:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zuopin.4399.com/tyq/", 100
[1:1:0713/020157.638072:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 1020
[1:1:0713/020157.638207:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1020 0x7f2a9189b070 0xb0b438b48e0 , 5:3_http://zuopin.4399.com/, 1, -5:3_http://zuopin.4399.com/, 1016 0x7f2a9189b070 0xb0b434431e0 
[1:1:0713/020157.752606:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 1020, 7f2a941e0881
[1:1:0713/020157.766278:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e64767e2860","ptid":"1016 0x7f2a9189b070 0xb0b434431e0 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020157.766467:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zuopin.4399.com/","ptid":"1016 0x7f2a9189b070 0xb0b434431e0 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020157.766705:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zuopin.4399.com/tyq/"
[1:1:0713/020157.767030:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zuopin.4399.com/, 0e64767e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/020157.767185:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zuopin.4399.com/tyq/", "4399.com", 3, 1, , , 0
[1:1:0713/020157.767533:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x128a51d029c8, 0xb0b430e6150
[1:1:0713/020157.767648:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zuopin.4399.com/tyq/", 100
[1:1:0713/020157.767825:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 1022
[1:1:0713/020157.767948:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1022 0x7f2a9189b070 0xb0b432a3f60 , 5:3_http://zuopin.4399.com/, 1, -5:3_http://zuopin.4399.com/, 1020 0x7f2a9189b070 0xb0b438b48e0 
[1:1:0713/020157.882325:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 1022, 7f2a941e0881
[1:1:0713/020157.896411:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e64767e2860","ptid":"1020 0x7f2a9189b070 0xb0b438b48e0 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020157.896621:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zuopin.4399.com/","ptid":"1020 0x7f2a9189b070 0xb0b438b48e0 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020157.896819:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zuopin.4399.com/tyq/"
[1:1:0713/020157.897110:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zuopin.4399.com/, 0e64767e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/020157.897270:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zuopin.4399.com/tyq/", "4399.com", 3, 1, , , 0
[1:1:0713/020157.897631:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x128a51d029c8, 0xb0b430e6150
[1:1:0713/020157.897781:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zuopin.4399.com/tyq/", 100
[1:1:0713/020157.897951:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 1024
[1:1:0713/020157.898073:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1024 0x7f2a9189b070 0xb0b433696e0 , 5:3_http://zuopin.4399.com/, 1, -5:3_http://zuopin.4399.com/, 1022 0x7f2a9189b070 0xb0b432a3f60 
[1:1:0713/020157.976037:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 1018, 7f2a941e0881
[1:1:0713/020157.989922:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e64767e2860","ptid":"994 0x7f2a9189b070 0xb0b43d4aa60 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020157.990119:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zuopin.4399.com/","ptid":"994 0x7f2a9189b070 0xb0b43d4aa60 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020157.990362:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zuopin.4399.com/tyq/"
[1:1:0713/020157.990699:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zuopin.4399.com/, 0e64767e2860, , , (){
		   iswide();
		}
[1:1:0713/020157.990843:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zuopin.4399.com/tyq/", "4399.com", 3, 1, , , 0
[1:1:0713/020158.006939:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 400, 0x128a51d029c8, 0xb0b430e6150
[1:1:0713/020158.007116:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zuopin.4399.com/tyq/", 400
[1:1:0713/020158.007356:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 1026
[1:1:0713/020158.007506:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1026 0x7f2a9189b070 0xb0b434cfa60 , 5:3_http://zuopin.4399.com/, 1, -5:3_http://zuopin.4399.com/, 1018 0x7f2a9189b070 0xb0b438991e0 
[1:1:0713/020158.008536:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 1024, 7f2a941e0881
[1:1:0713/020158.025281:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e64767e2860","ptid":"1022 0x7f2a9189b070 0xb0b432a3f60 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020158.025468:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zuopin.4399.com/","ptid":"1022 0x7f2a9189b070 0xb0b432a3f60 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020158.025698:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zuopin.4399.com/tyq/"
[1:1:0713/020158.026018:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zuopin.4399.com/, 0e64767e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/020158.026145:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zuopin.4399.com/tyq/", "4399.com", 3, 1, , , 0
[1:1:0713/020158.026470:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x128a51d029c8, 0xb0b430e6150
[1:1:0713/020158.026592:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zuopin.4399.com/tyq/", 100
[1:1:0713/020158.026784:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 1028
[1:1:0713/020158.026913:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1028 0x7f2a9189b070 0xb0b43e74a60 , 5:3_http://zuopin.4399.com/, 1, -5:3_http://zuopin.4399.com/, 1024 0x7f2a9189b070 0xb0b433696e0 
[1:1:0713/020158.142754:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 1028, 7f2a941e0881
[1:1:0713/020158.157150:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e64767e2860","ptid":"1024 0x7f2a9189b070 0xb0b433696e0 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020158.157357:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zuopin.4399.com/","ptid":"1024 0x7f2a9189b070 0xb0b433696e0 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020158.157607:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zuopin.4399.com/tyq/"
[1:1:0713/020158.157965:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zuopin.4399.com/, 0e64767e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/020158.158088:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zuopin.4399.com/tyq/", "4399.com", 3, 1, , , 0
[1:1:0713/020158.158446:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x128a51d029c8, 0xb0b430e6150
[1:1:0713/020158.158562:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zuopin.4399.com/tyq/", 100
[1:1:0713/020158.158742:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 1030
[1:1:0713/020158.158864:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1030 0x7f2a9189b070 0xb0b438dac60 , 5:3_http://zuopin.4399.com/, 1, -5:3_http://zuopin.4399.com/, 1028 0x7f2a9189b070 0xb0b43e74a60 
[1:1:0713/020158.272429:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 1030, 7f2a941e0881
[1:1:0713/020158.285876:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e64767e2860","ptid":"1028 0x7f2a9189b070 0xb0b43e74a60 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020158.286072:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zuopin.4399.com/","ptid":"1028 0x7f2a9189b070 0xb0b43e74a60 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020158.286315:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zuopin.4399.com/tyq/"
[1:1:0713/020158.286630:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zuopin.4399.com/, 0e64767e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/020158.286787:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zuopin.4399.com/tyq/", "4399.com", 3, 1, , , 0
[1:1:0713/020158.287142:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x128a51d029c8, 0xb0b430e6150
[1:1:0713/020158.287255:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zuopin.4399.com/tyq/", 100
[1:1:0713/020158.287438:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 1034
[1:1:0713/020158.287560:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1034 0x7f2a9189b070 0xb0b43a25d60 , 5:3_http://zuopin.4399.com/, 1, -5:3_http://zuopin.4399.com/, 1030 0x7f2a9189b070 0xb0b438dac60 
[1:1:0713/020158.401737:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 1034, 7f2a941e0881
[1:1:0713/020158.415299:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e64767e2860","ptid":"1030 0x7f2a9189b070 0xb0b438dac60 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020158.415491:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zuopin.4399.com/","ptid":"1030 0x7f2a9189b070 0xb0b438dac60 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020158.415728:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zuopin.4399.com/tyq/"
[1:1:0713/020158.416054:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zuopin.4399.com/, 0e64767e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/020158.416180:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zuopin.4399.com/tyq/", "4399.com", 3, 1, , , 0
[1:1:0713/020158.416486:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x128a51d029c8, 0xb0b430e6150
[1:1:0713/020158.416620:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zuopin.4399.com/tyq/", 100
[1:1:0713/020158.416784:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 1036
[1:1:0713/020158.416881:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1036 0x7f2a9189b070 0xb0b44bb2a60 , 5:3_http://zuopin.4399.com/, 1, -5:3_http://zuopin.4399.com/, 1034 0x7f2a9189b070 0xb0b43a25d60 
[1:1:0713/020158.417316:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 1026, 7f2a941e0881
[1:1:0713/020158.430975:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e64767e2860","ptid":"1018 0x7f2a9189b070 0xb0b438991e0 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020158.431115:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zuopin.4399.com/","ptid":"1018 0x7f2a9189b070 0xb0b438991e0 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020158.431302:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zuopin.4399.com/tyq/"
[1:1:0713/020158.431539:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zuopin.4399.com/, 0e64767e2860, , , (){
		   iswide();
		}
[1:1:0713/020158.431648:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zuopin.4399.com/tyq/", "4399.com", 3, 1, , , 0
[1:1:0713/020158.446418:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 400, 0x128a51d029c8, 0xb0b430e6150
[1:1:0713/020158.446556:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zuopin.4399.com/tyq/", 400
[1:1:0713/020158.446741:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 1038
[1:1:0713/020158.446870:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1038 0x7f2a9189b070 0xb0b43de81e0 , 5:3_http://zuopin.4399.com/, 1, -5:3_http://zuopin.4399.com/, 1026 0x7f2a9189b070 0xb0b434cfa60 
[1:1:0713/020158.531876:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 1036, 7f2a941e0881
[1:1:0713/020158.545884:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e64767e2860","ptid":"1034 0x7f2a9189b070 0xb0b43a25d60 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020158.546084:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zuopin.4399.com/","ptid":"1034 0x7f2a9189b070 0xb0b43a25d60 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020158.546326:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zuopin.4399.com/tyq/"
[1:1:0713/020158.546656:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zuopin.4399.com/, 0e64767e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/020158.546820:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zuopin.4399.com/tyq/", "4399.com", 3, 1, , , 0
[1:1:0713/020158.547167:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x128a51d029c8, 0xb0b430e6150
[1:1:0713/020158.547282:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zuopin.4399.com/tyq/", 100
[1:1:0713/020158.547459:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 1040
[1:1:0713/020158.547579:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1040 0x7f2a9189b070 0xb0b43e74d60 , 5:3_http://zuopin.4399.com/, 1, -5:3_http://zuopin.4399.com/, 1036 0x7f2a9189b070 0xb0b44bb2a60 
[1:1:0713/020158.662040:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 1040, 7f2a941e0881
[1:1:0713/020158.675846:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e64767e2860","ptid":"1036 0x7f2a9189b070 0xb0b44bb2a60 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020158.676036:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zuopin.4399.com/","ptid":"1036 0x7f2a9189b070 0xb0b44bb2a60 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020158.676261:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zuopin.4399.com/tyq/"
[1:1:0713/020158.676555:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zuopin.4399.com/, 0e64767e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/020158.676672:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zuopin.4399.com/tyq/", "4399.com", 3, 1, , , 0
[1:1:0713/020158.676957:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x128a51d029c8, 0xb0b430e6150
[1:1:0713/020158.677078:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zuopin.4399.com/tyq/", 100
[1:1:0713/020158.677249:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 1042
[1:1:0713/020158.677349:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1042 0x7f2a9189b070 0xb0b438afee0 , 5:3_http://zuopin.4399.com/, 1, -5:3_http://zuopin.4399.com/, 1040 0x7f2a9189b070 0xb0b43e74d60 
[1:1:0713/020158.791631:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 1042, 7f2a941e0881
[1:1:0713/020158.805402:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e64767e2860","ptid":"1040 0x7f2a9189b070 0xb0b43e74d60 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020158.805591:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zuopin.4399.com/","ptid":"1040 0x7f2a9189b070 0xb0b43e74d60 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020158.805832:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zuopin.4399.com/tyq/"
[1:1:0713/020158.806137:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zuopin.4399.com/, 0e64767e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/020158.806292:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zuopin.4399.com/tyq/", "4399.com", 3, 1, , , 0
[1:1:0713/020158.806641:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x128a51d029c8, 0xb0b430e6150
[1:1:0713/020158.806763:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zuopin.4399.com/tyq/", 100
[1:1:0713/020158.806938:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 1044
[1:1:0713/020158.807059:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1044 0x7f2a9189b070 0xb0b438b1ee0 , 5:3_http://zuopin.4399.com/, 1, -5:3_http://zuopin.4399.com/, 1042 0x7f2a9189b070 0xb0b438afee0 
[1:1:0713/020158.861090:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 1038, 7f2a941e0881
[1:1:0713/020158.874680:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e64767e2860","ptid":"1026 0x7f2a9189b070 0xb0b434cfa60 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020158.874867:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zuopin.4399.com/","ptid":"1026 0x7f2a9189b070 0xb0b434cfa60 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020158.875103:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zuopin.4399.com/tyq/"
[1:1:0713/020158.875403:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zuopin.4399.com/, 0e64767e2860, , , (){
		   iswide();
		}
[1:1:0713/020158.875540:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zuopin.4399.com/tyq/", "4399.com", 3, 1, , , 0
[1:1:0713/020158.890393:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 400, 0x128a51d029c8, 0xb0b430e6150
[1:1:0713/020158.890533:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zuopin.4399.com/tyq/", 400
[1:1:0713/020158.890720:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 1046
[1:1:0713/020158.890843:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1046 0x7f2a9189b070 0xb0b43716ce0 , 5:3_http://zuopin.4399.com/, 1, -5:3_http://zuopin.4399.com/, 1038 0x7f2a9189b070 0xb0b43de81e0 
[1:1:0713/020158.909552:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 1044, 7f2a941e0881
[1:1:0713/020158.925084:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e64767e2860","ptid":"1042 0x7f2a9189b070 0xb0b438afee0 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020158.925249:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zuopin.4399.com/","ptid":"1042 0x7f2a9189b070 0xb0b438afee0 ","rf":"5:3_http://zuopin.4399.com/"}
[1:1:0713/020158.925459:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zuopin.4399.com/tyq/"
[1:1:0713/020158.925760:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zuopin.4399.com/, 0e64767e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/020158.925879:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zuopin.4399.com/tyq/", "4399.com", 3, 1, , , 0
[1:1:0713/020158.926194:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x128a51d029c8, 0xb0b430e6150
[1:1:0713/020158.926304:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zuopin.4399.com/tyq/", 100
[1:1:0713/020158.926475:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zuopin.4399.com/, 1050
[1:1:0713/020158.926557:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1050 0x7f2a9189b070 0xb0b43a1e0e0 , 5:3_http://zuopin.4399.com/, 1, -5:3_http://zuopin.4399.com/, 1044 0x7f2a9189b070 0xb0b438b1ee0 
