[0713/033943.375425:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/033943.375698:INFO:switcher_clone.cc(787)] backtrace rip is 7f8740593891
[0713/033943.923441:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/033943.923695:INFO:switcher_clone.cc(787)] backtrace rip is 7f71a1fad891
[1:1:0713/033943.927535:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0713/033943.927706:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0713/033943.930523:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[0713/033944.756529:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/033944.756814:INFO:switcher_clone.cc(787)] backtrace rip is 7f770cc4e891
[28900:28900:0713/033944.816805:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/35155ce7-6555-405d-ba09-281892f98094
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[28932:28932:0713/033944.902547:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=28932
[28945:28945:0713/033944.902854:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=28945
[28900:28900:0713/033945.058069:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[28900:28930:0713/033945.058532:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0713/033945.058675:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0713/033945.058863:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0713/033945.059194:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0713/033945.059355:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0713/033945.061075:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x3b58bfed, 1
[1:1:0713/033945.061341:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x337e2df, 0
[1:1:0713/033945.061458:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x33f34d61, 3
[1:1:0713/033945.061659:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x357f4ab6, 2
[1:1:0713/033945.061787:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffdfffffffe23703 ffffffedffffffbf583b ffffffb64a7f35 614dfffffff333 , 10104, 4
[1:1:0713/033945.062487:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[28900:28930:0713/033945.062643:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING��7��X;�J5aM�3���
[28900:28930:0713/033945.062689:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ��7��X;�J5aM�3x���
[1:1:0713/033945.062631:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f71a01e70a0, 3
[1:1:0713/033945.062737:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f71a0373080, 2
[1:1:0713/033945.062847:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f718a035d20, -2
[28900:28930:0713/033945.063848:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[28900:28930:0713/033945.063888:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 28953, 4, dfe23703 edbf583b b64a7f35 614df333 
[1:1:0713/033945.071538:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0713/033945.071986:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 357f4ab6
[1:1:0713/033945.072406:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 357f4ab6
[1:1:0713/033945.073177:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 357f4ab6
[1:1:0713/033945.073741:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 357f4ab6
[1:1:0713/033945.073884:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 357f4ab6
[1:1:0713/033945.074000:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 357f4ab6
[1:1:0713/033945.074136:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 357f4ab6
[1:1:0713/033945.074408:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 357f4ab6
[1:1:0713/033945.074564:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f71a1fad7ba
[1:1:0713/033945.074647:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f71a1fa4def, 7f71a1fad77a, 7f71a1faf0cf
[1:1:0713/033945.076306:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 357f4ab6
[1:1:0713/033945.076475:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 357f4ab6
[1:1:0713/033945.076786:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 357f4ab6
[1:1:0713/033945.077612:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 357f4ab6
[1:1:0713/033945.077745:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 357f4ab6
[1:1:0713/033945.077867:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 357f4ab6
[1:1:0713/033945.077982:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 357f4ab6
[1:1:0713/033945.078519:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 357f4ab6
[1:1:0713/033945.078697:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f71a1fad7ba
[1:1:0713/033945.078807:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f71a1fa4def, 7f71a1fad77a, 7f71a1faf0cf
[1:1:0713/033945.081326:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0713/033945.081557:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0713/033945.081668:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffddc5aeb88, 0x7ffddc5aeb08)
[1:1:0713/033945.088377:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0713/033945.091117:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[28900:28900:0713/033945.484955:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[28900:28900:0713/033945.485891:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[28900:28912:0713/033945.494291:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[28900:28912:0713/033945.494359:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[28900:28900:0713/033945.494399:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[28900:28900:0713/033945.494442:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[28900:28900:0713/033945.494517:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,28953, 4
[1:7:0713/033945.498265:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/033945.539247:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x304ede895220
[1:1:0713/033945.539413:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[28900:28925:0713/033945.561069:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0713/033945.768315:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0713/033946.490220:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/033946.491856:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[28900:28900:0713/033946.829696:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[28900:28900:0713/033946.829772:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0713/033946.965871:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/033947.073633:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 34566d241f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0713/033947.073844:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/033947.079478:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 34566d241f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0713/033947.079633:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/033947.111291:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/033947.111455:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/033947.272044:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 359, "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/033947.274606:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 34566d241f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0713/033947.274730:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/033947.286735:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 360, "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/033947.289785:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 34566d241f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0713/033947.289926:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/033947.293718:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[28900:28900:0713/033947.294392:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0713/033947.295487:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x304ede893e20
[1:1:0713/033947.296318:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[28900:28900:0713/033947.296725:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[28900:28900:0713/033947.308756:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[28900:28900:0713/033947.308845:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0713/033947.328268:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/033947.623573:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 420 0x7f718bc102e0 0x304edeb16a60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/033947.624270:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 34566d241f78, , , var configData = {"googleBaseUrl":"https://www.google.com.hk/","isAccessibleBrowser":false,"isGoogle
[1:1:0713/033947.624433:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/033947.625005:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[28900:28900:0713/033947.649653:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0713/033947.650808:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x304ede894820
[1:1:0713/033947.650950:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[28900:28900:0713/033947.652201:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0713/033947.657751:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0713/033947.657927:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[28900:28900:0713/033947.659723:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[28900:28900:0713/033947.663580:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[28900:28900:0713/033947.664005:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[28900:28912:0713/033947.668336:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[28900:28912:0713/033947.668389:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[28900:28900:0713/033947.668406:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[28900:28900:0713/033947.668443:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[28900:28900:0713/033947.668501:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,28953, 4
[1:7:0713/033947.669927:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/033947.933018:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0713/033948.058449:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 467 0x7f718bc102e0 0x304edec1e360 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/033948.059031:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 34566d241f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0713/033948.059138:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/033948.059480:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[28900:28900:0713/033948.238427:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[28900:28900:0713/033948.238512:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0713/033948.249512:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[28900:28900:0713/033948.363493:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[28900:28930:0713/033948.363760:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0713/033948.363902:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0713/033948.364086:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0713/033948.364291:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0713/033948.364378:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0713/033948.366765:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x1b3caeb1, 1
[1:1:0713/033948.367021:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x2a426865, 0
[1:1:0713/033948.367193:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x203ab936, 3
[1:1:0713/033948.367354:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x138e6416, 2
[1:1:0713/033948.367491:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 6568422a ffffffb1ffffffae3c1b 1664ffffff8e13 36ffffffb93a20 , 10104, 5
[1:1:0713/033948.368235:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[28900:28930:0713/033948.368424:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGehB*��<d�6�: ���
[28900:28930:0713/033948.368469:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ehB*��<d�6�: ����
[1:1:0713/033948.368413:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f71a01e70a0, 3
[28900:28930:0713/033948.368605:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 28995, 5, 6568422a b1ae3c1b 16648e13 36b93a20 
[1:1:0713/033948.368602:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f71a0373080, 2
[1:1:0713/033948.368706:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f718a035d20, -2
[1:1:0713/033948.378402:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0713/033948.378623:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 138e6416
[1:1:0713/033948.378854:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 138e6416
[1:1:0713/033948.379152:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 138e6416
[1:1:0713/033948.379686:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 138e6416
[1:1:0713/033948.379803:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 138e6416
[1:1:0713/033948.379908:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 138e6416
[1:1:0713/033948.380026:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 138e6416
[1:1:0713/033948.380300:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 138e6416
[1:1:0713/033948.380469:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f71a1fad7ba
[1:1:0713/033948.380549:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f71a1fa4def, 7f71a1fad77a, 7f71a1faf0cf
[1:1:0713/033948.382264:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 138e6416
[1:1:0713/033948.382438:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 138e6416
[1:1:0713/033948.382741:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 138e6416
[1:1:0713/033948.383536:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 138e6416
[1:1:0713/033948.383639:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 138e6416
[1:1:0713/033948.383727:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 138e6416
[1:1:0713/033948.383803:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 138e6416
[1:1:0713/033948.384286:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 138e6416
[1:1:0713/033948.384440:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f71a1fad7ba
[1:1:0713/033948.384526:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f71a1fa4def, 7f71a1fad77a, 7f71a1faf0cf
[1:1:0713/033948.387146:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0713/033948.387369:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0713/033948.387472:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffddc5aeb88, 0x7ffddc5aeb08)
[1:1:0713/033948.392819:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/033948.393578:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0713/033948.396371:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0713/033948.485199:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x304ede861220
[1:1:0713/033948.485362:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0713/033948.661537:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/033948.661749:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/033948.808311:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 542, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/033948.810150:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 34566d36e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0713/033948.810417:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/033948.812955:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/033948.862239:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/033948.862627:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 34566d241f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0713/033948.862752:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/033948.919447:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/033948.920318:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0713/033948.920470:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 34566d36e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0713/033948.920615:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/033948.984049:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/033948.985789:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0713/033948.986500:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 34566d36e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0713/033948.986690:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[28900:28900:0713/033949.021570:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[28900:28900:0713/033949.023919:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[28900:28912:0713/033949.047443:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[28900:28912:0713/033949.047511:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[28900:28900:0713/033949.047649:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://news.sznews.com/
[28900:28900:0713/033949.047694:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://news.sznews.com/, http://news.sznews.com/node_33500.htm, 1
[28900:28900:0713/033949.047756:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://news.sznews.com/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 19:39:48 GMT Content-Type: text/html Transfer-Encoding: chunked Connection: keep-alive Expires: Fri, 12 Jul 2019 19:44:48 GMT Server: nginx Set-Cookie: security_session_verify=81a34e08442831b4623ecd52edc5d5b8; expires=Tue, 16-Jul-19 03:42:16 GMT; path=/; HttpOnly Set-Cookie: security_session_verify=81a34e08442831b4623ecd52edc5d5b8; expires=Tue, 16-Jul-19 03:42:16 GMT; path=/; HttpOnly Last-Modified: Fri, 12 Jul 2019 19:42:16 GMT ETag: W/"9fa0-58d8914968cca" Cache-Control: max-age=300 Content-Encoding: gzip X-Via: 1.1 changkuan197:2 (Cdn Cache Server V2.0), 1.1 hkuan177:8 (Cdn Cache Server V2.0)  ,28995, 5
[1:7:0713/033949.051148:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/033949.066141:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://news.sznews.com/
[28900:28900:0713/033949.119265:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://news.sznews.com/, http://news.sznews.com/, 1
[28900:28900:0713/033949.119329:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://news.sznews.com/, http://news.sznews.com
[1:1:0713/033949.123556:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.taobao.com/"
[1:1:0713/033949.134322:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/033949.175699:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/033949.206177:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/033949.206374:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://news.sznews.com/node_33500.htm"
[1:1:0713/033949.225775:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://m.vk.com/"
[1:1:0713/033949.389857:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.qq.com/"
[1:1:0713/033949.427447:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://amazon.com/"
[1:1:0713/033949.455952:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://tmall.com/"
[1:1:0713/033949.497111:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://github.com/"
[1:1:0713/033949.526589:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.jd.com/"
[1:1:0713/033949.581248:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://yahoo.com/"
[1:1:0713/033949.662216:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/033949.700722:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/033949.701225:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 34566d36e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0713/033949.701426:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/033949.719535:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 207 0x7f71a0373080 0x304ede92ad80 1 0 0x304ede92ad98 , "http://news.sznews.com/node_33500.htm"
[1:1:0713/033949.720601:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/033949.723461:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , , /*! jQuery v1.12.2 | (c) jQuery Foundation | jquery.org/license */
!function(a,b){"object"==typeof m
[1:1:0713/033949.723663:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/033949.832471:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 207 0x7f71a0373080 0x304ede92ad80 1 0 0x304ede92ad98 , "http://news.sznews.com/node_33500.htm"
[1:1:0713/033949.838455:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 207 0x7f71a0373080 0x304ede92ad80 1 0 0x304ede92ad98 , "http://news.sznews.com/node_33500.htm"
[1:1:0713/033949.849902:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 207 0x7f71a0373080 0x304ede92ad80 1 0 0x304ede92ad98 , "http://news.sznews.com/node_33500.htm"
[1:1:0713/033949.858631:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 207 0x7f71a0373080 0x304ede92ad80 1 0 0x304ede92ad98 , "http://news.sznews.com/node_33500.htm"
[1:1:0713/033949.901462:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 207 0x7f71a0373080 0x304ede92ad80 1 0 0x304ede92ad98 , "http://news.sznews.com/node_33500.htm"
[1:1:0713/033949.904251:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 207 0x7f71a0373080 0x304ede92ad80 1 0 0x304ede92ad98 , "http://news.sznews.com/node_33500.htm"
[1:1:0713/033949.908896:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 207 0x7f71a0373080 0x304ede92ad80 1 0 0x304ede92ad98 , "http://news.sznews.com/node_33500.htm"
[1:1:0713/033949.910145:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 207 0x7f71a0373080 0x304ede92ad80 1 0 0x304ede92ad98 , "http://news.sznews.com/node_33500.htm"
[1:1:0713/033949.914367:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 207 0x7f71a0373080 0x304ede92ad80 1 0 0x304ede92ad98 , "http://news.sznews.com/node_33500.htm"
[1:1:0713/033949.924997:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 207 0x7f71a0373080 0x304ede92ad80 1 0 0x304ede92ad98 , "http://news.sznews.com/node_33500.htm"
[1:1:0713/033950.227596:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/033950.393706:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/033950.393924:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://news.sznews.com/node_33500.htm"
[1:1:0713/033950.395225:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 286 0x7f7189ce8070 0x304ede970560 , "http://news.sznews.com/node_33500.htm"
[1:1:0713/033950.395948:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , , // //手机栏目页适配
// var Mobile = {
// 	Android: function() {
// 		return navigator.user
[1:1:0713/033950.396119:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/033950.399459:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 286 0x7f7189ce8070 0x304ede970560 , "http://news.sznews.com/node_33500.htm"
[1:1:0713/033950.446963:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0713/033950.449077:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x304ede470220
[1:1:0713/033950.449410:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[1:1:0713/033950.455977:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0713/033950.456154:INFO:render_frame_impl.cc(7019)] 	 [url] = http://news.sznews.com
[1:1:0713/033950.457112:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0631239, 812, 1
[1:1:0713/033950.457287:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/033950.661556:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/033950.661761:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://news.sznews.com/node_33500.htm"
[1:1:0713/033950.663081:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 322 0x7f7189ce8070 0x304edecec960 , "http://news.sznews.com/node_33500.htm"
[1:1:0713/033950.663550:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , , //百度统计
//var _bdhmProtocol = (("https:" == document.location.protocol) ? " https://" : " ht
[1:1:0713/033950.663690:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/033950.664579:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 322 0x7f7189ce8070 0x304edecec960 , "http://news.sznews.com/node_33500.htm"
[1:1:0713/033950.666143:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 322 0x7f7189ce8070 0x304edecec960 , "http://news.sznews.com/node_33500.htm"
[1:1:0713/033951.722443:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.sznews.com/node_33500.htm", 2000
[1:1:0713/033951.722760:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 374
[1:1:0713/033951.722887:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 374 0x7f7189ce8070 0x304eded79a60 , 5:3_http://news.sznews.com/, 1, -5:3_http://news.sznews.com/, 322 0x7f7189ce8070 0x304edecec960 
[1:1:0713/033951.723610:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 1.06176, 0, 0
[1:1:0713/033951.723728:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/033952.078698:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/033952.078872:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://news.sznews.com/node_33500.htm"
[1:1:0713/033952.080342:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 375 0x7f7189ce8070 0x304edf240b60 , "http://news.sznews.com/node_33500.htm"
[1:1:0713/033952.080928:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , , 

function remotejs(url, callback, jsonObject) {
    var date = new Date();
    var dcsSrc = url
[1:1:0713/033952.081088:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/033952.083961:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 375 0x7f7189ce8070 0x304edf240b60 , "http://news.sznews.com/node_33500.htm"
[1:1:0713/033952.086019:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://news.sznews.com/node_33500.htm"
[1:1:0713/033952.162518:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.sznews.com/node_33500.htm", 5000
[1:1:0713/033952.162798:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 422
[1:1:0713/033952.162941:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 422 0x7f7189ce8070 0x304edf1e8460 , 5:3_http://news.sznews.com/, 1, -5:3_http://news.sznews.com/, 375 0x7f7189ce8070 0x304edf240b60 
[1:1:0713/033952.165951:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x2230870629c8, 0x304ede390c40
[1:1:0713/033952.166083:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.sznews.com/node_33500.htm", 5000
[1:1:0713/033952.166267:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.sznews.com/, 423
[1:1:0713/033952.166394:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 423 0x7f7189ce8070 0x304eded4d3e0 , 5:3_http://news.sznews.com/, 1, -5:3_http://news.sznews.com/, 375 0x7f7189ce8070 0x304edf240b60 
[1:1:0713/033953.722748:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/033953.752882:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 374, 7f718c62d8db
[1:1:0713/033953.762475:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b05cd0a2860","ptid":"322 0x7f7189ce8070 0x304edecec960 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033953.762681:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.sznews.com/","ptid":"322 0x7f7189ce8070 0x304edecec960 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033953.762966:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 573
[1:1:0713/033953.763101:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 573 0x7f7189ce8070 0x304eded5fae0 , 5:3_http://news.sznews.com/, 0, , 374 0x7f7189ce8070 0x304eded79a60 
[1:1:0713/033953.763273:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/033953.763574:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , uu, ()
	{
		if(dnow<oli.length-2)
		{
			oli[dnow].className=rq[dnow].className="";
			dnow++;
			oli[dn
[1:1:0713/033953.763699:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/033953.764735:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.sznews.com/node_33500.htm", 15
[1:1:0713/033953.764923:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 574
[1:1:0713/033953.765027:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 574 0x7f7189ce8070 0x304edea8c1e0 , 5:3_http://news.sznews.com/, 1, -5:3_http://news.sznews.com/, 374 0x7f7189ce8070 0x304eded79a60 
[1:1:0713/033953.765306:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.sznews.com/node_33500.htm", 8000
[1:1:0713/033953.765494:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 575
[1:1:0713/033953.765627:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 575 0x7f7189ce8070 0x304edf214560 , 5:3_http://news.sznews.com/, 1, -5:3_http://news.sznews.com/, 374 0x7f7189ce8070 0x304eded79a60 
[1:1:0713/033953.817380:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 574, 7f718c62d8db
[1:1:0713/033953.827807:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b05cd0a2860","ptid":"374 0x7f7189ce8070 0x304eded79a60 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033953.828013:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.sznews.com/","ptid":"374 0x7f7189ce8070 0x304eded79a60 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033953.828267:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 580
[1:1:0713/033953.828405:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 580 0x7f7189ce8070 0x304eded6c6e0 , 5:3_http://news.sznews.com/, 0, , 574 0x7f7189ce8070 0x304edea8c1e0 
[1:1:0713/033953.828619:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/033953.828898:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/033953.829000:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/033953.863726:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 580, 7f718c62d8db
[1:1:0713/033953.873443:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"574 0x7f7189ce8070 0x304edea8c1e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033953.873615:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"574 0x7f7189ce8070 0x304edea8c1e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033953.873855:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 584
[1:1:0713/033953.873989:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 584 0x7f7189ce8070 0x304eded550e0 , 5:3_http://news.sznews.com/, 0, , 580 0x7f7189ce8070 0x304eded6c6e0 
[1:1:0713/033953.874164:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/033953.874457:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/033953.874582:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/033953.916596:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 584, 7f718c62d8db
[1:1:0713/033953.926269:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"580 0x7f7189ce8070 0x304eded6c6e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033953.926441:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"580 0x7f7189ce8070 0x304eded6c6e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033953.926677:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 589
[1:1:0713/033953.926812:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 589 0x7f7189ce8070 0x304edf1d9fe0 , 5:3_http://news.sznews.com/, 0, , 584 0x7f7189ce8070 0x304eded550e0 
[1:1:0713/033953.926986:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/033953.927286:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/033953.927409:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/033953.948866:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 589, 7f718c62d8db
[1:1:0713/033953.958826:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"584 0x7f7189ce8070 0x304eded550e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033953.958996:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"584 0x7f7189ce8070 0x304eded550e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033953.959228:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 594
[1:1:0713/033953.959435:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 594 0x7f7189ce8070 0x304ede9b7560 , 5:3_http://news.sznews.com/, 0, , 589 0x7f7189ce8070 0x304edf1d9fe0 
[1:1:0713/033953.959616:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/033953.959881:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/033953.959972:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/033954.002285:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 594, 7f718c62d8db
[1:1:0713/033954.012340:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"589 0x7f7189ce8070 0x304edf1d9fe0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033954.012514:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"589 0x7f7189ce8070 0x304edf1d9fe0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033954.012752:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 598
[1:1:0713/033954.012872:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 598 0x7f7189ce8070 0x304edebb2ce0 , 5:3_http://news.sznews.com/, 0, , 594 0x7f7189ce8070 0x304ede9b7560 
[1:1:0713/033954.013022:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/033954.013307:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/033954.013437:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/033954.045935:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 598, 7f718c62d8db
[1:1:0713/033954.055636:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"594 0x7f7189ce8070 0x304ede9b7560 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033954.055797:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"594 0x7f7189ce8070 0x304ede9b7560 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033954.056088:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 603
[1:1:0713/033954.056213:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 603 0x7f7189ce8070 0x304ede91c4e0 , 5:3_http://news.sznews.com/, 0, , 598 0x7f7189ce8070 0x304edebb2ce0 
[1:1:0713/033954.056377:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/033954.056658:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/033954.056765:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/033954.096224:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 603, 7f718c62d8db
[1:1:0713/033954.105861:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"598 0x7f7189ce8070 0x304edebb2ce0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033954.106021:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"598 0x7f7189ce8070 0x304edebb2ce0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033954.106237:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 607
[1:1:0713/033954.106363:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 607 0x7f7189ce8070 0x304eded532e0 , 5:3_http://news.sznews.com/, 0, , 603 0x7f7189ce8070 0x304ede91c4e0 
[1:1:0713/033954.106524:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/033954.106797:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/033954.106915:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/033954.146660:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 607, 7f718c62d8db
[1:1:0713/033954.156063:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"603 0x7f7189ce8070 0x304ede91c4e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033954.156226:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"603 0x7f7189ce8070 0x304ede91c4e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033954.156443:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 612
[1:1:0713/033954.156566:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 612 0x7f7189ce8070 0x304eded7dbe0 , 5:3_http://news.sznews.com/, 0, , 607 0x7f7189ce8070 0x304eded532e0 
[1:1:0713/033954.156718:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/033954.156976:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/033954.157104:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/033954.198397:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 612, 7f718c62d8db
[1:1:0713/033954.208666:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"607 0x7f7189ce8070 0x304eded532e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033954.208835:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"607 0x7f7189ce8070 0x304eded532e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033954.209071:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 617
[1:1:0713/033954.209204:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 617 0x7f7189ce8070 0x304eded549e0 , 5:3_http://news.sznews.com/, 0, , 612 0x7f7189ce8070 0x304eded7dbe0 
[1:1:0713/033954.209372:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/033954.209667:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/033954.209793:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/033954.252437:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 617, 7f718c62d8db
[1:1:0713/033954.262210:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"612 0x7f7189ce8070 0x304eded7dbe0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033954.262372:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"612 0x7f7189ce8070 0x304eded7dbe0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033954.262590:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 622
[1:1:0713/033954.262717:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 622 0x7f7189ce8070 0x304edebabde0 , 5:3_http://news.sznews.com/, 0, , 617 0x7f7189ce8070 0x304eded549e0 
[1:1:0713/033954.262887:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/033954.263152:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/033954.263271:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/033954.305219:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 622, 7f718c62d8db
[1:1:0713/033954.314975:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"617 0x7f7189ce8070 0x304eded549e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033954.315149:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"617 0x7f7189ce8070 0x304eded549e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033954.315369:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 627
[1:1:0713/033954.315497:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 627 0x7f7189ce8070 0x304eded53ce0 , 5:3_http://news.sznews.com/, 0, , 622 0x7f7189ce8070 0x304edebabde0 
[1:1:0713/033954.315656:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/033954.315932:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/033954.316040:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/033954.383188:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 627, 7f718c62d8db
[1:1:0713/033954.392071:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"622 0x7f7189ce8070 0x304edebabde0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033954.392226:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"622 0x7f7189ce8070 0x304edebabde0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033954.392436:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 633
[1:1:0713/033954.392560:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 633 0x7f7189ce8070 0x304eded7d260 , 5:3_http://news.sznews.com/, 0, , 627 0x7f7189ce8070 0x304eded53ce0 
[1:1:0713/033954.392727:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/033954.392984:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/033954.393120:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/033954.403725:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 633, 7f718c62d8db
[1:1:0713/033954.412771:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"627 0x7f7189ce8070 0x304eded53ce0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033954.412913:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"627 0x7f7189ce8070 0x304eded53ce0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033954.413146:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 635
[1:1:0713/033954.413274:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 635 0x7f7189ce8070 0x304edeba82e0 , 5:3_http://news.sznews.com/, 0, , 633 0x7f7189ce8070 0x304eded7d260 
[1:1:0713/033954.413487:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/033954.413754:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/033954.413873:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/033954.434599:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 635, 7f718c62d8db
[1:1:0713/033954.444293:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"633 0x7f7189ce8070 0x304eded7d260 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033954.444483:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"633 0x7f7189ce8070 0x304eded7d260 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033954.444714:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 639
[1:1:0713/033954.444829:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 639 0x7f7189ce8070 0x304edeb65ce0 , 5:3_http://news.sznews.com/, 0, , 635 0x7f7189ce8070 0x304edeba82e0 
[1:1:0713/033954.444976:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/033954.445247:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/033954.445411:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/033954.467718:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 639, 7f718c62d8db
[1:1:0713/033954.478210:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"635 0x7f7189ce8070 0x304edeba82e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033954.480141:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"635 0x7f7189ce8070 0x304edeba82e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033954.480392:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 644
[1:1:0713/033954.480517:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 644 0x7f7189ce8070 0x304ede975de0 , 5:3_http://news.sznews.com/, 0, , 639 0x7f7189ce8070 0x304edeb65ce0 
[1:1:0713/033954.480688:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/033954.480975:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/033954.481109:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/033954.516479:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 644, 7f718c62d8db
[1:1:0713/033954.527997:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"639 0x7f7189ce8070 0x304edeb65ce0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033954.528182:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"639 0x7f7189ce8070 0x304edeb65ce0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033954.528421:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 648
[1:1:0713/033954.528555:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 648 0x7f7189ce8070 0x304edeb6a5e0 , 5:3_http://news.sznews.com/, 0, , 644 0x7f7189ce8070 0x304ede975de0 
[1:1:0713/033954.528713:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/033954.528999:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/033954.529126:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/033954.574801:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 648, 7f718c62d8db
[1:1:0713/033954.585568:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"644 0x7f7189ce8070 0x304ede975de0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033954.585866:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"644 0x7f7189ce8070 0x304ede975de0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033954.586081:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 654
[1:1:0713/033954.586217:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 654 0x7f7189ce8070 0x304eded58ae0 , 5:3_http://news.sznews.com/, 0, , 648 0x7f7189ce8070 0x304edeb6a5e0 
[1:1:0713/033954.586433:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/033954.586735:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/033954.586859:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/033954.621260:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 654, 7f718c62d8db
[1:1:0713/033954.631847:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"648 0x7f7189ce8070 0x304edeb6a5e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033954.632012:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"648 0x7f7189ce8070 0x304edeb6a5e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033954.632242:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 660
[1:1:0713/033954.632372:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 660 0x7f7189ce8070 0x304ede96f360 , 5:3_http://news.sznews.com/, 0, , 654 0x7f7189ce8070 0x304eded58ae0 
[1:1:0713/033954.632549:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/033954.632821:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/033954.632922:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/033954.664687:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 660, 7f718c62d8db
[1:1:0713/033954.674743:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"654 0x7f7189ce8070 0x304eded58ae0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033954.674909:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"654 0x7f7189ce8070 0x304eded58ae0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033954.675131:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 662
[1:1:0713/033954.675260:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 662 0x7f7189ce8070 0x304edf1e8260 , 5:3_http://news.sznews.com/, 0, , 660 0x7f7189ce8070 0x304ede96f360 
[1:1:0713/033954.675425:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/033954.675715:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/033954.675838:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/033954.690130:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 662, 7f718c62d8db
[1:1:0713/033954.699723:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"660 0x7f7189ce8070 0x304ede96f360 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033954.699859:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"660 0x7f7189ce8070 0x304ede96f360 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033954.700066:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 664
[1:1:0713/033954.700185:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 664 0x7f7189ce8070 0x304eded50860 , 5:3_http://news.sznews.com/, 0, , 662 0x7f7189ce8070 0x304edf1e8260 
[1:1:0713/033954.700320:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/033954.700547:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/033954.700668:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/033954.719493:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 664, 7f718c62d8db
[1:1:0713/033954.728616:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"662 0x7f7189ce8070 0x304edf1e8260 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033954.728752:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"662 0x7f7189ce8070 0x304edf1e8260 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033954.728941:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 666
[1:1:0713/033954.729062:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 666 0x7f7189ce8070 0x304edea91c60 , 5:3_http://news.sznews.com/, 0, , 664 0x7f7189ce8070 0x304eded50860 
[1:1:0713/033954.729253:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/033954.729549:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/033954.729705:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/033954.749480:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 666, 7f718c62d8db
[1:1:0713/033954.758559:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"664 0x7f7189ce8070 0x304eded50860 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033954.758731:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"664 0x7f7189ce8070 0x304eded50860 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033954.758978:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 668
[1:1:0713/033954.759138:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 668 0x7f7189ce8070 0x304eded6c460 , 5:3_http://news.sznews.com/, 0, , 666 0x7f7189ce8070 0x304edea91c60 
[1:1:0713/033954.759341:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/033954.759628:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/033954.759752:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/033954.779508:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 668, 7f718c62d8db
[1:1:0713/033954.788793:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"666 0x7f7189ce8070 0x304edea91c60 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033954.788940:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"666 0x7f7189ce8070 0x304edea91c60 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033954.789168:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 670
[1:1:0713/033954.789329:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 670 0x7f7189ce8070 0x304edf799860 , 5:3_http://news.sznews.com/, 0, , 668 0x7f7189ce8070 0x304eded6c460 
[1:1:0713/033954.789527:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/033954.789827:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/033954.789946:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/033954.809527:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 670, 7f718c62d8db
[1:1:0713/033954.818665:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"668 0x7f7189ce8070 0x304eded6c460 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033954.818839:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"668 0x7f7189ce8070 0x304eded6c460 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033954.819086:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 672
[1:1:0713/033954.819247:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 672 0x7f7189ce8070 0x304ede975e60 , 5:3_http://news.sznews.com/, 0, , 670 0x7f7189ce8070 0x304edf799860 
[1:1:0713/033954.819440:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/033954.819725:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/033954.819843:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/033954.839459:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 672, 7f718c62d8db
[1:1:0713/033954.848601:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"670 0x7f7189ce8070 0x304edf799860 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033954.848785:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"670 0x7f7189ce8070 0x304edf799860 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033954.848990:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 674
[1:1:0713/033954.849160:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 674 0x7f7189ce8070 0x304ede9b7360 , 5:3_http://news.sznews.com/, 0, , 672 0x7f7189ce8070 0x304ede975e60 
[1:1:0713/033954.849353:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/033954.849613:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/033954.849732:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/033954.869455:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 674, 7f718c62d8db
[1:1:0713/033954.878663:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"672 0x7f7189ce8070 0x304ede975e60 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033954.878835:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"672 0x7f7189ce8070 0x304ede975e60 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033954.879081:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 676
[1:1:0713/033954.879240:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 676 0x7f7189ce8070 0x304edf27aae0 , 5:3_http://news.sznews.com/, 0, , 674 0x7f7189ce8070 0x304ede9b7360 
[1:1:0713/033954.879442:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/033954.879725:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/033954.879841:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/033954.899407:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 676, 7f718c62d8db
[1:1:0713/033954.908625:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"674 0x7f7189ce8070 0x304ede9b7360 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033954.908787:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"674 0x7f7189ce8070 0x304ede9b7360 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033954.909005:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 678
[1:1:0713/033954.909186:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 678 0x7f7189ce8070 0x304edeba64e0 , 5:3_http://news.sznews.com/, 0, , 676 0x7f7189ce8070 0x304edf27aae0 
[1:1:0713/033954.909391:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/033954.909685:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/033954.909810:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/033954.929527:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 678, 7f718c62d8db
[1:1:0713/033954.938678:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"676 0x7f7189ce8070 0x304edf27aae0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033954.938881:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"676 0x7f7189ce8070 0x304edf27aae0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033954.939129:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 680
[1:1:0713/033954.939288:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 680 0x7f7189ce8070 0x304edea6c160 , 5:3_http://news.sznews.com/, 0, , 678 0x7f7189ce8070 0x304edeba64e0 
[1:1:0713/033954.939471:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/033954.939742:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/033954.939883:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/033954.959547:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 680, 7f718c62d8db
[1:1:0713/033954.968714:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"678 0x7f7189ce8070 0x304edeba64e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033954.968873:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"678 0x7f7189ce8070 0x304edeba64e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033954.969100:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 682
[1:1:0713/033954.969260:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 682 0x7f7189ce8070 0x304eded97160 , 5:3_http://news.sznews.com/, 0, , 680 0x7f7189ce8070 0x304edea6c160 
[1:1:0713/033954.969453:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/033954.969748:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/033954.969865:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/033954.989677:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 682, 7f718c62d8db
[1:1:0713/033954.998858:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"680 0x7f7189ce8070 0x304edea6c160 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033954.999040:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"680 0x7f7189ce8070 0x304edea6c160 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033954.999288:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 684
[1:1:0713/033954.999447:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 684 0x7f7189ce8070 0x304eded7dbe0 , 5:3_http://news.sznews.com/, 0, , 682 0x7f7189ce8070 0x304eded97160 
[1:1:0713/033954.999640:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/033954.999921:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/033955.000036:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/033955.019623:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 684, 7f718c62d8db
[1:1:0713/033955.028904:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"682 0x7f7189ce8070 0x304eded97160 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033955.029070:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"682 0x7f7189ce8070 0x304eded97160 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033955.029328:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 686
[1:1:0713/033955.029489:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 686 0x7f7189ce8070 0x304edeb6b2e0 , 5:3_http://news.sznews.com/, 0, , 684 0x7f7189ce8070 0x304eded7dbe0 
[1:1:0713/033955.029680:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/033955.029971:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/033955.030094:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/033955.049789:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 686, 7f718c62d8db
[1:1:0713/033955.059170:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"684 0x7f7189ce8070 0x304eded7dbe0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033955.059343:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"684 0x7f7189ce8070 0x304eded7dbe0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033955.059590:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 688
[1:1:0713/033955.059739:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 688 0x7f7189ce8070 0x304edeba7a60 , 5:3_http://news.sznews.com/, 0, , 686 0x7f7189ce8070 0x304edeb6b2e0 
[1:1:0713/033955.059918:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/033955.060209:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/033955.060324:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/033955.079606:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 688, 7f718c62d8db
[1:1:0713/033955.089155:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"686 0x7f7189ce8070 0x304edeb6b2e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033955.089329:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"686 0x7f7189ce8070 0x304edeb6b2e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033955.089579:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 690
[1:1:0713/033955.089739:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 690 0x7f7189ce8070 0x304eded633e0 , 5:3_http://news.sznews.com/, 0, , 688 0x7f7189ce8070 0x304edeba7a60 
[1:1:0713/033955.089934:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/033955.090230:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/033955.090347:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/033955.110138:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 690, 7f718c62d8db
[1:1:0713/033955.119497:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"688 0x7f7189ce8070 0x304edeba7a60 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033955.119673:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"688 0x7f7189ce8070 0x304edeba7a60 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033955.119922:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 692
[1:1:0713/033955.120071:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 692 0x7f7189ce8070 0x304eded7a060 , 5:3_http://news.sznews.com/, 0, , 690 0x7f7189ce8070 0x304eded633e0 
[1:1:0713/033955.120267:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/033955.120550:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/033955.120667:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/033955.131031:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 692, 7f718c62d8db
[1:1:0713/033955.140332:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"690 0x7f7189ce8070 0x304eded633e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033955.140464:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"690 0x7f7189ce8070 0x304eded633e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033955.140663:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 695
[1:1:0713/033955.140776:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 695 0x7f7189ce8070 0x304edf7999e0 , 5:3_http://news.sznews.com/, 0, , 692 0x7f7189ce8070 0x304eded7a060 
[1:1:0713/033955.140909:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/033955.141182:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/033955.141297:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/033955.155255:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 695, 7f718c62d8db
[1:1:0713/033955.165286:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"692 0x7f7189ce8070 0x304eded7a060 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033955.165442:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"692 0x7f7189ce8070 0x304eded7a060 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033955.165657:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 697
[1:1:0713/033955.165783:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 697 0x7f7189ce8070 0x304edf2146e0 , 5:3_http://news.sznews.com/, 0, , 695 0x7f7189ce8070 0x304edf7999e0 
[1:1:0713/033955.165941:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/033955.166214:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/033955.166334:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/033955.185194:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 697, 7f718c62d8db
[1:1:0713/033955.194777:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"695 0x7f7189ce8070 0x304edf7999e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033955.194954:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"695 0x7f7189ce8070 0x304edf7999e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033955.195204:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 699
[1:1:0713/033955.195366:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 699 0x7f7189ce8070 0x304ededc2ce0 , 5:3_http://news.sznews.com/, 0, , 697 0x7f7189ce8070 0x304edf2146e0 
[1:1:0713/033955.195558:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/033955.195848:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/033955.195965:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/033955.214822:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 699, 7f718c62d8db
[1:1:0713/033955.224265:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"697 0x7f7189ce8070 0x304edf2146e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033955.224427:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"697 0x7f7189ce8070 0x304edf2146e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033955.224658:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 701
[1:1:0713/033955.224768:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 701 0x7f7189ce8070 0x304edeb6ace0 , 5:3_http://news.sznews.com/, 0, , 699 0x7f7189ce8070 0x304ededc2ce0 
[1:1:0713/033955.224913:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/033955.225190:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/033955.225307:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/033955.244733:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 701, 7f718c62d8db
[1:1:0713/033955.254189:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"699 0x7f7189ce8070 0x304ededc2ce0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033955.254363:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"699 0x7f7189ce8070 0x304ededc2ce0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033955.254611:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 703
[1:1:0713/033955.254771:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 703 0x7f7189ce8070 0x304edeba78e0 , 5:3_http://news.sznews.com/, 0, , 701 0x7f7189ce8070 0x304edeb6ace0 
[1:1:0713/033955.254966:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/033955.255260:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/033955.255377:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/033955.276227:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 703, 7f718c62d8db
[1:1:0713/033955.286930:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"701 0x7f7189ce8070 0x304edeb6ace0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033955.287123:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"701 0x7f7189ce8070 0x304edeb6ace0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033955.287398:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 705
[1:1:0713/033955.287565:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 705 0x7f7189ce8070 0x304eded7d1e0 , 5:3_http://news.sznews.com/, 0, , 703 0x7f7189ce8070 0x304edeba78e0 
[1:1:0713/033955.287770:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/033955.288081:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/033955.288185:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/033955.305351:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 705, 7f718c62d8db
[1:1:0713/033955.315187:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"703 0x7f7189ce8070 0x304edeba78e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033955.315319:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"703 0x7f7189ce8070 0x304edeba78e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033955.315522:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 707
[1:1:0713/033955.315641:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 707 0x7f7189ce8070 0x304eded63de0 , 5:3_http://news.sznews.com/, 0, , 705 0x7f7189ce8070 0x304eded7d1e0 
[1:1:0713/033955.315789:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/033955.316039:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/033955.316168:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/033955.335451:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 707, 7f718c62d8db
[1:1:0713/033955.345950:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"705 0x7f7189ce8070 0x304eded7d1e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033955.346139:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"705 0x7f7189ce8070 0x304eded7d1e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033955.346400:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 709
[1:1:0713/033955.346650:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 709 0x7f7189ce8070 0x304edeb65260 , 5:3_http://news.sznews.com/, 0, , 707 0x7f7189ce8070 0x304eded63de0 
[1:1:0713/033955.346914:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/033955.347274:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/033955.347420:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/033955.365617:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 709, 7f718c62d8db
[1:1:0713/033955.375532:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"707 0x7f7189ce8070 0x304eded63de0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033955.375709:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"707 0x7f7189ce8070 0x304eded63de0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033955.375949:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 711
[1:1:0713/033955.376096:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 711 0x7f7189ce8070 0x304edf799660 , 5:3_http://news.sznews.com/, 0, , 709 0x7f7189ce8070 0x304edeb65260 
[1:1:0713/033955.376276:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/033955.376564:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/033955.376680:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/033955.395219:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 711, 7f718c62d8db
[1:1:0713/033955.404885:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"709 0x7f7189ce8070 0x304edeb65260 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033955.405009:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"709 0x7f7189ce8070 0x304edeb65260 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033955.405220:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 713
[1:1:0713/033955.405340:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 713 0x7f7189ce8070 0x304ede974d60 , 5:3_http://news.sznews.com/, 0, , 711 0x7f7189ce8070 0x304edf799660 
[1:1:0713/033955.405524:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/033955.405808:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/033955.405914:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/033957.174080:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 422, 7f718c62d8db
[1:1:0713/033957.184152:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b05cd0a2860","ptid":"375 0x7f7189ce8070 0x304edf240b60 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033957.184366:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.sznews.com/","ptid":"375 0x7f7189ce8070 0x304edf240b60 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033957.184637:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 719
[1:1:0713/033957.184778:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 719 0x7f7189ce8070 0x304ede95a6e0 , 5:3_http://news.sznews.com/, 0, , 422 0x7f7189ce8070 0x304edf1e8460 
[1:1:0713/033957.184949:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/033957.185216:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , , () {
      feature_slide();
    }
[1:1:0713/033957.185366:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/033957.200917:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.sznews.com/, 423, 7f718c62d881
[1:1:0713/033957.212100:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b05cd0a2860","ptid":"375 0x7f7189ce8070 0x304edf240b60 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033957.212295:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.sznews.com/","ptid":"375 0x7f7189ce8070 0x304edf240b60 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033957.212514:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/033957.212812:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , _fnScroll, (){
			var scrollNews = $('#scrollNews'),
				top = parseInt(scrollNews.css('top')),
				height =
[1:1:0713/033957.212911:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/033957.265623:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2230870629c8, 0x304ede390950
[1:1:0713/033957.265803:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.sznews.com/node_33500.htm", 0
[1:1:0713/033957.266013:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.sznews.com/, 721
[1:1:0713/033957.266140:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 721 0x7f7189ce8070 0x304edf799ee0 , 5:3_http://news.sznews.com/, 1, -5:3_http://news.sznews.com/, 423 0x7f7189ce8070 0x304eded4d3e0 
[1:1:0713/033957.277442:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.sznews.com/node_33500.htm", 13
[1:1:0713/033957.277807:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 723
[1:1:0713/033957.277961:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 723 0x7f7189ce8070 0x304eded575e0 , 5:3_http://news.sznews.com/, 1, -5:3_http://news.sznews.com/, 423 0x7f7189ce8070 0x304eded4d3e0 
[1:1:0713/033957.283784:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.sznews.com/, 721, 7f718c62d881
[1:1:0713/033957.295698:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b05cd0a2860","ptid":"423 0x7f7189ce8070 0x304eded4d3e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033957.295873:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.sznews.com/","ptid":"423 0x7f7189ce8070 0x304eded4d3e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033957.296087:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/033957.296362:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , , (){hb=void 0}
[1:1:0713/033957.296485:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/033957.297154:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 723, 7f718c62d8db
[1:1:0713/033957.308524:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b05cd0a2860","ptid":"423 0x7f7189ce8070 0x304eded4d3e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033957.308702:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.sznews.com/","ptid":"423 0x7f7189ce8070 0x304eded4d3e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033957.308937:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 727
[1:1:0713/033957.309059:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 727 0x7f7189ce8070 0x304edec835e0 , 5:3_http://news.sznews.com/, 0, , 723 0x7f7189ce8070 0x304eded575e0 
[1:1:0713/033957.309239:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/033957.309546:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , n.fx.tick, (){var a,b=n.timers,c=0;for(hb=n.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0713/033957.309669:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/033957.328943:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 727, 7f718c62d8db
[1:1:0713/033957.340563:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"723 0x7f7189ce8070 0x304eded575e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033957.340758:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"723 0x7f7189ce8070 0x304eded575e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033957.340982:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 729
[1:1:0713/033957.341141:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 729 0x7f7189ce8070 0x304eded5d9e0 , 5:3_http://news.sznews.com/, 0, , 727 0x7f7189ce8070 0x304edec835e0 
[1:1:0713/033957.341322:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/033957.341610:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , n.fx.tick, (){var a,b=n.timers,c=0;for(hb=n.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0713/033957.341736:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/033957.343388:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 729, 7f718c62d8db
[1:1:0713/033957.354958:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"727 0x7f7189ce8070 0x304edec835e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033957.355115:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"727 0x7f7189ce8070 0x304edec835e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033957.355338:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 731
[1:1:0713/033957.355467:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 731 0x7f7189ce8070 0x304edeb651e0 , 5:3_http://news.sznews.com/, 0, , 729 0x7f7189ce8070 0x304eded5d9e0 
[1:1:0713/033957.355611:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/033957.357210:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , n.fx.tick, (){var a,b=n.timers,c=0;for(hb=n.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0713/033957.357358:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/033957.359042:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 731, 7f718c62d8db
[1:1:0713/033957.370979:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"729 0x7f7189ce8070 0x304eded5d9e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033957.371150:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"729 0x7f7189ce8070 0x304eded5d9e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033957.371422:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 733
[1:1:0713/033957.371553:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 733 0x7f7189ce8070 0x304eded97060 , 5:3_http://news.sznews.com/, 0, , 731 0x7f7189ce8070 0x304edeb651e0 
[1:1:0713/033957.371718:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/033957.372062:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , n.fx.tick, (){var a,b=n.timers,c=0;for(hb=n.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0713/033957.372210:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/033957.393841:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 733, 7f718c62d8db
[1:1:0713/033957.405212:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"731 0x7f7189ce8070 0x304edeb651e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033957.405440:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"731 0x7f7189ce8070 0x304edeb651e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033957.405915:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 735
[1:1:0713/033957.407418:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 735 0x7f7189ce8070 0x304edf240a60 , 5:3_http://news.sznews.com/, 0, , 733 0x7f7189ce8070 0x304eded97060 
[1:1:0713/033957.407636:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/033957.407977:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , n.fx.tick, (){var a,b=n.timers,c=0;for(hb=n.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0713/033957.408116:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/033957.424416:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 735, 7f718c62d8db
[1:1:0713/033957.436325:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"733 0x7f7189ce8070 0x304eded97060 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033957.436499:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"733 0x7f7189ce8070 0x304eded97060 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033957.436741:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 738
[1:1:0713/033957.436869:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 738 0x7f7189ce8070 0x304eded97ce0 , 5:3_http://news.sznews.com/, 0, , 735 0x7f7189ce8070 0x304edf240a60 
[1:1:0713/033957.437024:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/033957.437322:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , n.fx.tick, (){var a,b=n.timers,c=0;for(hb=n.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0713/033957.437451:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/033957.458850:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 738, 7f718c62d8db
[1:1:0713/033957.470145:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"735 0x7f7189ce8070 0x304edf240a60 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033957.470361:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"735 0x7f7189ce8070 0x304edf240a60 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033957.470667:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 740
[1:1:0713/033957.470864:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 740 0x7f7189ce8070 0x304eded9f160 , 5:3_http://news.sznews.com/, 0, , 738 0x7f7189ce8070 0x304eded97ce0 
[1:1:0713/033957.471100:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/033957.471475:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , n.fx.tick, (){var a,b=n.timers,c=0;for(hb=n.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0713/033957.471608:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/033957.473448:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 740, 7f718c62d8db
[1:1:0713/033957.484789:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"738 0x7f7189ce8070 0x304eded97ce0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033957.484917:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"738 0x7f7189ce8070 0x304eded97ce0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033957.485133:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 742
[1:1:0713/033957.485270:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 742 0x7f7189ce8070 0x304eded5b560 , 5:3_http://news.sznews.com/, 0, , 740 0x7f7189ce8070 0x304eded9f160 
[1:1:0713/033957.485449:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/033957.485781:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , n.fx.tick, (){var a,b=n.timers,c=0;for(hb=n.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0713/033957.485945:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/033957.487693:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 742, 7f718c62d8db
[1:1:0713/033957.499188:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"740 0x7f7189ce8070 0x304eded9f160 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033957.499361:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"740 0x7f7189ce8070 0x304eded9f160 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033957.499613:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 744
[1:1:0713/033957.499737:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 744 0x7f7189ce8070 0x304eded95160 , 5:3_http://news.sznews.com/, 0, , 742 0x7f7189ce8070 0x304eded5b560 
[1:1:0713/033957.499894:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/033957.500139:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , n.fx.tick, (){var a,b=n.timers,c=0;for(hb=n.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0713/033957.500249:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/033957.523947:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 744, 7f718c62d8db
[1:1:0713/033957.534995:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"742 0x7f7189ce8070 0x304eded5b560 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033957.535229:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"742 0x7f7189ce8070 0x304eded5b560 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033957.535517:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 746
[1:1:0713/033957.535696:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 746 0x7f7189ce8070 0x304edeb65860 , 5:3_http://news.sznews.com/, 0, , 744 0x7f7189ce8070 0x304eded95160 
[1:1:0713/033957.535909:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/033957.536251:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , n.fx.tick, (){var a,b=n.timers,c=0;for(hb=n.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0713/033957.536392:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/033957.538243:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 746, 7f718c62d8db
[1:1:0713/033957.549712:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"744 0x7f7189ce8070 0x304eded95160 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033957.549858:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"744 0x7f7189ce8070 0x304eded95160 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033957.550081:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 748
[1:1:0713/033957.550214:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 748 0x7f7189ce8070 0x304edf882ae0 , 5:3_http://news.sznews.com/, 0, , 746 0x7f7189ce8070 0x304edeb65860 
[1:1:0713/033957.550371:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/033957.550627:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , n.fx.tick, (){var a,b=n.timers,c=0;for(hb=n.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0713/033957.550745:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/033957.552397:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 748, 7f718c62d8db
[1:1:0713/033957.564330:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"746 0x7f7189ce8070 0x304edeb65860 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033957.564501:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"746 0x7f7189ce8070 0x304edeb65860 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/033957.564724:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 750
[1:1:0713/033957.564831:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 750 0x7f7189ce8070 0x304ede633560 , 5:3_http://news.sznews.com/, 0, , 748 0x7f7189ce8070 0x304edf882ae0 
[1:1:0713/033957.565013:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/033957.565352:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , n.fx.tick, (){var a,b=n.timers,c=0;for(hb=n.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0713/033957.565516:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/033957.568403:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x2230870629c8, 0x304ede390950
[1:1:0713/033957.568534:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.sznews.com/node_33500.htm", 5000
[1:1:0713/033957.568743:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.sznews.com/, 751
[1:1:0713/033957.568864:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 751 0x7f7189ce8070 0x304edf882be0 , 5:3_http://news.sznews.com/, 1, -5:3_http://news.sznews.com/, 748 0x7f7189ce8070 0x304edf882ae0 
[1:1:0713/033958.057191:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 758 0x7f718bc102e0 0x304edebad260 , "http://news.sznews.com/node_33500.htm"
[1:1:0713/033958.057860:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , , liveCallback({"isLogined":false,"uid":null,"seccodeinit":"bafdPjneCw1mj8JXAjd9pFO6uNTOnyy0GGO0bTpm%2
[1:1:0713/033958.058040:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034001.777988:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 575, 7f718c62d8db
[1:1:0713/034001.789417:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b05cd0a2860","ptid":"374 0x7f7189ce8070 0x304eded79a60 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034001.789624:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.sznews.com/","ptid":"374 0x7f7189ce8070 0x304eded79a60 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034001.789895:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 791
[1:1:0713/034001.790061:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 791 0x7f7189ce8070 0x304edf882960 , 5:3_http://news.sznews.com/, 0, , 575 0x7f7189ce8070 0x304edf214560 
[1:1:0713/034001.790259:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034001.790592:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , uu, ()
	{
		if(dnow<oli.length-2)
		{
			oli[dnow].className=rq[dnow].className="";
			dnow++;
			oli[dn
[1:1:0713/034001.790725:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034001.791482:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.sznews.com/node_33500.htm", 15
[1:1:0713/034001.791674:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 792
[1:1:0713/034001.791802:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 792 0x7f7189ce8070 0x304ede9d8b60 , 5:3_http://news.sznews.com/, 1, -5:3_http://news.sznews.com/, 575 0x7f7189ce8070 0x304edf214560 
[1:1:0713/034001.792048:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.sznews.com/node_33500.htm", 8000
[1:1:0713/034001.792211:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 793
[1:1:0713/034001.792331:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 793 0x7f7189ce8070 0x304ede9b2460 , 5:3_http://news.sznews.com/, 1, -5:3_http://news.sznews.com/, 575 0x7f7189ce8070 0x304edf214560 
[1:1:0713/034001.818362:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 792, 7f718c62d8db
[1:1:0713/034001.829379:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b05cd0a2860","ptid":"575 0x7f7189ce8070 0x304edf214560 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034001.829579:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.sznews.com/","ptid":"575 0x7f7189ce8070 0x304edf214560 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034001.829835:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 795
[1:1:0713/034001.830019:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 795 0x7f7189ce8070 0x304edf252e60 , 5:3_http://news.sznews.com/, 0, , 792 0x7f7189ce8070 0x304ede9d8b60 
[1:1:0713/034001.830213:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034001.830515:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034001.830635:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034001.848227:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 795, 7f718c62d8db
[1:1:0713/034001.859150:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"792 0x7f7189ce8070 0x304ede9d8b60 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034001.859296:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"792 0x7f7189ce8070 0x304ede9d8b60 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034001.859505:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 797
[1:1:0713/034001.859633:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 797 0x7f7189ce8070 0x304eded56560 , 5:3_http://news.sznews.com/, 0, , 795 0x7f7189ce8070 0x304edf252e60 
[1:1:0713/034001.859785:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034001.860039:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034001.860161:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034001.877831:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 797, 7f718c62d8db
[1:1:0713/034001.888456:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"795 0x7f7189ce8070 0x304edf252e60 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034001.888619:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"795 0x7f7189ce8070 0x304edf252e60 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034001.888879:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 799
[1:1:0713/034001.888980:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 799 0x7f7189ce8070 0x304edecf34e0 , 5:3_http://news.sznews.com/, 0, , 797 0x7f7189ce8070 0x304eded56560 
[1:1:0713/034001.889157:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034001.889455:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034001.889609:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034001.907805:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 799, 7f718c62d8db
[1:1:0713/034001.918392:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"797 0x7f7189ce8070 0x304eded56560 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034001.918564:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"797 0x7f7189ce8070 0x304eded56560 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034001.918814:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 801
[1:1:0713/034001.918936:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 801 0x7f7189ce8070 0x304edf1e8160 , 5:3_http://news.sznews.com/, 0, , 799 0x7f7189ce8070 0x304edecf34e0 
[1:1:0713/034001.919093:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034001.919346:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034001.919462:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034001.937785:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 801, 7f718c62d8db
[1:1:0713/034001.948546:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"799 0x7f7189ce8070 0x304edecf34e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034001.948710:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"799 0x7f7189ce8070 0x304edecf34e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034001.948936:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 803
[1:1:0713/034001.949048:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 803 0x7f7189ce8070 0x304edf7a92e0 , 5:3_http://news.sznews.com/, 0, , 801 0x7f7189ce8070 0x304edf1e8160 
[1:1:0713/034001.949248:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034001.949547:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034001.949712:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034001.967691:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 803, 7f718c62d8db
[1:1:0713/034001.978285:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"801 0x7f7189ce8070 0x304edf1e8160 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034001.978457:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"801 0x7f7189ce8070 0x304edf1e8160 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034001.978753:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 805
[1:1:0713/034001.978913:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 805 0x7f7189ce8070 0x304edeba8ae0 , 5:3_http://news.sznews.com/, 0, , 803 0x7f7189ce8070 0x304edf7a92e0 
[1:1:0713/034001.979107:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034001.979413:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034001.979534:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034001.997761:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 805, 7f718c62d8db
[1:1:0713/034002.008391:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"803 0x7f7189ce8070 0x304edf7a92e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034002.008553:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"803 0x7f7189ce8070 0x304edf7a92e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034002.008780:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 807
[1:1:0713/034002.008879:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 807 0x7f7189ce8070 0x304eded65d60 , 5:3_http://news.sznews.com/, 0, , 805 0x7f7189ce8070 0x304edeba8ae0 
[1:1:0713/034002.008988:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034002.009224:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034002.009341:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034002.027711:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 807, 7f718c62d8db
[1:1:0713/034002.038344:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"805 0x7f7189ce8070 0x304edeba8ae0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034002.038521:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"805 0x7f7189ce8070 0x304edeba8ae0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034002.038724:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 809
[1:1:0713/034002.038883:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 809 0x7f7189ce8070 0x304edf882160 , 5:3_http://news.sznews.com/, 0, , 807 0x7f7189ce8070 0x304eded65d60 
[1:1:0713/034002.039031:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034002.039310:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034002.039425:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034002.057910:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 809, 7f718c62d8db
[1:1:0713/034002.068618:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"807 0x7f7189ce8070 0x304eded65d60 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034002.068781:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"807 0x7f7189ce8070 0x304eded65d60 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034002.068974:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 811
[1:1:0713/034002.069103:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 811 0x7f7189ce8070 0x304ededb57e0 , 5:3_http://news.sznews.com/, 0, , 809 0x7f7189ce8070 0x304edf882160 
[1:1:0713/034002.069269:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034002.069567:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034002.069693:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034002.087798:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 811, 7f718c62d8db
[1:1:0713/034002.098563:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"809 0x7f7189ce8070 0x304edf882160 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034002.098744:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"809 0x7f7189ce8070 0x304edf882160 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034002.098994:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 813
[1:1:0713/034002.099155:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 813 0x7f7189ce8070 0x304ede5b9060 , 5:3_http://news.sznews.com/, 0, , 811 0x7f7189ce8070 0x304ededb57e0 
[1:1:0713/034002.099336:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034002.099616:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034002.099733:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034002.117766:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 813, 7f718c62d8db
[1:1:0713/034002.128420:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"811 0x7f7189ce8070 0x304ededb57e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034002.128582:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"811 0x7f7189ce8070 0x304ededb57e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034002.128800:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 815
[1:1:0713/034002.128905:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 815 0x7f7189ce8070 0x304edf940560 , 5:3_http://news.sznews.com/, 0, , 813 0x7f7189ce8070 0x304ede5b9060 
[1:1:0713/034002.129048:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034002.129371:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034002.129526:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034002.147873:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 815, 7f718c62d8db
[1:1:0713/034002.158652:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"813 0x7f7189ce8070 0x304ede5b9060 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034002.158832:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"813 0x7f7189ce8070 0x304ede5b9060 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034002.159041:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 817
[1:1:0713/034002.159162:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 817 0x7f7189ce8070 0x304ede97b660 , 5:3_http://news.sznews.com/, 0, , 815 0x7f7189ce8070 0x304edf940560 
[1:1:0713/034002.159304:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034002.159557:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034002.159674:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034002.173906:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 719, 7f718c62d8db
[1:1:0713/034002.184594:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"422 0x7f7189ce8070 0x304edf1e8460 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034002.184727:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"422 0x7f7189ce8070 0x304edf1e8460 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034002.184916:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 820
[1:1:0713/034002.185012:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 820 0x7f7189ce8070 0x304eded640e0 , 5:3_http://news.sznews.com/, 0, , 719 0x7f7189ce8070 0x304ede95a6e0 
[1:1:0713/034002.185148:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034002.185391:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , , () {
      feature_slide();
    }
[1:1:0713/034002.185507:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034002.192370:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 817, 7f718c62d8db
[1:1:0713/034002.203541:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"815 0x7f7189ce8070 0x304edf940560 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034002.203675:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"815 0x7f7189ce8070 0x304edf940560 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034002.203885:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 821
[1:1:0713/034002.204005:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 821 0x7f7189ce8070 0x304edf1e8b60 , 5:3_http://news.sznews.com/, 0, , 817 0x7f7189ce8070 0x304ede97b660 
[1:1:0713/034002.204154:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034002.204392:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034002.204516:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034002.223313:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 821, 7f718c62d8db
[1:1:0713/034002.234306:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"817 0x7f7189ce8070 0x304ede97b660 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034002.234484:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"817 0x7f7189ce8070 0x304ede97b660 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034002.234737:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 824
[1:1:0713/034002.234898:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 824 0x7f7189ce8070 0x304edf7e9060 , 5:3_http://news.sznews.com/, 0, , 821 0x7f7189ce8070 0x304edf1e8b60 
[1:1:0713/034002.235082:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034002.235373:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034002.235491:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034002.247489:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 824, 7f718c62d8db
[1:1:0713/034002.258377:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"821 0x7f7189ce8070 0x304edf1e8b60 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034002.258511:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"821 0x7f7189ce8070 0x304edf1e8b60 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034002.258714:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 826
[1:1:0713/034002.258835:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 826 0x7f7189ce8070 0x304ede9866e0 , 5:3_http://news.sznews.com/, 0, , 824 0x7f7189ce8070 0x304edf7e9060 
[1:1:0713/034002.258983:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034002.259228:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034002.259343:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034002.283018:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 826, 7f718c62d8db
[1:1:0713/034002.293933:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"824 0x7f7189ce8070 0x304edf7e9060 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034002.294117:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"824 0x7f7189ce8070 0x304edf7e9060 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034002.294368:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 828
[1:1:0713/034002.294530:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 828 0x7f7189ce8070 0x304edf7e9fe0 , 5:3_http://news.sznews.com/, 0, , 826 0x7f7189ce8070 0x304ede9866e0 
[1:1:0713/034002.294723:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034002.295022:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034002.295142:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034002.307122:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 828, 7f718c62d8db
[1:1:0713/034002.318065:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"826 0x7f7189ce8070 0x304ede9866e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034002.318205:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"826 0x7f7189ce8070 0x304ede9866e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034002.318407:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 831
[1:1:0713/034002.318528:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 831 0x7f7189ce8070 0x304ededb6960 , 5:3_http://news.sznews.com/, 0, , 828 0x7f7189ce8070 0x304edf7e9fe0 
[1:1:0713/034002.318674:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034002.318921:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034002.319037:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034002.343051:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 831, 7f718c62d8db
[1:1:0713/034002.353941:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"828 0x7f7189ce8070 0x304edf7e9fe0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034002.354117:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"828 0x7f7189ce8070 0x304edf7e9fe0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034002.354367:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 833
[1:1:0713/034002.354528:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 833 0x7f7189ce8070 0x304eded7a0e0 , 5:3_http://news.sznews.com/, 0, , 831 0x7f7189ce8070 0x304ededb6960 
[1:1:0713/034002.354735:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034002.355034:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034002.355154:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034002.373082:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 833, 7f718c62d8db
[1:1:0713/034002.383963:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"831 0x7f7189ce8070 0x304ededb6960 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034002.384127:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"831 0x7f7189ce8070 0x304ededb6960 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034002.384360:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 835
[1:1:0713/034002.384506:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 835 0x7f7189ce8070 0x304eded59260 , 5:3_http://news.sznews.com/, 0, , 833 0x7f7189ce8070 0x304eded7a0e0 
[1:1:0713/034002.384669:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034002.384907:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034002.385001:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034002.403009:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 835, 7f718c62d8db
[1:1:0713/034002.413950:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"833 0x7f7189ce8070 0x304eded7a0e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034002.414124:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"833 0x7f7189ce8070 0x304eded7a0e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034002.414375:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 837
[1:1:0713/034002.414537:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 837 0x7f7189ce8070 0x304eded625e0 , 5:3_http://news.sznews.com/, 0, , 835 0x7f7189ce8070 0x304eded59260 
[1:1:0713/034002.414729:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034002.415024:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034002.415143:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034002.433352:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 837, 7f718c62d8db
[1:1:0713/034002.444454:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"835 0x7f7189ce8070 0x304eded59260 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034002.444617:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"835 0x7f7189ce8070 0x304eded59260 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034002.444842:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 839
[1:1:0713/034002.444945:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 839 0x7f7189ce8070 0x304edecedb60 , 5:3_http://news.sznews.com/, 0, , 837 0x7f7189ce8070 0x304eded625e0 
[1:1:0713/034002.445111:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034002.445416:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034002.445572:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034002.463229:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 839, 7f718c62d8db
[1:1:0713/034002.474291:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"837 0x7f7189ce8070 0x304eded625e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034002.474426:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"837 0x7f7189ce8070 0x304eded625e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034002.474630:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 841
[1:1:0713/034002.474750:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 841 0x7f7189ce8070 0x304eded95fe0 , 5:3_http://news.sznews.com/, 0, , 839 0x7f7189ce8070 0x304edecedb60 
[1:1:0713/034002.474902:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034002.475151:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034002.475266:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034002.493194:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 841, 7f718c62d8db
[1:1:0713/034002.504198:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"839 0x7f7189ce8070 0x304edecedb60 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034002.504363:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"839 0x7f7189ce8070 0x304edecedb60 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034002.504585:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 843
[1:1:0713/034002.504717:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 843 0x7f7189ce8070 0x304eded58a60 , 5:3_http://news.sznews.com/, 0, , 841 0x7f7189ce8070 0x304eded95fe0 
[1:1:0713/034002.504864:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034002.505143:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034002.505301:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034002.523151:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 843, 7f718c62d8db
[1:1:0713/034002.534253:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"841 0x7f7189ce8070 0x304eded95fe0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034002.534391:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"841 0x7f7189ce8070 0x304eded95fe0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034002.534595:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 845
[1:1:0713/034002.534717:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 845 0x7f7189ce8070 0x304edf882a60 , 5:3_http://news.sznews.com/, 0, , 843 0x7f7189ce8070 0x304eded58a60 
[1:1:0713/034002.534864:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034002.535140:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034002.535258:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034002.553289:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 845, 7f718c62d8db
[1:1:0713/034002.564568:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"843 0x7f7189ce8070 0x304eded58a60 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034002.564743:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"843 0x7f7189ce8070 0x304eded58a60 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034002.564949:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 847
[1:1:0713/034002.565081:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 847 0x7f7189ce8070 0x304ededce060 , 5:3_http://news.sznews.com/, 0, , 845 0x7f7189ce8070 0x304edf882a60 
[1:1:0713/034002.565264:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034002.565564:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034002.565683:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034002.580316:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.sznews.com/, 751, 7f718c62d881
[1:1:0713/034002.591359:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b05cd0a2860","ptid":"748 0x7f7189ce8070 0x304edf882ae0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034002.591504:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.sznews.com/","ptid":"748 0x7f7189ce8070 0x304edf882ae0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034002.591704:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034002.591968:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , _fnScroll, (){
			var scrollNews = $('#scrollNews'),
				top = parseInt(scrollNews.css('top')),
				height =
[1:1:0713/034002.592102:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034002.613994:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2230870629c8, 0x304ede390950
[1:1:0713/034002.614141:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.sznews.com/node_33500.htm", 0
[1:1:0713/034002.614337:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.sznews.com/, 850
[1:1:0713/034002.614462:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 850 0x7f7189ce8070 0x304ededc3fe0 , 5:3_http://news.sznews.com/, 1, -5:3_http://news.sznews.com/, 751 0x7f7189ce8070 0x304edf882be0 
[1:1:0713/034002.621162:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.sznews.com/node_33500.htm", 13
[1:1:0713/034002.621360:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 851
[1:1:0713/034002.621484:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 851 0x7f7189ce8070 0x304ede96ef60 , 5:3_http://news.sznews.com/, 1, -5:3_http://news.sznews.com/, 751 0x7f7189ce8070 0x304edf882be0 
[1:1:0713/034002.627062:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 847, 7f718c62d8db
[1:1:0713/034002.639652:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"845 0x7f7189ce8070 0x304edf882a60 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034002.639789:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"845 0x7f7189ce8070 0x304edf882a60 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034002.640006:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 853
[1:1:0713/034002.640129:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 853 0x7f7189ce8070 0x304edf9159e0 , 5:3_http://news.sznews.com/, 0, , 847 0x7f7189ce8070 0x304ededce060 
[1:1:0713/034002.640268:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034002.640510:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034002.640621:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034002.641420:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.sznews.com/, 850, 7f718c62d881
[1:1:0713/034002.653226:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b05cd0a2860","ptid":"751 0x7f7189ce8070 0x304edf882be0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034002.653369:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.sznews.com/","ptid":"751 0x7f7189ce8070 0x304edf882be0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034002.653556:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034002.653795:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , , (){hb=void 0}
[1:1:0713/034002.653910:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034002.654348:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 851, 7f718c62d8db
[1:1:0713/034002.665939:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b05cd0a2860","ptid":"751 0x7f7189ce8070 0x304edf882be0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034002.666077:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.sznews.com/","ptid":"751 0x7f7189ce8070 0x304edf882be0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034002.666282:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 856
[1:1:0713/034002.666401:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 856 0x7f7189ce8070 0x304eded56f60 , 5:3_http://news.sznews.com/, 0, , 851 0x7f7189ce8070 0x304ede96ef60 
[1:1:0713/034002.666545:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034002.666778:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , n.fx.tick, (){var a,b=n.timers,c=0;for(hb=n.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0713/034002.666898:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034002.680073:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 853, 7f718c62d8db
[1:1:0713/034002.691459:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"847 0x7f7189ce8070 0x304ededce060 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034002.691604:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"847 0x7f7189ce8070 0x304ededce060 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034002.691807:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 858
[1:1:0713/034002.691928:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 858 0x7f7189ce8070 0x304ededb59e0 , 5:3_http://news.sznews.com/, 0, , 853 0x7f7189ce8070 0x304edf9159e0 
[1:1:0713/034002.692081:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034002.692355:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034002.692470:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034002.695211:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 856, 7f718c62d8db
[1:1:0713/034002.707308:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"851 0x7f7189ce8070 0x304ede96ef60 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034002.707447:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"851 0x7f7189ce8070 0x304ede96ef60 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034002.707659:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 859
[1:1:0713/034002.707780:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 859 0x7f7189ce8070 0x304ede4750e0 , 5:3_http://news.sznews.com/, 0, , 856 0x7f7189ce8070 0x304eded56f60 
[1:1:0713/034002.707931:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034002.708176:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , n.fx.tick, (){var a,b=n.timers,c=0;for(hb=n.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0713/034002.708280:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034002.709845:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 858, 7f718c62d8db
[1:1:0713/034002.721753:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"853 0x7f7189ce8070 0x304edf9159e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034002.721886:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"853 0x7f7189ce8070 0x304edf9159e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034002.722141:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 861
[1:1:0713/034002.722262:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 861 0x7f7189ce8070 0x304edf7993e0 , 5:3_http://news.sznews.com/, 0, , 858 0x7f7189ce8070 0x304ededb59e0 
[1:1:0713/034002.722399:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034002.722632:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034002.722746:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034002.725417:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 859, 7f718c62d8db
[1:1:0713/034002.737583:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"856 0x7f7189ce8070 0x304eded56f60 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034002.737718:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"856 0x7f7189ce8070 0x304eded56f60 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034002.737929:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 863
[1:1:0713/034002.738057:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 863 0x7f7189ce8070 0x304ede96e1e0 , 5:3_http://news.sznews.com/, 0, , 859 0x7f7189ce8070 0x304ede4750e0 
[1:1:0713/034002.738196:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034002.738439:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , n.fx.tick, (){var a,b=n.timers,c=0;for(hb=n.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0713/034002.738554:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034002.751983:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 861, 7f718c62d8db
[1:1:0713/034002.763576:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"858 0x7f7189ce8070 0x304ededb59e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034002.763718:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"858 0x7f7189ce8070 0x304ededb59e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034002.763922:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 866
[1:1:0713/034002.764043:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 866 0x7f7189ce8070 0x304edf1e8de0 , 5:3_http://news.sznews.com/, 0, , 861 0x7f7189ce8070 0x304edf7993e0 
[1:1:0713/034002.764189:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034002.764435:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034002.764550:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034002.767248:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 863, 7f718c62d8db
[1:1:0713/034002.779424:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"859 0x7f7189ce8070 0x304ede4750e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034002.779564:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"859 0x7f7189ce8070 0x304ede4750e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034002.779764:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 868
[1:1:0713/034002.779870:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 868 0x7f7189ce8070 0x304edf1e8460 , 5:3_http://news.sznews.com/, 0, , 863 0x7f7189ce8070 0x304ede96e1e0 
[1:1:0713/034002.780011:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034002.780255:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , n.fx.tick, (){var a,b=n.timers,c=0;for(hb=n.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0713/034002.780375:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034002.781923:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 866, 7f718c62d8db
[1:1:0713/034002.793838:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"861 0x7f7189ce8070 0x304edf7993e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034002.793969:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"861 0x7f7189ce8070 0x304edf7993e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034002.794176:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 869
[1:1:0713/034002.794295:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 869 0x7f7189ce8070 0x304edeac7360 , 5:3_http://news.sznews.com/, 0, , 866 0x7f7189ce8070 0x304edf1e8de0 
[1:1:0713/034002.794432:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034002.794665:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034002.794779:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034002.797439:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 868, 7f718c62d8db
[1:1:0713/034002.809572:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"863 0x7f7189ce8070 0x304ede96e1e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034002.809707:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"863 0x7f7189ce8070 0x304ede96e1e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034002.809918:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 872
[1:1:0713/034002.810039:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 872 0x7f7189ce8070 0x304eded4dee0 , 5:3_http://news.sznews.com/, 0, , 868 0x7f7189ce8070 0x304edf1e8460 
[1:1:0713/034002.810187:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034002.810436:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , n.fx.tick, (){var a,b=n.timers,c=0;for(hb=n.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0713/034002.810558:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034002.824088:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 869, 7f718c62d8db
[1:1:0713/034002.835697:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"866 0x7f7189ce8070 0x304edf1e8de0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034002.835841:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"866 0x7f7189ce8070 0x304edf1e8de0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034002.836047:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 874
[1:1:0713/034002.836168:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 874 0x7f7189ce8070 0x304eded62be0 , 5:3_http://news.sznews.com/, 0, , 869 0x7f7189ce8070 0x304edeac7360 
[1:1:0713/034002.836324:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034002.836566:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034002.836669:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034002.839361:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 872, 7f718c62d8db
[1:1:0713/034002.851409:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"868 0x7f7189ce8070 0x304edf1e8460 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034002.851545:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"868 0x7f7189ce8070 0x304edf1e8460 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034002.851756:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 875
[1:1:0713/034002.851876:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 875 0x7f7189ce8070 0x304edf27ade0 , 5:3_http://news.sznews.com/, 0, , 872 0x7f7189ce8070 0x304eded4dee0 
[1:1:0713/034002.852013:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034002.852254:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , n.fx.tick, (){var a,b=n.timers,c=0;for(hb=n.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0713/034002.852372:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034002.853944:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 874, 7f718c62d8db
[1:1:0713/034002.865998:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"869 0x7f7189ce8070 0x304edeac7360 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034002.866130:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"869 0x7f7189ce8070 0x304edeac7360 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034002.866343:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 877
[1:1:0713/034002.866464:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 877 0x7f7189ce8070 0x304edea8ca60 , 5:3_http://news.sznews.com/, 0, , 874 0x7f7189ce8070 0x304eded62be0 
[1:1:0713/034002.866600:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034002.866835:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034002.866951:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034002.869612:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 875, 7f718c62d8db
[1:1:0713/034002.881830:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"872 0x7f7189ce8070 0x304eded4dee0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034002.881966:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"872 0x7f7189ce8070 0x304eded4dee0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034002.882176:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 879
[1:1:0713/034002.882296:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 879 0x7f7189ce8070 0x304edeb77f60 , 5:3_http://news.sznews.com/, 0, , 875 0x7f7189ce8070 0x304edf27ade0 
[1:1:0713/034002.882433:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034002.882671:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , n.fx.tick, (){var a,b=n.timers,c=0;for(hb=n.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0713/034002.882787:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034002.896272:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 877, 7f718c62d8db
[1:1:0713/034002.907888:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"874 0x7f7189ce8070 0x304eded62be0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034002.908025:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"874 0x7f7189ce8070 0x304eded62be0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034002.908227:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 882
[1:1:0713/034002.908345:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 882 0x7f7189ce8070 0x304edf1e8be0 , 5:3_http://news.sznews.com/, 0, , 877 0x7f7189ce8070 0x304edea8ca60 
[1:1:0713/034002.908490:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034002.908716:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034002.908824:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034002.911487:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 879, 7f718c62d8db
[1:1:0713/034002.923679:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"875 0x7f7189ce8070 0x304edf27ade0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034002.923819:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"875 0x7f7189ce8070 0x304edf27ade0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034002.924032:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 883
[1:1:0713/034002.924152:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 883 0x7f7189ce8070 0x304edeb15660 , 5:3_http://news.sznews.com/, 0, , 879 0x7f7189ce8070 0x304edeb77f60 
[1:1:0713/034002.924298:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034002.924531:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , n.fx.tick, (){var a,b=n.timers,c=0;for(hb=n.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0713/034002.924632:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034002.926965:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x2230870629c8, 0x304ede390950
[1:1:0713/034002.927081:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.sznews.com/node_33500.htm", 5000
[1:1:0713/034002.927260:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.sznews.com/, 884
[1:1:0713/034002.927380:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 884 0x7f7189ce8070 0x304eded4f760 , 5:3_http://news.sznews.com/, 1, -5:3_http://news.sznews.com/, 879 0x7f7189ce8070 0x304edeb77f60 
[1:1:0713/034002.929761:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 882, 7f718c62d8db
[1:1:0713/034002.942087:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"877 0x7f7189ce8070 0x304edea8ca60 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034002.942219:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"877 0x7f7189ce8070 0x304edea8ca60 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034002.942427:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 886
[1:1:0713/034002.942548:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 886 0x7f7189ce8070 0x304eded95160 , 5:3_http://news.sznews.com/, 0, , 882 0x7f7189ce8070 0x304edf1e8be0 
[1:1:0713/034002.942693:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034002.942928:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034002.943050:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034002.959115:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 886, 7f718c62d8db
[1:1:0713/034002.970963:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"882 0x7f7189ce8070 0x304edf1e8be0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034002.971106:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"882 0x7f7189ce8070 0x304edf1e8be0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034002.971313:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 888
[1:1:0713/034002.971436:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 888 0x7f7189ce8070 0x304ede476460 , 5:3_http://news.sznews.com/, 0, , 886 0x7f7189ce8070 0x304eded95160 
[1:1:0713/034002.971584:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034002.971838:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034002.971955:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034002.988706:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 888, 7f718c62d8db
[1:1:0713/034003.000218:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"886 0x7f7189ce8070 0x304eded95160 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034003.000352:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"886 0x7f7189ce8070 0x304eded95160 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034003.000555:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 890
[1:1:0713/034003.000664:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 890 0x7f7189ce8070 0x304eded9f760 , 5:3_http://news.sznews.com/, 0, , 888 0x7f7189ce8070 0x304ede476460 
[1:1:0713/034003.000794:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034003.001026:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034003.001174:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034003.018597:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 890, 7f718c62d8db
[1:1:0713/034003.030183:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"888 0x7f7189ce8070 0x304ede476460 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034003.030401:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"888 0x7f7189ce8070 0x304ede476460 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034003.030663:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 892
[1:1:0713/034003.030825:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 892 0x7f7189ce8070 0x304edec2c4e0 , 5:3_http://news.sznews.com/, 0, , 890 0x7f7189ce8070 0x304eded9f760 
[1:1:0713/034003.031010:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034003.031284:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034003.031415:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034003.048837:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 892, 7f718c62d8db
[1:1:0713/034003.060421:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"890 0x7f7189ce8070 0x304eded9f760 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034003.060597:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"890 0x7f7189ce8070 0x304eded9f760 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034003.060824:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 894
[1:1:0713/034003.060952:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 894 0x7f7189ce8070 0x304ede8727e0 , 5:3_http://news.sznews.com/, 0, , 892 0x7f7189ce8070 0x304edec2c4e0 
[1:1:0713/034003.061084:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034003.061381:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034003.061535:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034003.078567:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 894, 7f718c62d8db
[1:1:0713/034003.090090:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"892 0x7f7189ce8070 0x304edec2c4e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034003.090265:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"892 0x7f7189ce8070 0x304edec2c4e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034003.090517:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 896
[1:1:0713/034003.090676:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 896 0x7f7189ce8070 0x304ededb5ae0 , 5:3_http://news.sznews.com/, 0, , 894 0x7f7189ce8070 0x304ede8727e0 
[1:1:0713/034003.090867:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034003.091174:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034003.091294:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034003.108643:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 896, 7f718c62d8db
[1:1:0713/034003.120184:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"894 0x7f7189ce8070 0x304ede8727e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034003.120355:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"894 0x7f7189ce8070 0x304ede8727e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034003.120594:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 898
[1:1:0713/034003.120729:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 898 0x7f7189ce8070 0x304ede633060 , 5:3_http://news.sznews.com/, 0, , 896 0x7f7189ce8070 0x304ededb5ae0 
[1:1:0713/034003.120892:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034003.121147:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034003.121267:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034003.138642:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 898, 7f718c62d8db
[1:1:0713/034003.150166:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"896 0x7f7189ce8070 0x304ededb5ae0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034003.150302:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"896 0x7f7189ce8070 0x304ededb5ae0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034003.150504:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 900
[1:1:0713/034003.150623:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 900 0x7f7189ce8070 0x304edf252e60 , 5:3_http://news.sznews.com/, 0, , 898 0x7f7189ce8070 0x304ede633060 
[1:1:0713/034003.150756:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034003.150993:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034003.151087:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034003.168522:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 900, 7f718c62d8db
[1:1:0713/034003.179996:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"898 0x7f7189ce8070 0x304ede633060 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034003.180131:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"898 0x7f7189ce8070 0x304ede633060 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034003.180321:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 902
[1:1:0713/034003.180423:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 902 0x7f7189ce8070 0x304ede97bce0 , 5:3_http://news.sznews.com/, 0, , 900 0x7f7189ce8070 0x304edf252e60 
[1:1:0713/034003.180533:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034003.180793:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034003.180886:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034003.198592:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 902, 7f718c62d8db
[1:1:0713/034003.210048:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"900 0x7f7189ce8070 0x304edf252e60 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034003.210182:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"900 0x7f7189ce8070 0x304edf252e60 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034003.210371:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 904
[1:1:0713/034003.210475:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 904 0x7f7189ce8070 0x304edf214560 , 5:3_http://news.sznews.com/, 0, , 902 0x7f7189ce8070 0x304ede97bce0 
[1:1:0713/034003.210600:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034003.210823:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034003.210937:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034003.228544:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 904, 7f718c62d8db
[1:1:0713/034003.240082:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"902 0x7f7189ce8070 0x304ede97bce0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034003.240216:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"902 0x7f7189ce8070 0x304ede97bce0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034003.240405:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 906
[1:1:0713/034003.240512:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 906 0x7f7189ce8070 0x304eded59160 , 5:3_http://news.sznews.com/, 0, , 904 0x7f7189ce8070 0x304edf214560 
[1:1:0713/034003.240648:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034003.240885:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034003.240978:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034007.177559:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 820, 7f718c62d8db
[1:1:0713/034007.190340:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"719 0x7f7189ce8070 0x304ede95a6e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034007.190522:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"719 0x7f7189ce8070 0x304ede95a6e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034007.190785:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 908
[1:1:0713/034007.190948:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 908 0x7f7189ce8070 0x304eded64060 , 5:3_http://news.sznews.com/, 0, , 820 0x7f7189ce8070 0x304eded640e0 
[1:1:0713/034007.191146:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034007.191470:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , , () {
      feature_slide();
    }
[1:1:0713/034007.191589:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034007.940930:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.sznews.com/, 884, 7f718c62d881
[1:1:0713/034007.953494:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b05cd0a2860","ptid":"879 0x7f7189ce8070 0x304edeb77f60 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034007.953686:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.sznews.com/","ptid":"879 0x7f7189ce8070 0x304edeb77f60 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034007.953932:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034007.954285:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , _fnScroll, (){
			var scrollNews = $('#scrollNews'),
				top = parseInt(scrollNews.css('top')),
				height =
[1:1:0713/034007.954441:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034007.975696:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2230870629c8, 0x304ede390950
[1:1:0713/034007.975832:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.sznews.com/node_33500.htm", 0
[1:1:0713/034007.976023:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.sznews.com/, 910
[1:1:0713/034007.976154:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 910 0x7f7189ce8070 0x304eded97960 , 5:3_http://news.sznews.com/, 1, -5:3_http://news.sznews.com/, 884 0x7f7189ce8070 0x304eded4f760 
[1:1:0713/034007.982092:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.sznews.com/node_33500.htm", 13
[1:1:0713/034007.982293:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 911
[1:1:0713/034007.982421:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 911 0x7f7189ce8070 0x304edf7e9ae0 , 5:3_http://news.sznews.com/, 1, -5:3_http://news.sznews.com/, 884 0x7f7189ce8070 0x304eded4f760 
[1:1:0713/034007.988039:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.sznews.com/, 910, 7f718c62d881
[1:1:0713/034008.001425:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b05cd0a2860","ptid":"884 0x7f7189ce8070 0x304eded4f760 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034008.001573:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.sznews.com/","ptid":"884 0x7f7189ce8070 0x304eded4f760 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034008.001770:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034008.002016:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , , (){hb=void 0}
[1:1:0713/034008.002130:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034008.002577:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 911, 7f718c62d8db
[1:1:0713/034008.014977:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b05cd0a2860","ptid":"884 0x7f7189ce8070 0x304eded4f760 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034008.015119:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.sznews.com/","ptid":"884 0x7f7189ce8070 0x304eded4f760 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034008.015326:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 914
[1:1:0713/034008.015446:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 914 0x7f7189ce8070 0x304edf7e9ce0 , 5:3_http://news.sznews.com/, 0, , 911 0x7f7189ce8070 0x304edf7e9ae0 
[1:1:0713/034008.015588:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034008.015821:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , n.fx.tick, (){var a,b=n.timers,c=0;for(hb=n.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0713/034008.015939:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034008.033776:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 914, 7f718c62d8db
[1:1:0713/034008.045999:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"911 0x7f7189ce8070 0x304edf7e9ae0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034008.046142:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"911 0x7f7189ce8070 0x304edf7e9ae0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034008.046346:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 916
[1:1:0713/034008.046467:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 916 0x7f7189ce8070 0x304eded53de0 , 5:3_http://news.sznews.com/, 0, , 914 0x7f7189ce8070 0x304edf7e9ce0 
[1:1:0713/034008.046621:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034008.046871:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , n.fx.tick, (){var a,b=n.timers,c=0;for(hb=n.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0713/034008.046987:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034008.048493:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 916, 7f718c62d8db
[1:1:0713/034008.060721:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"914 0x7f7189ce8070 0x304edf7e9ce0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034008.060854:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"914 0x7f7189ce8070 0x304edf7e9ce0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034008.061077:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 918
[1:1:0713/034008.061199:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 918 0x7f7189ce8070 0x304edeac7ee0 , 5:3_http://news.sznews.com/, 0, , 916 0x7f7189ce8070 0x304eded53de0 
[1:1:0713/034008.061343:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034008.061577:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , n.fx.tick, (){var a,b=n.timers,c=0;for(hb=n.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0713/034008.061693:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034008.085750:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 918, 7f718c62d8db
[1:1:0713/034008.097763:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"916 0x7f7189ce8070 0x304eded53de0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034008.097937:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"916 0x7f7189ce8070 0x304eded53de0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034008.098187:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 920
[1:1:0713/034008.098349:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 920 0x7f7189ce8070 0x304ede9717e0 , 5:3_http://news.sznews.com/, 0, , 918 0x7f7189ce8070 0x304edeac7ee0 
[1:1:0713/034008.098536:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034008.098820:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , n.fx.tick, (){var a,b=n.timers,c=0;for(hb=n.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0713/034008.098951:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034008.100472:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 920, 7f718c62d8db
[1:1:0713/034008.112660:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"918 0x7f7189ce8070 0x304edeac7ee0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034008.112793:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"918 0x7f7189ce8070 0x304edeac7ee0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034008.112988:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 922
[1:1:0713/034008.113099:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 922 0x7f7189ce8070 0x304edea6c7e0 , 5:3_http://news.sznews.com/, 0, , 920 0x7f7189ce8070 0x304ede9717e0 
[1:1:0713/034008.113244:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034008.113479:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , n.fx.tick, (){var a,b=n.timers,c=0;for(hb=n.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0713/034008.113595:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034008.137687:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 922, 7f718c62d8db
[1:1:0713/034008.149625:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"920 0x7f7189ce8070 0x304ede9717e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034008.149799:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"920 0x7f7189ce8070 0x304ede9717e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034008.150038:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 924
[1:1:0713/034008.150179:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 924 0x7f7189ce8070 0x304ede9708e0 , 5:3_http://news.sznews.com/, 0, , 922 0x7f7189ce8070 0x304edea6c7e0 
[1:1:0713/034008.150300:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034008.150602:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , n.fx.tick, (){var a,b=n.timers,c=0;for(hb=n.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0713/034008.150720:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034008.152307:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 924, 7f718c62d8db
[1:1:0713/034008.164453:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"922 0x7f7189ce8070 0x304edea6c7e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034008.164589:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"922 0x7f7189ce8070 0x304edea6c7e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034008.164782:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 926
[1:1:0713/034008.164885:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 926 0x7f7189ce8070 0x304ede9d8b60 , 5:3_http://news.sznews.com/, 0, , 924 0x7f7189ce8070 0x304ede9708e0 
[1:1:0713/034008.164989:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034008.165213:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , n.fx.tick, (){var a,b=n.timers,c=0;for(hb=n.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0713/034008.165328:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034008.189630:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 926, 7f718c62d8db
[1:1:0713/034008.201586:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"924 0x7f7189ce8070 0x304ede9708e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034008.201759:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"924 0x7f7189ce8070 0x304ede9708e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034008.202009:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 928
[1:1:0713/034008.202170:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 928 0x7f7189ce8070 0x304edea916e0 , 5:3_http://news.sznews.com/, 0, , 926 0x7f7189ce8070 0x304ede9d8b60 
[1:1:0713/034008.202359:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034008.202653:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , n.fx.tick, (){var a,b=n.timers,c=0;for(hb=n.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0713/034008.202770:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034008.204271:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 928, 7f718c62d8db
[1:1:0713/034008.216370:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"926 0x7f7189ce8070 0x304ede9d8b60 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034008.216504:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"926 0x7f7189ce8070 0x304ede9d8b60 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034008.216699:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 930
[1:1:0713/034008.216814:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 930 0x7f7189ce8070 0x304eded5f7e0 , 5:3_http://news.sznews.com/, 0, , 928 0x7f7189ce8070 0x304edea916e0 
[1:1:0713/034008.216944:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034008.217162:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , n.fx.tick, (){var a,b=n.timers,c=0;for(hb=n.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0713/034008.217281:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034008.241792:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 930, 7f718c62d8db
[1:1:0713/034008.253767:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"928 0x7f7189ce8070 0x304edea916e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034008.253942:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"928 0x7f7189ce8070 0x304edea916e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034008.254191:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 932
[1:1:0713/034008.254350:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 932 0x7f7189ce8070 0x304eded62260 , 5:3_http://news.sznews.com/, 0, , 930 0x7f7189ce8070 0x304eded5f7e0 
[1:1:0713/034008.254544:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034008.254838:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , n.fx.tick, (){var a,b=n.timers,c=0;for(hb=n.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0713/034008.254958:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034008.256485:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 932, 7f718c62d8db
[1:1:0713/034008.268569:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"930 0x7f7189ce8070 0x304eded5f7e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034008.268704:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"930 0x7f7189ce8070 0x304eded5f7e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034008.268896:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 934
[1:1:0713/034008.268995:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 934 0x7f7189ce8070 0x304ede4750e0 , 5:3_http://news.sznews.com/, 0, , 932 0x7f7189ce8070 0x304eded62260 
[1:1:0713/034008.269128:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034008.269362:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , n.fx.tick, (){var a,b=n.timers,c=0;for(hb=n.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0713/034008.269477:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034008.293853:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 934, 7f718c62d8db
[1:1:0713/034008.305863:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"932 0x7f7189ce8070 0x304eded62260 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034008.306035:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"932 0x7f7189ce8070 0x304eded62260 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034008.306290:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 936
[1:1:0713/034008.306455:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 936 0x7f7189ce8070 0x304edea1eae0 , 5:3_http://news.sznews.com/, 0, , 934 0x7f7189ce8070 0x304ede4750e0 
[1:1:0713/034008.306647:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034008.306942:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , n.fx.tick, (){var a,b=n.timers,c=0;for(hb=n.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0713/034008.307062:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034008.309367:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x2230870629c8, 0x304ede390950
[1:1:0713/034008.309482:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.sznews.com/node_33500.htm", 5000
[1:1:0713/034008.309661:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.sznews.com/, 937
[1:1:0713/034008.309785:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 937 0x7f7189ce8070 0x304edeb77960 , 5:3_http://news.sznews.com/, 1, -5:3_http://news.sznews.com/, 934 0x7f7189ce8070 0x304ede4750e0 
[1:1:0713/034009.806610:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 793, 7f718c62d8db
[1:1:0713/034009.819528:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b05cd0a2860","ptid":"575 0x7f7189ce8070 0x304edf214560 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034009.819722:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.sznews.com/","ptid":"575 0x7f7189ce8070 0x304edf214560 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034009.819986:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 939
[1:1:0713/034009.820171:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 939 0x7f7189ce8070 0x304edf252660 , 5:3_http://news.sznews.com/, 0, , 793 0x7f7189ce8070 0x304ede9b2460 
[1:1:0713/034009.820364:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034009.820678:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , uu, ()
	{
		if(dnow<oli.length-2)
		{
			oli[dnow].className=rq[dnow].className="";
			dnow++;
			oli[dn
[1:1:0713/034009.820789:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034009.821363:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.sznews.com/node_33500.htm", 15
[1:1:0713/034009.821550:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 940
[1:1:0713/034009.821677:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 940 0x7f7189ce8070 0x304edea6cfe0 , 5:3_http://news.sznews.com/, 1, -5:3_http://news.sznews.com/, 793 0x7f7189ce8070 0x304ede9b2460 
[1:1:0713/034009.821918:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.sznews.com/node_33500.htm", 8000
[1:1:0713/034009.822093:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 941
[1:1:0713/034009.822226:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 941 0x7f7189ce8070 0x304eded50ee0 , 5:3_http://news.sznews.com/, 1, -5:3_http://news.sznews.com/, 793 0x7f7189ce8070 0x304ede9b2460 
[1:1:0713/034009.849747:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 940, 7f718c62d8db
[1:1:0713/034009.862167:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b05cd0a2860","ptid":"793 0x7f7189ce8070 0x304ede9b2460 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034009.862353:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.sznews.com/","ptid":"793 0x7f7189ce8070 0x304ede9b2460 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034009.862607:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 943
[1:1:0713/034009.862768:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 943 0x7f7189ce8070 0x304ede970560 , 5:3_http://news.sznews.com/, 0, , 940 0x7f7189ce8070 0x304edea6cfe0 
[1:1:0713/034009.862961:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034009.863263:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034009.863385:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034009.866836:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 943, 7f718c62d8db
[1:1:0713/034009.879992:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"940 0x7f7189ce8070 0x304edea6cfe0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034009.880133:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"940 0x7f7189ce8070 0x304edea6cfe0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034009.880346:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 945
[1:1:0713/034009.880468:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 945 0x7f7189ce8070 0x304eded7d1e0 , 5:3_http://news.sznews.com/, 0, , 943 0x7f7189ce8070 0x304ede970560 
[1:1:0713/034009.880613:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034009.880852:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034009.880947:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034009.894366:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 945, 7f718c62d8db
[1:1:0713/034009.906697:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"943 0x7f7189ce8070 0x304ede970560 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034009.906825:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"943 0x7f7189ce8070 0x304ede970560 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034009.907043:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 947
[1:1:0713/034009.907163:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 947 0x7f7189ce8070 0x304edf7a98e0 , 5:3_http://news.sznews.com/, 0, , 945 0x7f7189ce8070 0x304eded7d1e0 
[1:1:0713/034009.907309:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034009.907554:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034009.907669:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034009.924305:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 947, 7f718c62d8db
[1:1:0713/034009.936556:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"945 0x7f7189ce8070 0x304eded7d1e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034009.936691:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"945 0x7f7189ce8070 0x304eded7d1e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034009.936881:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 949
[1:1:0713/034009.936979:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 949 0x7f7189ce8070 0x304edf799ee0 , 5:3_http://news.sznews.com/, 0, , 947 0x7f7189ce8070 0x304edf7a98e0 
[1:1:0713/034009.937138:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034009.937391:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034009.937506:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034009.954162:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 949, 7f718c62d8db
[1:1:0713/034009.966261:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"947 0x7f7189ce8070 0x304edf7a98e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034009.966394:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"947 0x7f7189ce8070 0x304edf7a98e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034009.966596:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 951
[1:1:0713/034009.966720:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 951 0x7f7189ce8070 0x304eded5b9e0 , 5:3_http://news.sznews.com/, 0, , 949 0x7f7189ce8070 0x304edf799ee0 
[1:1:0713/034009.966865:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034009.967113:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034009.967229:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034009.984030:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 951, 7f718c62d8db
[1:1:0713/034009.996126:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"949 0x7f7189ce8070 0x304edf799ee0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034009.996259:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"949 0x7f7189ce8070 0x304edf799ee0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034009.996460:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 953
[1:1:0713/034009.996579:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 953 0x7f7189ce8070 0x304eded972e0 , 5:3_http://news.sznews.com/, 0, , 951 0x7f7189ce8070 0x304eded5b9e0 
[1:1:0713/034009.996710:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034009.996946:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034009.997061:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034010.014012:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 953, 7f718c62d8db
[1:1:0713/034010.026031:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"951 0x7f7189ce8070 0x304eded5b9e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034010.026164:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"951 0x7f7189ce8070 0x304eded5b9e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034010.026362:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 955
[1:1:0713/034010.026491:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 955 0x7f7189ce8070 0x304edf882260 , 5:3_http://news.sznews.com/, 0, , 953 0x7f7189ce8070 0x304eded972e0 
[1:1:0713/034010.026639:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034010.026888:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034010.027009:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034010.044130:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 955, 7f718c62d8db
[1:1:0713/034010.056382:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"953 0x7f7189ce8070 0x304eded972e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034010.056517:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"953 0x7f7189ce8070 0x304eded972e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034010.056705:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 957
[1:1:0713/034010.056810:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 957 0x7f7189ce8070 0x304edea6cf60 , 5:3_http://news.sznews.com/, 0, , 955 0x7f7189ce8070 0x304edf882260 
[1:1:0713/034010.056938:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034010.057186:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034010.057313:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034010.074145:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 957, 7f718c62d8db
[1:1:0713/034010.086245:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"955 0x7f7189ce8070 0x304edf882260 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034010.086378:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"955 0x7f7189ce8070 0x304edf882260 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034010.086578:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 959
[1:1:0713/034010.086696:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 959 0x7f7189ce8070 0x304edec2cfe0 , 5:3_http://news.sznews.com/, 0, , 957 0x7f7189ce8070 0x304edea6cf60 
[1:1:0713/034010.086840:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034010.087089:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034010.087204:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034010.104072:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 959, 7f718c62d8db
[1:1:0713/034010.116223:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"957 0x7f7189ce8070 0x304edea6cf60 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034010.116357:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"957 0x7f7189ce8070 0x304edea6cf60 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034010.116565:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 961
[1:1:0713/034010.116671:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 961 0x7f7189ce8070 0x304edf240a60 , 5:3_http://news.sznews.com/, 0, , 959 0x7f7189ce8070 0x304edec2cfe0 
[1:1:0713/034010.116803:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034010.117050:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034010.117174:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034010.134122:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 961, 7f718c62d8db
[1:1:0713/034010.146250:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"959 0x7f7189ce8070 0x304edec2cfe0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034010.146384:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"959 0x7f7189ce8070 0x304edec2cfe0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034010.146583:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 963
[1:1:0713/034010.146689:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 963 0x7f7189ce8070 0x304ede9717e0 , 5:3_http://news.sznews.com/, 0, , 961 0x7f7189ce8070 0x304edf240a60 
[1:1:0713/034010.146822:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034010.147056:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034010.147150:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034010.164295:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 963, 7f718c62d8db
[1:1:0713/034010.176512:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"961 0x7f7189ce8070 0x304edf240a60 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034010.176645:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"961 0x7f7189ce8070 0x304edf240a60 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034010.176842:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 965
[1:1:0713/034010.176941:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 965 0x7f7189ce8070 0x304ededc3360 , 5:3_http://news.sznews.com/, 0, , 963 0x7f7189ce8070 0x304ede9717e0 
[1:1:0713/034010.177067:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034010.177320:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034010.177439:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034010.194468:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 965, 7f718c62d8db
[1:1:0713/034010.206631:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"963 0x7f7189ce8070 0x304ede9717e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034010.206763:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"963 0x7f7189ce8070 0x304ede9717e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034010.206963:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 967
[1:1:0713/034010.207081:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 967 0x7f7189ce8070 0x304edf7e9260 , 5:3_http://news.sznews.com/, 0, , 965 0x7f7189ce8070 0x304ededc3360 
[1:1:0713/034010.207236:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034010.207542:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034010.207656:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034010.224126:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 967, 7f718c62d8db
[1:1:0713/034010.236337:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"965 0x7f7189ce8070 0x304ededc3360 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034010.236471:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"965 0x7f7189ce8070 0x304ededc3360 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034010.236660:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 969
[1:1:0713/034010.236765:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 969 0x7f7189ce8070 0x304eded508e0 , 5:3_http://news.sznews.com/, 0, , 967 0x7f7189ce8070 0x304edf7e9260 
[1:1:0713/034010.236889:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034010.237122:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034010.237246:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034010.254158:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 969, 7f718c62d8db
[1:1:0713/034010.266425:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"967 0x7f7189ce8070 0x304edf7e9260 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034010.266566:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"967 0x7f7189ce8070 0x304edf7e9260 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034010.266766:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 971
[1:1:0713/034010.266884:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 971 0x7f7189ce8070 0x304edececc60 , 5:3_http://news.sznews.com/, 0, , 969 0x7f7189ce8070 0x304eded508e0 
[1:1:0713/034010.267031:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034010.267281:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034010.267396:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034010.284171:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 971, 7f718c62d8db
[1:1:0713/034010.296388:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"969 0x7f7189ce8070 0x304eded508e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034010.296523:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"969 0x7f7189ce8070 0x304eded508e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034010.296713:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 973
[1:1:0713/034010.296818:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 973 0x7f7189ce8070 0x304edec831e0 , 5:3_http://news.sznews.com/, 0, , 971 0x7f7189ce8070 0x304edececc60 
[1:1:0713/034010.296943:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034010.297175:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034010.297290:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034010.314240:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 973, 7f718c62d8db
[1:1:0713/034010.326533:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"971 0x7f7189ce8070 0x304edececc60 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034010.326675:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"971 0x7f7189ce8070 0x304edececc60 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034010.326878:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 975
[1:1:0713/034010.326998:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 975 0x7f7189ce8070 0x304ede96f3e0 , 5:3_http://news.sznews.com/, 0, , 973 0x7f7189ce8070 0x304edec831e0 
[1:1:0713/034010.327149:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034010.327399:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034010.327515:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034010.344353:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 975, 7f718c62d8db
[1:1:0713/034010.356633:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"973 0x7f7189ce8070 0x304edec831e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034010.356767:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"973 0x7f7189ce8070 0x304edec831e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034010.356954:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 977
[1:1:0713/034010.357072:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 977 0x7f7189ce8070 0x304ede93bee0 , 5:3_http://news.sznews.com/, 0, , 975 0x7f7189ce8070 0x304ede96f3e0 
[1:1:0713/034010.357217:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034010.357467:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034010.357582:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034010.374323:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 977, 7f718c62d8db
[1:1:0713/034010.386665:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"975 0x7f7189ce8070 0x304ede96f3e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034010.386800:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"975 0x7f7189ce8070 0x304ede96f3e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034010.386999:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 979
[1:1:0713/034010.387116:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 979 0x7f7189ce8070 0x304edec2cfe0 , 5:3_http://news.sznews.com/, 0, , 977 0x7f7189ce8070 0x304ede93bee0 
[1:1:0713/034010.387262:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034010.387520:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034010.387636:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034010.404311:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 979, 7f718c62d8db
[1:1:0713/034010.416706:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"977 0x7f7189ce8070 0x304ede93bee0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034010.416841:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"977 0x7f7189ce8070 0x304ede93bee0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034010.417027:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 981
[1:1:0713/034010.417173:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 981 0x7f7189ce8070 0x304edea91660 , 5:3_http://news.sznews.com/, 0, , 979 0x7f7189ce8070 0x304edec2cfe0 
[1:1:0713/034010.417319:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034010.417569:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034010.417685:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034010.434660:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 981, 7f718c62d8db
[1:1:0713/034010.447267:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"979 0x7f7189ce8070 0x304edec2cfe0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034010.447411:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"979 0x7f7189ce8070 0x304edec2cfe0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034010.447606:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 983
[1:1:0713/034010.447739:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 983 0x7f7189ce8070 0x304edf252be0 , 5:3_http://news.sznews.com/, 0, , 981 0x7f7189ce8070 0x304edea91660 
[1:1:0713/034010.447886:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034010.448144:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034010.448261:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034010.464524:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 983, 7f718c62d8db
[1:1:0713/034010.477065:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"981 0x7f7189ce8070 0x304edea91660 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034010.477201:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"981 0x7f7189ce8070 0x304edea91660 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034010.477402:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 985
[1:1:0713/034010.477524:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 985 0x7f7189ce8070 0x304eded5dc60 , 5:3_http://news.sznews.com/, 0, , 983 0x7f7189ce8070 0x304edf252be0 
[1:1:0713/034010.477674:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034010.477926:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034010.478043:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034010.494622:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 985, 7f718c62d8db
[1:1:0713/034010.507154:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"983 0x7f7189ce8070 0x304edf252be0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034010.507289:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"983 0x7f7189ce8070 0x304edf252be0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034010.507490:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 987
[1:1:0713/034010.507620:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 987 0x7f7189ce8070 0x304edf915a60 , 5:3_http://news.sznews.com/, 0, , 985 0x7f7189ce8070 0x304eded5dc60 
[1:1:0713/034010.507778:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034010.508071:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034010.508189:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034010.524465:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 987, 7f718c62d8db
[1:1:0713/034010.536976:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"985 0x7f7189ce8070 0x304eded5dc60 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034010.537136:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"985 0x7f7189ce8070 0x304eded5dc60 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034010.537338:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 989
[1:1:0713/034010.537456:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 989 0x7f7189ce8070 0x304ede8742e0 , 5:3_http://news.sznews.com/, 0, , 987 0x7f7189ce8070 0x304edf915a60 
[1:1:0713/034010.537608:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034010.537860:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034010.537976:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034010.554714:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 989, 7f718c62d8db
[1:1:0713/034010.567319:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"987 0x7f7189ce8070 0x304edf915a60 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034010.567455:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"987 0x7f7189ce8070 0x304edf915a60 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034010.567660:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 991
[1:1:0713/034010.567780:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 991 0x7f7189ce8070 0x304edea8cfe0 , 5:3_http://news.sznews.com/, 0, , 989 0x7f7189ce8070 0x304ede8742e0 
[1:1:0713/034010.567934:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034010.568190:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034010.568294:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034010.584491:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 991, 7f718c62d8db
[1:1:0713/034010.596981:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"989 0x7f7189ce8070 0x304ede8742e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034010.597143:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"989 0x7f7189ce8070 0x304ede8742e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034010.597344:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 993
[1:1:0713/034010.597462:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 993 0x7f7189ce8070 0x304edf7e9460 , 5:3_http://news.sznews.com/, 0, , 991 0x7f7189ce8070 0x304edea8cfe0 
[1:1:0713/034010.597607:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034010.597856:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034010.597970:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034010.614548:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 993, 7f718c62d8db
[1:1:0713/034010.627158:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"991 0x7f7189ce8070 0x304edea8cfe0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034010.627291:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"991 0x7f7189ce8070 0x304edea8cfe0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034010.627491:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 995
[1:1:0713/034010.627616:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 995 0x7f7189ce8070 0x304ede9756e0 , 5:3_http://news.sznews.com/, 0, , 993 0x7f7189ce8070 0x304edf7e9460 
[1:1:0713/034010.627765:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034010.628015:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034010.628131:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034010.644647:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 995, 7f718c62d8db
[1:1:0713/034010.657401:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"993 0x7f7189ce8070 0x304edf7e9460 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034010.657536:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"993 0x7f7189ce8070 0x304edf7e9460 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034010.657739:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 997
[1:1:0713/034010.657858:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 997 0x7f7189ce8070 0x304eded8c860 , 5:3_http://news.sznews.com/, 0, , 995 0x7f7189ce8070 0x304ede9756e0 
[1:1:0713/034010.658003:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034010.658300:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034010.658415:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034010.674532:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 997, 7f718c62d8db
[1:1:0713/034010.687147:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"995 0x7f7189ce8070 0x304ede9756e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034010.687279:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"995 0x7f7189ce8070 0x304ede9756e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034010.687479:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 999
[1:1:0713/034010.687598:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 999 0x7f7189ce8070 0x304eded59260 , 5:3_http://news.sznews.com/, 0, , 997 0x7f7189ce8070 0x304eded8c860 
[1:1:0713/034010.687752:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034010.688002:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034010.688120:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034010.704557:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 999, 7f718c62d8db
[1:1:0713/034010.717248:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"997 0x7f7189ce8070 0x304eded8c860 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034010.717382:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"997 0x7f7189ce8070 0x304eded8c860 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034010.717582:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1001
[1:1:0713/034010.717700:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1001 0x7f7189ce8070 0x304edea8c1e0 , 5:3_http://news.sznews.com/, 0, , 999 0x7f7189ce8070 0x304eded59260 
[1:1:0713/034010.717891:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034010.718141:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034010.718255:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034010.734659:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1001, 7f718c62d8db
[1:1:0713/034010.747277:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"999 0x7f7189ce8070 0x304eded59260 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034010.747411:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"999 0x7f7189ce8070 0x304eded59260 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034010.747610:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1003
[1:1:0713/034010.747722:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1003 0x7f7189ce8070 0x304eded82860 , 5:3_http://news.sznews.com/, 0, , 1001 0x7f7189ce8070 0x304edea8c1e0 
[1:1:0713/034010.747904:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034010.748154:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034010.748269:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034010.764749:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1003, 7f718c62d8db
[1:1:0713/034010.777486:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1001 0x7f7189ce8070 0x304edea8c1e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034010.777621:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1001 0x7f7189ce8070 0x304edea8c1e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034010.777829:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1005
[1:1:0713/034010.777950:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1005 0x7f7189ce8070 0x304eded65d60 , 5:3_http://news.sznews.com/, 0, , 1003 0x7f7189ce8070 0x304eded82860 
[1:1:0713/034010.778141:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034010.778393:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034010.778508:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034010.794652:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1005, 7f718c62d8db
[1:1:0713/034010.807355:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1003 0x7f7189ce8070 0x304eded82860 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034010.807489:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1003 0x7f7189ce8070 0x304eded82860 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034010.807691:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1007
[1:1:0713/034010.807809:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1007 0x7f7189ce8070 0x304edf7e9660 , 5:3_http://news.sznews.com/, 0, , 1005 0x7f7189ce8070 0x304eded65d60 
[1:1:0713/034010.808011:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034010.808271:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034010.808385:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034010.824721:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1007, 7f718c62d8db
[1:1:0713/034010.837482:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1005 0x7f7189ce8070 0x304eded65d60 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034010.837615:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1005 0x7f7189ce8070 0x304eded65d60 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034010.837815:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1009
[1:1:0713/034010.837941:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1009 0x7f7189ce8070 0x304eded625e0 , 5:3_http://news.sznews.com/, 0, , 1007 0x7f7189ce8070 0x304edf7e9660 
[1:1:0713/034010.838132:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034010.838386:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034010.838502:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034010.854818:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1009, 7f718c62d8db
[1:1:0713/034010.867597:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1007 0x7f7189ce8070 0x304edf7e9660 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034010.867731:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1007 0x7f7189ce8070 0x304edf7e9660 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034010.867931:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1011
[1:1:0713/034010.868048:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1011 0x7f7189ce8070 0x304edebad4e0 , 5:3_http://news.sznews.com/, 0, , 1009 0x7f7189ce8070 0x304eded625e0 
[1:1:0713/034010.868241:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034010.868491:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034010.868608:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034010.884883:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1011, 7f718c62d8db
[1:1:0713/034010.897564:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1009 0x7f7189ce8070 0x304eded625e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034010.897699:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1009 0x7f7189ce8070 0x304eded625e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034010.897887:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1013
[1:1:0713/034010.897991:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1013 0x7f7189ce8070 0x304ede93ba60 , 5:3_http://news.sznews.com/, 0, , 1011 0x7f7189ce8070 0x304edebad4e0 
[1:1:0713/034010.898168:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034010.898434:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034010.898556:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034010.914899:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1013, 7f718c62d8db
[1:1:0713/034010.927652:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1011 0x7f7189ce8070 0x304edebad4e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034010.927792:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1011 0x7f7189ce8070 0x304edebad4e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034010.927994:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1015
[1:1:0713/034010.928114:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1015 0x7f7189ce8070 0x304edea6c3e0 , 5:3_http://news.sznews.com/, 0, , 1013 0x7f7189ce8070 0x304ede93ba60 
[1:1:0713/034010.928306:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034010.928554:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034010.928656:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034010.944842:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1015, 7f718c62d8db
[1:1:0713/034010.957662:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1013 0x7f7189ce8070 0x304ede93ba60 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034010.957796:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1013 0x7f7189ce8070 0x304ede93ba60 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034010.958000:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1017
[1:1:0713/034010.958123:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1017 0x7f7189ce8070 0x304edf1e8ae0 , 5:3_http://news.sznews.com/, 0, , 1015 0x7f7189ce8070 0x304edea6c3e0 
[1:1:0713/034010.958312:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034010.958563:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034010.958689:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034010.974872:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1017, 7f718c62d8db
[1:1:0713/034010.987668:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1015 0x7f7189ce8070 0x304edea6c3e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034010.987802:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1015 0x7f7189ce8070 0x304edea6c3e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034010.988010:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1019
[1:1:0713/034010.988128:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1019 0x7f7189ce8070 0x304edebadbe0 , 5:3_http://news.sznews.com/, 0, , 1017 0x7f7189ce8070 0x304edf1e8ae0 
[1:1:0713/034010.988322:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034010.988569:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034010.988672:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034011.004973:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1019, 7f718c62d8db
[1:1:0713/034011.017921:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1017 0x7f7189ce8070 0x304edf1e8ae0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034011.018055:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1017 0x7f7189ce8070 0x304edf1e8ae0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034011.018255:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1021
[1:1:0713/034011.018374:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1021 0x7f7189ce8070 0x304edea91d60 , 5:3_http://news.sznews.com/, 0, , 1019 0x7f7189ce8070 0x304edebadbe0 
[1:1:0713/034011.018565:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034011.018813:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034011.018928:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034011.034942:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1021, 7f718c62d8db
[1:1:0713/034011.047946:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1019 0x7f7189ce8070 0x304edebadbe0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034011.048082:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1019 0x7f7189ce8070 0x304edebadbe0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034011.048288:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1023
[1:1:0713/034011.048407:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1023 0x7f7189ce8070 0x304edeb77c60 , 5:3_http://news.sznews.com/, 0, , 1021 0x7f7189ce8070 0x304edea91d60 
[1:1:0713/034011.048587:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034011.048837:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034011.048930:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034011.065302:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1023, 7f718c62d8db
[1:1:0713/034011.078365:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1021 0x7f7189ce8070 0x304edea91d60 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034011.078508:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1021 0x7f7189ce8070 0x304edea91d60 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034011.078711:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1025
[1:1:0713/034011.078830:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1025 0x7f7189ce8070 0x304ede476be0 , 5:3_http://news.sznews.com/, 0, , 1023 0x7f7189ce8070 0x304edeb77c60 
[1:1:0713/034011.079026:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034011.079288:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034011.079404:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034011.094959:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1025, 7f718c62d8db
[1:1:0713/034011.107959:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1023 0x7f7189ce8070 0x304edeb77c60 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034011.108103:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1023 0x7f7189ce8070 0x304edeb77c60 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034011.108317:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1027
[1:1:0713/034011.108459:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1027 0x7f7189ce8070 0x304ededb6960 , 5:3_http://news.sznews.com/, 0, , 1025 0x7f7189ce8070 0x304ede476be0 
[1:1:0713/034011.108646:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034011.108908:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034011.109015:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034011.146179:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0713/034011.146364:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034011.150706:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1027, 7f718c62d8db
[1:1:0713/034011.167829:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1025 0x7f7189ce8070 0x304ede476be0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034011.168365:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1025 0x7f7189ce8070 0x304ede476be0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034011.168933:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1035
[1:1:0713/034011.169071:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1035 0x7f7189ce8070 0x304eded59160 , 5:3_http://news.sznews.com/, 0, , 1027 0x7f7189ce8070 0x304ededb6960 
[1:1:0713/034011.169404:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034011.169890:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034011.170022:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[28900:28900:0713/034011.310644:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[28900:28900:0713/034011.313744:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: sznews_frame, 4, 4, 
[28900:28900:0713/034011.317049:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://news.sznews.com/
[3:3:0713/034011.895797:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[28900:28900:0713/034011.937022:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[28900:28900:0713/034011.938650:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[28900:28912:0713/034011.953224:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 4
[28900:28900:0713/034011.953306:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://news.sznews.com/
[28900:28912:0713/034011.953304:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 4, HandleIncomingMessage, HandleIncomingMessage
[28900:28900:0713/034011.953354:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_http://news.sznews.com/, http://news.sznews.com/node_148726.htm, 4
[28900:28900:0713/034011.953418:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:4_http://news.sznews.com/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 19:40:11 GMT Server: nginx Last-Modified: Fri, 12 Jul 2019 15:10:03 GMT Expires: Fri, 12 Jul 2019 19:44:40 GMT Cache-Control: max-age=300 X-Via: 1.1 hangkuan193:5 (Cdn Cache Server V2.0), 1.1 hkuan176:1 (Cdn Cache Server V2.0) Content-Type: text/html ETag: W/"407a-58d7d4e0608d3" Content-Encoding: gzip Age: 274  ,28995, 5
[1:7:0713/034011.956507:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[28900:28900:0713/034012.027412:INFO:CONSOLE(0)] "[DOM] Input elements should have autocomplete attributes (suggested: autocomplete='email', confirm at https://goo.gl/6KgkJg) %o", source: http://news.sznews.com/node_33500.htm (0)
[1:1:0713/034012.296017:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:4_http://news.sznews.com/
[1:1:0713/034012.475839:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , , document.readyState
[1:1:0713/034012.476056:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034012.723745:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 908, 7f718c62d8db
[1:1:0713/034012.743010:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"820 0x7f7189ce8070 0x304eded640e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034012.743620:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"820 0x7f7189ce8070 0x304eded640e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034012.743948:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1130
[1:1:0713/034012.744096:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1130 0x7f7189ce8070 0x304edfc51660 , 5:3_http://news.sznews.com/, 0, , 908 0x7f7189ce8070 0x304eded64060 
[1:1:0713/034012.744318:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034012.744619:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , , () {
      feature_slide();
    }
[1:1:0713/034012.744721:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[28900:28900:0713/034012.832357:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_http://news.sznews.com/, http://news.sznews.com/, 4
[28900:28900:0713/034012.832475:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, http://news.sznews.com/, http://news.sznews.com
[1:1:0713/034012.832598:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/034013.164200:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , , document.readyState
[1:1:0713/034013.164370:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034013.866034:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/034014.065794:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , , document.readyState
[1:1:0713/034014.066019:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034014.102961:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.sznews.com/, 937, 7f718c62d881
[1:1:0713/034014.120957:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b05cd0a2860","ptid":"934 0x7f7189ce8070 0x304ede4750e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034014.121220:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.sznews.com/","ptid":"934 0x7f7189ce8070 0x304ede4750e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034014.121495:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034014.121828:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , _fnScroll, (){
			var scrollNews = $('#scrollNews'),
				top = parseInt(scrollNews.css('top')),
				height =
[1:1:0713/034014.121983:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034014.143739:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2230870629c8, 0x304ede390950
[1:1:0713/034014.143915:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.sznews.com/node_33500.htm", 0
[1:1:0713/034014.144139:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.sznews.com/, 1165
[1:1:0713/034014.144272:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1165 0x7f7189ce8070 0x304edfb98360 , 5:3_http://news.sznews.com/, 1, -5:3_http://news.sznews.com/, 937 0x7f7189ce8070 0x304edeb77960 
[1:1:0713/034014.150786:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.sznews.com/node_33500.htm", 13
[1:1:0713/034014.151015:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1166
[1:1:0713/034014.151142:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1166 0x7f7189ce8070 0x304edfc1f3e0 , 5:3_http://news.sznews.com/, 1, -5:3_http://news.sznews.com/, 937 0x7f7189ce8070 0x304edeb77960 
[1:1:0713/034014.263242:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/034014.263469:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://news.sznews.com/node_148726.htm"
[1:1:0713/034014.325279:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , , document.readyState
[1:1:0713/034014.325468:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034014.345840:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.sznews.com/, 1165, 7f718c62d881
[1:1:0713/034014.364597:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b05cd0a2860","ptid":"937 0x7f7189ce8070 0x304edeb77960 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034014.364822:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.sznews.com/","ptid":"937 0x7f7189ce8070 0x304edeb77960 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034014.365064:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034014.365389:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , , (){hb=void 0}
[1:1:0713/034014.365521:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034014.366188:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1166, 7f718c62d8db
[1:1:0713/034014.384099:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b05cd0a2860","ptid":"937 0x7f7189ce8070 0x304edeb77960 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034014.384300:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.sznews.com/","ptid":"937 0x7f7189ce8070 0x304edeb77960 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034014.384558:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1185
[1:1:0713/034014.384713:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1185 0x7f7189ce8070 0x304eded5e060 , 5:3_http://news.sznews.com/, 0, , 1166 0x7f7189ce8070 0x304edfc1f3e0 
[1:1:0713/034014.384929:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034014.385241:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , n.fx.tick, (){var a,b=n.timers,c=0;for(hb=n.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0713/034014.385367:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034014.679842:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , , document.readyState
[1:1:0713/034014.680049:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034014.700840:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1185, 7f718c62d8db
[1:1:0713/034014.718458:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1166 0x7f7189ce8070 0x304edfc1f3e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034014.718660:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1166 0x7f7189ce8070 0x304edfc1f3e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034014.718970:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1204
[1:1:0713/034014.719130:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1204 0x7f7189ce8070 0x304ee03aac60 , 5:3_http://news.sznews.com/, 0, , 1185 0x7f7189ce8070 0x304eded5e060 
[1:1:0713/034014.719364:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034014.719684:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , n.fx.tick, (){var a,b=n.timers,c=0;for(hb=n.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0713/034014.719809:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034014.722449:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x2230870629c8, 0x304ede390950
[1:1:0713/034014.722602:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.sznews.com/node_33500.htm", 5000
[1:1:0713/034014.722790:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.sznews.com/, 1205
[1:1:0713/034014.722902:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1205 0x7f7189ce8070 0x304ee04863e0 , 5:3_http://news.sznews.com/, 1, -5:3_http://news.sznews.com/, 1185 0x7f7189ce8070 0x304eded5e060 
[1:1:0713/034014.987170:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1198 0x7f7189ce8070 0x304ee03e3660 , "http://news.sznews.com/node_148726.htm"
[1:1:0713/034015.002660:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://news.sznews.com/, 2b05cd1a6d80, , , /*! jQuery v1.12.2 | (c) jQuery Foundation | jquery.org/license */
!function(a,b){"object"==typeof m
[1:1:0713/034015.002883:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_148726.htm", "news.sznews.com", 4, 1, http://news.sznews.com, news.sznews.com, 3
[1:1:0713/034015.095639:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1198 0x7f7189ce8070 0x304ee03e3660 , "http://news.sznews.com/node_148726.htm"
[1:1:0713/034015.099574:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1198 0x7f7189ce8070 0x304ee03e3660 , "http://news.sznews.com/node_148726.htm"
[1:1:0713/034015.114625:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0231309, 204, 1
[1:1:0713/034015.114862:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/034015.181564:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , , document.readyState
[1:1:0713/034015.181753:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034016.037603:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/034016.037836:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://news.sznews.com/node_148726.htm"
[1:1:0713/034016.039231:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1236 0x7f7189ce8070 0x304edecf5b60 , "http://news.sznews.com/node_148726.htm"
[1:1:0713/034016.039817:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://news.sznews.com/, 2b05cd1a6d80, , , 
document.writeln("<script type=\"text\/javascript\" src=\"http:\/\/www.sznews.com\/2013\/blbjs\/fo
[1:1:0713/034016.040022:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_148726.htm", "news.sznews.com", 4, 1, http://news.sznews.com, news.sznews.com, 3
[1:1:0713/034016.050231:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1236 0x7f7189ce8070 0x304edecf5b60 , "http://news.sznews.com/node_148726.htm"
[1:1:0713/034016.155074:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , , document.readyState
[1:1:0713/034016.155305:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034016.866041:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/034016.929568:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , , document.readyState
[1:1:0713/034016.929815:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034017.276039:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/034017.276257:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://news.sznews.com/node_148726.htm"
[1:1:0713/034017.277695:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1306 0x7f7189ce8070 0x304edfbcf2e0 , "http://news.sznews.com/node_148726.htm"
[1:1:0713/034017.278359:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://news.sznews.com/, 2b05cd1a6d80, , , // //手机栏目页适配
// var Mobile = {
// 	Android: function() {
// 		return navigator.user
[1:1:0713/034017.278531:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_148726.htm", "news.sznews.com", 4, 1, http://news.sznews.com, news.sznews.com, 3
[1:1:0713/034017.281735:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1306 0x7f7189ce8070 0x304edfbcf2e0 , "http://news.sznews.com/node_148726.htm"
[1:1:0713/034017.297758:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://news.sznews.com/node_148726.htm"
[1:1:0713/034017.495125:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , , document.readyState
[1:1:0713/034017.495294:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034017.629257:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1130, 7f718c62d8db
[1:1:0713/034017.650116:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"908 0x7f7189ce8070 0x304eded64060 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034017.650333:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"908 0x7f7189ce8070 0x304eded64060 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034017.650610:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1349
[1:1:0713/034017.650762:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1349 0x7f7189ce8070 0x304edfc4a5e0 , 5:3_http://news.sznews.com/, 0, , 1130 0x7f7189ce8070 0x304edfc51660 
[1:1:0713/034017.650982:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034017.651254:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , , () {
      feature_slide();
    }
[1:1:0713/034017.651411:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034017.916911:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , , document.readyState
[1:1:0713/034017.917128:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034018.350098:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 941, 7f718c62d8db
[1:1:0713/034018.370777:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b05cd0a2860","ptid":"793 0x7f7189ce8070 0x304ede9b2460 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034018.371027:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.sznews.com/","ptid":"793 0x7f7189ce8070 0x304ede9b2460 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034018.371329:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1376
[1:1:0713/034018.371501:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1376 0x7f7189ce8070 0x304ee0636560 , 5:3_http://news.sznews.com/, 0, , 941 0x7f7189ce8070 0x304eded50ee0 
[1:1:0713/034018.371780:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034018.372135:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , uu, ()
	{
		if(dnow<oli.length-2)
		{
			oli[dnow].className=rq[dnow].className="";
			dnow++;
			oli[dn
[1:1:0713/034018.372286:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034018.372950:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.sznews.com/node_33500.htm", 15
[1:1:0713/034018.373172:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1377
[1:1:0713/034018.373362:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1377 0x7f7189ce8070 0x304ee076d0e0 , 5:3_http://news.sznews.com/, 1, -5:3_http://news.sznews.com/, 941 0x7f7189ce8070 0x304eded50ee0 
[1:1:0713/034018.373721:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.sznews.com/node_33500.htm", 8000
[1:1:0713/034018.373906:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1378
[1:1:0713/034018.373997:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1378 0x7f7189ce8070 0x304ee076dc60 , 5:3_http://news.sznews.com/, 1, -5:3_http://news.sznews.com/, 941 0x7f7189ce8070 0x304eded50ee0 
[1:1:0713/034018.437951:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , , document.readyState
[1:1:0713/034018.438115:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034018.714630:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1377, 7f718c62d8db
[1:1:0713/034018.737165:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b05cd0a2860","ptid":"941 0x7f7189ce8070 0x304eded50ee0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034018.737405:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.sznews.com/","ptid":"941 0x7f7189ce8070 0x304eded50ee0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034018.737699:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1395
[1:1:0713/034018.737865:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1395 0x7f7189ce8070 0x304ede5c2060 , 5:3_http://news.sznews.com/, 0, , 1377 0x7f7189ce8070 0x304ee076d0e0 
[1:1:0713/034018.738118:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034018.738489:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034018.738656:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034018.808190:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , , document.readyState
[1:1:0713/034018.808355:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034019.087997:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1395, 7f718c62d8db
[1:1:0713/034019.112826:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1377 0x7f7189ce8070 0x304ee076d0e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034019.113027:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1377 0x7f7189ce8070 0x304ee076d0e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034019.113379:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1409
[1:1:0713/034019.113561:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1409 0x7f7189ce8070 0x304ee0844360 , 5:3_http://news.sznews.com/, 0, , 1395 0x7f7189ce8070 0x304ede5c2060 
[1:1:0713/034019.113844:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034019.114185:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034019.114332:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034019.163112:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , , document.readyState
[1:1:0713/034019.163305:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034019.422294:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1409, 7f718c62d8db
[1:1:0713/034019.444335:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1395 0x7f7189ce8070 0x304ede5c2060 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034019.444519:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1395 0x7f7189ce8070 0x304ede5c2060 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034019.444778:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1425
[1:1:0713/034019.444881:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1425 0x7f7189ce8070 0x304edfc1c8e0 , 5:3_http://news.sznews.com/, 0, , 1409 0x7f7189ce8070 0x304ee0844360 
[1:1:0713/034019.445101:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034019.445381:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034019.445487:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034019.468279:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , , document.readyState
[1:1:0713/034019.468461:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034019.816798:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1425, 7f718c62d8db
[1:1:0713/034019.842020:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1409 0x7f7189ce8070 0x304ee0844360 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034019.842205:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1409 0x7f7189ce8070 0x304ee0844360 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034019.842385:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1441
[1:1:0713/034019.842520:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1441 0x7f7189ce8070 0x304ee077a0e0 , 5:3_http://news.sznews.com/, 0, , 1425 0x7f7189ce8070 0x304edfc1c8e0 
[1:1:0713/034019.842737:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034019.843029:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034019.843150:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034019.866318:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , , document.readyState
[1:1:0713/034019.866478:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034019.961730:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.sznews.com/, 1205, 7f718c62d881
[1:1:0713/034019.983419:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b05cd0a2860","ptid":"1185 0x7f7189ce8070 0x304eded5e060 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034019.983623:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.sznews.com/","ptid":"1185 0x7f7189ce8070 0x304eded5e060 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034019.983829:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034019.984153:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , _fnScroll, (){
			var scrollNews = $('#scrollNews'),
				top = parseInt(scrollNews.css('top')),
				height =
[1:1:0713/034019.984279:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034020.021433:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2230870629c8, 0x304ede390950
[1:1:0713/034020.021624:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.sznews.com/node_33500.htm", 0
[1:1:0713/034020.022396:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.sznews.com/, 1452
[1:1:0713/034020.022570:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1452 0x7f7189ce8070 0x304ee0587660 , 5:3_http://news.sznews.com/, 1, -5:3_http://news.sznews.com/, 1205 0x7f7189ce8070 0x304ee04863e0 
[1:1:0713/034020.029146:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.sznews.com/node_33500.htm", 13
[1:1:0713/034020.029345:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1453
[1:1:0713/034020.029457:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1453 0x7f7189ce8070 0x304edfc28860 , 5:3_http://news.sznews.com/, 1, -5:3_http://news.sznews.com/, 1205 0x7f7189ce8070 0x304ee04863e0 
[1:1:0713/034020.236567:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1441, 7f718c62d8db
[1:1:0713/034020.266114:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1425 0x7f7189ce8070 0x304edfc1c8e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034020.266324:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1425 0x7f7189ce8070 0x304edfc1c8e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034020.266579:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1462
[1:1:0713/034020.266756:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1462 0x7f7189ce8070 0x304ee059d8e0 , 5:3_http://news.sznews.com/, 0, , 1441 0x7f7189ce8070 0x304ee077a0e0 
[1:1:0713/034020.266996:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034020.267362:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034020.267485:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034020.292602:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , , document.readyState
[1:1:0713/034020.292788:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034020.417280:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.sznews.com/, 1452, 7f718c62d881
[1:1:0713/034020.442746:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b05cd0a2860","ptid":"1205 0x7f7189ce8070 0x304ee04863e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034020.442952:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.sznews.com/","ptid":"1205 0x7f7189ce8070 0x304ee04863e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034020.443151:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034020.443456:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , , (){hb=void 0}
[1:1:0713/034020.443575:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034020.467824:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1453, 7f718c62d8db
[1:1:0713/034020.488842:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b05cd0a2860","ptid":"1205 0x7f7189ce8070 0x304ee04863e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034020.489068:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.sznews.com/","ptid":"1205 0x7f7189ce8070 0x304ee04863e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034020.489318:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1472
[1:1:0713/034020.489433:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1472 0x7f7189ce8070 0x304edfbf5ce0 , 5:3_http://news.sznews.com/, 0, , 1453 0x7f7189ce8070 0x304edfc28860 
[1:1:0713/034020.489625:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034020.489893:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , n.fx.tick, (){var a,b=n.timers,c=0;for(hb=n.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0713/034020.490015:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034020.492570:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x2230870629c8, 0x304ede390950
[1:1:0713/034020.492672:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.sznews.com/node_33500.htm", 5000
[1:1:0713/034020.492827:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.sznews.com/, 1473
[1:1:0713/034020.492920:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1473 0x7f7189ce8070 0x304ee0267de0 , 5:3_http://news.sznews.com/, 1, -5:3_http://news.sznews.com/, 1453 0x7f7189ce8070 0x304edfc28860 
[1:1:0713/034020.650598:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1462, 7f718c62d8db
[1:1:0713/034020.676305:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1441 0x7f7189ce8070 0x304ee077a0e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034020.676478:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1441 0x7f7189ce8070 0x304ee077a0e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034020.676660:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1480
[1:1:0713/034020.676753:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1480 0x7f7189ce8070 0x304ee03e34e0 , 5:3_http://news.sznews.com/, 0, , 1462 0x7f7189ce8070 0x304ee059d8e0 
[1:1:0713/034020.676938:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034020.677227:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034020.677361:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034020.700529:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , , document.readyState
[1:1:0713/034020.700656:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034021.047839:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1480, 7f718c62d8db
[1:1:0713/034021.067189:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1462 0x7f7189ce8070 0x304ee059d8e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034021.067346:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1462 0x7f7189ce8070 0x304ee059d8e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034021.067513:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1493
[1:1:0713/034021.067592:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1493 0x7f7189ce8070 0x304eded551e0 , 5:3_http://news.sznews.com/, 0, , 1480 0x7f7189ce8070 0x304ee03e34e0 
[1:1:0713/034021.067751:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034021.067993:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034021.068079:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034021.295930:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1493, 7f718c62d8db
[1:1:0713/034021.321563:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1480 0x7f7189ce8070 0x304ee03e34e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034021.321775:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1480 0x7f7189ce8070 0x304ee03e34e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034021.322035:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1504
[1:1:0713/034021.322162:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1504 0x7f7189ce8070 0x304edfc26d60 , 5:3_http://news.sznews.com/, 0, , 1493 0x7f7189ce8070 0x304eded551e0 
[1:1:0713/034021.322466:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034021.322762:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034021.322863:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034021.367320:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: the server responded with a status of 404 (Not Found)","http://news.sznews.com/favicon.ico"
[1:1:0713/034021.539408:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1504, 7f718c62d8db
[1:1:0713/034021.565218:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1493 0x7f7189ce8070 0x304eded551e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034021.565395:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1493 0x7f7189ce8070 0x304eded551e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034021.565593:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1519
[1:1:0713/034021.565707:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1519 0x7f7189ce8070 0x304ede4d9360 , 5:3_http://news.sznews.com/, 0, , 1504 0x7f7189ce8070 0x304edfc26d60 
[1:1:0713/034021.565911:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034021.566189:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034021.566305:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034021.812411:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1519, 7f718c62d8db
[1:1:0713/034021.838128:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1504 0x7f7189ce8070 0x304edfc26d60 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034021.838344:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1504 0x7f7189ce8070 0x304edfc26d60 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034021.838669:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1526
[1:1:0713/034021.838832:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1526 0x7f7189ce8070 0x304ede8818e0 , 5:3_http://news.sznews.com/, 0, , 1519 0x7f7189ce8070 0x304ede4d9360 
[1:1:0713/034021.839051:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034021.839356:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034021.839476:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034022.009253:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1526, 7f718c62d8db
[1:1:0713/034022.035552:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1519 0x7f7189ce8070 0x304ede4d9360 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034022.035746:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1519 0x7f7189ce8070 0x304ede4d9360 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034022.035985:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1535
[1:1:0713/034022.036099:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1535 0x7f7189ce8070 0x304ede5a8a60 , 5:3_http://news.sznews.com/, 0, , 1526 0x7f7189ce8070 0x304ede8818e0 
[1:1:0713/034022.036290:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034022.036556:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034022.036645:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034022.256160:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1535, 7f718c62d8db
[1:1:0713/034022.276995:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1526 0x7f7189ce8070 0x304ede8818e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034022.277223:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1526 0x7f7189ce8070 0x304ede8818e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034022.277413:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1546
[1:1:0713/034022.277543:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1546 0x7f7189ce8070 0x304ee03b9de0 , 5:3_http://news.sznews.com/, 0, , 1535 0x7f7189ce8070 0x304ede5a8a60 
[1:1:0713/034022.277742:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034022.278009:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034022.278116:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034022.380366:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1349, 7f718c62d8db
[1:1:0713/034022.400236:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1130 0x7f7189ce8070 0x304edfc51660 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034022.400393:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1130 0x7f7189ce8070 0x304edfc51660 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034022.400576:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1551
[1:1:0713/034022.400683:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1551 0x7f7189ce8070 0x304ee077a560 , 5:3_http://news.sznews.com/, 0, , 1349 0x7f7189ce8070 0x304edfc4a5e0 
[1:1:0713/034022.400873:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034022.401162:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , , () {
      feature_slide();
    }
[1:1:0713/034022.401278:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034022.499130:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1546, 7f718c62d8db
[1:1:0713/034022.525927:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1535 0x7f7189ce8070 0x304ede5a8a60 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034022.526121:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1535 0x7f7189ce8070 0x304ede5a8a60 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034022.526336:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1557
[1:1:0713/034022.526468:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1557 0x7f7189ce8070 0x304ede22b460 , 5:3_http://news.sznews.com/, 0, , 1546 0x7f7189ce8070 0x304ee03b9de0 
[1:1:0713/034022.526680:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034022.526974:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034022.527095:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034022.727455:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1557, 7f718c62d8db
[1:1:0713/034022.750480:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1546 0x7f7189ce8070 0x304ee03b9de0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034022.750631:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1546 0x7f7189ce8070 0x304ee03b9de0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034022.750817:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1566
[1:1:0713/034022.750949:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1566 0x7f7189ce8070 0x304ee05a4de0 , 5:3_http://news.sznews.com/, 0, , 1557 0x7f7189ce8070 0x304ede22b460 
[1:1:0713/034022.751146:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034022.751423:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034022.751528:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034022.924103:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1566, 7f718c62d8db
[1:1:0713/034022.950738:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1557 0x7f7189ce8070 0x304ede22b460 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034022.950917:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1557 0x7f7189ce8070 0x304ede22b460 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034022.951112:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1574
[1:1:0713/034022.951243:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1574 0x7f7189ce8070 0x304edf09c7e0 , 5:3_http://news.sznews.com/, 0, , 1566 0x7f7189ce8070 0x304ee05a4de0 
[1:1:0713/034022.951443:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034022.951734:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034022.951847:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034023.127737:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1574, 7f718c62d8db
[1:1:0713/034023.154454:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1566 0x7f7189ce8070 0x304ee05a4de0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034023.154632:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1566 0x7f7189ce8070 0x304ee05a4de0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034023.154876:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1582
[1:1:0713/034023.155042:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1582 0x7f7189ce8070 0x304ede5aa060 , 5:3_http://news.sznews.com/, 0, , 1574 0x7f7189ce8070 0x304edf09c7e0 
[1:1:0713/034023.155279:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034023.155651:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034023.155794:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034023.357970:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1582, 7f718c62d8db
[1:1:0713/034023.380811:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1574 0x7f7189ce8070 0x304edf09c7e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034023.380964:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1574 0x7f7189ce8070 0x304edf09c7e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034023.381150:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1592
[1:1:0713/034023.381273:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1592 0x7f7189ce8070 0x304eded5b160 , 5:3_http://news.sznews.com/, 0, , 1582 0x7f7189ce8070 0x304ede5aa060 
[1:1:0713/034023.381465:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034023.381761:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034023.381868:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034023.607234:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1592, 7f718c62d8db
[1:1:0713/034023.628343:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1582 0x7f7189ce8070 0x304ede5aa060 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034023.628520:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1582 0x7f7189ce8070 0x304ede5aa060 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034023.628718:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1598
[1:1:0713/034023.628828:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1598 0x7f7189ce8070 0x304edf0121e0 , 5:3_http://news.sznews.com/, 0, , 1592 0x7f7189ce8070 0x304eded5b160 
[1:1:0713/034023.629019:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034023.629293:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034023.629417:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034023.659567:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1598, 7f718c62d8db
[1:1:0713/034023.680117:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1592 0x7f7189ce8070 0x304eded5b160 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034023.680353:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1592 0x7f7189ce8070 0x304eded5b160 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034023.680584:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1600
[1:1:0713/034023.680721:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1600 0x7f7189ce8070 0x304edf27bf60 , 5:3_http://news.sznews.com/, 0, , 1598 0x7f7189ce8070 0x304edf0121e0 
[1:1:0713/034023.680916:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034023.681197:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034023.681350:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034023.704464:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1600, 7f718c62d8db
[1:1:0713/034023.725362:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1598 0x7f7189ce8070 0x304edf0121e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034023.725536:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1598 0x7f7189ce8070 0x304edf0121e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034023.725731:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1602
[1:1:0713/034023.725853:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1602 0x7f7189ce8070 0x304ee08169e0 , 5:3_http://news.sznews.com/, 0, , 1600 0x7f7189ce8070 0x304edf27bf60 
[1:1:0713/034023.726059:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034023.726336:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034023.726452:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034023.749603:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1602, 7f718c62d8db
[1:1:0713/034023.770433:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1600 0x7f7189ce8070 0x304edf27bf60 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034023.770657:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1600 0x7f7189ce8070 0x304edf27bf60 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034023.770898:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1604
[1:1:0713/034023.771053:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1604 0x7f7189ce8070 0x304edfc15c60 , 5:3_http://news.sznews.com/, 0, , 1602 0x7f7189ce8070 0x304ee08169e0 
[1:1:0713/034023.771319:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034023.771626:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034023.771768:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034023.794523:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1604, 7f718c62d8db
[1:1:0713/034023.815325:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1602 0x7f7189ce8070 0x304ee08169e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034023.815503:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1602 0x7f7189ce8070 0x304ee08169e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034023.815701:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1606
[1:1:0713/034023.815823:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1606 0x7f7189ce8070 0x304edf012be0 , 5:3_http://news.sznews.com/, 0, , 1604 0x7f7189ce8070 0x304edfc15c60 
[1:1:0713/034023.816034:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034023.816307:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034023.816423:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034023.839634:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1606, 7f718c62d8db
[1:1:0713/034023.860569:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1604 0x7f7189ce8070 0x304edfc15c60 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034023.860749:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1604 0x7f7189ce8070 0x304edfc15c60 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034023.860935:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1608
[1:1:0713/034023.861048:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1608 0x7f7189ce8070 0x304ee05a39e0 , 5:3_http://news.sznews.com/, 0, , 1606 0x7f7189ce8070 0x304edf012be0 
[1:1:0713/034023.861274:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034023.861558:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034023.861675:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034023.884522:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1608, 7f718c62d8db
[1:1:0713/034023.905234:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1606 0x7f7189ce8070 0x304edf012be0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034023.905408:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1606 0x7f7189ce8070 0x304edf012be0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034023.905623:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1610
[1:1:0713/034023.905745:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1610 0x7f7189ce8070 0x304ede3b42e0 , 5:3_http://news.sznews.com/, 0, , 1608 0x7f7189ce8070 0x304ee05a39e0 
[1:1:0713/034023.905952:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034023.906227:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034023.906336:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034023.929639:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1610, 7f718c62d8db
[1:1:0713/034023.950437:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1608 0x7f7189ce8070 0x304ee05a39e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034023.950610:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1608 0x7f7189ce8070 0x304ee05a39e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034023.950808:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1612
[1:1:0713/034023.950929:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1612 0x7f7189ce8070 0x304eded58a60 , 5:3_http://news.sznews.com/, 0, , 1610 0x7f7189ce8070 0x304ede3b42e0 
[1:1:0713/034023.951140:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034023.951425:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034023.951541:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034023.974800:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1612, 7f718c62d8db
[1:1:0713/034023.995568:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1610 0x7f7189ce8070 0x304ede3b42e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034023.995742:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1610 0x7f7189ce8070 0x304ede3b42e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034023.995939:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1614
[1:1:0713/034023.996072:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1614 0x7f7189ce8070 0x304ee03d9f60 , 5:3_http://news.sznews.com/, 0, , 1612 0x7f7189ce8070 0x304eded58a60 
[1:1:0713/034023.996276:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034023.996569:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034023.996674:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034024.039874:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1614, 7f718c62d8db
[1:1:0713/034024.061322:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1612 0x7f7189ce8070 0x304eded58a60 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034024.061501:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1612 0x7f7189ce8070 0x304eded58a60 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034024.061702:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1617
[1:1:0713/034024.061825:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1617 0x7f7189ce8070 0x304ee076d460 , 5:3_http://news.sznews.com/, 0, , 1614 0x7f7189ce8070 0x304ee03d9f60 
[1:1:0713/034024.062041:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034024.062319:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034024.062437:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034024.094660:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1617, 7f718c62d8db
[1:1:0713/034024.115523:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1614 0x7f7189ce8070 0x304ee03d9f60 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034024.115724:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1614 0x7f7189ce8070 0x304ee03d9f60 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034024.115949:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1619
[1:1:0713/034024.116097:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1619 0x7f7189ce8070 0x304ede3877e0 , 5:3_http://news.sznews.com/, 0, , 1617 0x7f7189ce8070 0x304ee076d460 
[1:1:0713/034024.116355:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034024.116667:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034024.116799:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034024.139707:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1619, 7f718c62d8db
[1:1:0713/034024.160722:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1617 0x7f7189ce8070 0x304ee076d460 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034024.160900:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1617 0x7f7189ce8070 0x304ee076d460 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034024.161103:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1621
[1:1:0713/034024.161227:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1621 0x7f7189ce8070 0x304eded4f4e0 , 5:3_http://news.sznews.com/, 0, , 1619 0x7f7189ce8070 0x304ede3877e0 
[1:1:0713/034024.161439:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034024.161716:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034024.161832:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034024.184637:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1621, 7f718c62d8db
[1:1:0713/034024.205477:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1619 0x7f7189ce8070 0x304ede3877e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034024.205702:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1619 0x7f7189ce8070 0x304ede3877e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034024.205909:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1623
[1:1:0713/034024.206031:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1623 0x7f7189ce8070 0x304ede4d7d60 , 5:3_http://news.sznews.com/, 0, , 1621 0x7f7189ce8070 0x304eded4f4e0 
[1:1:0713/034024.206237:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034024.206509:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034024.206625:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034024.229935:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1623, 7f718c62d8db
[1:1:0713/034024.251322:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1621 0x7f7189ce8070 0x304eded4f4e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034024.251501:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1621 0x7f7189ce8070 0x304eded4f4e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034024.251707:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1625
[1:1:0713/034024.251818:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1625 0x7f7189ce8070 0x304edfc4ec60 , 5:3_http://news.sznews.com/, 0, , 1623 0x7f7189ce8070 0x304ede4d7d60 
[1:1:0713/034024.252016:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034024.252303:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034024.252421:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034024.274989:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1625, 7f718c62d8db
[1:1:0713/034024.295968:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1623 0x7f7189ce8070 0x304ede4d7d60 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034024.296147:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1623 0x7f7189ce8070 0x304ede4d7d60 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034024.296346:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1627
[1:1:0713/034024.296467:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1627 0x7f7189ce8070 0x304ee03e3be0 , 5:3_http://news.sznews.com/, 0, , 1625 0x7f7189ce8070 0x304edfc4ec60 
[1:1:0713/034024.296667:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034024.296926:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034024.297021:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034024.319955:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1627, 7f718c62d8db
[1:1:0713/034024.340859:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1625 0x7f7189ce8070 0x304edfc4ec60 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034024.341050:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1625 0x7f7189ce8070 0x304edfc4ec60 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034024.341257:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1629
[1:1:0713/034024.341388:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1629 0x7f7189ce8070 0x304ee0298be0 , 5:3_http://news.sznews.com/, 0, , 1627 0x7f7189ce8070 0x304ee03e3be0 
[1:1:0713/034024.341600:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034024.341872:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034024.341993:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034024.364902:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1629, 7f718c62d8db
[1:1:0713/034024.385986:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1627 0x7f7189ce8070 0x304ee03e3be0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034024.386159:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1627 0x7f7189ce8070 0x304ee03e3be0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034024.386357:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1631
[1:1:0713/034024.386477:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1631 0x7f7189ce8070 0x304ee03c8b60 , 5:3_http://news.sznews.com/, 0, , 1629 0x7f7189ce8070 0x304ee0298be0 
[1:1:0713/034024.386683:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034024.386957:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034024.387074:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034024.409854:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1631, 7f718c62d8db
[1:1:0713/034024.430899:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1629 0x7f7189ce8070 0x304ee0298be0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034024.431113:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1629 0x7f7189ce8070 0x304ee0298be0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034024.431320:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1633
[1:1:0713/034024.431442:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1633 0x7f7189ce8070 0x304edf09c7e0 , 5:3_http://news.sznews.com/, 0, , 1631 0x7f7189ce8070 0x304ee03c8b60 
[1:1:0713/034024.431654:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034024.431928:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034024.432054:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034024.455071:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1633, 7f718c62d8db
[1:1:0713/034024.476317:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1631 0x7f7189ce8070 0x304ee03c8b60 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034024.476501:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1631 0x7f7189ce8070 0x304ee03c8b60 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034024.476706:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1635
[1:1:0713/034024.476818:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1635 0x7f7189ce8070 0x304ee05d59e0 , 5:3_http://news.sznews.com/, 0, , 1633 0x7f7189ce8070 0x304edf09c7e0 
[1:1:0713/034024.477014:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034024.477292:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034024.477408:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034024.500190:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1635, 7f718c62d8db
[1:1:0713/034024.521388:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1633 0x7f7189ce8070 0x304edf09c7e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034024.521570:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1633 0x7f7189ce8070 0x304edf09c7e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034024.521770:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1637
[1:1:0713/034024.521893:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1637 0x7f7189ce8070 0x304ee00d81e0 , 5:3_http://news.sznews.com/, 0, , 1635 0x7f7189ce8070 0x304ee05d59e0 
[1:1:0713/034024.522105:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034024.522402:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034024.522518:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034024.545242:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1637, 7f718c62d8db
[1:1:0713/034024.567022:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1635 0x7f7189ce8070 0x304ee05d59e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034024.567200:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1635 0x7f7189ce8070 0x304ee05d59e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034024.567406:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1641
[1:1:0713/034024.567539:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1641 0x7f7189ce8070 0x304ee08164e0 , 5:3_http://news.sznews.com/, 0, , 1637 0x7f7189ce8070 0x304ee00d81e0 
[1:1:0713/034024.567745:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034024.568024:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034024.568141:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034024.568858:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1641, 7f718c62d8db
[1:1:0713/034024.591080:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1637 0x7f7189ce8070 0x304ee00d81e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034024.591251:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1637 0x7f7189ce8070 0x304ee00d81e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034024.591445:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1643
[1:1:0713/034024.592016:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1643 0x7f7189ce8070 0x304ee03b6660 , 5:3_http://news.sznews.com/, 0, , 1641 0x7f7189ce8070 0x304ee08164e0 
[1:1:0713/034024.592245:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034024.592524:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034024.592642:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034024.620484:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1643, 7f718c62d8db
[1:1:0713/034024.641786:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1641 0x7f7189ce8070 0x304ee08164e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034024.642002:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1641 0x7f7189ce8070 0x304ee08164e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034024.642246:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1645
[1:1:0713/034024.642408:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1645 0x7f7189ce8070 0x304edfc265e0 , 5:3_http://news.sznews.com/, 0, , 1643 0x7f7189ce8070 0x304ee03b6660 
[1:1:0713/034024.642660:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034024.642971:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034024.643096:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034024.643803:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1645, 7f718c62d8db
[1:1:0713/034024.665655:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1643 0x7f7189ce8070 0x304ee03b6660 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034024.665832:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1643 0x7f7189ce8070 0x304ee03b6660 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034024.666031:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1647
[1:1:0713/034024.666153:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1647 0x7f7189ce8070 0x304ee03c8960 , 5:3_http://news.sznews.com/, 0, , 1645 0x7f7189ce8070 0x304edfc265e0 
[1:1:0713/034024.666366:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034024.666636:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034024.666755:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034024.695443:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1647, 7f718c62d8db
[1:1:0713/034024.717254:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1645 0x7f7189ce8070 0x304edfc265e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034024.717462:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1645 0x7f7189ce8070 0x304edfc265e0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034024.717707:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1649
[1:1:0713/034024.717872:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1649 0x7f7189ce8070 0x304ee0474360 , 5:3_http://news.sznews.com/, 0, , 1647 0x7f7189ce8070 0x304ee03c8960 
[1:1:0713/034024.718130:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034024.718454:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034024.718572:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034024.719290:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1649, 7f718c62d8db
[1:1:0713/034024.741167:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1647 0x7f7189ce8070 0x304ee03c8960 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034024.741355:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1647 0x7f7189ce8070 0x304ee03c8960 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034024.741556:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1651
[1:1:0713/034024.741677:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1651 0x7f7189ce8070 0x304ee0477ee0 , 5:3_http://news.sznews.com/, 0, , 1649 0x7f7189ce8070 0x304ee0474360 
[1:1:0713/034024.741886:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034024.742159:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034024.742274:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034024.770218:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1651, 7f718c62d8db
[1:1:0713/034024.791773:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1649 0x7f7189ce8070 0x304ee0474360 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034024.791953:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1649 0x7f7189ce8070 0x304ee0474360 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034024.792152:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1653
[1:1:0713/034024.792273:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1653 0x7f7189ce8070 0x304edfc233e0 , 5:3_http://news.sznews.com/, 0, , 1651 0x7f7189ce8070 0x304ee0477ee0 
[1:1:0713/034024.792481:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034024.792757:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , bc, ()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
	
[1:1:0713/034024.792877:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034025.515615:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.sznews.com/, 1473, 7f718c62d881
[1:1:0713/034025.537371:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b05cd0a2860","ptid":"1453 0x7f7189ce8070 0x304edfc28860 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034025.537606:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.sznews.com/","ptid":"1453 0x7f7189ce8070 0x304edfc28860 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034025.537837:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034025.538192:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , _fnScroll, (){
			var scrollNews = $('#scrollNews'),
				top = parseInt(scrollNews.css('top')),
				height =
[1:1:0713/034025.538357:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034025.570306:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2230870629c8, 0x304ede390950
[1:1:0713/034025.570480:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.sznews.com/node_33500.htm", 0
[1:1:0713/034025.570673:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.sznews.com/, 1655
[1:1:0713/034025.570805:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1655 0x7f7189ce8070 0x304ee0273de0 , 5:3_http://news.sznews.com/, 1, -5:3_http://news.sznews.com/, 1473 0x7f7189ce8070 0x304ee0267de0 
[1:1:0713/034025.576596:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.sznews.com/node_33500.htm", 13
[1:1:0713/034025.576794:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1656
[1:1:0713/034025.576907:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1656 0x7f7189ce8070 0x304edfc29560 , 5:3_http://news.sznews.com/, 1, -5:3_http://news.sznews.com/, 1473 0x7f7189ce8070 0x304ee0267de0 
[1:1:0713/034025.605809:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.sznews.com/, 1655, 7f718c62d881
[1:1:0713/034025.627399:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b05cd0a2860","ptid":"1473 0x7f7189ce8070 0x304ee0267de0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034025.627592:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.sznews.com/","ptid":"1473 0x7f7189ce8070 0x304ee0267de0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034025.627774:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034025.628054:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , , (){hb=void 0}
[1:1:0713/034025.628170:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034025.628602:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1656, 7f718c62d8db
[1:1:0713/034025.650207:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b05cd0a2860","ptid":"1473 0x7f7189ce8070 0x304ee0267de0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034025.650389:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.sznews.com/","ptid":"1473 0x7f7189ce8070 0x304ee0267de0 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034025.650589:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1662
[1:1:0713/034025.650713:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1662 0x7f7189ce8070 0x304edfc15c60 , 5:3_http://news.sznews.com/, 0, , 1656 0x7f7189ce8070 0x304edfc29560 
[1:1:0713/034025.650914:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034025.651183:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , n.fx.tick, (){var a,b=n.timers,c=0;for(hb=n.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0713/034025.651309:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0713/034025.675020:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1662, 7f718c62d8db
[1:1:0713/034025.696647:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1656 0x7f7189ce8070 0x304edfc29560 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034025.696829:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1656 0x7f7189ce8070 0x304edfc29560 ","rf":"5:3_http://news.sznews.com/"}
[1:1:0713/034025.697018:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1664
[1:1:0713/034025.697150:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1664 0x7f7189ce8070 0x304edf012660 , 5:3_http://news.sznews.com/, 0, , 1662 0x7f7189ce8070 0x304edfc15c60 
[1:1:0713/034025.697359:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.sznews.com/node_33500.htm"
[1:1:0713/034025.697631:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.sznews.com/, 2b05cd0a2860, , n.fx.tick, (){var a,b=n.timers,c=0;for(hb=n.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0713/034025.697748:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.sznews.com/node_33500.htm", "news.sznews.com", 3, 1, , , 0
[1:1:0100/000000.752108:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.sznews.com/, 1664, 7f718c62d8db
