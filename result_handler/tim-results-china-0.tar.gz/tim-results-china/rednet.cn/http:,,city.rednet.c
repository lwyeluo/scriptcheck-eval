[0712/145740.328547:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/145740.328801:INFO:switcher_clone.cc(787)] backtrace rip is 7ffb6461d891
[0712/145740.863450:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/145740.863695:INFO:switcher_clone.cc(787)] backtrace rip is 7faba3092891
[1:1:0712/145740.867481:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/145740.867641:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/145740.870423:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[9334:9334:0712/145741.608784:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/fd80ab4c-79f7-497c-bab7-64d7885b203c
[0712/145741.700850:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/145741.701126:INFO:switcher_clone.cc(787)] backtrace rip is 7f64fe0ed891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[9365:9365:0712/145741.853467:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=9365
[9378:9378:0712/145741.864100:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=9378
[9334:9334:0712/145741.873336:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[9334:9363:0712/145741.873717:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/145741.873839:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/145741.873974:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/145741.874255:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/145741.874391:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/145741.876071:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0xd8f7b9, 1
[1:1:0712/145741.876275:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x3e18be80, 0
[1:1:0712/145741.876368:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x2934c584, 3
[1:1:0712/145741.876455:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x1ad87208, 2
[1:1:0712/145741.876547:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffff80ffffffbe183e ffffffb9fffffff7ffffffd800 0872ffffffd81a ffffff84ffffffc53429 , 10104, 4
[1:1:0712/145741.877258:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[9334:9363:0712/145741.877380:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING��>���
[9334:9363:0712/145741.877427:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ��>���
[9334:9363:0712/145741.877579:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[9334:9363:0712/145741.877608:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 9386, 4, 80be183e b9f7d800 0872d81a 84c53429 
[1:1:0712/145741.877851:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7faba12cc0a0, 3
[1:1:0712/145741.877949:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7faba1458080, 2
[1:1:0712/145741.878037:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fab8b11ad20, -2
[1:1:0712/145741.885853:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/145741.886304:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1ad87208
[1:1:0712/145741.886786:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1ad87208
[1:1:0712/145741.887551:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1ad87208
[1:1:0712/145741.888105:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1ad87208
[1:1:0712/145741.888202:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1ad87208
[1:1:0712/145741.888327:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1ad87208
[1:1:0712/145741.888436:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1ad87208
[1:1:0712/145741.888703:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1ad87208
[1:1:0712/145741.888827:INFO:switcher_clone.cc(775)] clone wrapper rip is 7faba30927ba
[1:1:0712/145741.888905:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7faba3089def, 7faba309277a, 7faba30940cf
[1:1:0712/145741.890607:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1ad87208
[1:1:0712/145741.890830:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1ad87208
[1:1:0712/145741.891132:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1ad87208
[1:1:0712/145741.891900:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1ad87208
[1:1:0712/145741.892010:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1ad87208
[1:1:0712/145741.892107:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1ad87208
[1:1:0712/145741.892182:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1ad87208
[1:1:0712/145741.892654:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1ad87208
[1:1:0712/145741.892793:INFO:switcher_clone.cc(775)] clone wrapper rip is 7faba30927ba
[1:1:0712/145741.892846:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7faba3089def, 7faba309277a, 7faba30940cf
[1:1:0712/145741.895364:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/145741.895568:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/145741.895650:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fff65d86dc8, 0x7fff65d86d48)
[1:1:0712/145741.902300:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/145741.907599:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[9334:9334:0712/145742.300466:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[9334:9334:0712/145742.300975:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[9334:9345:0712/145742.309275:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[9334:9345:0712/145742.309339:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[9334:9334:0712/145742.309367:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[9334:9334:0712/145742.309410:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[9334:9334:0712/145742.309475:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,9386, 4
[1:7:0712/145742.310550:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/145742.311759:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x25198461c220
[1:1:0712/145742.312164:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[9334:9357:0712/145742.392010:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/145742.574831:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[9334:9334:0712/145743.200505:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[9334:9334:0712/145743.200589:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/145743.215791:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/145743.217504:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/145743.635071:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3af997da1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/145743.635250:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/145743.645288:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3af997da1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/145743.645453:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/145743.678627:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/145743.773664:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/145743.773824:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/145743.890716:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 359, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/145743.893199:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3af997da1f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/145743.893330:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/145743.905125:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 360, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/145743.908002:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3af997da1f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/145743.908128:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/145743.911870:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[9334:9334:0712/145743.912511:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/145743.913602:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x25198461ae20
[1:1:0712/145743.913708:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[9334:9334:0712/145743.914994:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[9334:9334:0712/145743.926327:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[9334:9334:0712/145743.926407:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/145743.945996:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/145744.243229:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 420 0x7fab8ccf52e0 0x2519848188e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/145744.243918:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3af997da1f78, , , var configData = {"googleBaseUrl":"https://www.google.com.hk/","isAccessibleBrowser":false,"isGoogle
[1:1:0712/145744.244043:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/145744.244582:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[9334:9334:0712/145744.269210:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/145744.270294:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x25198461b820
[1:1:0712/145744.270411:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[9334:9334:0712/145744.271631:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/145744.277242:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/145744.277401:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[9334:9334:0712/145744.278329:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[9334:9334:0712/145744.282347:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[9334:9334:0712/145744.282753:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[9334:9345:0712/145744.287059:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[9334:9345:0712/145744.287111:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[9334:9334:0712/145744.287129:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[9334:9334:0712/145744.287166:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[9334:9334:0712/145744.287222:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,9386, 4
[1:7:0712/145744.288645:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/145744.538377:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/145744.707556:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 477 0x7fab8ccf52e0 0x2519849bce60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/145744.708131:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3af997da1f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/145744.708282:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/145744.708654:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[9334:9334:0712/145744.780688:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[9334:9334:0712/145744.780749:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/145744.793303:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/145744.921535:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/145745.130108:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/145745.130278:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[9334:9334:0712/145745.183778:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[9334:9363:0712/145745.186371:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/145745.186506:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/145745.186635:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/145745.186819:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/145745.186896:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/145745.197318:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x853b36b, 1
[1:1:0712/145745.197542:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x30de7ea6, 0
[1:1:0712/145745.197641:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x39aafc91, 3
[1:1:0712/145745.197792:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x2e62431d, 2
[1:1:0712/145745.197940:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffa67effffffde30 6bffffffb35308 1d43622e ffffff91fffffffcffffffaa39 , 10104, 5
[1:1:0712/145745.198701:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[9334:9363:0712/145745.198911:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�~�0k�SCb.���9](�
[9334:9363:0712/145745.198962:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �~�0k�SCb.���9x](�
[1:1:0712/145745.198904:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7faba12cc0a0, 3
[9334:9363:0712/145745.199114:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 9428, 5, a67ede30 6bb35308 1d43622e 91fcaa39 
[1:1:0712/145745.199095:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7faba1458080, 2
[1:1:0712/145745.199201:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fab8b11ad20, -2
[1:1:0712/145745.208297:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/145745.208529:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2e62431d
[1:1:0712/145745.208730:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2e62431d
[1:1:0712/145745.208969:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2e62431d
[1:1:0712/145745.209464:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2e62431d
[1:1:0712/145745.209578:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2e62431d
[1:1:0712/145745.209688:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2e62431d
[1:1:0712/145745.209802:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2e62431d
[1:1:0712/145745.210062:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2e62431d
[1:1:0712/145745.210205:INFO:switcher_clone.cc(775)] clone wrapper rip is 7faba30927ba
[1:1:0712/145745.210301:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7faba3089def, 7faba309277a, 7faba30940cf
[1:1:0712/145745.211868:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2e62431d
[1:1:0712/145745.212026:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2e62431d
[1:1:0712/145745.212310:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2e62431d
[1:1:0712/145745.213049:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2e62431d
[1:1:0712/145745.213189:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2e62431d
[1:1:0712/145745.213287:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2e62431d
[1:1:0712/145745.213384:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2e62431d
[1:1:0712/145745.213851:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2e62431d
[1:1:0712/145745.214010:INFO:switcher_clone.cc(775)] clone wrapper rip is 7faba30927ba
[1:1:0712/145745.214091:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7faba3089def, 7faba309277a, 7faba30940cf
[1:1:0712/145745.216596:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/145745.216806:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/145745.216878:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fff65d86dc8, 0x7fff65d86d48)
[1:1:0712/145745.222996:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/145745.225141:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/145745.287597:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 538, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/145745.289441:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3af997ece5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/145745.289635:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/145745.291994:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/145745.318167:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x2519845e6220
[1:1:0712/145745.319452:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[9334:9334:0712/145745.858037:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[9334:9334:0712/145745.870302:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 6
[9334:9363:0712/145745.873206:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 6
[3:3:0712/145745.873357:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/145745.873477:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/145745.873657:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/145745.873744:INFO:zygote_linux.cc(633)] 		cid is 6
[1:1:0712/145745.876006:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x15b2234c, 1
[1:1:0712/145745.876792:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x2c0afdc6, 0
[1:1:0712/145745.877627:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x3b350428, 3
[1:1:0712/145745.877754:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x138fca4a, 2
[1:1:0712/145745.877904:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffc6fffffffd0a2c 4c23ffffffb215 4affffffcaffffff8f13 2804353b , 10104, 6
[1:1:0712/145745.879282:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[9334:9363:0712/145745.879422:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING��
,L#�Jʏ(5;A&�
[9334:9363:0712/145745.879468:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ��
,L#�Jʏ(5;5A&�
[9334:9363:0712/145745.879610:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 9440, 6, c6fd0a2c 4c23b215 4aca8f13 2804353b 
[1:1:0712/145745.879787:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7faba12cc0a0, 3
[1:1:0712/145745.879882:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7faba1458080, 2
[1:1:0712/145745.879975:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fab8b11ad20, -2
[9334:9334:0712/145745.883656:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0712/145745.888976:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/145745.889201:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 138fca4a
[1:1:0712/145745.889341:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 138fca4a
[1:1:0712/145745.889583:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 138fca4a
[1:1:0712/145745.890082:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 138fca4a
[1:1:0712/145745.890203:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 138fca4a
[1:1:0712/145745.890304:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 138fca4a
[1:1:0712/145745.890400:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 138fca4a
[1:1:0712/145745.890671:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 138fca4a
[1:1:0712/145745.890808:INFO:switcher_clone.cc(775)] clone wrapper rip is 7faba30927ba
[1:1:0712/145745.890889:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7faba3089def, 7faba309277a, 7faba30940cf
[1:1:0712/145745.892540:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 138fca4a
[1:1:0712/145745.892704:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 138fca4a
[1:1:0712/145745.892995:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 138fca4a
[1:1:0712/145745.893823:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 138fca4a
[1:1:0712/145745.893955:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 138fca4a
[1:1:0712/145745.894071:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 138fca4a
[1:1:0712/145745.894185:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 138fca4a
[1:1:0712/145745.894684:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 138fca4a
[1:1:0712/145745.894866:INFO:switcher_clone.cc(775)] clone wrapper rip is 7faba30927ba
[1:1:0712/145745.895047:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7faba3089def, 7faba309277a, 7faba30940cf
[1:1:0712/145745.897709:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/145745.897926:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/145745.898025:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fff65d86dc8, 0x7fff65d86d48)
[9334:9345:0712/145745.900764:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 6, 3
[9334:9345:0712/145745.900831:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 6, 3, HandleIncomingMessage, HandleIncomingMessage
[9334:9334:0712/145745.900998:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://city.rednet.cn/
[9334:9334:0712/145745.901048:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:3_https://city.rednet.cn/, https://city.rednet.cn/, 1
[9334:9334:0712/145745.901113:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 6:3_https://city.rednet.cn/, HTTP/1.1 200 OK Server: nginx Date: Fri, 12 Jul 2019 06:57:45 GMT Content-Type: text/html Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Strict-Transport-Security: max-age=3600; includeSubdomains; preload Content-Encoding: gzip  ,0, 6
[1:1:0712/145745.904242:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/145745.907429:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[3:3:0712/145745.909766:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:7:0712/145745.936592:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/145746.005276:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x251984628220
[1:1:0712/145746.005432:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/145746.036360:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 6:3_https://city.rednet.cn/
[9334:9334:0712/145746.131844:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:3_https://city.rednet.cn/, https://city.rednet.cn/, 1
[9334:9334:0712/145746.131951:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://city.rednet.cn/, https://city.rednet.cn
[1:1:0712/145746.145795:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/145746.196256:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/145746.213876:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/145746.242134:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/145746.242291:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://city.rednet.cn/"
[1:1:0712/145746.339727:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/145746.444758:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/145746.528191:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/145746.568089:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/145746.617976:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/145746.647605:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/145746.665989:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 170 0x7fab8b135bd0 0x251984789b58 , "https://city.rednet.cn/"
[1:1:0712/145746.668653:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://city.rednet.cn/, 27e311822860, , , /*! jQuery v1.11.3 | (c) 2005, 2015 jQuery Foundation, Inc. | jquery.org/license */
!function(a,b){"
[1:1:0712/145746.668834:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://city.rednet.cn/", "city.rednet.cn", 3, 1, , , 0
[1:1:0712/145746.675908:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/145747.752490:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/145748.142602:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/145748.142807:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://city.rednet.cn/"
[1:1:0712/145748.290940:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.148072, 2365, 1
[1:1:0712/145748.291125:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/145750.457736:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/145752.173851:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/145752.174071:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://city.rednet.cn/"
[1:1:0712/145752.175350:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 634 0x7fab8adcd070 0x251984d312e0 , "https://city.rednet.cn/"
[1:1:0712/145752.176233:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://city.rednet.cn/, 27e311822860, , , // JavaScript Document
function funRoll(div){
	var obj=$("#"+div),
		top=obj.find(".top"),
		lis
[1:1:0712/145752.176360:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://city.rednet.cn/", "city.rednet.cn", 3, 1, , , 0
[1:1:0712/145752.194555:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://city.rednet.cn/", 5000
[1:1:0712/145752.194834:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://city.rednet.cn/, 724
[1:1:0712/145752.194960:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 724 0x7fab8adcd070 0x251984484760 , 6:3_https://city.rednet.cn/, 1, -6:3_https://city.rednet.cn/, 634 0x7fab8adcd070 0x251984d312e0 
[1:1:0712/145752.233979:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://city.rednet.cn/", 5000
[1:1:0712/145752.234228:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://city.rednet.cn/, 726
[1:1:0712/145752.234356:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 726 0x7fab8adcd070 0x2519847a5ee0 , 6:3_https://city.rednet.cn/, 1, -6:3_https://city.rednet.cn/, 634 0x7fab8adcd070 0x251984d312e0 
[1:1:0712/145752.265648:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://city.rednet.cn/", 5000
[1:1:0712/145752.265897:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://city.rednet.cn/, 728
[1:1:0712/145752.266023:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 728 0x7fab8adcd070 0x251984bc8460 , 6:3_https://city.rednet.cn/, 1, -6:3_https://city.rednet.cn/, 634 0x7fab8adcd070 0x251984d312e0 
[1:1:0712/145752.268880:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 634 0x7fab8adcd070 0x251984d312e0 , "https://city.rednet.cn/"
[1:1:0712/145752.298852:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://city.rednet.cn/"
[3:3:0712/145757.450774:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/145758.365612:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://city.rednet.cn/, 27e311822860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/145758.365811:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://city.rednet.cn/", "city.rednet.cn", 3, 1, , , 0
[1:1:0712/145758.555386:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://city.rednet.cn/, 724, 7fab8d7128db
[1:1:0712/145758.572245:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"27e311822860","ptid":"634 0x7fab8adcd070 0x251984d312e0 ","rf":"6:3_https://city.rednet.cn/"}
[1:1:0712/145758.572472:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://city.rednet.cn/","ptid":"634 0x7fab8adcd070 0x251984d312e0 ","rf":"6:3_https://city.rednet.cn/"}
[1:1:0712/145758.572737:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://city.rednet.cn/, 1048
[1:1:0712/145758.572828:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1048 0x7fab8adcd070 0x251984bf60e0 , 6:3_https://city.rednet.cn/, 0, , 724 0x7fab8adcd070 0x251984484760 
[1:1:0712/145758.573059:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://city.rednet.cn/"
[1:1:0712/145758.573438:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://city.rednet.cn/, 27e311822860, , funGo, (){
		funShow(curr);
		curr=funNext(curr);
	}
[1:1:0712/145758.573585:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://city.rednet.cn/", "city.rednet.cn", 3, 1, , , 0
[1:1:0712/145758.615787:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://city.rednet.cn/, 726, 7fab8d7128db
[1:1:0712/145758.632999:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"27e311822860","ptid":"634 0x7fab8adcd070 0x251984d312e0 ","rf":"6:3_https://city.rednet.cn/"}
[1:1:0712/145758.633220:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://city.rednet.cn/","ptid":"634 0x7fab8adcd070 0x251984d312e0 ","rf":"6:3_https://city.rednet.cn/"}
[1:1:0712/145758.633468:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://city.rednet.cn/, 1052
[1:1:0712/145758.633592:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1052 0x7fab8adcd070 0x251984cc5a60 , 6:3_https://city.rednet.cn/, 0, , 726 0x7fab8adcd070 0x2519847a5ee0 
[1:1:0712/145758.633803:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://city.rednet.cn/"
[1:1:0712/145758.634076:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://city.rednet.cn/, 27e311822860, , funGo, (){
		funShow(curr);
		curr=funNext(curr);
	}
[1:1:0712/145758.634181:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://city.rednet.cn/", "city.rednet.cn", 3, 1, , , 0
[1:1:0712/145758.722527:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://city.rednet.cn/, 728, 7fab8d7128db
[1:1:0712/145758.739613:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"27e311822860","ptid":"634 0x7fab8adcd070 0x251984d312e0 ","rf":"6:3_https://city.rednet.cn/"}
[1:1:0712/145758.739779:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://city.rednet.cn/","ptid":"634 0x7fab8adcd070 0x251984d312e0 ","rf":"6:3_https://city.rednet.cn/"}
[1:1:0712/145758.739996:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://city.rednet.cn/, 1054
[1:1:0712/145758.740110:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1054 0x7fab8adcd070 0x2519848cfee0 , 6:3_https://city.rednet.cn/, 0, , 728 0x7fab8adcd070 0x251984bc8460 
[1:1:0712/145758.740327:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://city.rednet.cn/"
[1:1:0712/145758.740567:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://city.rednet.cn/, 27e311822860, , funGo, (){
		funShow(curr);
		curr=funNext(curr);
	}
[1:1:0712/145758.740676:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://city.rednet.cn/", "city.rednet.cn", 3, 1, , , 0
[1:1:0712/145759.499726:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://city.rednet.cn/, 27e311822860, , , document.readyState
[1:1:0712/145759.499915:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://city.rednet.cn/", "city.rednet.cn", 3, 1, , , 0
[1:1:0712/145800.374609:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://city.rednet.cn/, 27e311822860, , , document.readyState
[1:1:0712/145800.374831:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://city.rednet.cn/", "city.rednet.cn", 3, 1, , , 0
[1:1:0712/145801.980334:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://city.rednet.cn/, 27e311822860, , , document.readyState
[1:1:0712/145801.980539:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://city.rednet.cn/", "city.rednet.cn", 3, 1, , , 0
[1:1:0712/145805.893909:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://city.rednet.cn/, 27e311822860, , , document.readyState
[1:1:0712/145805.894113:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://city.rednet.cn/", "city.rednet.cn", 3, 1, , , 0
[1:1:0712/145806.394062:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://city.rednet.cn/, 1048, 7fab8d7128db
[1:1:0712/145806.425674:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"724 0x7fab8adcd070 0x251984484760 ","rf":"6:3_https://city.rednet.cn/"}
[1:1:0712/145806.425966:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"724 0x7fab8adcd070 0x251984484760 ","rf":"6:3_https://city.rednet.cn/"}
[1:1:0712/145806.426201:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://city.rednet.cn/, 1757
[1:1:0712/145806.426352:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1757 0x7fab8adcd070 0x25198686b5e0 , 6:3_https://city.rednet.cn/, 0, , 1048 0x7fab8adcd070 0x251984bf60e0 
[1:1:0712/145806.426581:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://city.rednet.cn/"
[1:1:0712/145806.426860:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://city.rednet.cn/, 27e311822860, , funGo, (){
		funShow(curr);
		curr=funNext(curr);
	}
[1:1:0712/145806.426963:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://city.rednet.cn/", "city.rednet.cn", 3, 1, , , 0
[1:1:0712/145806.496667:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://city.rednet.cn/, 1052, 7fab8d7128db
[1:1:0712/145806.528320:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"726 0x7fab8adcd070 0x2519847a5ee0 ","rf":"6:3_https://city.rednet.cn/"}
[1:1:0712/145806.528523:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"726 0x7fab8adcd070 0x2519847a5ee0 ","rf":"6:3_https://city.rednet.cn/"}
[1:1:0712/145806.528756:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://city.rednet.cn/, 1769
[1:1:0712/145806.528993:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1769 0x7fab8adcd070 0x2519864f3a60 , 6:3_https://city.rednet.cn/, 0, , 1052 0x7fab8adcd070 0x251984cc5a60 
[1:1:0712/145806.529263:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://city.rednet.cn/"
[1:1:0712/145806.529561:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://city.rednet.cn/, 27e311822860, , funGo, (){
		funShow(curr);
		curr=funNext(curr);
	}
[1:1:0712/145806.529797:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://city.rednet.cn/", "city.rednet.cn", 3, 1, , , 0
[1:1:0712/145806.713766:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://city.rednet.cn/, 1054, 7fab8d7128db
[1:1:0712/145806.745248:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"728 0x7fab8adcd070 0x251984bc8460 ","rf":"6:3_https://city.rednet.cn/"}
[1:1:0712/145806.745412:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"728 0x7fab8adcd070 0x251984bc8460 ","rf":"6:3_https://city.rednet.cn/"}
[1:1:0712/145806.745622:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://city.rednet.cn/, 1789
[1:1:0712/145806.745714:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1789 0x7fab8adcd070 0x2519869e6de0 , 6:3_https://city.rednet.cn/, 0, , 1054 0x7fab8adcd070 0x2519848cfee0 
[1:1:0712/145806.745925:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://city.rednet.cn/"
[1:1:0712/145806.746197:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://city.rednet.cn/, 27e311822860, , funGo, (){
		funShow(curr);
		curr=funNext(curr);
	}
[1:1:0712/145806.746302:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://city.rednet.cn/", "city.rednet.cn", 3, 1, , , 0
[1:1:0712/145825.380655:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://city.rednet.cn/, 27e311822860, , , document.readyState
[1:1:0712/145825.380865:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://city.rednet.cn/", "city.rednet.cn", 3, 1, , , 0
[1:1:0712/145831.369620:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://city.rednet.cn/, 1757, 7fab8d7128db
[1:1:0712/145831.410446:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1048 0x7fab8adcd070 0x251984bf60e0 ","rf":"6:3_https://city.rednet.cn/"}
[1:1:0712/145831.410668:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1048 0x7fab8adcd070 0x251984bf60e0 ","rf":"6:3_https://city.rednet.cn/"}
[1:1:0712/145831.410907:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://city.rednet.cn/, 2635
[1:1:0712/145831.411062:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2635 0x7fab8adcd070 0x25198718d660 , 6:3_https://city.rednet.cn/, 0, , 1757 0x7fab8adcd070 0x25198686b5e0 
[1:1:0712/145831.411304:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://city.rednet.cn/"
[1:1:0712/145831.411594:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://city.rednet.cn/, 27e311822860, , funGo, (){
		funShow(curr);
		curr=funNext(curr);
	}
[1:1:0712/145831.411701:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://city.rednet.cn/", "city.rednet.cn", 3, 1, , , 0
[1:1:0712/145831.627205:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://city.rednet.cn/, 1769, 7fab8d7128db
[1:1:0712/145831.667572:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1052 0x7fab8adcd070 0x251984cc5a60 ","rf":"6:3_https://city.rednet.cn/"}
[1:1:0712/145831.667772:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1052 0x7fab8adcd070 0x251984cc5a60 ","rf":"6:3_https://city.rednet.cn/"}
[1:1:0712/145831.667996:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://city.rednet.cn/, 2638
[1:1:0712/145831.668120:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2638 0x7fab8adcd070 0x251984b29ae0 , 6:3_https://city.rednet.cn/, 0, , 1769 0x7fab8adcd070 0x2519864f3a60 
[1:1:0712/145831.668322:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://city.rednet.cn/"
[1:1:0712/145831.668592:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://city.rednet.cn/, 27e311822860, , funGo, (){
		funShow(curr);
		curr=funNext(curr);
	}
[1:1:0712/145831.668697:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://city.rednet.cn/", "city.rednet.cn", 3, 1, , , 0
[1:1:0712/145831.938884:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://city.rednet.cn/, 1789, 7fab8d7128db
[1:1:0712/145831.981298:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1054 0x7fab8adcd070 0x2519848cfee0 ","rf":"6:3_https://city.rednet.cn/"}
[1:1:0712/145831.981471:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1054 0x7fab8adcd070 0x2519848cfee0 ","rf":"6:3_https://city.rednet.cn/"}
[1:1:0712/145831.981668:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://city.rednet.cn/, 2641
[1:1:0712/145831.981801:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2641 0x7fab8adcd070 0x251987179a60 , 6:3_https://city.rednet.cn/, 0, , 1789 0x7fab8adcd070 0x2519869e6de0 
[1:1:0712/145831.981990:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://city.rednet.cn/"
[1:1:0712/145831.982249:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://city.rednet.cn/, 27e311822860, , funGo, (){
		funShow(curr);
		curr=funNext(curr);
	}
[1:1:0712/145831.982355:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://city.rednet.cn/", "city.rednet.cn", 3, 1, , , 0
[9334:9345:0712/145847.470608:ERROR:ssl_client_socket_impl.cc(1046)] handshake failed; returned -1, SSL error code 1, net_error -101
[9334:9345:0712/145847.514308:ERROR:ssl_client_socket_impl.cc(1046)] handshake failed; returned -1, SSL error code 1, net_error -101
