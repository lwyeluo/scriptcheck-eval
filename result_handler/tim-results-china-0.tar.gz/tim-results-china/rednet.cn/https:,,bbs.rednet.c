[0712/144929.307265:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/144929.307522:INFO:switcher_clone.cc(787)] backtrace rip is 7f9f85cdd891
[0712/144929.847828:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/144929.848072:INFO:switcher_clone.cc(787)] backtrace rip is 7f5b6f8d0891
[1:1:0712/144929.851900:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/144929.852064:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/144929.854882:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[7921:7921:0712/144930.595024:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/eebd4037-a339-48e6-a57d-24e7176a62fb
[0712/144930.704127:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/144930.704414:INFO:switcher_clone.cc(787)] backtrace rip is 7f4e91427891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[7953:7953:0712/144930.854617:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=7953
[7966:7966:0712/144930.855068:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=7966
[7921:7921:0712/144930.858913:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[7921:7951:0712/144930.859286:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/144930.859404:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/144930.859552:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/144930.859841:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/144930.859959:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/144930.862387:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x887c60, 1
[1:1:0712/144930.862605:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x214f0f18, 0
[1:1:0712/144930.862694:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x3cdab0fb, 3
[1:1:0712/144930.862779:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x2b6a64b2, 2
[1:1:0712/144930.862869:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 180f4f21 607cffffff8800 ffffffb2646a2b fffffffbffffffb0ffffffda3c , 10104, 4
[1:1:0712/144930.863561:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[7921:7951:0712/144930.863679:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGO!`|�
[7921:7951:0712/144930.863723:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is O!`|�
[7921:7951:0712/144930.863873:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[7921:7951:0712/144930.863904:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 7968, 4, 180f4f21 607c8800 b2646a2b fbb0da3c 
[1:1:0712/144930.864148:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f5b6db0a0a0, 3
[1:1:0712/144930.864257:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f5b6dc96080, 2
[1:1:0712/144930.864336:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f5b57958d20, -2
[1:1:0712/144930.872257:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/144930.872739:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2b6a64b2
[1:1:0712/144930.873229:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2b6a64b2
[1:1:0712/144930.874024:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2b6a64b2
[1:1:0712/144930.874586:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2b6a64b2
[1:1:0712/144930.874694:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2b6a64b2
[1:1:0712/144930.874789:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2b6a64b2
[1:1:0712/144930.874879:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2b6a64b2
[1:1:0712/144930.875120:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2b6a64b2
[1:1:0712/144930.875276:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f5b6f8d07ba
[1:1:0712/144930.875352:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f5b6f8c7def, 7f5b6f8d077a, 7f5b6f8d20cf
[1:1:0712/144930.877053:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2b6a64b2
[1:1:0712/144930.877226:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2b6a64b2
[1:1:0712/144930.877525:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2b6a64b2
[1:1:0712/144930.878311:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2b6a64b2
[1:1:0712/144930.878417:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2b6a64b2
[1:1:0712/144930.878519:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2b6a64b2
[1:1:0712/144930.878630:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2b6a64b2
[1:1:0712/144930.880772:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2b6a64b2
[1:1:0712/144930.881109:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f5b6f8d07ba
[1:1:0712/144930.881213:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f5b6f8c7def, 7f5b6f8d077a, 7f5b6f8d20cf
[1:1:0712/144930.884296:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/144930.884499:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/144930.884587:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffef97b4a18, 0x7ffef97b4998)
[1:1:0712/144930.891044:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/144930.897756:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[7921:7921:0712/144931.297175:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[7921:7921:0712/144931.297647:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[7921:7933:0712/144931.306105:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[7921:7921:0712/144931.306196:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[7921:7933:0712/144931.306188:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[7921:7921:0712/144931.306243:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[7921:7921:0712/144931.306322:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,7968, 4
[1:7:0712/144931.307300:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/144931.312769:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0xc8b70319220
[1:1:0712/144931.312899:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[7921:7945:0712/144931.428264:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/144931.529050:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[7921:7921:0712/144932.176140:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[7921:7921:0712/144932.176217:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/144932.191861:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/144932.193527:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/144932.594752:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2d01f1a21f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/144932.594941:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/144932.599940:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2d01f1a21f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/144932.600066:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/144932.621396:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/144932.732918:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/144932.733115:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/144932.850194:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 357, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/144932.852697:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2d01f1a21f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/144932.852827:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/144932.864604:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 358, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/144932.867582:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2d01f1a21f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/144932.867708:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/144932.871515:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[7921:7921:0712/144932.872180:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/144932.873294:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0xc8b70317e20
[1:1:0712/144932.873394:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[7921:7921:0712/144932.874597:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[7921:7921:0712/144932.886067:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[7921:7921:0712/144932.886144:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/144932.905531:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/144933.193319:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 417 0x7f5b595332e0 0xc8b70527b60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/144933.194056:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2d01f1a21f78, , , var configData = {"googleBaseUrl":"https://www.google.com.hk/","isAccessibleBrowser":false,"isGoogle
[1:1:0712/144933.194171:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/144933.194704:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[7921:7921:0712/144933.220215:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/144933.221322:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0xc8b70318820
[1:1:0712/144933.221472:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[7921:7921:0712/144933.222597:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/144933.228280:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/144933.228491:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[7921:7921:0712/144933.229409:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[7921:7921:0712/144933.233259:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[7921:7921:0712/144933.233650:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[7921:7933:0712/144933.238094:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[7921:7933:0712/144933.238147:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[7921:7921:0712/144933.238168:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[7921:7921:0712/144933.238206:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[7921:7921:0712/144933.238262:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,7968, 4
[1:7:0712/144933.239788:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/144933.479515:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/144933.644480:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 471 0x7f5b595332e0 0xc8b706affe0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/144933.645101:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2d01f1a21f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/144933.645261:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/144933.645631:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[7921:7921:0712/144933.716824:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[7921:7921:0712/144933.716892:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/144933.728226:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/144933.856423:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/144934.011030:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/144934.011232:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/144934.178639:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 531, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/144934.180305:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2d01f1b4e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/144934.180472:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/144934.182858:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[7921:7921:0712/144934.206889:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[7921:7951:0712/144934.207161:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/144934.207287:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/144934.207418:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/144934.207604:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/144934.207680:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/144934.209796:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x3f657abe, 1
[1:1:0712/144934.210010:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x1ae0e251, 0
[1:1:0712/144934.210102:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x1f0f41ba, 3
[1:1:0712/144934.210186:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x22247725, 2
[1:1:0712/144934.210263:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 51ffffffe2ffffffe01a ffffffbe7a653f 25772422 ffffffba410f1f , 10104, 5
[1:1:0712/144934.210944:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[7921:7951:0712/144934.211089:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGQ���ze?%w$"�Aq�$
[1:1:0712/144934.211080:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f5b6db0a0a0, 3
[7921:7951:0712/144934.211131:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is Q���ze?%w$"�Ah�q�$
[1:1:0712/144934.211165:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f5b6dc96080, 2
[7921:7951:0712/144934.211279:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 8016, 5, 51e2e01a be7a653f 25772422 ba410f1f 
[1:1:0712/144934.211261:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f5b57958d20, -2
[1:1:0712/144934.220405:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/144934.221628:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 22247725
[1:1:0712/144934.221813:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 22247725
[1:1:0712/144934.222084:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 22247725
[1:1:0712/144934.222579:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 22247725
[1:1:0712/144934.222730:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 22247725
[1:1:0712/144934.222872:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 22247725
[1:1:0712/144934.222985:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 22247725
[1:1:0712/144934.223244:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 22247725
[1:1:0712/144934.223379:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f5b6f8d07ba
[1:1:0712/144934.223464:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f5b6f8c7def, 7f5b6f8d077a, 7f5b6f8d20cf
[1:1:0712/144934.225140:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 22247725
[1:1:0712/144934.225318:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 22247725
[1:1:0712/144934.225625:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 22247725
[1:1:0712/144934.226389:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 22247725
[1:1:0712/144934.226517:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 22247725
[1:1:0712/144934.226632:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 22247725
[1:1:0712/144934.226746:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 22247725
[1:1:0712/144934.227244:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 22247725
[1:1:0712/144934.227426:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f5b6f8d07ba
[1:1:0712/144934.227511:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f5b6f8c7def, 7f5b6f8d077a, 7f5b6f8d20cf
[1:1:0712/144934.230091:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/144934.230323:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/144934.230432:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffef97b4a18, 0x7ffef97b4998)
[1:1:0712/144934.236641:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/144934.239153:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/144934.249121:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/144934.249522:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2d01f1a21f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/144934.249630:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/144934.339062:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0xc8b702e7220
[1:1:0712/144934.339605:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/144934.359260:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/144934.360035:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/144934.360318:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2d01f1b4e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/144934.360454:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/144934.428539:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/144934.428956:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/144934.429085:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2d01f1b4e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/144934.429199:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/144934.723595:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.qq.com/"
[1:1:0712/144934.756412:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://amazon.com/"
[1:1:0712/144934.820315:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://taobao.com/"
[1:1:0712/144934.854234:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://tmall.com/"
[1:1:0712/144934.879211:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://vk.com/"
[1:1:0712/144934.915049:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.jd.com/"
[1:1:0712/144934.940617:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://yahoo.com/"
[1:1:0712/144934.975633:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://sohu.com/"
[1:1:0712/144934.997104:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/144934.997534:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2d01f1b4e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/144934.997665:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/144935.043416:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/144935.043824:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2d01f1b4e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/144935.043950:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/144935.073749:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/144935.074149:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2d01f1b4e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/144935.074273:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/144935.095241:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/144935.095644:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2d01f1b4e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/144935.095767:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/144935.133422:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/144935.133824:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2d01f1b4e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/144935.133948:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/144935.174094:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/144935.174502:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2d01f1b4e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/144935.174697:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/144935.195344:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/144935.195783:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2d01f1b4e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/144935.195926:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/144935.234037:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/144935.234479:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2d01f1b4e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/144935.234637:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/144935.277752:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/144935.278212:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2d01f1b4e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/144935.278352:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/144935.299618:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/144935.300082:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2d01f1b4e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/144935.300235:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/144935.352001:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/144935.352483:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2d01f1b4e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/144935.352626:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/144935.384019:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/144935.384453:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2d01f1b4e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/144935.384602:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/144935.405458:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/144935.405852:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2d01f1b4e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/144935.405973:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[7921:7933:0712/144935.432345:ERROR:ssl_client_socket_impl.cc(1046)] handshake failed; returned -1, SSL error code 1, net_error -101
[1:1:0712/144935.444349:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/144935.444770:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2d01f1b4e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/144935.444912:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/144935.485626:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/144935.486079:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2d01f1b4e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/144935.486206:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/144935.515460:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/144935.515891:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2d01f1b4e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/144935.516019:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[7921:7921:0712/144935.675762:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[7921:7921:0712/144935.678150:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0712/144935.691344:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/144935.691990:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:1_chrome-search://local-ntp/, 4:4_chrome-search://most-visited/
[1:1:0712/144935.692106:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2d01f1a21f78, , handlePostMessage, (event) {
  var cmd = event.data.cmd;
  var args = event.data;
  if (cmd === 'loaded') {
    tilesAr
[1:1:0712/144935.692221:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[7921:7933:0712/144935.694106:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[7921:7933:0712/144935.694165:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[7921:7921:0712/144935.694327:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://bbs.rednet.cn/
[7921:7921:0712/144935.694369:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://bbs.rednet.cn/, https://bbs.rednet.cn/thread-48108136-1-1.html, 1
[7921:7921:0712/144935.694434:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_https://bbs.rednet.cn/, HTTP/1.1 521 Server: nginx Date: Fri, 12 Jul 2019 06:49:35 GMT Transfer-Encoding: chunked Connection: keep-alive X-Via-JSL: 2768106,- Set-Cookie: __jsluid_s=d583230877d02d45f2a195a08964edf5; max-age=31536000; path=/; HttpOnly; secure Connection: close  ,8016, 5
[1:7:0712/144935.696451:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/144935.713709:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_https://bbs.rednet.cn/
[1:1:0712/144935.720373:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: the server responded with a status of 521 ()","https://bbs.rednet.cn/thread-48108136-1-1.html"
[7921:7921:0712/144935.785673:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://bbs.rednet.cn/, https://bbs.rednet.cn/, 1
[7921:7921:0712/144935.785729:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://bbs.rednet.cn/, https://bbs.rednet.cn
[1:1:0712/144935.797387:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/144935.847510:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/144935.878769:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/144935.878944:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://bbs.rednet.cn/thread-48108136-1-1.html"
[1:1:0712/144935.880416:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 139 0x7f5b5760b070 0xc8b704127e0 , "https://bbs.rednet.cn/thread-48108136-1-1.html"
[1:1:0712/144935.881447:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bbs.rednet.cn/, 3fd748482860, , , var x="if@reverse@@19@charAt@@1562914175@for@@chars@@@attachEvent@@49@@@@e@parseInt@onreadystatechan
[1:1:0712/144935.881569:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.rednet.cn/thread-48108136-1-1.html", "bbs.rednet.cn", 3, 1, , , 0
[1:1:0712/144936.834022:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/144936.901716:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 1.0228, 0, 0
[1:1:0712/144936.901939:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/144936.915363:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/144936.915555:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://bbs.rednet.cn/thread-48108136-1-1.html"
[1:1:0712/144936.916960:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://bbs.rednet.cn/thread-48108136-1-1.html"
[1:1:0712/144936.917869:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bbs.rednet.cn/, 3fd748482860, , _1a, (){setTimeout('location.href=location.pathname+location.search.replace(/[\?|&]captcha-challenge/,\'\
[1:1:0712/144936.918032:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.rednet.cn/thread-48108136-1-1.html", "bbs.rednet.cn", 3, 1, , , 0
[1:1:0712/144936.918813:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://bbs.rednet.cn/thread-48108136-1-1.html", 1500
[1:1:0712/144936.919133:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bbs.rednet.cn/, 149
[1:1:0712/144936.919752:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 149 0x7f5b5760b070 0xc8b703a0e60 , 5:3_https://bbs.rednet.cn/, 1, -5:3_https://bbs.rednet.cn/, 144 0x7f5b5760b070 0xc8b70412e60 
[1:1:0712/144939.458298:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[3:3:0712/144945.909156:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/144950.277315:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bbs.rednet.cn/, 3fd748482860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/144950.277536:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.rednet.cn/thread-48108136-1-1.html", "bbs.rednet.cn", 3, 1, , , 0
[1:1:0712/144950.342375:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bbs.rednet.cn/, 149, 7f5b59f50881
[1:1:0712/144950.344827:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3fd748482860","ptid":"144 0x7f5b5760b070 0xc8b70412e60 ","rf":"5:3_https://bbs.rednet.cn/"}
[1:1:0712/144950.344984:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://bbs.rednet.cn/","ptid":"144 0x7f5b5760b070 0xc8b70412e60 ","rf":"5:3_https://bbs.rednet.cn/"}
[1:1:0712/144950.345148:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://bbs.rednet.cn/thread-48108136-1-1.html"
[1:1:0712/144950.345664:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bbs.rednet.cn/, 3fd748482860, , , location.href=location.pathname+location.search.replace(/[?|&]captcha-challenge/,'')
[1:1:0712/144950.345786:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.rednet.cn/thread-48108136-1-1.html", "bbs.rednet.cn", 3, 1, , , 0
[1:1:0712/144950.372997:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/144950.373160:INFO:render_frame_impl.cc(7019)] 	 [url] = https://bbs.rednet.cn
[7921:7921:0712/144953.389048:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_https://bbs.rednet.cn/
[7921:7921:0712/144955.643285:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[7921:7921:0712/144955.643732:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[7921:7933:0712/144955.651192:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[7921:7933:0712/144955.651256:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[7921:7921:0712/144955.651277:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://bbs.rednet.cn/
[7921:7921:0712/144955.651317:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://bbs.rednet.cn/, https://bbs.rednet.cn/thread-48108136-1-1.html, 1
[7921:7921:0712/144955.651357:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_https://bbs.rednet.cn/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 06:49:55 GMT Content-Type: text/html; charset=gbk Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Set-Cookie: FKPl_e1a1_saltkey=wsPwZ1p5; expires=Sun, 11-Aug-2019 06:49:54 GMT; path=/; domain=rednet.cn; httponly Set-Cookie: FKPl_e1a1_lastvisit=1562910594; expires=Sun, 11-Aug-2019 06:49:54 GMT; path=/; domain=rednet.cn Set-Cookie: FKPl_e1a1_lastact=1562914194%09forum.php%09viewthread; expires=Sat, 13-Jul-2019 06:49:54 GMT; path=/; domain=rednet.cn Set-Cookie: FKPl_e1a1_viewid=tid_48108136; path=/; domain=rednet.cn flydragon: 1.35 Content-Encoding: gzip X-Via-JSL: 2768106,- X-Cache: bypass  ,8016, 5
[1:7:0712/144955.652940:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/144955.676099:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_https://bbs.rednet.cn/
[1:1:0712/144955.736788:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[7921:7921:0712/144955.739590:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://bbs.rednet.cn/, https://bbs.rednet.cn/, 1
[7921:7921:0712/144955.739638:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://bbs.rednet.cn/, https://bbs.rednet.cn
[1:1:0712/144955.764332:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/144955.788730:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/144955.814926:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/144955.815086:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://bbs.rednet.cn/thread-48108136-1-1.html"
[1:1:0712/144956.295468:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 298 0x7f5b5760b070 0xc8b70415f60 , "https://bbs.rednet.cn/thread-48108136-1-1.html"
[1:1:0712/144956.296380:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bbs.rednet.cn/, 3fd748482860, , , var STYLEID = '2', STATICURL = 'static/', IMGDIR = 'static/image/common', VERHASH = 'k6B', charset =
[1:1:0712/144956.296537:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.rednet.cn/thread-48108136-1-1.html", "bbs.rednet.cn", 3, 1, , , 0
[1:1:0712/144958.092959:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 340, "https://bbs.rednet.cn/thread-48108136-1-1.html"
[1:1:0712/144958.098942:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bbs.rednet.cn/, 3fd748482860, , , /*
	[Discuz!] (C)2001-2099 Comsenz Inc.
	This is NOT a freeware, use is subject to license terms

[1:1:0712/144958.099110:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.rednet.cn/thread-48108136-1-1.html", "bbs.rednet.cn", 3, 1, , , 0
[1:1:0712/144958.117901:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 340, "https://bbs.rednet.cn/thread-48108136-1-1.html"
[1:1:0712/144958.170952:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0559261, 54, 1
[1:1:0712/144958.171157:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
