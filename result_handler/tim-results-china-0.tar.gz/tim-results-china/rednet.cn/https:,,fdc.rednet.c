[0712/145716.669960:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/145716.670217:INFO:switcher_clone.cc(787)] backtrace rip is 7f37ebc35891
[0712/145717.216206:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/145717.216455:INFO:switcher_clone.cc(787)] backtrace rip is 7f0aa7a3d891
[1:1:0712/145717.220232:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/145717.220393:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/145717.223107:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[9221:9221:0712/145717.972342:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/cad7f5b8-ff98-42cb-ab28-da99a4393937
[0712/145718.077529:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/145718.077884:INFO:switcher_clone.cc(787)] backtrace rip is 7f29c4500891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[9221:9221:0712/145718.232247:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[9221:9250:0712/145718.233317:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/145718.233448:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/145718.233614:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/145718.233915:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[9253:9253:0712/145718.234035:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=9253
[3:3:0712/145718.234074:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/145718.237884:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x616b44c, 1
[1:1:0712/145718.242850:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x2fa9689, 0
[1:1:0712/145718.242968:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x3c6c449a, 3
[1:1:0712/145718.243052:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x10f3b48b, 2
[1:1:0712/145718.243142:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffff89ffffff96fffffffa02 4cffffffb41606 ffffff8bffffffb4fffffff310 ffffff9a446c3c , 10104, 4
[1:1:0712/145718.243853:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[9221:9250:0712/145718.243973:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING���L�����Dl<-S"
[9221:9250:0712/145718.244015:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ���L�����Dl<X6-S"
[9221:9250:0712/145718.244163:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[9221:9250:0712/145718.244192:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 9267, 4, 8996fa02 4cb41606 8bb4f310 9a446c3c 
[1:1:0712/145718.244344:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f0aa5c770a0, 3
[1:1:0712/145718.244443:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f0aa5e03080, 2
[1:1:0712/145718.244527:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f0a8fac5d20, -2
[9266:9266:0712/145718.245356:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=9266
[1:1:0712/145718.253311:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/145718.253752:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 10f3b48b
[1:1:0712/145718.254217:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 10f3b48b
[1:1:0712/145718.254939:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 10f3b48b
[1:1:0712/145718.255507:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 10f3b48b
[1:1:0712/145718.255617:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 10f3b48b
[1:1:0712/145718.255713:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 10f3b48b
[1:1:0712/145718.255784:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 10f3b48b
[1:1:0712/145718.256010:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 10f3b48b
[1:1:0712/145718.256143:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f0aa7a3d7ba
[1:1:0712/145718.256216:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f0aa7a34def, 7f0aa7a3d77a, 7f0aa7a3f0cf
[1:1:0712/145718.257899:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 10f3b48b
[1:1:0712/145718.258082:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 10f3b48b
[1:1:0712/145718.258375:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 10f3b48b
[1:1:0712/145718.259171:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 10f3b48b
[1:1:0712/145718.259269:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 10f3b48b
[1:1:0712/145718.259366:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 10f3b48b
[1:1:0712/145718.259462:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 10f3b48b
[1:1:0712/145718.259947:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 10f3b48b
[1:1:0712/145718.260110:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f0aa7a3d7ba
[1:1:0712/145718.260185:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f0aa7a34def, 7f0aa7a3d77a, 7f0aa7a3f0cf
[1:1:0712/145718.262843:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/145718.263040:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/145718.263118:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe927a8558, 0x7ffe927a84d8)
[1:1:0712/145718.269774:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/145718.273083:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[9221:9221:0712/145718.684414:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[9221:9221:0712/145718.684957:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[9221:9221:0712/145718.693482:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[9221:9221:0712/145718.693552:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[9221:9221:0712/145718.693621:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,9267, 4
[9221:9232:0712/145718.693969:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[9221:9232:0712/145718.694025:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[1:7:0712/145718.694523:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/145718.695393:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x26f0a92ea220
[1:1:0712/145718.695730:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[9221:9244:0712/145718.765079:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/145718.923172:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[9221:9221:0712/145719.572782:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[9221:9221:0712/145719.572902:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/145719.588922:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/145719.590515:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/145720.000892:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0ad2e1181f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/145720.001114:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/145720.006709:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0ad2e1181f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/145720.006858:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/145720.032617:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/145720.128123:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/145720.128292:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/145720.243874:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 358, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/145720.246343:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0ad2e1181f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/145720.246487:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/145720.258217:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 359, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/145720.261166:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0ad2e1181f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/145720.261300:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/145720.265085:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[9221:9221:0712/145720.265724:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/145720.266759:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x26f0a92e8e20
[1:1:0712/145720.266863:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[9221:9221:0712/145720.268176:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[9221:9221:0712/145720.279572:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[9221:9221:0712/145720.279655:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/145720.299296:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/145720.588421:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 418 0x7f0a916a02e0 0x26f0a959b2e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/145720.589138:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0ad2e1181f78, , , var configData = {"googleBaseUrl":"https://www.google.com.hk/","isAccessibleBrowser":false,"isGoogle
[1:1:0712/145720.589272:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/145720.589899:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[9221:9221:0712/145720.615417:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/145720.616527:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x26f0a92e9820
[1:1:0712/145720.616663:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[9221:9221:0712/145720.617770:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/145720.624158:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/145720.624305:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[9221:9221:0712/145720.625370:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[9221:9221:0712/145720.629213:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[9221:9221:0712/145720.629603:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[9221:9232:0712/145720.633955:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[9221:9232:0712/145720.634009:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[9221:9221:0712/145720.634028:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[9221:9221:0712/145720.634065:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[9221:9221:0712/145720.634123:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,9267, 4
[1:7:0712/145720.635513:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/145720.877353:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/145720.991540:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 465 0x7f0a916a02e0 0x26f0a91fcf60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/145720.992089:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0ad2e1181f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/145720.992209:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/145720.992507:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[9221:9221:0712/145721.130562:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[9221:9221:0712/145721.130684:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/145721.142944:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/145721.278930:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/145721.484384:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/145721.484538:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[9221:9221:0712/145721.518617:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[9221:9250:0712/145721.518900:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/145721.519025:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/145721.519167:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/145721.519357:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/145721.519433:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/145721.521773:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x3fb70f31, 1
[1:1:0712/145721.522022:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x1b7e2192, 0
[1:1:0712/145721.522180:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x349411a8, 3
[1:1:0712/145721.522321:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0xc944aeb, 2
[1:1:0712/145721.522448:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffff92217e1b 310fffffffb73f ffffffeb4affffff940c ffffffa811ffffff9434 , 10104, 5
[1:1:0712/145721.523140:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[9221:9250:0712/145721.523310:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�!~1�?�J���4-S"
[9221:9250:0712/145721.523352:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �!~1�?�J���4��-S"
[1:1:0712/145721.523299:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f0aa5c770a0, 3
[9221:9250:0712/145721.523485:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 9315, 5, 92217e1b 310fb73f eb4a940c a8119434 
[1:1:0712/145721.523478:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f0aa5e03080, 2
[1:1:0712/145721.523582:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f0a8fac5d20, -2
[1:1:0712/145721.532871:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/145721.533994:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal c944aeb
[1:1:0712/145721.534143:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal c944aeb
[1:1:0712/145721.534382:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal c944aeb
[1:1:0712/145721.534933:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal c944aeb
[1:1:0712/145721.535030:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal c944aeb
[1:1:0712/145721.535107:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal c944aeb
[1:1:0712/145721.535192:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal c944aeb
[1:1:0712/145721.535426:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal c944aeb
[1:1:0712/145721.535540:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f0aa7a3d7ba
[1:1:0712/145721.535600:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f0aa7a34def, 7f0aa7a3d77a, 7f0aa7a3f0cf
[1:1:0712/145721.537265:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal c944aeb
[1:1:0712/145721.537445:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal c944aeb
[1:1:0712/145721.537753:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal c944aeb
[1:1:0712/145721.538532:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal c944aeb
[1:1:0712/145721.538656:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal c944aeb
[1:1:0712/145721.538771:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal c944aeb
[1:1:0712/145721.538872:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal c944aeb
[1:1:0712/145721.539356:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal c944aeb
[1:1:0712/145721.539521:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f0aa7a3d7ba
[1:1:0712/145721.539602:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f0aa7a34def, 7f0aa7a3d77a, 7f0aa7a3f0cf
[1:1:0712/145721.542210:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/145721.542439:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/145721.542549:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe927a8558, 0x7ffe927a84d8)
[1:1:0712/145721.548584:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/145721.550594:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/145721.626891:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 533, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/145721.628468:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0ad2e12ae5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/145721.628621:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/145721.630964:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/145721.641544:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x26f0a92cc220
[1:1:0712/145721.641711:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[9221:9221:0712/145722.113502:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[9221:9221:0712/145722.116005:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[9221:9221:0712/145722.134921:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://fdc.rednet.cn/
[9221:9221:0712/145722.134982:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://fdc.rednet.cn/, https://fdc.rednet.cn/content/2019/07/10/5705554.html, 1
[9221:9221:0712/145722.135045:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_https://fdc.rednet.cn/, HTTP/1.1 200 OK Server: nginx Date: Fri, 12 Jul 2019 06:57:22 GMT Content-Type: text/html Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Content-Encoding: gzip  ,9315, 5
[9221:9232:0712/145722.136308:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[9221:9232:0712/145722.136365:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[1:7:0712/145722.136929:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/145722.151683:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_https://fdc.rednet.cn/
[9221:9221:0712/145722.206557:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://fdc.rednet.cn/, https://fdc.rednet.cn/, 1
[9221:9221:0712/145722.206613:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://fdc.rednet.cn/, https://fdc.rednet.cn
[1:1:0712/145722.219538:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/145722.261819:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/145722.294520:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/145722.294702:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145722.448091:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/145722.727986:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 221 0x7f0a8f778070 0x26f0a943c260 , "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145722.729155:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/145722.732193:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://fdc.rednet.cn/, 165d51a62860, , , "object"==typeof navigator&&function(e,t){"object"==typeof exports&&"undefined"!=typeof module?modul
[1:1:0712/145722.732336:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://fdc.rednet.cn/content/2019/07/10/5705554.html", "fdc.rednet.cn", 3, 1, , , 0
[1:1:0712/145722.826072:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 221 0x7f0a8f778070 0x26f0a943c260 , "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145722.957766:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 221 0x7f0a8f778070 0x26f0a943c260 , "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145723.030484:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 237, "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145723.032502:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://fdc.rednet.cn/, 165d51a62860, , , /*! jPlayer 2.9.2 for jQuery ~ (c) 2009-2014 Happyworm Ltd ~ MIT License */
!function(a,b){"function
[1:1:0712/145723.032667:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://fdc.rednet.cn/content/2019/07/10/5705554.html", "fdc.rednet.cn", 3, 1, , , 0
[1:1:0712/145723.105664:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/145723.145508:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/145723.145664:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145723.146778:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 253 0x7f0a8f778070 0x26f0a9440660 , "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145723.148601:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://fdc.rednet.cn/, 165d51a62860, , , "object"==typeof navigator&&function(e,t){"object"==typeof exports&&"undefined"!=typeof module?modul
[1:1:0712/145723.148795:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://fdc.rednet.cn/content/2019/07/10/5705554.html", "fdc.rednet.cn", 3, 1, , , 0
[1:1:0712/145723.206606:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 253 0x7f0a8f778070 0x26f0a9440660 , "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145723.213120:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 253 0x7f0a8f778070 0x26f0a9440660 , "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145723.223271:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 253 0x7f0a8f778070 0x26f0a9440660 , "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145723.228462:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 253 0x7f0a8f778070 0x26f0a9440660 , "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145723.235022:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3aab76229c8, 0x26f0a915a1a8
[1:1:0712/145723.235211:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html", 0
[1:1:0712/145723.235456:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 266
[1:1:0712/145723.235580:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 266 0x7f0a8f778070 0x26f0a95f70e0 , 5:3_https://fdc.rednet.cn/, 1, -5:3_https://fdc.rednet.cn/, 253 0x7f0a8f778070 0x26f0a9440660 
[1:1:0712/145723.238304:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 253 0x7f0a8f778070 0x26f0a9440660 , "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145723.244209:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 253 0x7f0a8f778070 0x26f0a9440660 , "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145723.245506:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 253 0x7f0a8f778070 0x26f0a9440660 , "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145723.251512:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.105805, 61, 1
[1:1:0712/145723.251660:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/145723.352988:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/145723.353181:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145723.353653:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 274 0x7f0a8f778070 0x26f0a9848660 , "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145723.354204:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://fdc.rednet.cn/, 165d51a62860, , ,  new RedAd('ad1561971058721_12',52)
[1:1:0712/145723.354330:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://fdc.rednet.cn/content/2019/07/10/5705554.html", "fdc.rednet.cn", 3, 1, , , 0
[1:1:0712/145723.385832:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 274 0x7f0a8f778070 0x26f0a9848660 , "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145723.411833:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 274 0x7f0a8f778070 0x26f0a9848660 , "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145726.839875:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/145729.530837:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/145729.614627:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 6.26145, 48, 0
[1:1:0712/145729.614836:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/145729.632953:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 266, 7f0a920bd881
[1:1:0712/145729.638280:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"165d51a62860","ptid":"253 0x7f0a8f778070 0x26f0a9440660 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145729.638428:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://fdc.rednet.cn/","ptid":"253 0x7f0a8f778070 0x26f0a9440660 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145729.638629:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145729.638929:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://fdc.rednet.cn/, 165d51a62860, , ab, (){if(L){return}if(!/loaded|complete/.test(h.readyState)){setTimeout(ab,0);return}f()}
[1:1:0712/145729.639046:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://fdc.rednet.cn/content/2019/07/10/5705554.html", "fdc.rednet.cn", 3, 1, , , 0
[1:1:0712/145729.639388:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3aab76229c8, 0x26f0a915a150
[1:1:0712/145729.639483:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html", 0
[1:1:0712/145729.639660:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 302
[1:1:0712/145729.639769:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 302 0x7f0a8f778070 0x26f0adec56e0 , 5:3_https://fdc.rednet.cn/, 1, -5:3_https://fdc.rednet.cn/, 266 0x7f0a8f778070 0x26f0a95f70e0 
[1:1:0712/145729.716914:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145729.717397:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://fdc.rednet.cn/, 165d51a62860, , b, (c,e){var h,i,j;if(b&&(e||4===f.readyState))if(delete Xb[g],b=void 0,f.onreadystatechange=m.noop,e)4
[1:1:0712/145729.717517:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://fdc.rednet.cn/content/2019/07/10/5705554.html", "fdc.rednet.cn", 3, 1, , , 0
[1:1:0712/145729.718075:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145729.719280:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145729.719612:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x2282b5dcc568
[1:1:0712/145729.753721:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145729.754125:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://fdc.rednet.cn/, 165d51a62860, , b, (c,e){var h,i,j;if(b&&(e||4===f.readyState))if(delete Xb[g],b=void 0,f.onreadystatechange=m.noop,e)4
[1:1:0712/145729.754287:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://fdc.rednet.cn/content/2019/07/10/5705554.html", "fdc.rednet.cn", 3, 1, , , 0
[1:1:0712/145729.754609:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145729.755862:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145729.756209:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x2282b5dcc568
[1:1:0712/145729.784055:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/145729.784200:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145729.788793:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.004529, 82, 1
[1:1:0712/145729.788916:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/145729.831421:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 302, 7f0a920bd881
[1:1:0712/145729.835742:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"165d51a62860","ptid":"266 0x7f0a8f778070 0x26f0a95f70e0 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145729.835882:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://fdc.rednet.cn/","ptid":"266 0x7f0a8f778070 0x26f0a95f70e0 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145729.836067:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145729.836344:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://fdc.rednet.cn/, 165d51a62860, , ab, (){if(L){return}if(!/loaded|complete/.test(h.readyState)){setTimeout(ab,0);return}f()}
[1:1:0712/145729.836457:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://fdc.rednet.cn/content/2019/07/10/5705554.html", "fdc.rednet.cn", 3, 1, , , 0
[1:1:0712/145729.836743:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3aab76229c8, 0x26f0a915a150
[1:1:0712/145729.836837:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html", 0
[1:1:0712/145729.837003:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 326
[1:1:0712/145729.837121:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 326 0x7f0a8f778070 0x26f0a8ecf1e0 , 5:3_https://fdc.rednet.cn/, 1, -5:3_https://fdc.rednet.cn/, 302 0x7f0a8f778070 0x26f0adec56e0 
[1:1:0712/145729.913090:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/145729.913228:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145729.913656:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 321 0x7f0a8f778070 0x26f0adf4c6e0 , "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145729.914096:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://fdc.rednet.cn/, 165d51a62860, , ,  new RedAd('ad1561971111281_14',52)
[1:1:0712/145729.914225:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://fdc.rednet.cn/content/2019/07/10/5705554.html", "fdc.rednet.cn", 3, 1, , , 0
[1:1:0712/145729.935496:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 321 0x7f0a8f778070 0x26f0adf4c6e0 , "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145729.961806:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0485311, 107, 1
[1:1:0712/145729.961960:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/145729.988738:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145729.989172:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://fdc.rednet.cn/, 165d51a62860, , b.src.e.onload, () {
                        d.drawImage(e, (b.width - b.imgWidth) / 2, (b.height - b.imgHeight) / 
[1:1:0712/145729.989294:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://fdc.rednet.cn/content/2019/07/10/5705554.html", "fdc.rednet.cn", 3, 1, , , 0
[1:1:0712/145730.006852:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 326, 7f0a920bd881
[1:1:0712/145730.011482:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"165d51a62860","ptid":"302 0x7f0a8f778070 0x26f0adec56e0 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145730.011622:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://fdc.rednet.cn/","ptid":"302 0x7f0a8f778070 0x26f0adec56e0 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145730.011807:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145730.012077:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://fdc.rednet.cn/, 165d51a62860, , ab, (){if(L){return}if(!/loaded|complete/.test(h.readyState)){setTimeout(ab,0);return}f()}
[1:1:0712/145730.012192:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://fdc.rednet.cn/content/2019/07/10/5705554.html", "fdc.rednet.cn", 3, 1, , , 0
[1:1:0712/145730.012492:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3aab76229c8, 0x26f0a915a150
[1:1:0712/145730.012596:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html", 0
[1:1:0712/145730.012770:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 347
[1:1:0712/145730.012873:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 347 0x7f0a8f778070 0x26f0ae017f60 , 5:3_https://fdc.rednet.cn/, 1, -5:3_https://fdc.rednet.cn/, 326 0x7f0a8f778070 0x26f0a8ecf1e0 
[1:1:0712/145730.065210:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/145730.065342:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145730.065762:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 339 0x7f0a8f778070 0x26f0ae019260 , "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145730.066216:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://fdc.rednet.cn/, 165d51a62860, , ,  new RedAd('ad1561971128297_16',52)
[1:1:0712/145730.066332:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://fdc.rednet.cn/content/2019/07/10/5705554.html", "fdc.rednet.cn", 3, 1, , , 0
[1:1:0712/145730.087766:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 339 0x7f0a8f778070 0x26f0ae019260 , "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145730.089018:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 339 0x7f0a8f778070 0x26f0ae019260 , "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145730.119212:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 339 0x7f0a8f778070 0x26f0ae019260 , "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145730.151313:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 339 0x7f0a8f778070 0x26f0ae019260 , "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145730.157900:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 339 0x7f0a8f778070 0x26f0ae019260 , "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145730.163475:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145730.672568:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html", 2000
[1:1:0712/145730.672893:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://fdc.rednet.cn/, 384
[1:1:0712/145730.673011:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 384 0x7f0a8f778070 0x26f0ae112de0 , 5:3_https://fdc.rednet.cn/, 1, -5:3_https://fdc.rednet.cn/, 339 0x7f0a8f778070 0x26f0ae019260 
[1:1:0712/145730.699644:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145730.737655:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145730.738054:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://fdc.rednet.cn/, 165d51a62860, , b, (c,e){var h,i,j;if(b&&(e||4===f.readyState))if(delete Xb[g],b=void 0,f.onreadystatechange=m.noop,e)4
[1:1:0712/145730.738179:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://fdc.rednet.cn/content/2019/07/10/5705554.html", "fdc.rednet.cn", 3, 1, , , 0
[1:1:0712/145730.738477:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145730.739650:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145730.739957:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x2282b5dcc568
[1:1:0712/145730.791426:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145730.791791:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://fdc.rednet.cn/, 165d51a62860, , b, (c,e){var h,i,j;if(b&&(e||4===f.readyState))if(delete Xb[g],b=void 0,f.onreadystatechange=m.noop,e)4
[1:1:0712/145730.791916:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://fdc.rednet.cn/content/2019/07/10/5705554.html", "fdc.rednet.cn", 3, 1, , , 0
[1:1:0712/145730.792183:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145730.793342:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145730.793644:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x2282b5dcc568
[1:1:0712/145730.812131:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 347, 7f0a920bd881
[1:1:0712/145730.818449:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"165d51a62860","ptid":"326 0x7f0a8f778070 0x26f0a8ecf1e0 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145730.818614:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://fdc.rednet.cn/","ptid":"326 0x7f0a8f778070 0x26f0a8ecf1e0 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145730.818819:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145730.819109:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://fdc.rednet.cn/, 165d51a62860, , ab, (){if(L){return}if(!/loaded|complete/.test(h.readyState)){setTimeout(ab,0);return}f()}
[1:1:0712/145730.819225:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://fdc.rednet.cn/content/2019/07/10/5705554.html", "fdc.rednet.cn", 3, 1, , , 0
[1:1:0712/145730.845730:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145730.846096:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://fdc.rednet.cn/, 165d51a62860, , b, (c,e){var h,i,j;if(b&&(e||4===f.readyState))if(delete Xb[g],b=void 0,f.onreadystatechange=m.noop,e)4
[1:1:0712/145730.846214:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://fdc.rednet.cn/content/2019/07/10/5705554.html", "fdc.rednet.cn", 3, 1, , , 0
[1:1:0712/145730.846478:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145730.847605:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145730.847908:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x2282b5dcc568
[1:1:0712/145730.902232:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145730.902596:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://fdc.rednet.cn/, 165d51a62860, , b, (c,e){var h,i,j;if(b&&(e||4===f.readyState))if(delete Xb[g],b=void 0,f.onreadystatechange=m.noop,e)4
[1:1:0712/145730.902715:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://fdc.rednet.cn/content/2019/07/10/5705554.html", "fdc.rednet.cn", 3, 1, , , 0
[1:1:0712/145730.902945:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145730.904077:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145730.904380:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x2282b5dcc568
[1:1:0712/145731.092412:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: the server responded with a status of 400 ()","https://front-web.rednet.cn/content/list/channel?channelId=undefined&pageSize=10"
[1:1:0712/145731.093382:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145731.093720:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://fdc.rednet.cn/, 165d51a62860, , b, (c,e){var h,i,j;if(b&&(e||4===f.readyState))if(delete Xb[g],b=void 0,f.onreadystatechange=m.noop,e)4
[1:1:0712/145731.093841:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://fdc.rednet.cn/content/2019/07/10/5705554.html", "fdc.rednet.cn", 3, 1, , , 0
[1:1:0712/145731.094095:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145731.095174:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145731.095476:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x2282b5dcc568
[1:1:0712/145731.230523:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 410 0x7f0a916a02e0 0x26f0ae5cfe60 , "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145731.231312:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://fdc.rednet.cn/, 165d51a62860, , , var ROOTDM=[".hebtv.com",".jstv.com",".chinawater.com.cn",".cwec.org.cn",".nsbd.gov.cn",".zgzx.org.c
[1:1:0712/145731.231433:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://fdc.rednet.cn/content/2019/07/10/5705554.html", "fdc.rednet.cn", 3, 1, , , 0
[1:1:0712/145731.401623:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 411 0x7f0a916a02e0 0x26f0ae5f3560 , "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145731.402159:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://fdc.rednet.cn/, 165d51a62860, , , var ROOTDM=[".hebtv.com",".jstv.com",".chinawater.com.cn",".cwec.org.cn",".nsbd.gov.cn",".zgzx.org.c
[1:1:0712/145731.402251:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://fdc.rednet.cn/content/2019/07/10/5705554.html", "fdc.rednet.cn", 3, 1, , , 0
[1:1:0712/145731.530001:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x2282b5dd4f30
[1:1:0712/145731.568458:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 412 0x7f0a916a02e0 0x26f0ae5f32e0 , "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145731.569350:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://fdc.rednet.cn/, 165d51a62860, , , !function(){var e=/([http|https]:\/\/[a-zA-Z0-9\_\.]+\.baidu\.com)/gi,r=window.location.href,t=docum
[1:1:0712/145731.569546:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://fdc.rednet.cn/content/2019/07/10/5705554.html", "fdc.rednet.cn", 3, 1, , , 0
[1:1:0712/145731.590261:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 413 0x7f0a916a02e0 0x26f0ae5f0f60 , "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145731.591870:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://fdc.rednet.cn/, 165d51a62860, , , (function(){var h={},mt={},c={id:"aaecf8414f59c3fb0127932014cf53c7",dm:["rednet.cn"],js:"tongji.baid
[1:1:0712/145731.592022:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://fdc.rednet.cn/content/2019/07/10/5705554.html", "fdc.rednet.cn", 3, 1, , , 0
[1:1:0712/145731.601829:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3aab76229c8, 0x26f0a915a190
[1:1:0712/145731.601981:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html", 100
[1:1:0712/145731.602210:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 469
[1:1:0712/145731.602343:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 469 0x7f0a8f778070 0x26f0ae8a47e0 , 5:3_https://fdc.rednet.cn/, 1, -5:3_https://fdc.rednet.cn/, 413 0x7f0a916a02e0 0x26f0ae5f0f60 
[9221:9221:0712/145732.799473:INFO:CONSOLE(84)] "Mixed Content: The page at 'https://fdc.rednet.cn/content/2019/07/10/5705554.html' was loaded over a secure connection, but contains a form that targets an insecure endpoint 'http://s.rednet.cn/'. This endpoint should be made available over a secure connection.", source: https://fdc.rednet.cn/content/2019/07/10/5705554.html (84)
[3:3:0712/145732.857509:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/145733.025923:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145733.026387:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://fdc.rednet.cn/, 165d51a62860, , b, (c,e){var h,i,j;if(b&&(e||4===f.readyState))if(delete Xb[g],b=void 0,f.onreadystatechange=m.noop,e)4
[1:1:0712/145733.026542:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://fdc.rednet.cn/content/2019/07/10/5705554.html", "fdc.rednet.cn", 3, 1, , , 0
[1:1:0712/145733.026763:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145733.027059:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x2282b5dcc568
[1:1:0712/145733.507191:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://fdc.rednet.cn/, 165d51a62860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/145733.507388:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://fdc.rednet.cn/content/2019/07/10/5705554.html", "fdc.rednet.cn", 3, 1, , , 0
[1:1:0712/145733.855419:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 469, 7f0a920bd881
[1:1:0712/145733.863647:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"165d51a62860","ptid":"413 0x7f0a916a02e0 0x26f0ae5f0f60 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145733.863835:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://fdc.rednet.cn/","ptid":"413 0x7f0a916a02e0 0x26f0ae5f0f60 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145733.864043:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145733.864344:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://fdc.rednet.cn/, 165d51a62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/145733.864459:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://fdc.rednet.cn/content/2019/07/10/5705554.html", "fdc.rednet.cn", 3, 1, , , 0
[1:1:0712/145733.864813:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3aab76229c8, 0x26f0a915a150
[1:1:0712/145733.864898:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html", 100
[1:1:0712/145733.865103:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 540
[1:1:0712/145733.865222:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 540 0x7f0a8f778070 0x26f0ae9e4ce0 , 5:3_https://fdc.rednet.cn/, 1, -5:3_https://fdc.rednet.cn/, 469 0x7f0a8f778070 0x26f0ae8a47e0 
[1:1:0712/145733.874529:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://fdc.rednet.cn/, 384, 7f0a920bd8db
[1:1:0712/145733.883561:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"165d51a62860","ptid":"339 0x7f0a8f778070 0x26f0ae019260 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145733.883778:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://fdc.rednet.cn/","ptid":"339 0x7f0a8f778070 0x26f0ae019260 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145733.884007:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://fdc.rednet.cn/, 541
[1:1:0712/145733.884471:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 541 0x7f0a8f778070 0x26f0a902ebe0 , 5:3_https://fdc.rednet.cn/, 0, , 384 0x7f0a8f778070 0x26f0ae112de0 
[1:1:0712/145733.884606:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145733.884882:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://fdc.rednet.cn/, 165d51a62860, , , () {
			mySwiper1.swipeNext && mySwiper1.swipeNext()
		}
[1:1:0712/145733.884975:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://fdc.rednet.cn/content/2019/07/10/5705554.html", "fdc.rednet.cn", 3, 1, , , 0
[1:1:0712/145734.026633:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145734.027030:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://fdc.rednet.cn/, 165d51a62860, , _wdEC, (){}
[1:1:0712/145734.027140:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://fdc.rednet.cn/content/2019/07/10/5705554.html", "fdc.rednet.cn", 3, 1, , , 0
[1:1:0712/145734.042805:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145734.043191:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://fdc.rednet.cn/, 165d51a62860, , _wdEC, (){}
[1:1:0712/145734.043370:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://fdc.rednet.cn/content/2019/07/10/5705554.html", "fdc.rednet.cn", 3, 1, , , 0
[1:1:0712/145734.070954:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145734.071465:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://fdc.rednet.cn/, 165d51a62860, , _wdEC, (){}
[1:1:0712/145734.071608:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://fdc.rednet.cn/content/2019/07/10/5705554.html", "fdc.rednet.cn", 3, 1, , , 0
[1:1:0712/145734.088858:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145734.089301:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://fdc.rednet.cn/, 165d51a62860, , _wdEC, (){}
[1:1:0712/145734.089471:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://fdc.rednet.cn/content/2019/07/10/5705554.html", "fdc.rednet.cn", 3, 1, , , 0
[1:1:0712/145734.116823:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://fdc.rednet.cn/, 165d51a62860, , , document.readyState
[1:1:0712/145734.116972:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://fdc.rednet.cn/content/2019/07/10/5705554.html", "fdc.rednet.cn", 3, 1, , , 0
[1:1:0712/145734.283134:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145734.283572:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://fdc.rednet.cn/, 165d51a62860, , f.onload, (){f.onload=u;f=window[d]=u;a&&a(b)}
[1:1:0712/145734.283679:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://fdc.rednet.cn/content/2019/07/10/5705554.html", "fdc.rednet.cn", 3, 1, , , 0
[1:1:0712/145734.287674:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 540, 7f0a920bd881
[1:1:0712/145734.297776:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"165d51a62860","ptid":"469 0x7f0a8f778070 0x26f0ae8a47e0 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145734.305191:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://fdc.rednet.cn/","ptid":"469 0x7f0a8f778070 0x26f0ae8a47e0 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145734.305455:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145734.305781:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://fdc.rednet.cn/, 165d51a62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/145734.305898:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://fdc.rednet.cn/content/2019/07/10/5705554.html", "fdc.rednet.cn", 3, 1, , , 0
[1:1:0712/145734.306231:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3aab76229c8, 0x26f0a915a150
[1:1:0712/145734.306327:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html", 100
[1:1:0712/145734.306521:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 579
[1:1:0712/145734.306632:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 579 0x7f0a8f778070 0x26f0aea28b60 , 5:3_https://fdc.rednet.cn/, 1, -5:3_https://fdc.rednet.cn/, 540 0x7f0a8f778070 0x26f0ae9e4ce0 
[1:1:0712/145734.359299:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://fdc.rednet.cn/, 165d51a62860, , , document.readyState
[1:1:0712/145734.359545:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://fdc.rednet.cn/content/2019/07/10/5705554.html", "fdc.rednet.cn", 3, 1, , , 0
[1:1:0712/145734.494778:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145734.495206:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://fdc.rednet.cn/, 165d51a62860, , a, (){if(!a.U){a.U=t;for(var d=0,b=g.length;d<b;d++)g[d]()}}
[1:1:0712/145734.495343:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://fdc.rednet.cn/content/2019/07/10/5705554.html", "fdc.rednet.cn", 3, 1, , , 0
[1:1:0712/145734.496297:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "pageshow", "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145734.496885:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3aab76229c8, 0x26f0a915a2f0
[1:1:0712/145734.496969:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html", 100
[1:1:0712/145734.497165:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 589
[1:1:0712/145734.497268:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 589 0x7f0a8f778070 0x26f0adfd5f60 , 5:3_https://fdc.rednet.cn/, 1, -5:3_https://fdc.rednet.cn/, 561 0x7f0a8f778070 0x26f0ae986560 
[1:1:0712/145734.748305:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://fdc.rednet.cn/, 165d51a62860, , , document.readyState
[1:1:0712/145734.748461:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://fdc.rednet.cn/content/2019/07/10/5705554.html", "fdc.rednet.cn", 3, 1, , , 0
[1:1:0712/145734.816467:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 589, 7f0a920bd881
[1:1:0712/145734.826324:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"165d51a62860","ptid":"561 0x7f0a8f778070 0x26f0ae986560 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145734.826527:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://fdc.rednet.cn/","ptid":"561 0x7f0a8f778070 0x26f0ae986560 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145734.826741:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145734.827033:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://fdc.rednet.cn/, 165d51a62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/145734.827134:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://fdc.rednet.cn/content/2019/07/10/5705554.html", "fdc.rednet.cn", 3, 1, , , 0
[1:1:0712/145734.827440:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3aab76229c8, 0x26f0a915a150
[1:1:0712/145734.827532:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html", 100
[1:1:0712/145734.827707:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 613
[1:1:0712/145734.827796:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 613 0x7f0a8f778070 0x26f0aea59d60 , 5:3_https://fdc.rednet.cn/, 1, -5:3_https://fdc.rednet.cn/, 589 0x7f0a8f778070 0x26f0adfd5f60 
[1:1:0712/145734.845047:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://fdc.rednet.cn/, 541, 7f0a920bd8db
[1:1:0712/145734.854576:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"384 0x7f0a8f778070 0x26f0ae112de0 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145734.854785:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"384 0x7f0a8f778070 0x26f0ae112de0 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145734.855024:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://fdc.rednet.cn/, 614
[1:1:0712/145734.855148:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 614 0x7f0a8f778070 0x26f0aea5b2e0 , 5:3_https://fdc.rednet.cn/, 0, , 541 0x7f0a8f778070 0x26f0a902ebe0 
[1:1:0712/145734.855305:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145734.855601:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://fdc.rednet.cn/, 165d51a62860, , , () {
			mySwiper1.swipeNext && mySwiper1.swipeNext()
		}
[1:1:0712/145734.855719:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://fdc.rednet.cn/content/2019/07/10/5705554.html", "fdc.rednet.cn", 3, 1, , , 0
[1:1:0712/145734.956902:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 613, 7f0a920bd881
[1:1:0712/145734.966522:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"165d51a62860","ptid":"589 0x7f0a8f778070 0x26f0adfd5f60 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145734.966695:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://fdc.rednet.cn/","ptid":"589 0x7f0a8f778070 0x26f0adfd5f60 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145734.966911:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145734.967209:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://fdc.rednet.cn/, 165d51a62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/145734.967306:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://fdc.rednet.cn/content/2019/07/10/5705554.html", "fdc.rednet.cn", 3, 1, , , 0
[1:1:0712/145734.967615:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3aab76229c8, 0x26f0a915a150
[1:1:0712/145734.967709:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html", 100
[1:1:0712/145734.967889:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 618
[1:1:0712/145734.967994:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 618 0x7f0a8f778070 0x26f0ae8df260 , 5:3_https://fdc.rednet.cn/, 1, -5:3_https://fdc.rednet.cn/, 613 0x7f0a8f778070 0x26f0aea59d60 
[1:1:0712/145735.069138:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 618, 7f0a920bd881
[1:1:0712/145735.077740:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"165d51a62860","ptid":"613 0x7f0a8f778070 0x26f0aea59d60 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145735.077910:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://fdc.rednet.cn/","ptid":"613 0x7f0a8f778070 0x26f0aea59d60 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145735.078130:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145735.078442:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://fdc.rednet.cn/, 165d51a62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/145735.078549:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://fdc.rednet.cn/content/2019/07/10/5705554.html", "fdc.rednet.cn", 3, 1, , , 0
[1:1:0712/145735.079749:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3aab76229c8, 0x26f0a915a150
[1:1:0712/145735.079840:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html", 100
[1:1:0712/145735.080011:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 633
[1:1:0712/145735.080120:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 633 0x7f0a8f778070 0x26f0a9326b60 , 5:3_https://fdc.rednet.cn/, 1, -5:3_https://fdc.rednet.cn/, 618 0x7f0a8f778070 0x26f0ae8df260 
[1:1:0712/145735.190022:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 633, 7f0a920bd881
[1:1:0712/145735.198112:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"165d51a62860","ptid":"618 0x7f0a8f778070 0x26f0ae8df260 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145735.198285:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://fdc.rednet.cn/","ptid":"618 0x7f0a8f778070 0x26f0ae8df260 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145735.198522:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145735.198852:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://fdc.rednet.cn/, 165d51a62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/145735.199000:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://fdc.rednet.cn/content/2019/07/10/5705554.html", "fdc.rednet.cn", 3, 1, , , 0
[1:1:0712/145735.199383:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3aab76229c8, 0x26f0a915a150
[1:1:0712/145735.199485:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html", 100
[1:1:0712/145735.199675:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 641
[1:1:0712/145735.199787:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 641 0x7f0a8f778070 0x26f0aea002e0 , 5:3_https://fdc.rednet.cn/, 1, -5:3_https://fdc.rednet.cn/, 633 0x7f0a8f778070 0x26f0a9326b60 
[1:1:0712/145735.310387:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 641, 7f0a920bd881
[1:1:0712/145735.320217:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"165d51a62860","ptid":"633 0x7f0a8f778070 0x26f0a9326b60 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145735.320407:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://fdc.rednet.cn/","ptid":"633 0x7f0a8f778070 0x26f0a9326b60 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145735.320619:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145735.320923:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://fdc.rednet.cn/, 165d51a62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/145735.321013:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://fdc.rednet.cn/content/2019/07/10/5705554.html", "fdc.rednet.cn", 3, 1, , , 0
[1:1:0712/145735.321352:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3aab76229c8, 0x26f0a915a150
[1:1:0712/145735.321489:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html", 100
[1:1:0712/145735.321730:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 645
[1:1:0712/145735.321891:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 645 0x7f0a8f778070 0x26f0ae8601e0 , 5:3_https://fdc.rednet.cn/, 1, -5:3_https://fdc.rednet.cn/, 641 0x7f0a8f778070 0x26f0aea002e0 
[1:1:0712/145735.432700:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 645, 7f0a920bd881
[1:1:0712/145735.440660:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"165d51a62860","ptid":"641 0x7f0a8f778070 0x26f0aea002e0 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145735.440820:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://fdc.rednet.cn/","ptid":"641 0x7f0a8f778070 0x26f0aea002e0 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145735.440994:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145735.441257:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://fdc.rednet.cn/, 165d51a62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/145735.441400:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://fdc.rednet.cn/content/2019/07/10/5705554.html", "fdc.rednet.cn", 3, 1, , , 0
[1:1:0712/145735.441748:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3aab76229c8, 0x26f0a915a150
[1:1:0712/145735.441852:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html", 100
[1:1:0712/145735.442029:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 649
[1:1:0712/145735.442142:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 649 0x7f0a8f778070 0x26f0ae4d2760 , 5:3_https://fdc.rednet.cn/, 1, -5:3_https://fdc.rednet.cn/, 645 0x7f0a8f778070 0x26f0ae8601e0 
[1:1:0712/145735.552277:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 649, 7f0a920bd881
[1:1:0712/145735.562131:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"165d51a62860","ptid":"645 0x7f0a8f778070 0x26f0ae8601e0 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145735.562374:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://fdc.rednet.cn/","ptid":"645 0x7f0a8f778070 0x26f0ae8601e0 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145735.562656:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145735.563001:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://fdc.rednet.cn/, 165d51a62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/145735.563155:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://fdc.rednet.cn/content/2019/07/10/5705554.html", "fdc.rednet.cn", 3, 1, , , 0
[1:1:0712/145735.563523:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3aab76229c8, 0x26f0a915a150
[1:1:0712/145735.563632:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html", 100
[1:1:0712/145735.563831:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 652
[1:1:0712/145735.563954:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 652 0x7f0a8f778070 0x26f0a937ffe0 , 5:3_https://fdc.rednet.cn/, 1, -5:3_https://fdc.rednet.cn/, 649 0x7f0a8f778070 0x26f0ae4d2760 
[1:1:0712/145735.674113:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 652, 7f0a920bd881
[1:1:0712/145735.682495:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"165d51a62860","ptid":"649 0x7f0a8f778070 0x26f0ae4d2760 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145735.682674:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://fdc.rednet.cn/","ptid":"649 0x7f0a8f778070 0x26f0ae4d2760 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145735.682913:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145735.683242:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://fdc.rednet.cn/, 165d51a62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/145735.683398:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://fdc.rednet.cn/content/2019/07/10/5705554.html", "fdc.rednet.cn", 3, 1, , , 0
[1:1:0712/145735.683770:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3aab76229c8, 0x26f0a915a150
[1:1:0712/145735.683874:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html", 100
[1:1:0712/145735.684056:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 654
[1:1:0712/145735.684158:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 654 0x7f0a8f778070 0x26f0a9380660 , 5:3_https://fdc.rednet.cn/, 1, -5:3_https://fdc.rednet.cn/, 652 0x7f0a8f778070 0x26f0a937ffe0 
[1:1:0712/145735.803838:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 654, 7f0a920bd881
[1:1:0712/145735.815447:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"165d51a62860","ptid":"652 0x7f0a8f778070 0x26f0a937ffe0 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145735.815674:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://fdc.rednet.cn/","ptid":"652 0x7f0a8f778070 0x26f0a937ffe0 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145735.815975:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145735.816383:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://fdc.rednet.cn/, 165d51a62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/145735.816558:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://fdc.rednet.cn/content/2019/07/10/5705554.html", "fdc.rednet.cn", 3, 1, , , 0
[1:1:0712/145735.816968:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3aab76229c8, 0x26f0a915a150
[1:1:0712/145735.817089:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html", 100
[1:1:0712/145735.817386:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 656
[1:1:0712/145735.817586:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 656 0x7f0a8f778070 0x26f0a934ba60 , 5:3_https://fdc.rednet.cn/, 1, -5:3_https://fdc.rednet.cn/, 654 0x7f0a8f778070 0x26f0a9380660 
[1:1:0712/145735.927435:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 656, 7f0a920bd881
[1:1:0712/145735.935583:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"165d51a62860","ptid":"654 0x7f0a8f778070 0x26f0a9380660 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145735.935754:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://fdc.rednet.cn/","ptid":"654 0x7f0a8f778070 0x26f0a9380660 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145735.935989:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145735.936317:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://fdc.rednet.cn/, 165d51a62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/145735.936454:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://fdc.rednet.cn/content/2019/07/10/5705554.html", "fdc.rednet.cn", 3, 1, , , 0
[1:1:0712/145735.936803:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3aab76229c8, 0x26f0a915a150
[1:1:0712/145735.936887:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html", 100
[1:1:0712/145735.937137:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 658
[1:1:0712/145735.937248:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 658 0x7f0a8f778070 0x26f0a939dde0 , 5:3_https://fdc.rednet.cn/, 1, -5:3_https://fdc.rednet.cn/, 656 0x7f0a8f778070 0x26f0a934ba60 
[1:1:0712/145736.047465:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 658, 7f0a920bd881
[1:1:0712/145736.058289:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"165d51a62860","ptid":"656 0x7f0a8f778070 0x26f0a934ba60 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145736.058463:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://fdc.rednet.cn/","ptid":"656 0x7f0a8f778070 0x26f0a934ba60 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145736.058693:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145736.059023:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://fdc.rednet.cn/, 165d51a62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/145736.059170:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://fdc.rednet.cn/content/2019/07/10/5705554.html", "fdc.rednet.cn", 3, 1, , , 0
[1:1:0712/145736.059522:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3aab76229c8, 0x26f0a915a150
[1:1:0712/145736.059626:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html", 100
[1:1:0712/145736.059825:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 661
[1:1:0712/145736.059933:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 661 0x7f0a8f778070 0x26f0a9327c60 , 5:3_https://fdc.rednet.cn/, 1, -5:3_https://fdc.rednet.cn/, 658 0x7f0a8f778070 0x26f0a939dde0 
[1:1:0712/145736.170459:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 661, 7f0a920bd881
[1:1:0712/145736.178873:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"165d51a62860","ptid":"658 0x7f0a8f778070 0x26f0a939dde0 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145736.179053:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://fdc.rednet.cn/","ptid":"658 0x7f0a8f778070 0x26f0a939dde0 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145736.179282:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145736.179611:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://fdc.rednet.cn/, 165d51a62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/145736.179748:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://fdc.rednet.cn/content/2019/07/10/5705554.html", "fdc.rednet.cn", 3, 1, , , 0
[1:1:0712/145736.180086:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3aab76229c8, 0x26f0a915a150
[1:1:0712/145736.180233:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html", 100
[1:1:0712/145736.180412:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 663
[1:1:0712/145736.180505:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 663 0x7f0a8f778070 0x26f0aea57de0 , 5:3_https://fdc.rednet.cn/, 1, -5:3_https://fdc.rednet.cn/, 661 0x7f0a8f778070 0x26f0a9327c60 
[1:1:0712/145736.290676:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 663, 7f0a920bd881
[1:1:0712/145736.298940:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"165d51a62860","ptid":"661 0x7f0a8f778070 0x26f0a9327c60 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145736.299117:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://fdc.rednet.cn/","ptid":"661 0x7f0a8f778070 0x26f0a9327c60 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145736.299336:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145736.299669:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://fdc.rednet.cn/, 165d51a62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/145736.299828:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://fdc.rednet.cn/content/2019/07/10/5705554.html", "fdc.rednet.cn", 3, 1, , , 0
[1:1:0712/145736.300167:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3aab76229c8, 0x26f0a915a150
[1:1:0712/145736.300297:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html", 100
[1:1:0712/145736.300470:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 667
[1:1:0712/145736.300578:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 667 0x7f0a8f778070 0x26f0ae8e1be0 , 5:3_https://fdc.rednet.cn/, 1, -5:3_https://fdc.rednet.cn/, 663 0x7f0a8f778070 0x26f0aea57de0 
[1:1:0712/145736.411169:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 667, 7f0a920bd881
[1:1:0712/145736.419491:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"165d51a62860","ptid":"663 0x7f0a8f778070 0x26f0aea57de0 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145736.419673:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://fdc.rednet.cn/","ptid":"663 0x7f0a8f778070 0x26f0aea57de0 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145736.419901:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145736.420230:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://fdc.rednet.cn/, 165d51a62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/145736.420368:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://fdc.rednet.cn/content/2019/07/10/5705554.html", "fdc.rednet.cn", 3, 1, , , 0
[1:1:0712/145736.420688:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3aab76229c8, 0x26f0a915a150
[1:1:0712/145736.420778:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html", 100
[1:1:0712/145736.420940:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 669
[1:1:0712/145736.421014:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 669 0x7f0a8f778070 0x26f0ae9864e0 , 5:3_https://fdc.rednet.cn/, 1, -5:3_https://fdc.rednet.cn/, 667 0x7f0a8f778070 0x26f0ae8e1be0 
[1:1:0712/145736.536435:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 669, 7f0a920bd881
[1:1:0712/145736.545010:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"165d51a62860","ptid":"667 0x7f0a8f778070 0x26f0ae8e1be0 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145736.545208:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://fdc.rednet.cn/","ptid":"667 0x7f0a8f778070 0x26f0ae8e1be0 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145736.545437:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145736.545766:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://fdc.rednet.cn/, 165d51a62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/145736.545912:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://fdc.rednet.cn/content/2019/07/10/5705554.html", "fdc.rednet.cn", 3, 1, , , 0
[1:1:0712/145736.546294:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3aab76229c8, 0x26f0a915a150
[1:1:0712/145736.546392:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html", 100
[1:1:0712/145736.546573:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 671
[1:1:0712/145736.546688:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 671 0x7f0a8f778070 0x26f0a9380a60 , 5:3_https://fdc.rednet.cn/, 1, -5:3_https://fdc.rednet.cn/, 669 0x7f0a8f778070 0x26f0ae9864e0 
[1:1:0712/145736.657323:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 671, 7f0a920bd881
[1:1:0712/145736.666059:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"165d51a62860","ptid":"669 0x7f0a8f778070 0x26f0ae9864e0 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145736.666250:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://fdc.rednet.cn/","ptid":"669 0x7f0a8f778070 0x26f0ae9864e0 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145736.666482:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145736.666811:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://fdc.rednet.cn/, 165d51a62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/145736.666957:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://fdc.rednet.cn/content/2019/07/10/5705554.html", "fdc.rednet.cn", 3, 1, , , 0
[1:1:0712/145736.667309:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3aab76229c8, 0x26f0a915a150
[1:1:0712/145736.667411:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html", 100
[1:1:0712/145736.667595:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 673
[1:1:0712/145736.667709:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 673 0x7f0a8f778070 0x26f0ae6bdf60 , 5:3_https://fdc.rednet.cn/, 1, -5:3_https://fdc.rednet.cn/, 671 0x7f0a8f778070 0x26f0a9380a60 
[1:1:0712/145736.681770:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://fdc.rednet.cn/, 614, 7f0a920bd8db
[1:1:0712/145736.690489:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"541 0x7f0a8f778070 0x26f0a902ebe0 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145736.690610:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"541 0x7f0a8f778070 0x26f0a902ebe0 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145736.690797:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://fdc.rednet.cn/, 675
[1:1:0712/145736.690904:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 675 0x7f0a8f778070 0x26f0aea5bae0 , 5:3_https://fdc.rednet.cn/, 0, , 614 0x7f0a8f778070 0x26f0aea5b2e0 
[1:1:0712/145736.691039:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145736.691295:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://fdc.rednet.cn/, 165d51a62860, , , () {
			mySwiper1.swipeNext && mySwiper1.swipeNext()
		}
[1:1:0712/145736.691389:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://fdc.rednet.cn/content/2019/07/10/5705554.html", "fdc.rednet.cn", 3, 1, , , 0
[1:1:0712/145736.777909:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 673, 7f0a920bd881
[1:1:0712/145736.786215:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"165d51a62860","ptid":"671 0x7f0a8f778070 0x26f0a9380a60 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145736.786388:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://fdc.rednet.cn/","ptid":"671 0x7f0a8f778070 0x26f0a9380a60 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145736.786618:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145736.786952:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://fdc.rednet.cn/, 165d51a62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/145736.787098:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://fdc.rednet.cn/content/2019/07/10/5705554.html", "fdc.rednet.cn", 3, 1, , , 0
[1:1:0712/145736.787445:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3aab76229c8, 0x26f0a915a150
[1:1:0712/145736.787548:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html", 100
[1:1:0712/145736.787732:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 677
[1:1:0712/145736.787844:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 677 0x7f0a8f778070 0x26f0aea58c60 , 5:3_https://fdc.rednet.cn/, 1, -5:3_https://fdc.rednet.cn/, 673 0x7f0a8f778070 0x26f0ae6bdf60 
[1:1:0712/145736.898137:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 677, 7f0a920bd881
[1:1:0712/145736.906476:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"165d51a62860","ptid":"673 0x7f0a8f778070 0x26f0ae6bdf60 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145736.906649:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://fdc.rednet.cn/","ptid":"673 0x7f0a8f778070 0x26f0ae6bdf60 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145736.906878:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145736.907206:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://fdc.rednet.cn/, 165d51a62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/145736.907324:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://fdc.rednet.cn/content/2019/07/10/5705554.html", "fdc.rednet.cn", 3, 1, , , 0
[1:1:0712/145736.907645:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3aab76229c8, 0x26f0a915a150
[1:1:0712/145736.907772:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html", 100
[1:1:0712/145736.907999:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 679
[1:1:0712/145736.908104:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 679 0x7f0a8f778070 0x26f0ae9557e0 , 5:3_https://fdc.rednet.cn/, 1, -5:3_https://fdc.rednet.cn/, 677 0x7f0a8f778070 0x26f0aea58c60 
[1:1:0712/145737.018222:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 679, 7f0a920bd881
[1:1:0712/145737.026562:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"165d51a62860","ptid":"677 0x7f0a8f778070 0x26f0aea58c60 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145737.026735:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://fdc.rednet.cn/","ptid":"677 0x7f0a8f778070 0x26f0aea58c60 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145737.026964:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145737.027298:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://fdc.rednet.cn/, 165d51a62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/145737.027434:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://fdc.rednet.cn/content/2019/07/10/5705554.html", "fdc.rednet.cn", 3, 1, , , 0
[1:1:0712/145737.027762:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3aab76229c8, 0x26f0a915a150
[1:1:0712/145737.027891:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html", 100
[1:1:0712/145737.028068:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 681
[1:1:0712/145737.028160:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 681 0x7f0a8f778070 0x26f0ae4d2760 , 5:3_https://fdc.rednet.cn/, 1, -5:3_https://fdc.rednet.cn/, 679 0x7f0a8f778070 0x26f0ae9557e0 
[1:1:0712/145737.138356:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 681, 7f0a920bd881
[1:1:0712/145737.146618:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"165d51a62860","ptid":"679 0x7f0a8f778070 0x26f0ae9557e0 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145737.146788:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://fdc.rednet.cn/","ptid":"679 0x7f0a8f778070 0x26f0ae9557e0 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145737.147016:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145737.147346:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://fdc.rednet.cn/, 165d51a62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/145737.147481:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://fdc.rednet.cn/content/2019/07/10/5705554.html", "fdc.rednet.cn", 3, 1, , , 0
[1:1:0712/145737.147845:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3aab76229c8, 0x26f0a915a150
[1:1:0712/145737.147975:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html", 100
[1:1:0712/145737.148145:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 683
[1:1:0712/145737.148238:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 683 0x7f0a8f778070 0x26f0ae9f0060 , 5:3_https://fdc.rednet.cn/, 1, -5:3_https://fdc.rednet.cn/, 681 0x7f0a8f778070 0x26f0ae4d2760 
[1:1:0712/145737.258438:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 683, 7f0a920bd881
[1:1:0712/145737.266845:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"165d51a62860","ptid":"681 0x7f0a8f778070 0x26f0ae4d2760 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145737.267018:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://fdc.rednet.cn/","ptid":"681 0x7f0a8f778070 0x26f0ae4d2760 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145737.267248:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145737.267586:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://fdc.rednet.cn/, 165d51a62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/145737.267714:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://fdc.rednet.cn/content/2019/07/10/5705554.html", "fdc.rednet.cn", 3, 1, , , 0
[1:1:0712/145737.268047:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3aab76229c8, 0x26f0a915a150
[1:1:0712/145737.268136:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html", 100
[1:1:0712/145737.268307:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 686
[1:1:0712/145737.268407:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 686 0x7f0a8f778070 0x26f0a93802e0 , 5:3_https://fdc.rednet.cn/, 1, -5:3_https://fdc.rednet.cn/, 683 0x7f0a8f778070 0x26f0ae9f0060 
[1:1:0712/145737.378697:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 686, 7f0a920bd881
[1:1:0712/145737.387150:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"165d51a62860","ptid":"683 0x7f0a8f778070 0x26f0ae9f0060 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145737.387324:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://fdc.rednet.cn/","ptid":"683 0x7f0a8f778070 0x26f0ae9f0060 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145737.387554:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145737.387883:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://fdc.rednet.cn/, 165d51a62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/145737.388064:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://fdc.rednet.cn/content/2019/07/10/5705554.html", "fdc.rednet.cn", 3, 1, , , 0
[1:1:0712/145737.388401:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3aab76229c8, 0x26f0a915a150
[1:1:0712/145737.388529:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html", 100
[1:1:0712/145737.388735:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 688
[1:1:0712/145737.388828:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 688 0x7f0a8f778070 0x26f0a938a960 , 5:3_https://fdc.rednet.cn/, 1, -5:3_https://fdc.rednet.cn/, 686 0x7f0a8f778070 0x26f0a93802e0 
[1:1:0712/145737.499704:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 688, 7f0a920bd881
[1:1:0712/145737.508709:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"165d51a62860","ptid":"686 0x7f0a8f778070 0x26f0a93802e0 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145737.508851:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://fdc.rednet.cn/","ptid":"686 0x7f0a8f778070 0x26f0a93802e0 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145737.509050:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145737.509404:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://fdc.rednet.cn/, 165d51a62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/145737.509550:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://fdc.rednet.cn/content/2019/07/10/5705554.html", "fdc.rednet.cn", 3, 1, , , 0
[1:1:0712/145737.509935:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3aab76229c8, 0x26f0a915a150
[1:1:0712/145737.510081:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html", 100
[1:1:0712/145737.510326:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 690
[1:1:0712/145737.510487:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 690 0x7f0a8f778070 0x26f0aea5b0e0 , 5:3_https://fdc.rednet.cn/, 1, -5:3_https://fdc.rednet.cn/, 688 0x7f0a8f778070 0x26f0a938a960 
[1:1:0712/145737.620842:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 690, 7f0a920bd881
[1:1:0712/145737.629433:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"165d51a62860","ptid":"688 0x7f0a8f778070 0x26f0a938a960 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145737.629607:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://fdc.rednet.cn/","ptid":"688 0x7f0a8f778070 0x26f0a938a960 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145737.629840:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145737.630168:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://fdc.rednet.cn/, 165d51a62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/145737.630313:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://fdc.rednet.cn/content/2019/07/10/5705554.html", "fdc.rednet.cn", 3, 1, , , 0
[1:1:0712/145737.630675:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3aab76229c8, 0x26f0a915a150
[1:1:0712/145737.630779:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html", 100
[1:1:0712/145737.630962:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 692
[1:1:0712/145737.631075:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 692 0x7f0a8f778070 0x26f0ae9390e0 , 5:3_https://fdc.rednet.cn/, 1, -5:3_https://fdc.rednet.cn/, 690 0x7f0a8f778070 0x26f0aea5b0e0 
[1:1:0712/145737.741664:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 692, 7f0a920bd881
[1:1:0712/145737.750212:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"165d51a62860","ptid":"690 0x7f0a8f778070 0x26f0aea5b0e0 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145737.750385:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://fdc.rednet.cn/","ptid":"690 0x7f0a8f778070 0x26f0aea5b0e0 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145737.750623:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145737.750950:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://fdc.rednet.cn/, 165d51a62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/145737.751096:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://fdc.rednet.cn/content/2019/07/10/5705554.html", "fdc.rednet.cn", 3, 1, , , 0
[1:1:0712/145737.751447:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3aab76229c8, 0x26f0a915a150
[1:1:0712/145737.751551:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html", 100
[1:1:0712/145737.751733:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 694
[1:1:0712/145737.751845:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 694 0x7f0a8f778070 0x26f0a93807e0 , 5:3_https://fdc.rednet.cn/, 1, -5:3_https://fdc.rednet.cn/, 692 0x7f0a8f778070 0x26f0ae9390e0 
[1:1:0712/145737.862204:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 694, 7f0a920bd881
[1:1:0712/145737.870879:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"165d51a62860","ptid":"692 0x7f0a8f778070 0x26f0ae9390e0 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145737.871056:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://fdc.rednet.cn/","ptid":"692 0x7f0a8f778070 0x26f0ae9390e0 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145737.871296:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145737.871607:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://fdc.rednet.cn/, 165d51a62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/145737.871741:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://fdc.rednet.cn/content/2019/07/10/5705554.html", "fdc.rednet.cn", 3, 1, , , 0
[1:1:0712/145737.872106:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3aab76229c8, 0x26f0a915a150
[1:1:0712/145737.872206:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html", 100
[1:1:0712/145737.872399:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 696
[1:1:0712/145737.872510:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 696 0x7f0a8f778070 0x26f0aec44a60 , 5:3_https://fdc.rednet.cn/, 1, -5:3_https://fdc.rednet.cn/, 694 0x7f0a8f778070 0x26f0a93807e0 
[1:1:0712/145737.982796:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 696, 7f0a920bd881
[1:1:0712/145737.991380:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"165d51a62860","ptid":"694 0x7f0a8f778070 0x26f0a93807e0 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145737.991556:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://fdc.rednet.cn/","ptid":"694 0x7f0a8f778070 0x26f0a93807e0 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145737.991783:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145737.992101:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://fdc.rednet.cn/, 165d51a62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/145737.992235:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://fdc.rednet.cn/content/2019/07/10/5705554.html", "fdc.rednet.cn", 3, 1, , , 0
[1:1:0712/145737.992564:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3aab76229c8, 0x26f0a915a150
[1:1:0712/145737.992653:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html", 100
[1:1:0712/145737.992824:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 698
[1:1:0712/145737.992915:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 698 0x7f0a8f778070 0x26f0ae944760 , 5:3_https://fdc.rednet.cn/, 1, -5:3_https://fdc.rednet.cn/, 696 0x7f0a8f778070 0x26f0aec44a60 
[1:1:0712/145738.103314:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 698, 7f0a920bd881
[1:1:0712/145738.111828:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"165d51a62860","ptid":"696 0x7f0a8f778070 0x26f0aec44a60 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145738.111999:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://fdc.rednet.cn/","ptid":"696 0x7f0a8f778070 0x26f0aec44a60 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145738.112226:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145738.112516:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://fdc.rednet.cn/, 165d51a62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/145738.112615:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://fdc.rednet.cn/content/2019/07/10/5705554.html", "fdc.rednet.cn", 3, 1, , , 0
[1:1:0712/145738.112907:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3aab76229c8, 0x26f0a915a150
[1:1:0712/145738.112987:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html", 100
[1:1:0712/145738.113150:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 700
[1:1:0712/145738.113263:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 700 0x7f0a8f778070 0x26f0a93806e0 , 5:3_https://fdc.rednet.cn/, 1, -5:3_https://fdc.rednet.cn/, 698 0x7f0a8f778070 0x26f0ae944760 
[1:1:0712/145738.223790:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 700, 7f0a920bd881
[1:1:0712/145738.232386:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"165d51a62860","ptid":"698 0x7f0a8f778070 0x26f0ae944760 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145738.232523:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://fdc.rednet.cn/","ptid":"698 0x7f0a8f778070 0x26f0ae944760 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145738.232708:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145738.232984:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://fdc.rednet.cn/, 165d51a62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/145738.233109:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://fdc.rednet.cn/content/2019/07/10/5705554.html", "fdc.rednet.cn", 3, 1, , , 0
[1:1:0712/145738.233465:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3aab76229c8, 0x26f0a915a150
[1:1:0712/145738.233603:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html", 100
[1:1:0712/145738.233831:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 702
[1:1:0712/145738.233934:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 702 0x7f0a8f778070 0x26f0a95b9e60 , 5:3_https://fdc.rednet.cn/, 1, -5:3_https://fdc.rednet.cn/, 700 0x7f0a8f778070 0x26f0a93806e0 
[1:1:0712/145738.344596:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 702, 7f0a920bd881
[1:1:0712/145738.355557:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"165d51a62860","ptid":"700 0x7f0a8f778070 0x26f0a93806e0 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145738.355730:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://fdc.rednet.cn/","ptid":"700 0x7f0a8f778070 0x26f0a93806e0 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145738.356037:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145738.356339:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://fdc.rednet.cn/, 165d51a62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/145738.356467:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://fdc.rednet.cn/content/2019/07/10/5705554.html", "fdc.rednet.cn", 3, 1, , , 0
[1:1:0712/145738.356782:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3aab76229c8, 0x26f0a915a150
[1:1:0712/145738.356865:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html", 100
[1:1:0712/145738.357021:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 704
[1:1:0712/145738.357179:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 704 0x7f0a8f778070 0x26f0a935db60 , 5:3_https://fdc.rednet.cn/, 1, -5:3_https://fdc.rednet.cn/, 702 0x7f0a8f778070 0x26f0a95b9e60 
[1:1:0712/145738.467612:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 704, 7f0a920bd881
[1:1:0712/145738.476266:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"165d51a62860","ptid":"702 0x7f0a8f778070 0x26f0a95b9e60 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145738.476403:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://fdc.rednet.cn/","ptid":"702 0x7f0a8f778070 0x26f0a95b9e60 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145738.476585:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145738.476861:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://fdc.rednet.cn/, 165d51a62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/145738.476948:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://fdc.rednet.cn/content/2019/07/10/5705554.html", "fdc.rednet.cn", 3, 1, , , 0
[1:1:0712/145738.477237:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3aab76229c8, 0x26f0a915a150
[1:1:0712/145738.477377:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html", 100
[1:1:0712/145738.477567:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 706
[1:1:0712/145738.477679:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 706 0x7f0a8f778070 0x26f0a92d24e0 , 5:3_https://fdc.rednet.cn/, 1, -5:3_https://fdc.rednet.cn/, 704 0x7f0a8f778070 0x26f0a935db60 
[1:1:0712/145738.588431:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 706, 7f0a920bd881
[1:1:0712/145738.597870:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"165d51a62860","ptid":"704 0x7f0a8f778070 0x26f0a935db60 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145738.598060:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://fdc.rednet.cn/","ptid":"704 0x7f0a8f778070 0x26f0a935db60 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145738.598324:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145738.598652:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://fdc.rednet.cn/, 165d51a62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/145738.598823:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://fdc.rednet.cn/content/2019/07/10/5705554.html", "fdc.rednet.cn", 3, 1, , , 0
[1:1:0712/145738.599185:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3aab76229c8, 0x26f0a915a150
[1:1:0712/145738.599294:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html", 100
[1:1:0712/145738.599485:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 708
[1:1:0712/145738.599605:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 708 0x7f0a8f778070 0x26f0ae9e9060 , 5:3_https://fdc.rednet.cn/, 1, -5:3_https://fdc.rednet.cn/, 706 0x7f0a8f778070 0x26f0a92d24e0 
[1:1:0712/145738.682712:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://fdc.rednet.cn/, 675, 7f0a920bd8db
[1:1:0712/145738.691891:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"614 0x7f0a8f778070 0x26f0aea5b2e0 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145738.692072:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"614 0x7f0a8f778070 0x26f0aea5b2e0 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145738.692307:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://fdc.rednet.cn/, 710
[1:1:0712/145738.692452:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 710 0x7f0a8f778070 0x26f0a92dcee0 , 5:3_https://fdc.rednet.cn/, 0, , 675 0x7f0a8f778070 0x26f0aea5bae0 
[1:1:0712/145738.692582:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145738.692833:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://fdc.rednet.cn/, 165d51a62860, , , () {
			mySwiper1.swipeNext && mySwiper1.swipeNext()
		}
[1:1:0712/145738.692925:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://fdc.rednet.cn/content/2019/07/10/5705554.html", "fdc.rednet.cn", 3, 1, , , 0
[1:1:0712/145738.708896:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 708, 7f0a920bd881
[1:1:0712/145738.717938:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"165d51a62860","ptid":"706 0x7f0a8f778070 0x26f0a92d24e0 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145738.718084:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://fdc.rednet.cn/","ptid":"706 0x7f0a8f778070 0x26f0a92d24e0 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145738.718267:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145738.718532:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://fdc.rednet.cn/, 165d51a62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/145738.718645:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://fdc.rednet.cn/content/2019/07/10/5705554.html", "fdc.rednet.cn", 3, 1, , , 0
[1:1:0712/145738.718954:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3aab76229c8, 0x26f0a915a150
[1:1:0712/145738.719049:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html", 100
[1:1:0712/145738.719222:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 712
[1:1:0712/145738.719317:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 712 0x7f0a8f778070 0x26f0a937ffe0 , 5:3_https://fdc.rednet.cn/, 1, -5:3_https://fdc.rednet.cn/, 708 0x7f0a8f778070 0x26f0ae9e9060 
[1:1:0712/145738.829121:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 712, 7f0a920bd881
[1:1:0712/145738.838446:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"165d51a62860","ptid":"708 0x7f0a8f778070 0x26f0ae9e9060 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145738.838633:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://fdc.rednet.cn/","ptid":"708 0x7f0a8f778070 0x26f0ae9e9060 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145738.838867:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145738.839196:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://fdc.rednet.cn/, 165d51a62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/145738.839349:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://fdc.rednet.cn/content/2019/07/10/5705554.html", "fdc.rednet.cn", 3, 1, , , 0
[1:1:0712/145738.839703:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3aab76229c8, 0x26f0a915a150
[1:1:0712/145738.839812:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html", 100
[1:1:0712/145738.840012:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 714
[1:1:0712/145738.840128:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 714 0x7f0a8f778070 0x26f0aec443e0 , 5:3_https://fdc.rednet.cn/, 1, -5:3_https://fdc.rednet.cn/, 712 0x7f0a8f778070 0x26f0a937ffe0 
[1:1:0712/145738.950048:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 714, 7f0a920bd881
[1:1:0712/145738.959526:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"165d51a62860","ptid":"712 0x7f0a8f778070 0x26f0a937ffe0 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145738.959719:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://fdc.rednet.cn/","ptid":"712 0x7f0a8f778070 0x26f0a937ffe0 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145738.959956:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145738.960273:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://fdc.rednet.cn/, 165d51a62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/145738.960412:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://fdc.rednet.cn/content/2019/07/10/5705554.html", "fdc.rednet.cn", 3, 1, , , 0
[1:1:0712/145738.960736:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3aab76229c8, 0x26f0a915a150
[1:1:0712/145738.960828:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html", 100
[1:1:0712/145738.961001:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 716
[1:1:0712/145738.961118:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 716 0x7f0a8f778070 0x26f0ae0e6c60 , 5:3_https://fdc.rednet.cn/, 1, -5:3_https://fdc.rednet.cn/, 714 0x7f0a8f778070 0x26f0aec443e0 
[1:1:0712/145739.070997:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 716, 7f0a920bd881
[1:1:0712/145739.080319:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"165d51a62860","ptid":"714 0x7f0a8f778070 0x26f0aec443e0 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145739.080473:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://fdc.rednet.cn/","ptid":"714 0x7f0a8f778070 0x26f0aec443e0 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145739.080653:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145739.080934:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://fdc.rednet.cn/, 165d51a62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/145739.081027:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://fdc.rednet.cn/content/2019/07/10/5705554.html", "fdc.rednet.cn", 3, 1, , , 0
[1:1:0712/145739.081428:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3aab76229c8, 0x26f0a915a150
[1:1:0712/145739.081573:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html", 100
[1:1:0712/145739.081805:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 718
[1:1:0712/145739.081925:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 718 0x7f0a8f778070 0x26f0aea28be0 , 5:3_https://fdc.rednet.cn/, 1, -5:3_https://fdc.rednet.cn/, 716 0x7f0a8f778070 0x26f0ae0e6c60 
[1:1:0712/145739.191749:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 718, 7f0a920bd881
[1:1:0712/145739.201086:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"165d51a62860","ptid":"716 0x7f0a8f778070 0x26f0ae0e6c60 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145739.201274:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://fdc.rednet.cn/","ptid":"716 0x7f0a8f778070 0x26f0ae0e6c60 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145739.201509:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145739.201826:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://fdc.rednet.cn/, 165d51a62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/145739.201978:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://fdc.rednet.cn/content/2019/07/10/5705554.html", "fdc.rednet.cn", 3, 1, , , 0
[1:1:0712/145739.202333:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3aab76229c8, 0x26f0a915a150
[1:1:0712/145739.202442:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html", 100
[1:1:0712/145739.202630:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 720
[1:1:0712/145739.202746:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 720 0x7f0a8f778070 0x26f0aea264e0 , 5:3_https://fdc.rednet.cn/, 1, -5:3_https://fdc.rednet.cn/, 718 0x7f0a8f778070 0x26f0aea28be0 
[1:1:0712/145739.318944:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 720, 7f0a920bd881
[1:1:0712/145739.328485:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"165d51a62860","ptid":"718 0x7f0a8f778070 0x26f0aea28be0 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145739.328643:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://fdc.rednet.cn/","ptid":"718 0x7f0a8f778070 0x26f0aea28be0 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145739.328824:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145739.329133:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://fdc.rednet.cn/, 165d51a62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/145739.329286:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://fdc.rednet.cn/content/2019/07/10/5705554.html", "fdc.rednet.cn", 3, 1, , , 0
[1:1:0712/145739.329641:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3aab76229c8, 0x26f0a915a150
[1:1:0712/145739.329787:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html", 100
[1:1:0712/145739.329981:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 724
[1:1:0712/145739.330099:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 724 0x7f0a8f778070 0x26f0a93f73e0 , 5:3_https://fdc.rednet.cn/, 1, -5:3_https://fdc.rednet.cn/, 720 0x7f0a8f778070 0x26f0aea264e0 
[1:1:0712/145739.440480:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 724, 7f0a920bd881
[1:1:0712/145739.449897:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"165d51a62860","ptid":"720 0x7f0a8f778070 0x26f0aea264e0 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145739.450084:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://fdc.rednet.cn/","ptid":"720 0x7f0a8f778070 0x26f0aea264e0 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145739.450323:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145739.450660:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://fdc.rednet.cn/, 165d51a62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/145739.450801:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://fdc.rednet.cn/content/2019/07/10/5705554.html", "fdc.rednet.cn", 3, 1, , , 0
[1:1:0712/145739.451168:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3aab76229c8, 0x26f0a915a150
[1:1:0712/145739.451278:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html", 100
[1:1:0712/145739.451467:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 726
[1:1:0712/145739.451586:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 726 0x7f0a8f778070 0x26f0aea29060 , 5:3_https://fdc.rednet.cn/, 1, -5:3_https://fdc.rednet.cn/, 724 0x7f0a8f778070 0x26f0a93f73e0 
[1:1:0712/145739.561644:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 726, 7f0a920bd881
[1:1:0712/145739.571190:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"165d51a62860","ptid":"724 0x7f0a8f778070 0x26f0a93f73e0 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145739.571384:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://fdc.rednet.cn/","ptid":"724 0x7f0a8f778070 0x26f0a93f73e0 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145739.571620:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145739.571949:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://fdc.rednet.cn/, 165d51a62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/145739.572080:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://fdc.rednet.cn/content/2019/07/10/5705554.html", "fdc.rednet.cn", 3, 1, , , 0
[1:1:0712/145739.572403:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3aab76229c8, 0x26f0a915a150
[1:1:0712/145739.572572:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html", 100
[1:1:0712/145739.572793:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 728
[1:1:0712/145739.572919:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 728 0x7f0a8f778070 0x26f0ae9e9060 , 5:3_https://fdc.rednet.cn/, 1, -5:3_https://fdc.rednet.cn/, 726 0x7f0a8f778070 0x26f0aea29060 
[1:1:0712/145739.683092:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 728, 7f0a920bd881
[1:1:0712/145739.692909:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"165d51a62860","ptid":"726 0x7f0a8f778070 0x26f0aea29060 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145739.693107:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://fdc.rednet.cn/","ptid":"726 0x7f0a8f778070 0x26f0aea29060 ","rf":"5:3_https://fdc.rednet.cn/"}
[1:1:0712/145739.693353:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html"
[1:1:0712/145739.693680:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://fdc.rednet.cn/, 165d51a62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/145739.693833:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://fdc.rednet.cn/content/2019/07/10/5705554.html", "fdc.rednet.cn", 3, 1, , , 0
[1:1:0712/145739.694205:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3aab76229c8, 0x26f0a915a150
[1:1:0712/145739.694313:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://fdc.rednet.cn/content/2019/07/10/5705554.html", 100
[1:1:0712/145739.694508:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://fdc.rednet.cn/, 730
[1:1:0712/145739.694628:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 730 0x7f0a8f778070 0x26f0a98cc460 , 5:3_https://fdc.rednet.cn/, 1, -5:3_https://fdc.rednet.cn/, 728 0x7f0a8f778070 0x26f0ae9e9060 
