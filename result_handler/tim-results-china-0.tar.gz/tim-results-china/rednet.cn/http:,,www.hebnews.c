[0712/145159.142675:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/145159.142929:INFO:switcher_clone.cc(787)] backtrace rip is 7ff2940aa891
[0712/145159.676165:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/145159.676412:INFO:switcher_clone.cc(787)] backtrace rip is 7fcaa4f5e891
[1:1:0712/145159.680240:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/145159.680404:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/145159.683169:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[8383:8383:0712/145200.447854:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/1e3c41ee-1c69-4818-b91e-30769869a28b
[0712/145200.515258:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/145200.515520:INFO:switcher_clone.cc(787)] backtrace rip is 7f662a6d6891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[8414:8414:0712/145200.678262:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=8414
[8427:8427:0712/145200.678586:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=8427
[8383:8383:0712/145200.704690:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[8383:8412:0712/145200.705146:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/145200.705270:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/145200.705425:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/145200.705724:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/145200.705842:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/145200.707602:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x1e7a068b, 1
[1:1:0712/145200.707807:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x231f0c98, 0
[1:1:0712/145200.707899:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x2e7b83e9, 3
[1:1:0712/145200.707984:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x2737b356, 2
[1:1:0712/145200.708078:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffff980c1f23 ffffff8b067a1e 56ffffffb33727 ffffffe9ffffff837b2e , 10104, 4
[1:1:0712/145200.708788:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[8383:8412:0712/145200.709566:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�#�zV�7'�{.�X�
[8383:8412:0712/145200.709611:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �#�zV�7'�{.���X�
[8383:8412:0712/145200.709762:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[8383:8412:0712/145200.709799:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 8435, 4, 980c1f23 8b067a1e 56b33727 e9837b2e 
[1:1:0712/145200.710072:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fcaa31980a0, 3
[1:1:0712/145200.710183:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fcaa3324080, 2
[1:1:0712/145200.710263:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fca8cfe6d20, -2
[1:1:0712/145200.718305:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/145200.718753:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2737b356
[1:1:0712/145200.719226:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2737b356
[1:1:0712/145200.719984:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2737b356
[1:1:0712/145200.720531:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2737b356
[1:1:0712/145200.720664:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2737b356
[1:1:0712/145200.720771:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2737b356
[1:1:0712/145200.720867:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2737b356
[1:1:0712/145200.721124:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2737b356
[1:1:0712/145200.721288:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fcaa4f5e7ba
[1:1:0712/145200.721385:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fcaa4f55def, 7fcaa4f5e77a, 7fcaa4f600cf
[1:1:0712/145200.723054:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2737b356
[1:1:0712/145200.723250:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2737b356
[1:1:0712/145200.723598:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2737b356
[1:1:0712/145200.724404:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2737b356
[1:1:0712/145200.724521:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2737b356
[1:1:0712/145200.724617:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2737b356
[1:1:0712/145200.724742:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2737b356
[1:1:0712/145200.725286:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2737b356
[1:1:0712/145200.725454:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fcaa4f5e7ba
[1:1:0712/145200.725539:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fcaa4f55def, 7fcaa4f5e77a, 7fcaa4f600cf
[1:1:0712/145200.728384:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/145200.728569:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/145200.728652:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffc88ec04c8, 0x7ffc88ec0448)
[1:1:0712/145200.735264:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/145200.738739:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[8383:8383:0712/145201.130767:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[8383:8383:0712/145201.131263:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[8383:8394:0712/145201.139483:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[8383:8394:0712/145201.139549:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[8383:8383:0712/145201.139563:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[8383:8383:0712/145201.139607:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[8383:8383:0712/145201.139671:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,8435, 4
[1:7:0712/145201.142712:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/145201.187919:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x2b6f4c24a220
[1:1:0712/145201.188052:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[8383:8406:0712/145201.214868:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/145201.393460:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[8383:8383:0712/145202.139651:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[8383:8383:0712/145202.139738:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/145202.155715:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/145202.157400:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/145202.590026:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1c822a9e1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/145202.590211:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/145202.595305:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1c822a9e1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/145202.595429:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/145202.616489:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/145202.721244:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/145202.721390:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/145202.848943:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 358, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/145202.851495:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1c822a9e1f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/145202.851635:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/145202.863436:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 359, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/145202.866391:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1c822a9e1f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/145202.866522:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/145202.870279:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[8383:8383:0712/145202.870950:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/145202.872033:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x2b6f4c248e20
[1:1:0712/145202.872133:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[8383:8383:0712/145202.873510:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[8383:8383:0712/145202.884602:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[8383:8383:0712/145202.884682:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/145202.903557:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/145203.218122:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 419 0x7fca8ebc12e0 0x2b6f4c341660 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/145203.218867:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1c822a9e1f78, , , var configData = {"googleBaseUrl":"https://www.google.com.hk/","isAccessibleBrowser":false,"isGoogle
[1:1:0712/145203.219019:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/145203.219635:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[8383:8383:0712/145203.245707:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/145203.246871:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x2b6f4c249820
[1:1:0712/145203.247015:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[8383:8383:0712/145203.248356:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/145203.253936:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/145203.254088:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[8383:8383:0712/145203.256927:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[8383:8383:0712/145203.260891:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[8383:8383:0712/145203.261322:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[8383:8394:0712/145203.266144:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[8383:8394:0712/145203.266200:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[8383:8383:0712/145203.266224:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[8383:8383:0712/145203.266265:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[8383:8383:0712/145203.266327:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,8435, 4
[1:7:0712/145203.271149:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/145203.524521:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/145203.666263:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 467 0x7fca8ebc12e0 0x2b6f4c2b7be0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/145203.666876:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1c822a9e1f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/145203.666991:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/145203.667346:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[8383:8383:0712/145203.800131:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[8383:8383:0712/145203.800206:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/145203.811536:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/145203.971568:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[8383:8383:0712/145204.136575:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[8383:8412:0712/145204.136861:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/145204.136984:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/145204.137139:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/145204.137333:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/145204.137413:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/145204.139573:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x11eba7b5, 1
[1:1:0712/145204.139763:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x34491852, 0
[1:1:0712/145204.139858:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x34e397e, 3
[1:1:0712/145204.139941:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x220031b2, 2
[1:1:0712/145204.140018:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 52184934 ffffffb5ffffffa7ffffffeb11 ffffffb2310022 7e394e03 , 10104, 5
[1:1:0712/145204.140722:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[8383:8412:0712/145204.140899:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGRI4����1
[1:1:0712/145204.140887:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fcaa31980a0, 3
[8383:8412:0712/145204.140944:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is RI4����1
[1:1:0712/145204.140971:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fcaa3324080, 2
[8383:8412:0712/145204.141102:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 8477, 5, 52184934 b5a7eb11 b2310022 7e394e03 
[1:1:0712/145204.141081:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fca8cfe6d20, -2
[1:1:0712/145204.150436:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/145204.150661:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 220031b2
[1:1:0712/145204.150864:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 220031b2
[1:1:0712/145204.151163:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 220031b2
[1:1:0712/145204.151740:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 220031b2
[1:1:0712/145204.151843:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 220031b2
[1:1:0712/145204.151947:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 220031b2
[1:1:0712/145204.152036:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 220031b2
[1:1:0712/145204.152289:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 220031b2
[1:1:0712/145204.152419:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fcaa4f5e7ba
[1:1:0712/145204.152492:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fcaa4f55def, 7fcaa4f5e77a, 7fcaa4f600cf
[1:1:0712/145204.154218:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 220031b2
[1:1:0712/145204.154374:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 220031b2
[1:1:0712/145204.154666:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 220031b2
[1:1:0712/145204.155434:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 220031b2
[1:1:0712/145204.155546:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 220031b2
[1:1:0712/145204.155653:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 220031b2
[1:1:0712/145204.155754:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 220031b2
[1:1:0712/145204.156244:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 220031b2
[1:1:0712/145204.156413:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fcaa4f5e7ba
[1:1:0712/145204.156493:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fcaa4f55def, 7fcaa4f5e77a, 7fcaa4f600cf
[1:1:0712/145204.159121:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/145204.159245:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/145204.159366:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/145204.159474:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffc88ec04c8, 0x7ffc88ec0448)
[1:1:0712/145204.159379:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/145204.165639:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/145204.167835:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/145204.254356:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x2b6f4c1e0220
[1:1:0712/145204.254786:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/145204.357009:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 540, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/145204.358837:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1c822ab0e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/145204.359027:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/145204.361486:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/145204.414054:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/145204.414405:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1c822a9e1f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/145204.414519:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/145204.472088:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/145204.472853:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/145204.472986:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1c822ab0e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/145204.473131:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/145204.548560:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/145204.561623:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/145204.561765:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1c822ab0e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/145204.561935:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/145204.729163:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.qq.com/"
[8383:8383:0712/145204.844406:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[8383:8383:0712/145204.846663:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[8383:8383:0712/145204.863282:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://www.hebnews.cn/
[8383:8383:0712/145204.863336:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://www.hebnews.cn/, http://www.hebnews.cn/, 1
[8383:8383:0712/145204.863393:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://www.hebnews.cn/, HTTP/1.1 200 OK Server: Tengine Content-Type: text/html Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Date: Fri, 12 Jul 2019 06:52:04 GMT Vary: Accept-Encoding Ali-Swift-Global-Savetime: 1562914324 Via: cache10.l2et2-1[23,200-0,M], cache15.l2et2-1[24,0], cache4.cn143[203,200-0,M], cache7.cn143[204,0] X-Cache: MISS TCP_MISS dirn:-2:-2 X-Swift-SaveTime: Fri, 12 Jul 2019 06:52:04 GMT X-Swift-CacheTime: 0 Timing-Allow-Origin: * EagleId: 7cc1e29b15629143244967064e Content-Encoding: gzip  ,8477, 5
[8383:8394:0712/145204.865194:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[8383:8394:0712/145204.865253:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[1:7:0712/145204.868632:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/145204.879980:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://www.hebnews.cn/
[1:1:0712/145204.884188:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://amazon.com/"
[8383:8383:0712/145204.938308:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://www.hebnews.cn/, http://www.hebnews.cn/, 1
[8383:8383:0712/145204.938366:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://www.hebnews.cn/, http://www.hebnews.cn
[1:1:0712/145204.950304:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://taobao.com/"
[1:1:0712/145204.951742:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/145204.978167:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://tmall.com/"
[1:1:0712/145204.990494:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/145205.017462:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://vk.com/"
[1:1:0712/145205.018083:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/145205.018250:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.hebnews.cn/"
[1:1:0712/145205.046803:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.jd.com/"
[1:1:0712/145205.084810:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://yahoo.com/"
[1:1:0712/145205.111630:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://sohu.com/"
[1:1:0712/145205.163709:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/145205.164128:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1c822ab0e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/145205.164286:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/145205.192434:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/145205.192823:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1c822ab0e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/145205.192958:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/145205.214942:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/145205.215356:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1c822ab0e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/145205.215554:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/145205.225251:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/145205.308745:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/145205.309732:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/145205.310158:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1c822ab0e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/145205.310318:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/145205.354794:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/145205.355216:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1c822ab0e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/145205.355373:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/145205.949774:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/145206.592287:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/145206.673772:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/145207.874918:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/145209.353170:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/145211.270794:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/145212.643176:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 323 0x7fca8d001bd0 0x2b6f4c2f1958 , "http://www.hebnews.cn/"
[1:1:0712/145212.649594:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , /*! jQuery v1.8.3 jquery.com | jquery.org/license */
(function(e,t){function _(e){var t=M[e]={};retu
[1:1:0712/145212.649791:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145212.650513:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
		remove user.d_2a0a6841 -> 0
[1:1:0712/145212.746079:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 323 0x7fca8d001bd0 0x2b6f4c2f1958 , "http://www.hebnews.cn/"
[1:1:0712/145213.535890:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 375 0x7fca8d001bd0 0x2b6f4c501458 , "http://www.hebnews.cn/"
[1:1:0712/145213.543232:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , try{!function(){window.___baidu_union_||(window.___baidu_union_={}),window.___baidu_union_dup_||(win
[1:1:0712/145213.543411:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
		remove user.e_77d28ea9 -> 0
[1:1:0712/145214.119279:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 375 0x7fca8d001bd0 0x2b6f4c501458 , "http://www.hebnews.cn/"
[1:1:0712/145214.138423:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 375 0x7fca8d001bd0 0x2b6f4c501458 , "http://www.hebnews.cn/"
[1:1:0712/145214.140294:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 375 0x7fca8d001bd0 0x2b6f4c501458 , "http://www.hebnews.cn/"
[1:1:0712/145214.155021:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 375 0x7fca8d001bd0 0x2b6f4c501458 , "http://www.hebnews.cn/"
[1:1:0712/145214.159989:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 375 0x7fca8d001bd0 0x2b6f4c501458 , "http://www.hebnews.cn/"
[1:1:0712/145214.164642:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/145214.166584:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x2b6f4c1dda20
[1:1:0712/145214.166707:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[1:1:0712/145214.173634:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/145214.173820:INFO:render_frame_impl.cc(7019)] 	 [url] = http://www.hebnews.cn
[1:1:0712/145214.200877:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.082078, 750, 1
[1:1:0712/145214.201003:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/145214.623086:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/145214.623238:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.hebnews.cn/"
[1:1:0712/145214.623653:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 431 0x7fca8cc99070 0x2b6f4c8e67e0 , "http://www.hebnews.cn/"
[1:1:0712/145214.624261:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , 
(function() {
    var s = "_" + Math.random().toString(36).slice(2);
    document.write('<div id="'
[1:1:0712/145214.624384:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[8383:8383:0712/145215.220158:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[8383:8383:0712/145215.222266:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 4, 4, 
[8383:8383:0712/145215.225692:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://www.hebnews.cn/
[3:3:0712/145215.235492:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[8383:8383:0712/145215.265169:INFO:CONSOLE(3)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://pos.baidu.com/dctm?psi=44d19a27fc5a70d4026dd3c3226e0505&di=3229865&dri=0&dis=0&dai=0&ps=229x0&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562914334076&ti=%E6%B2%B3%E5%8C%97%E6%96%B0%E9%97%BB%E7%BD%91_%E6%B2%B3%E5%8C%97%E6%9C%80%E5%A4%A7%E7%9A%84%E7%BD%91%E7%BB%9C%E5%AA%92%E4%BD%93_%E6%B2%B3%E5%8C%97%E7%AC%AC%E4%B8%80%E6%96%B0%E9%97%BB%E9%97%A8%E6%88%B7%E7%BD%91%E7%AB%99_%E6%B2%B3%E5%8C%97%E6%97%A5%E6%8A%A5%E6%8A%A5%E4%B8%9A%E9%9B%86%E5%9B%A2%E4%B8%BB%E5%8A%9E&ari=2&dbv=2&drs=1&pcs=902x620&pss=1215x620&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562914334&rw=635&ltu=http%3A%2F%2Fwww.hebnews.cn%2F&ecd=1&uc=1855x1056&pis=-1x-1&sr=1920x1080&tcn=1562914335&exps=110011, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://dup.baidustatic.com/js/ds.js (3)
[8383:8383:0712/145215.266741:INFO:CONSOLE(3)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://pos.baidu.com/dctm?psi=44d19a27fc5a70d4026dd3c3226e0505&di=3229865&dri=0&dis=0&dai=0&ps=229x0&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562914334076&ti=%E6%B2%B3%E5%8C%97%E6%96%B0%E9%97%BB%E7%BD%91_%E6%B2%B3%E5%8C%97%E6%9C%80%E5%A4%A7%E7%9A%84%E7%BD%91%E7%BB%9C%E5%AA%92%E4%BD%93_%E6%B2%B3%E5%8C%97%E7%AC%AC%E4%B8%80%E6%96%B0%E9%97%BB%E9%97%A8%E6%88%B7%E7%BD%91%E7%AB%99_%E6%B2%B3%E5%8C%97%E6%97%A5%E6%8A%A5%E6%8A%A5%E4%B8%9A%E9%9B%86%E5%9B%A2%E4%B8%BB%E5%8A%9E&ari=2&dbv=2&drs=1&pcs=902x620&pss=1215x620&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562914334&rw=635&ltu=http%3A%2F%2Fwww.hebnews.cn%2F&ecd=1&uc=1855x1056&pis=-1x-1&sr=1920x1080&tcn=1562914335&exps=110011, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://dup.baidustatic.com/js/ds.js (3)
[1:1:0712/145215.522348:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/145215.577178:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/145215.577392:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[8383:8383:0712/145215.856209:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[8383:8383:0712/145215.858202:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[8383:8383:0712/145215.872388:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://tianqi.2345.com/
[8383:8383:0712/145215.872435:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_http://tianqi.2345.com/, http://tianqi.2345.com/plugin/widget/index.htm?s=3&z=3&t=0&v=0&d=2&bd=0&k=&f=&q=1&e=1&a=1&c=53698&w=180&h=36&align=left, 4
[8383:8394:0712/145215.872305:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 4
[8383:8383:0712/145215.872495:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:4_http://tianqi.2345.com/, HTTP/1.1 200 OK Content-Type: text/html Last-Modified: Tue, 22 Jan 2019 05:50:38 GMT Vary: Accept-Encoding ETag: W/"5c46af2e-92c" Expires: Fri, 12 Jul 2019 06:55:11 GMT Cache-Control: max-age=300 P3P: CP=CAO PSA OUR Content-Encoding: gzip Content-Length: 940 Accept-Ranges: bytes Date: Fri, 12 Jul 2019 06:52:15 GMT Age: 123 Connection: keep-alive x-hits: 2  ,8477, 5
[8383:8394:0712/145215.872505:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 4, HandleIncomingMessage, HandleIncomingMessage
[1:7:0712/145215.881195:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/145216.360053:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:4_http://tianqi.2345.com/
[1:1:0712/145216.425279:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , document.readyState
[1:1:0712/145216.425447:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145216.984365:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[8383:8383:0712/145216.984638:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_http://tianqi.2345.com/, http://tianqi.2345.com/, 4
[8383:8383:0712/145216.984686:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, http://tianqi.2345.com/, http://tianqi.2345.com
[1:1:0712/145217.132111:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , document.readyState
[1:1:0712/145217.132269:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145217.444490:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/145217.658652:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , document.readyState
[1:1:0712/145217.658826:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145217.909870:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/145217.910036:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://tianqi.2345.com/plugin/widget/index.htm?s=3&z=3&t=0&v=0&d=2&bd=0&k=&f=&q=1&e=1&a=1&c=53698&w=180&h=36&align=left"
[1:1:0712/145218.074112:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , document.readyState
[1:1:0712/145218.074301:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145218.441521:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , document.readyState
[1:1:0712/145218.441714:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145218.679347:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , document.readyState
[1:1:0712/145218.679505:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145218.826777:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , document.readyState
[1:1:0712/145218.826931:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145218.963904:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , document.readyState
[1:1:0712/145218.964055:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145219.062110:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , document.readyState
[1:1:0712/145219.062284:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145219.145079:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , document.readyState
[1:1:0712/145219.145295:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145219.219467:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , document.readyState
[1:1:0712/145219.219674:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145219.332948:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , document.readyState
[1:1:0712/145219.333151:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145219.471223:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , document.readyState
[1:1:0712/145219.471430:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145219.606397:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , document.readyState
[1:1:0712/145219.606552:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145219.685296:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , document.readyState
[1:1:0712/145219.685441:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145219.742179:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , document.readyState
[1:1:0712/145219.742331:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145219.875237:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , document.readyState
[1:1:0712/145219.875395:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145219.960212:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , document.readyState
[1:1:0712/145219.960382:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145220.098794:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , document.readyState
[1:1:0712/145220.098966:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145220.255033:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , document.readyState
[1:1:0712/145220.255188:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145220.370227:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 874 0x7fcaa3324080 0x2b6f4bbaa920 1 0 0x2b6f4bbaa938 , "http://tianqi.2345.com/plugin/widget/index.htm?s=3&z=3&t=0&v=0&d=2&bd=0&k=&f=&q=1&e=1&a=1&c=53698&w=180&h=36&align=left"
[1:1:0712/145220.386052:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/145220.389328:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://tianqi.2345.com/, 144296588e58, , , /*! jQuery v1.8.3 jquery.com | jquery.org/license */
(function(e,t){function _(e){var t=M[e]={};retu
[1:1:0712/145220.389548:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tianqi.2345.com/plugin/widget/index.htm?s=3&z=3&t=0&v=0&d=2&bd=0&k=&f=&q=1&e=1&a=1&c=53698&w=180&h=36&align=left", "tianqi.2345.com", 4, 1, http://www.hebnews.cn, www.hebnews.cn, 3
[1:1:0712/145220.480398:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 874 0x7fcaa3324080 0x2b6f4bbaa920 1 0 0x2b6f4bbaa938 , "http://tianqi.2345.com/plugin/widget/index.htm?s=3&z=3&t=0&v=0&d=2&bd=0&k=&f=&q=1&e=1&a=1&c=53698&w=180&h=36&align=left"
[1:1:0712/145220.503444:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , document.readyState
[1:1:0712/145220.503586:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145220.805838:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , document.readyState
[1:1:0712/145220.806009:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145221.072189:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , document.readyState
[1:1:0712/145221.072340:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145221.105669:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 930, "http://www.hebnews.cn/"
[1:1:0712/145221.106332:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , ___adblockplus({"queryid" : "502e300ed4a8109c","tuid" : "3229865_0","placement" : {"basic" : {"sspId
[1:1:0712/145221.106463:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[8383:8383:0712/145221.121587:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/145221.122676:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 5, 0x2b6f4cc1a020
[1:1:0712/145221.122831:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 5
[8383:8383:0712/145221.123874:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 5, 5, 
[8383:8383:0712/145221.138279:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:5_http://www.hebnews.cn/, http://www.hebnews.cn/, 5
[8383:8383:0712/145221.138360:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 5, 5, http://www.hebnews.cn/, http://www.hebnews.cn
[1:1:0712/145221.167368:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/145221.169659:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 6, 0x2b6f4cc32820
[1:1:0712/145221.169824:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 6
[8383:8383:0712/145221.170254:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[8383:8383:0712/145221.172522:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: iframe3229865_0, 6, 6, 
[8383:8383:0712/145221.187673:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:6_http://www.hebnews.cn/, http://www.hebnews.cn/, 6
[8383:8383:0712/145221.187752:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 6, 6, http://www.hebnews.cn/, http://www.hebnews.cn
[1:1:0712/145221.189203:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.hebnews.cn/"
[1:1:0712/145221.208286:INFO:switcher_impl.cc(1369)] 			updated frame chain. [WARN] subject_frame does not exist in protected memory. [subject_frame, principals, url] = 1442965796c0, 5:3_http://www.hebnews.cn/, 5:6_http://www.hebnews.cn/, about:blank
[1:1:0712/145221.208478:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:3_http://www.hebnews.cn/-5:6_http://www.hebnews.cn/, 1442965796c0, 144296482860, open, 
[1:1:0712/145221.208595:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "www.hebnews.cn", 6, 2, http://www.hebnews.cn, www.hebnews.cn, 3
[1:1:0712/145221.209752:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.renderFrame (http://dup.baidustatic.com/js/ds.js:1:1)
	http://dup.baidustatic.com/js/ds.js:1:1
	HTMLIFrameElement.onload (http://www.hebnews.cn/:471:10)
	Object.render (http://dup.baidustatic.com/js/ds.js:1:1)
	Object.painterLoadedCallback (http://dup.baidustatic.com/js/ds.js:1:1)
	Object.callback (http://dup.baidustatic.com/js/ds.js:1:1)
	http://dup.baidustatic.com/js/ds.js:1:1
	http://pos.baidu.com/dctm?psi=44d19a27fc5a70d4026dd3c3226e0505&di=3229865&dri=0&dis=0&dai=0&ps=229x0&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562914334076&ti=%E6%B2%B3%E5%8C%97%E6%96%B0%E9%97%BB%E7%BD%91_%E6%B2%B3%E5%8C%97%E6%9C%80%E5%A4%A7%E7%9A%84%E7%BD%91%E7%BB%9C%E5%AA%92%E4%BD%93_%E6%B2%B3%E5%8C%97%E7%AC%AC%E4%B8%80%E6%96%B0%E9%97%BB%E9%97%A8%E6%88%B7%E7%BD%91%E7%AB%99_%E6%B2%B3%E5%8C%97%E6%97%A5%E6%8A%A5%E6%8A%A5%E4%B8%9A%E9%9B%86%E5%9B%A2%E4%B8%BB%E5%8A%9E&ari=2&dbv=2&drs=1&pcs=902x620&pss=1215x620&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562914334&rw=635&ltu=http%3A%2F%2Fwww.hebnews.cn%2F&ecd=1&uc=1855x1056&pis=-1x-1&sr=1920x1080&tcn=1562914335&exps=110011:1:1

[1:1:0712/145221.212683:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 930, "http://www.hebnews.cn/"
[1:1:0712/145221.217446:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hebnews.cn/", 5000
[1:1:0712/145221.217694:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 991
[1:1:0712/145221.217807:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 991 0x7fca8cc99070 0x2b6f4d425a60 , 5:3_http://www.hebnews.cn/, 2, -5:3_http://www.hebnews.cn/-5:6_http://www.hebnews.cn/, 930
[1:1:0712/145221.219869:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:3_http://www.hebnews.cn/-5:6_http://www.hebnews.cn/-5:3_http://www.hebnews.cn/, 144296482860, 1442965796c0, regisetViewWatch, (t){this.isEventInited||(this.initializeEvent(),this.isEventInited=!0),this.watchingList=this.watchi
[1:1:0712/145221.219999:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 3, , , 0
[1:1:0712/145221.220349:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.render (http://dup.baidustatic.com/js/ds.js:1:1)
	Object.painterLoadedCallback (http://dup.baidustatic.com/js/ds.js:1:1)
	Object.callback (http://dup.baidustatic.com/js/ds.js:1:1)
	http://dup.baidustatic.com/js/ds.js:1:1
	http://pos.baidu.com/dctm?psi=44d19a27fc5a70d4026dd3c3226e0505&di=3229865&dri=0&dis=0&dai=0&ps=229x0&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562914334076&ti=%E6%B2%B3%E5%8C%97%E6%96%B0%E9%97%BB%E7%BD%91_%E6%B2%B3%E5%8C%97%E6%9C%80%E5%A4%A7%E7%9A%84%E7%BD%91%E7%BB%9C%E5%AA%92%E4%BD%93_%E6%B2%B3%E5%8C%97%E7%AC%AC%E4%B8%80%E6%96%B0%E9%97%BB%E9%97%A8%E6%88%B7%E7%BD%91%E7%AB%99_%E6%B2%B3%E5%8C%97%E6%97%A5%E6%8A%A5%E6%8A%A5%E4%B8%9A%E9%9B%86%E5%9B%A2%E4%B8%BB%E5%8A%9E&ari=2&dbv=2&drs=1&pcs=902x620&pss=1215x620&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562914334&rw=635&ltu=http%3A%2F%2Fwww.hebnews.cn%2F&ecd=1&uc=1855x1056&pis=-1x-1&sr=1920x1080&tcn=1562914335&exps=110011:1:1

[1:1:0712/145221.223336:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hebnews.cn/", 500
[1:1:0712/145221.223540:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 994
[1:1:0712/145221.223657:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 994 0x7fca8cc99070 0x2b6f4d45c660 , 5:3_http://www.hebnews.cn/, 3, -5:3_http://www.hebnews.cn/-5:6_http://www.hebnews.cn/-5:3_http://www.hebnews.cn/, 930
[1:1:0712/145221.225148:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hebnews.cn/", 50
[1:1:0712/145221.225408:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 995
[1:1:0712/145221.225597:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 995 0x7fca8cc99070 0x2b6f4d45cf60 , 5:3_http://www.hebnews.cn/, 3, -5:3_http://www.hebnews.cn/-5:6_http://www.hebnews.cn/-5:3_http://www.hebnews.cn/, 930
[1:1:0712/145221.246382:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 930, "http://www.hebnews.cn/"
[1:1:0712/145221.417073:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3c17ca4629c8, 0x2b6f4c06d998
[1:1:0712/145221.417230:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hebnews.cn/", 0
[1:1:0712/145221.417419:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hebnews.cn/, 1005
[1:1:0712/145221.417542:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1005 0x7fca8cc99070 0x2b6f4d4a1de0 , 5:3_http://www.hebnews.cn/, 3, -5:3_http://www.hebnews.cn/-5:6_http://www.hebnews.cn/-5:3_http://www.hebnews.cn/, 930
[1:1:0712/145221.441899:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hebnews.cn/", 50
[1:1:0712/145221.442119:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1006
[1:1:0712/145221.442229:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1006 0x7fca8cc99070 0x2b6f4d54db60 , 5:3_http://www.hebnews.cn/, 3, -5:3_http://www.hebnews.cn/-5:6_http://www.hebnews.cn/-5:3_http://www.hebnews.cn/, 930
[1:1:0712/145221.453881:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 930, "http://www.hebnews.cn/"
[8383:8383:0712/145221.491243:INFO:CONSOLE(3)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://pos.baidu.com/dctm?psi=44d19a27fc5a70d4026dd3c3226e0505&di=5854320&dri=0&dis=0&dai=0&ps=289x795&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562914334076&ti=%E6%B2%B3%E5%8C%97%E6%96%B0%E9%97%BB%E7%BD%91_%E6%B2%B3%E5%8C%97%E6%9C%80%E5%A4%A7%E7%9A%84%E7%BD%91%E7%BB%9C%E5%AA%92%E4%BD%93_%E6%B2%B3%E5%8C%97%E7%AC%AC%E4%B8%80%E6%96%B0%E9%97%BB%E9%97%A8%E6%88%B7%E7%BD%91%E7%AB%99_%E6%B2%B3%E5%8C%97%E6%97%A5%E6%8A%A5%E6%8A%A5%E4%B8%9A%E9%9B%86%E5%9B%A2%E4%B8%BB%E5%8A%9E&ari=2&dbv=2&drs=1&pcs=902x666&pss=1215x666&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562914341&rw=681&ltu=http%3A%2F%2Fwww.hebnews.cn%2F&ecd=1&uc=1855x1056&pis=-1x-1&sr=1920x1080&tcn=1562914341&exps=110011, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://dup.baidustatic.com/js/ds.js (3)
[8383:8383:0712/145221.496678:INFO:CONSOLE(3)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://pos.baidu.com/dctm?psi=44d19a27fc5a70d4026dd3c3226e0505&di=5854320&dri=0&dis=0&dai=0&ps=289x795&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562914334076&ti=%E6%B2%B3%E5%8C%97%E6%96%B0%E9%97%BB%E7%BD%91_%E6%B2%B3%E5%8C%97%E6%9C%80%E5%A4%A7%E7%9A%84%E7%BD%91%E7%BB%9C%E5%AA%92%E4%BD%93_%E6%B2%B3%E5%8C%97%E7%AC%AC%E4%B8%80%E6%96%B0%E9%97%BB%E9%97%A8%E6%88%B7%E7%BD%91%E7%AB%99_%E6%B2%B3%E5%8C%97%E6%97%A5%E6%8A%A5%E6%8A%A5%E4%B8%9A%E9%9B%86%E5%9B%A2%E4%B8%BB%E5%8A%9E&ari=2&dbv=2&drs=1&pcs=902x666&pss=1215x666&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562914341&rw=681&ltu=http%3A%2F%2Fwww.hebnews.cn%2F&ecd=1&uc=1855x1056&pis=-1x-1&sr=1920x1080&tcn=1562914341&exps=110011, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://dup.baidustatic.com/js/ds.js (3)
[1:1:0712/145221.820176:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 947 0x7fcaa3324080 0x2b6f4d3db380 1 0 0x2b6f4d3db398 , "http://tianqi.2345.com/plugin/widget/index.htm?s=3&z=3&t=0&v=0&d=2&bd=0&k=&f=&q=1&e=1&a=1&c=53698&w=180&h=36&align=left"
[1:1:0712/145221.822979:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://tianqi.2345.com/, 144296588e58, , , var prov=new Array();
prov[12] = '12-B 北京-12';
prov[37] = '37-T 天津-37';
prov[34] = '34-S 上
[1:1:0712/145221.823182:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tianqi.2345.com/plugin/widget/index.htm?s=3&z=3&t=0&v=0&d=2&bd=0&k=&f=&q=1&e=1&a=1&c=53698&w=180&h=36&align=left", "tianqi.2345.com", 4, 1, http://www.hebnews.cn, www.hebnews.cn, 3
[1:1:0712/145221.857921:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , document.readyState
[1:1:0712/145221.858088:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145222.786842:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1027, "http://www.hebnews.cn/"
[1:1:0712/145222.787567:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , ___adblockplus({"queryid" : "82b6327ef9852425","tuid" : "5854320_0","placement" : {"basic" : {"sspId
[1:1:0712/145222.787699:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145222.798479:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[8383:8383:0712/145222.799702:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/145222.800668:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 7, 0x2b6f4cc31420
[1:1:0712/145222.800811:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 7
[8383:8383:0712/145222.801953:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: iframe5854320_0, 7, 7, 
[8383:8383:0712/145222.816981:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:7_http://www.hebnews.cn/, http://www.hebnews.cn/, 7
[8383:8383:0712/145222.817089:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 7, 7, http://www.hebnews.cn/, http://www.hebnews.cn
[1:1:0712/145222.819000:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.hebnews.cn/"
[1:1:0712/145222.838464:INFO:switcher_impl.cc(1369)] 			updated frame chain. [WARN] subject_frame does not exist in protected memory. [subject_frame, principals, url] = 14429654c330, 5:3_http://www.hebnews.cn/, 5:7_http://www.hebnews.cn/, about:blank
[1:1:0712/145222.838658:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:3_http://www.hebnews.cn/-5:7_http://www.hebnews.cn/, 14429654c330, 144296482860, open, 
[1:1:0712/145222.838807:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "www.hebnews.cn", 7, 2, http://www.hebnews.cn, www.hebnews.cn, 3
[1:1:0712/145222.839683:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.renderFrame (http://dup.baidustatic.com/js/ds.js:1:1)
	http://dup.baidustatic.com/js/ds.js:1:1
	HTMLIFrameElement.onload (http://www.hebnews.cn/:498:10)
	Object.render (http://dup.baidustatic.com/js/ds.js:1:1)
	Object.painterLoadedCallback (http://dup.baidustatic.com/js/ds.js:1:1)
	Object.callback (http://dup.baidustatic.com/js/ds.js:1:1)
	http://dup.baidustatic.com/js/ds.js:1:1
	http://pos.baidu.com/dctm?psi=44d19a27fc5a70d4026dd3c3226e0505&di=5854320&dri=0&dis=0&dai=0&ps=289x795&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562914334076&ti=%E6%B2%B3%E5%8C%97%E6%96%B0%E9%97%BB%E7%BD%91_%E6%B2%B3%E5%8C%97%E6%9C%80%E5%A4%A7%E7%9A%84%E7%BD%91%E7%BB%9C%E5%AA%92%E4%BD%93_%E6%B2%B3%E5%8C%97%E7%AC%AC%E4%B8%80%E6%96%B0%E9%97%BB%E9%97%A8%E6%88%B7%E7%BD%91%E7%AB%99_%E6%B2%B3%E5%8C%97%E6%97%A5%E6%8A%A5%E6%8A%A5%E4%B8%9A%E9%9B%86%E5%9B%A2%E4%B8%BB%E5%8A%9E&ari=2&dbv=2&drs=1&pcs=902x666&pss=1215x666&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562914341&rw=681&ltu=http%3A%2F%2Fwww.hebnews.cn%2F&ecd=1&uc=1855x1056&pis=-1x-1&sr=1920x1080&tcn=1562914341&exps=110011:1:1

[1:1:0712/145222.842250:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1027, "http://www.hebnews.cn/"
[1:1:0712/145222.846074:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hebnews.cn/", 5000
[1:1:0712/145222.846351:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1098
[1:1:0712/145222.846487:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1098 0x7fca8cc99070 0x2b6f4cfde2e0 , 5:3_http://www.hebnews.cn/, 2, -5:3_http://www.hebnews.cn/-5:7_http://www.hebnews.cn/, 1027
[1:1:0712/145222.848703:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:3_http://www.hebnews.cn/-5:7_http://www.hebnews.cn/-5:3_http://www.hebnews.cn/, 144296482860, 14429654c330, regisetViewWatch, (t){this.isEventInited||(this.initializeEvent(),this.isEventInited=!0),this.watchingList=this.watchi
[1:1:0712/145222.848866:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 3, , , 0
[1:1:0712/145222.849245:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.render (http://dup.baidustatic.com/js/ds.js:1:1)
	Object.painterLoadedCallback (http://dup.baidustatic.com/js/ds.js:1:1)
	Object.callback (http://dup.baidustatic.com/js/ds.js:1:1)
	http://dup.baidustatic.com/js/ds.js:1:1
	http://pos.baidu.com/dctm?psi=44d19a27fc5a70d4026dd3c3226e0505&di=5854320&dri=0&dis=0&dai=0&ps=289x795&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562914334076&ti=%E6%B2%B3%E5%8C%97%E6%96%B0%E9%97%BB%E7%BD%91_%E6%B2%B3%E5%8C%97%E6%9C%80%E5%A4%A7%E7%9A%84%E7%BD%91%E7%BB%9C%E5%AA%92%E4%BD%93_%E6%B2%B3%E5%8C%97%E7%AC%AC%E4%B8%80%E6%96%B0%E9%97%BB%E9%97%A8%E6%88%B7%E7%BD%91%E7%AB%99_%E6%B2%B3%E5%8C%97%E6%97%A5%E6%8A%A5%E6%8A%A5%E4%B8%9A%E9%9B%86%E5%9B%A2%E4%B8%BB%E5%8A%9E&ari=2&dbv=2&drs=1&pcs=902x666&pss=1215x666&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562914341&rw=681&ltu=http%3A%2F%2Fwww.hebnews.cn%2F&ecd=1&uc=1855x1056&pis=-1x-1&sr=1920x1080&tcn=1562914341&exps=110011:1:1

[1:1:0712/145222.881183:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0154798, 166, 1
[1:1:0712/145222.881380:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/145222.883759:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 995, 7fca8f5de8db
[1:1:0712/145222.905552:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1442964828601442965796c0144296482860","ptid":"930","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145222.905767:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hebnews.cn/-5:6_http://www.hebnews.cn/-5:3_http://www.hebnews.cn/","ptid":"930","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145222.906055:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1124
[1:1:0712/145222.906217:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1124 0x7fca8cc99070 0x2b6f4cfa35e0 , 5:3_http://www.hebnews.cn/, 0, , 995 0x7fca8cc99070 0x2b6f4d45cf60 
[1:1:0712/145222.906453:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145222.906728:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/145222.906821:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145222.926036:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hebnews.cn/, 1005, 7fca8f5de881
[1:1:0712/145222.943912:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1442964828601442965796c0144296482860","ptid":"930","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145222.944085:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hebnews.cn/-5:6_http://www.hebnews.cn/-5:3_http://www.hebnews.cn/","ptid":"930","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145222.944279:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145222.944538:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , (){qn=t}
[1:1:0712/145222.944624:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145222.945204:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1006, 7fca8f5de8db
[1:1:0712/145222.961826:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1442964828601442965796c0144296482860","ptid":"930","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145222.962063:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hebnews.cn/-5:6_http://www.hebnews.cn/-5:3_http://www.hebnews.cn/","ptid":"930","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145222.962367:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1126
[1:1:0712/145222.962483:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1126 0x7fca8cc99070 0x2b6f4cc60360 , 5:3_http://www.hebnews.cn/, 0, , 1006 0x7fca8cc99070 0x2b6f4d54db60 
[1:1:0712/145222.962661:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145222.963038:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , ab, (a){if(!A||M!=p||a||R){if(R?p>=1?p=1:0>=p&&(p=0):(O=p,p>=k?p=0:0>p&&(p=k-1)),S(),null!=n&&_(l.childr
[1:1:0712/145222.963182:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145223.105197:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3c17ca4629c8, 0x2b6f4c06d950
[1:1:0712/145223.105347:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hebnews.cn/", 0
[1:1:0712/145223.105549:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hebnews.cn/, 1130
[1:1:0712/145223.105651:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1130 0x7fca8cc99070 0x2b6f4d0cc3e0 , 5:3_http://www.hebnews.cn/, 1, -5:3_http://www.hebnews.cn/, 1006 0x7fca8cc99070 0x2b6f4d54db60 
[1:1:0712/145223.228482:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 994, 7fca8f5de8db
[1:1:0712/145223.246508:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1442964828601442965796c0144296482860","ptid":"930","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145223.246720:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hebnews.cn/-5:6_http://www.hebnews.cn/-5:3_http://www.hebnews.cn/","ptid":"930","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145223.246983:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1137
[1:1:0712/145223.247277:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1137 0x7fca8cc99070 0x2b6f4d681b60 , 5:3_http://www.hebnews.cn/, 0, , 994 0x7fca8cc99070 0x2b6f4d45c660 
[1:1:0712/145223.247459:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145223.247726:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/145223.247866:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145223.490596:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , document.readyState
[1:1:0712/145223.490755:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145224.765595:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/145224.765803:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.hebnews.cn/"
[1:1:0712/145224.766415:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1118 0x7fca8cc99070 0x2b6f4d683a60 , "http://www.hebnews.cn/"
[1:1:0712/145224.767008:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , jQuery(".activityBox").slide({ mainCell:".contentInner ul", effect:"top",delayTime:400});
[1:1:0712/145224.767134:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145224.847562:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hebnews.cn/", 13
[1:1:0712/145224.847792:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1181
[1:1:0712/145224.847899:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1181 0x7fca8cc99070 0x2b6f4d549be0 , 5:3_http://www.hebnews.cn/, 1, -5:3_http://www.hebnews.cn/, 1118 0x7fca8cc99070 0x2b6f4d683a60 
[1:1:0712/145224.865509:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.099633, 55, 1
[1:1:0712/145224.865672:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/145224.982358:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1124, 7fca8f5de8db
[1:1:0712/145225.000460:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"995 0x7fca8cc99070 0x2b6f4d45cf60 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145225.000596:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"995 0x7fca8cc99070 0x2b6f4d45cf60 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145225.000790:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1194
[1:1:0712/145225.000881:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1194 0x7fca8cc99070 0x2b6f4d7bf960 , 5:3_http://www.hebnews.cn/, 0, , 1124 0x7fca8cc99070 0x2b6f4cfa35e0 
[1:1:0712/145225.001021:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145225.001311:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/145225.001427:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145225.078875:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1126, 7fca8f5de8db
[1:1:0712/145225.098547:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1006 0x7fca8cc99070 0x2b6f4d54db60 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145225.098726:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1006 0x7fca8cc99070 0x2b6f4d54db60 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145225.098975:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1196
[1:1:0712/145225.099109:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1196 0x7fca8cc99070 0x2b6f4cc60060 , 5:3_http://www.hebnews.cn/, 0, , 1126 0x7fca8cc99070 0x2b6f4cc60360 
[1:1:0712/145225.099314:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145225.099615:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , ab, (a){if(!A||M!=p||a||R){if(R?p>=1?p=1:0>=p&&(p=0):(O=p,p>=k?p=0:0>p&&(p=k-1)),S(),null!=n&&_(l.childr
[1:1:0712/145225.099731:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145225.176589:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hebnews.cn/, 1130, 7fca8f5de881
[1:1:0712/145225.195329:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"144296482860","ptid":"1006 0x7fca8cc99070 0x2b6f4d54db60 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145225.195514:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hebnews.cn/","ptid":"1006 0x7fca8cc99070 0x2b6f4d54db60 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145225.195742:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145225.196030:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , (){qn=t}
[1:1:0712/145225.196154:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145225.367813:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , document.readyState
[1:1:0712/145225.368127:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145225.463595:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1137, 7fca8f5de8db
[1:1:0712/145225.481316:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"994 0x7fca8cc99070 0x2b6f4d45c660 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145225.481535:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"994 0x7fca8cc99070 0x2b6f4d45c660 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145225.481819:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1212
[1:1:0712/145225.481970:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1212 0x7fca8cc99070 0x2b6f4d40a5e0 , 5:3_http://www.hebnews.cn/, 0, , 1137 0x7fca8cc99070 0x2b6f4d681b60 
[1:1:0712/145225.482176:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145225.485353:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/145225.485458:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145226.216286:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/145226.216425:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.hebnews.cn/"
[1:1:0712/145226.217925:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1189 0x7fca8cc99070 0x2b6f4d4960e0 , "http://www.hebnews.cn/"
[1:1:0712/145226.218792:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , (function($) {
    $.fn.extend({
        yx_rotaion: function(options) {
            var defaults
[1:1:0712/145226.218904:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145226.221333:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1189 0x7fca8cc99070 0x2b6f4d4960e0 , "http://www.hebnews.cn/"
[1:1:0712/145226.274003:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hebnews.cn/", 3000
[1:1:0712/145226.274294:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1239
[1:1:0712/145226.274431:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1239 0x7fca8cc99070 0x2b6f4d6b02e0 , 5:3_http://www.hebnews.cn/, 1, -5:3_http://www.hebnews.cn/, 1189 0x7fca8cc99070 0x2b6f4d4960e0 
[1:1:0712/145226.359527:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.143046, 98, 1
[1:1:0712/145226.359681:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/145226.417992:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1181, 7fca8f5de8db
[1:1:0712/145226.436016:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"144296482860","ptid":"1118 0x7fca8cc99070 0x2b6f4d683a60 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145226.436216:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hebnews.cn/","ptid":"1118 0x7fca8cc99070 0x2b6f4d683a60 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145226.436481:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1251
[1:1:0712/145226.436937:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1251 0x7fca8cc99070 0x2b6f4d54a160 , 5:3_http://www.hebnews.cn/, 0, , 1181 0x7fca8cc99070 0x2b6f4d549be0 
[1:1:0712/145226.437164:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145226.437494:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , v.fx.tick, (){var e,n=v.timers,r=0;qn=v.now();for(;r<n.length;r++)e=n[r],!e()&&n[r]===e&&n.splice(r--,1);n.leng
[1:1:0712/145226.437605:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145226.461955:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1194, 7fca8f5de8db
[1:1:0712/145226.481815:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1124 0x7fca8cc99070 0x2b6f4cfa35e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145226.481994:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1124 0x7fca8cc99070 0x2b6f4cfa35e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145226.482218:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1252
[1:1:0712/145226.482332:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1252 0x7fca8cc99070 0x2b6f4caa6ce0 , 5:3_http://www.hebnews.cn/, 0, , 1194 0x7fca8cc99070 0x2b6f4d7bf960 
[1:1:0712/145226.482503:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145226.482768:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/145226.482887:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145226.483671:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1196, 7fca8f5de8db
[1:1:0712/145226.501939:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1126 0x7fca8cc99070 0x2b6f4cc60360 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145226.502094:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1126 0x7fca8cc99070 0x2b6f4cc60360 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145226.502312:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1254
[1:1:0712/145226.502418:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1254 0x7fca8cc99070 0x2b6f4c871fe0 , 5:3_http://www.hebnews.cn/, 0, , 1196 0x7fca8cc99070 0x2b6f4cc60060 
[1:1:0712/145226.502582:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145226.502857:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , ab, (a){if(!A||M!=p||a||R){if(R?p>=1?p=1:0>=p&&(p=0):(O=p,p>=k?p=0:0>p&&(p=k-1)),S(),null!=n&&_(l.childr
[1:1:0712/145226.502953:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145226.592719:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3c17ca4629c8, 0x2b6f4c06d950
[1:1:0712/145226.592889:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hebnews.cn/", 0
[1:1:0712/145226.593098:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hebnews.cn/, 1257
[1:1:0712/145226.593244:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1257 0x7fca8cc99070 0x2b6f4dcae060 , 5:3_http://www.hebnews.cn/, 1, -5:3_http://www.hebnews.cn/, 1196 0x7fca8cc99070 0x2b6f4cc60060 
[1:1:0712/145226.772836:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , document.readyState
[1:1:0712/145226.772998:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145226.957693:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1212, 7fca8f5de8db
[1:1:0712/145226.979990:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1137 0x7fca8cc99070 0x2b6f4d681b60 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145226.980194:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1137 0x7fca8cc99070 0x2b6f4d681b60 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145226.980440:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1282
[1:1:0712/145226.980552:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1282 0x7fca8cc99070 0x2b6f4dce8ee0 , 5:3_http://www.hebnews.cn/, 0, , 1212 0x7fca8cc99070 0x2b6f4d40a5e0 
[1:1:0712/145226.980720:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145226.980965:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/145226.981086:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145227.639183:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/145227.639321:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.hebnews.cn/"
[1:1:0712/145227.639898:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1245 0x7fca8cc99070 0x2b6f4cd129e0 , "http://www.hebnews.cn/"
[1:1:0712/145227.640502:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , 
			/*
				多行/多列的滚动解决思路在于：把每次滚动的n个li放到1个ul里面，�
[1:1:0712/145227.640633:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145227.734998:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hebnews.cn/", 13
[1:1:0712/145227.735225:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1306
[1:1:0712/145227.735334:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1306 0x7fca8cc99070 0x2b6f4d7f64e0 , 5:3_http://www.hebnews.cn/, 1, -5:3_http://www.hebnews.cn/, 1245 0x7fca8cc99070 0x2b6f4cd129e0 
[1:1:0712/145227.742297:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hebnews.cn/", 5000
[1:1:0712/145227.742461:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1307
[1:1:0712/145227.742569:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1307 0x7fca8cc99070 0x2b6f4cfe5960 , 5:3_http://www.hebnews.cn/, 1, -5:3_http://www.hebnews.cn/, 1245 0x7fca8cc99070 0x2b6f4cd129e0 
[1:1:0712/145227.769556:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.130174, 246, 1
[1:1:0712/145227.769706:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/145227.770357:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 991, 7fca8f5de8db
[1:1:0712/145227.792704:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1442964828601442965796c0","ptid":"930","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145227.792889:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hebnews.cn/-5:6_http://www.hebnews.cn/","ptid":"930","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145227.793166:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1321
[1:1:0712/145227.793276:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1321 0x7fca8cc99070 0x2b6f4c8e11e0 , 5:3_http://www.hebnews.cn/, 0, , 991 0x7fca8cc99070 0x2b6f4d425a60 
[1:1:0712/145227.793448:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145227.793705:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:6_http://www.hebnews.cn/, 1442965796c0, , , () { roll(); }
[1:1:0712/145227.793828:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 6, 1, http://www.hebnews.cn, www.hebnews.cn, 3
[1:1:0712/145227.989874:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1252, 7fca8f5de8db
[1:1:0712/145228.011751:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1194 0x7fca8cc99070 0x2b6f4d7bf960 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145228.011914:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1194 0x7fca8cc99070 0x2b6f4d7bf960 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145228.012203:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1325
[1:1:0712/145228.012303:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1325 0x7fca8cc99070 0x2b6f4d49c9e0 , 5:3_http://www.hebnews.cn/, 0, , 1252 0x7fca8cc99070 0x2b6f4caa6ce0 
[1:1:0712/145228.012496:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145228.012765:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/145228.013783:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145228.014532:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1254, 7fca8f5de8db
[1:1:0712/145228.035784:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1196 0x7fca8cc99070 0x2b6f4cc60060 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145228.035949:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1196 0x7fca8cc99070 0x2b6f4cc60060 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145228.036163:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1326
[1:1:0712/145228.036258:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1326 0x7fca8cc99070 0x2b6f4dd42ae0 , 5:3_http://www.hebnews.cn/, 0, , 1254 0x7fca8cc99070 0x2b6f4c871fe0 
[1:1:0712/145228.036422:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145228.036709:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , ab, (a){if(!A||M!=p||a||R){if(R?p>=1?p=1:0>=p&&(p=0):(O=p,p>=k?p=0:0>p&&(p=k-1)),S(),null!=n&&_(l.childr
[1:1:0712/145228.036805:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145228.260152:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hebnews.cn/, 1257, 7fca8f5de881
[1:1:0712/145228.281569:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"144296482860","ptid":"1196 0x7fca8cc99070 0x2b6f4cc60060 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145228.281757:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hebnews.cn/","ptid":"1196 0x7fca8cc99070 0x2b6f4cc60060 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145228.281967:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145228.282220:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , (){qn=t}
[1:1:0712/145228.282305:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145228.491878:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , document.readyState
[1:1:0712/145228.492059:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145228.789185:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1282, 7fca8f5de8db
[1:1:0712/145228.811298:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1212 0x7fca8cc99070 0x2b6f4d40a5e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145228.811509:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1212 0x7fca8cc99070 0x2b6f4d40a5e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145228.811787:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1351
[1:1:0712/145228.811994:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1351 0x7fca8cc99070 0x2b6f4d800e60 , 5:3_http://www.hebnews.cn/, 0, , 1282 0x7fca8cc99070 0x2b6f4dce8ee0 
[1:1:0712/145228.812236:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145228.812510:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/145228.812624:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145229.527355:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/145229.527525:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.hebnews.cn/"
[1:1:0712/145229.528129:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1317 0x7fca8cc99070 0x2b6f4d849560 , "http://www.hebnews.cn/"
[1:1:0712/145229.528848:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , 
			function g(o){return document.getElementById(o);}
			function HoverLi31(n){
			for(var i=31;i<=3
[1:1:0712/145229.528992:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145229.530248:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1317 0x7fca8cc99070 0x2b6f4d849560 , "http://www.hebnews.cn/"
[8383:8383:0712/145229.569267:INFO:CONSOLE(3)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://pos.baidu.com/dctm?psi=44d19a27fc5a70d4026dd3c3226e0505&di=3229894&dri=0&dis=0&dai=0&ps=1878x0&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562914334076&ti=%E6%B2%B3%E5%8C%97%E6%96%B0%E9%97%BB%E7%BD%91_%E6%B2%B3%E5%8C%97%E6%9C%80%E5%A4%A7%E7%9A%84%E7%BD%91%E7%BB%9C%E5%AA%92%E4%BD%93_%E6%B2%B3%E5%8C%97%E7%AC%AC%E4%B8%80%E6%96%B0%E9%97%BB%E9%97%A8%E6%88%B7%E7%BD%91%E7%AB%99_%E6%B2%B3%E5%8C%97%E6%97%A5%E6%8A%A5%E6%8A%A5%E4%B8%9A%E9%9B%86%E5%9B%A2%E4%B8%BB%E5%8A%9E&ari=2&dbv=2&drs=1&pcs=887x666&pss=1215x1983&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562914349&rw=681&ltu=http%3A%2F%2Fwww.hebnews.cn%2F&ecd=1&uc=1855x1056&pis=-1x-1&sr=1920x1080&tcn=1562914350&exps=110011, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://dup.baidustatic.com/js/ds.js (3)
[1:1:0712/145229.572499:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1306, 7fca8f5de8db
[8383:8383:0712/145229.574523:INFO:CONSOLE(3)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://pos.baidu.com/dctm?psi=44d19a27fc5a70d4026dd3c3226e0505&di=3229894&dri=0&dis=0&dai=0&ps=1878x0&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562914334076&ti=%E6%B2%B3%E5%8C%97%E6%96%B0%E9%97%BB%E7%BD%91_%E6%B2%B3%E5%8C%97%E6%9C%80%E5%A4%A7%E7%9A%84%E7%BD%91%E7%BB%9C%E5%AA%92%E4%BD%93_%E6%B2%B3%E5%8C%97%E7%AC%AC%E4%B8%80%E6%96%B0%E9%97%BB%E9%97%A8%E6%88%B7%E7%BD%91%E7%AB%99_%E6%B2%B3%E5%8C%97%E6%97%A5%E6%8A%A5%E6%8A%A5%E4%B8%9A%E9%9B%86%E5%9B%A2%E4%B8%BB%E5%8A%9E&ari=2&dbv=2&drs=1&pcs=887x666&pss=1215x1983&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562914349&rw=681&ltu=http%3A%2F%2Fwww.hebnews.cn%2F&ecd=1&uc=1855x1056&pis=-1x-1&sr=1920x1080&tcn=1562914350&exps=110011, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://dup.baidustatic.com/js/ds.js (3)
[1:1:0712/145229.597323:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"144296482860","ptid":"1245 0x7fca8cc99070 0x2b6f4cd129e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145229.597527:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hebnews.cn/","ptid":"1245 0x7fca8cc99070 0x2b6f4cd129e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145229.597801:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1401
[1:1:0712/145229.597952:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1401 0x7fca8cc99070 0x2b6f4dd42b60 , 5:3_http://www.hebnews.cn/, 0, , 1306 0x7fca8cc99070 0x2b6f4d7f64e0 
[1:1:0712/145229.598252:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145229.598616:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , v.fx.tick, (){var e,n=v.timers,r=0;qn=v.now();for(;r<n.length;r++)e=n[r],!e()&&n[r]===e&&n.splice(r--,1);n.leng
[1:1:0712/145229.598811:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145229.627098:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1098, 7fca8f5de8db
[1:1:0712/145229.648634:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"14429648286014429654c330","ptid":"1027","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145229.649073:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hebnews.cn/-5:7_http://www.hebnews.cn/","ptid":"1027","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145229.649367:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1402
[1:1:0712/145229.649483:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1402 0x7fca8cc99070 0x2b6f4de2dbe0 , 5:3_http://www.hebnews.cn/, 0, , 1098 0x7fca8cc99070 0x2b6f4cfde2e0 
[1:1:0712/145229.649671:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145229.649993:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:7_http://www.hebnews.cn/, 14429654c330, , , () { roll(); }
[1:1:0712/145229.650162:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 7, 1, http://www.hebnews.cn, www.hebnews.cn, 3
[1:1:0712/145229.747828:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1325, 7fca8f5de8db
[1:1:0712/145229.773326:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1252 0x7fca8cc99070 0x2b6f4caa6ce0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145229.773520:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1252 0x7fca8cc99070 0x2b6f4caa6ce0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145229.773905:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1411
[1:1:0712/145229.774216:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1411 0x7fca8cc99070 0x2b6f4dfb5fe0 , 5:3_http://www.hebnews.cn/, 0, , 1325 0x7fca8cc99070 0x2b6f4d49c9e0 
[1:1:0712/145229.774396:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145229.774704:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/145229.774818:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145229.800267:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1326, 7fca8f5de8db
[1:1:0712/145229.822621:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1254 0x7fca8cc99070 0x2b6f4c871fe0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145229.822803:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1254 0x7fca8cc99070 0x2b6f4c871fe0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145229.823059:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1413
[1:1:0712/145229.823197:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1413 0x7fca8cc99070 0x2b6f4c8ce560 , 5:3_http://www.hebnews.cn/, 0, , 1326 0x7fca8cc99070 0x2b6f4dd42ae0 
[1:1:0712/145229.823429:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145229.823772:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , ab, (a){if(!A||M!=p||a||R){if(R?p>=1?p=1:0>=p&&(p=0):(O=p,p>=k?p=0:0>p&&(p=k-1)),S(),null!=n&&_(l.childr
[1:1:0712/145229.823886:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145229.837297:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3c17ca4629c8, 0x2b6f4c06d950
[1:1:0712/145229.837442:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hebnews.cn/", 0
[1:1:0712/145229.837613:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hebnews.cn/, 1414
[1:1:0712/145229.837722:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1414 0x7fca8cc99070 0x2b6f4d458ae0 , 5:3_http://www.hebnews.cn/, 1, -5:3_http://www.hebnews.cn/, 1326 0x7fca8cc99070 0x2b6f4dd42ae0 
[1:1:0712/145230.089744:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , document.readyState
[1:1:0712/145230.089926:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145230.558209:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1351, 7fca8f5de8db
[1:1:0712/145230.581547:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1282 0x7fca8cc99070 0x2b6f4dce8ee0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145230.581708:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1282 0x7fca8cc99070 0x2b6f4dce8ee0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145230.581930:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1439
[1:1:0712/145230.582037:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1439 0x7fca8cc99070 0x2b6f4df58fe0 , 5:3_http://www.hebnews.cn/, 0, , 1351 0x7fca8cc99070 0x2b6f4d800e60 
[1:1:0712/145230.582209:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145230.582467:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/145230.582575:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145230.965385:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1239, 7fca8f5de8db
[1:1:0712/145230.988256:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"144296482860","ptid":"1189 0x7fca8cc99070 0x2b6f4d4960e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145230.988424:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hebnews.cn/","ptid":"1189 0x7fca8cc99070 0x2b6f4d4960e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145230.988644:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1454
[1:1:0712/145230.988731:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1454 0x7fca8cc99070 0x2b6f4dd1d860 , 5:3_http://www.hebnews.cn/, 0, , 1239 0x7fca8cc99070 0x2b6f4d6b02e0 
[1:1:0712/145230.988883:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145230.989130:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , () {
                    $btn.last().click()
                }
[1:1:0712/145230.989236:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145231.018667:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hebnews.cn/", 13
[1:1:0712/145231.018886:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1455
[1:1:0712/145231.019001:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1455 0x7fca8cc99070 0x2b6f4dcae960 , 5:3_http://www.hebnews.cn/, 1, -5:3_http://www.hebnews.cn/, 1239 0x7fca8cc99070 0x2b6f4d6b02e0 
[1:1:0712/145231.108042:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "click", "http://www.hebnews.cn/"
[1:1:0712/145231.898400:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1403, "http://www.hebnews.cn/"
[1:1:0712/145231.899170:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , ___adblockplus({"queryid" : "3f9681d24d98e470","tuid" : "3229894_0","placement" : {"basic" : {"sspId
[1:1:0712/145231.899311:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145231.910042:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[8383:8383:0712/145231.911377:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/145231.912514:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 8, 0x2b6f4de62820
[1:1:0712/145231.912661:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 8
[8383:8383:0712/145231.914967:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: iframe3229894_0, 8, 8, 
[8383:8383:0712/145231.927962:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:8_http://www.hebnews.cn/, http://www.hebnews.cn/, 8
[8383:8383:0712/145231.928046:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 8, 8, http://www.hebnews.cn/, http://www.hebnews.cn
[1:1:0712/145231.930809:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.hebnews.cn/"
[1:1:0712/145231.950903:INFO:switcher_impl.cc(1369)] 			updated frame chain. [WARN] subject_frame does not exist in protected memory. [subject_frame, principals, url] = 144296532210, 5:3_http://www.hebnews.cn/, 5:8_http://www.hebnews.cn/, about:blank
[1:1:0712/145231.951069:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:3_http://www.hebnews.cn/-5:8_http://www.hebnews.cn/, 144296532210, 144296482860, open, 
[1:1:0712/145231.951204:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "www.hebnews.cn", 8, 2, http://www.hebnews.cn, www.hebnews.cn, 3
[1:1:0712/145231.952090:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.renderFrame (http://dup.baidustatic.com/js/ds.js:1:1)
	http://dup.baidustatic.com/js/ds.js:1:1
	HTMLIFrameElement.onload (http://www.hebnews.cn/:727:10)
	Object.render (http://dup.baidustatic.com/js/ds.js:1:1)
	Object.painterLoadedCallback (http://dup.baidustatic.com/js/ds.js:1:1)
	Object.callback (http://dup.baidustatic.com/js/ds.js:1:1)
	http://dup.baidustatic.com/js/ds.js:1:1
	http://pos.baidu.com/dctm?psi=44d19a27fc5a70d4026dd3c3226e0505&di=3229894&dri=0&dis=0&dai=0&ps=1878x0&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562914334076&ti=%E6%B2%B3%E5%8C%97%E6%96%B0%E9%97%BB%E7%BD%91_%E6%B2%B3%E5%8C%97%E6%9C%80%E5%A4%A7%E7%9A%84%E7%BD%91%E7%BB%9C%E5%AA%92%E4%BD%93_%E6%B2%B3%E5%8C%97%E7%AC%AC%E4%B8%80%E6%96%B0%E9%97%BB%E9%97%A8%E6%88%B7%E7%BD%91%E7%AB%99_%E6%B2%B3%E5%8C%97%E6%97%A5%E6%8A%A5%E6%8A%A5%E4%B8%9A%E9%9B%86%E5%9B%A2%E4%B8%BB%E5%8A%9E&ari=2&dbv=2&drs=1&pcs=887x666&pss=1215x1983&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562914349&rw=681&ltu=http%3A%2F%2Fwww.hebnews.cn%2F&ecd=1&uc=1855x1056&pis=-1x-1&sr=1920x1080&tcn=1562914350&exps=110011:1:1

[1:1:0712/145231.954515:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1403, "http://www.hebnews.cn/"
[1:1:0712/145231.958335:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hebnews.cn/", 5000
[1:1:0712/145231.958579:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1517
[1:1:0712/145231.958706:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1517 0x7fca8cc99070 0x2b6f4d5339e0 , 5:3_http://www.hebnews.cn/, 2, -5:3_http://www.hebnews.cn/-5:8_http://www.hebnews.cn/, 1403
[1:1:0712/145231.960969:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:3_http://www.hebnews.cn/-5:8_http://www.hebnews.cn/-5:3_http://www.hebnews.cn/, 144296482860, 144296532210, regisetViewWatch, (t){this.isEventInited||(this.initializeEvent(),this.isEventInited=!0),this.watchingList=this.watchi
[1:1:0712/145231.961142:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 3, , , 0
[1:1:0712/145231.961517:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.render (http://dup.baidustatic.com/js/ds.js:1:1)
	Object.painterLoadedCallback (http://dup.baidustatic.com/js/ds.js:1:1)
	Object.callback (http://dup.baidustatic.com/js/ds.js:1:1)
	http://dup.baidustatic.com/js/ds.js:1:1
	http://pos.baidu.com/dctm?psi=44d19a27fc5a70d4026dd3c3226e0505&di=3229894&dri=0&dis=0&dai=0&ps=1878x0&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562914334076&ti=%E6%B2%B3%E5%8C%97%E6%96%B0%E9%97%BB%E7%BD%91_%E6%B2%B3%E5%8C%97%E6%9C%80%E5%A4%A7%E7%9A%84%E7%BD%91%E7%BB%9C%E5%AA%92%E4%BD%93_%E6%B2%B3%E5%8C%97%E7%AC%AC%E4%B8%80%E6%96%B0%E9%97%BB%E9%97%A8%E6%88%B7%E7%BD%91%E7%AB%99_%E6%B2%B3%E5%8C%97%E6%97%A5%E6%8A%A5%E6%8A%A5%E4%B8%9A%E9%9B%86%E5%9B%A2%E4%B8%BB%E5%8A%9E&ari=2&dbv=2&drs=1&pcs=887x666&pss=1215x1983&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562914349&rw=681&ltu=http%3A%2F%2Fwww.hebnews.cn%2F&ecd=1&uc=1855x1056&pis=-1x-1&sr=1920x1080&tcn=1562914350&exps=110011:1:1

[1:1:0712/145231.980443:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1403, "http://www.hebnews.cn/"
[8383:8383:0712/145232.017310:INFO:CONSOLE(3)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://pos.baidu.com/dctm?psi=44d19a27fc5a70d4026dd3c3226e0505&di=3229899&dri=0&dis=0&dai=0&ps=1878x930&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562914334076&ti=%E6%B2%B3%E5%8C%97%E6%96%B0%E9%97%BB%E7%BD%91_%E6%B2%B3%E5%8C%97%E6%9C%80%E5%A4%A7%E7%9A%84%E7%BD%91%E7%BB%9C%E5%AA%92%E4%BD%93_%E6%B2%B3%E5%8C%97%E7%AC%AC%E4%B8%80%E6%96%B0%E9%97%BB%E9%97%A8%E6%88%B7%E7%BD%91%E7%AB%99_%E6%B2%B3%E5%8C%97%E6%97%A5%E6%8A%A5%E6%8A%A5%E4%B8%9A%E9%9B%86%E5%9B%A2%E4%B8%BB%E5%8A%9E&ari=2&dbv=2&drs=1&pcs=887x666&pss=1215x1983&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562914352&rw=681&ltu=http%3A%2F%2Fwww.hebnews.cn%2F&ecd=1&uc=1855x1056&pis=-1x-1&sr=1920x1080&tcn=1562914352&exps=110011, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://dup.baidustatic.com/js/ds.js (3)
[8383:8383:0712/145232.022679:INFO:CONSOLE(3)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://pos.baidu.com/dctm?psi=44d19a27fc5a70d4026dd3c3226e0505&di=3229899&dri=0&dis=0&dai=0&ps=1878x930&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562914334076&ti=%E6%B2%B3%E5%8C%97%E6%96%B0%E9%97%BB%E7%BD%91_%E6%B2%B3%E5%8C%97%E6%9C%80%E5%A4%A7%E7%9A%84%E7%BD%91%E7%BB%9C%E5%AA%92%E4%BD%93_%E6%B2%B3%E5%8C%97%E7%AC%AC%E4%B8%80%E6%96%B0%E9%97%BB%E9%97%A8%E6%88%B7%E7%BD%91%E7%AB%99_%E6%B2%B3%E5%8C%97%E6%97%A5%E6%8A%A5%E6%8A%A5%E4%B8%9A%E9%9B%86%E5%9B%A2%E4%B8%BB%E5%8A%9E&ari=2&dbv=2&drs=1&pcs=887x666&pss=1215x1983&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562914352&rw=681&ltu=http%3A%2F%2Fwww.hebnews.cn%2F&ecd=1&uc=1855x1056&pis=-1x-1&sr=1920x1080&tcn=1562914352&exps=110011, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://dup.baidustatic.com/js/ds.js (3)
[1:1:0712/145232.226089:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1411, 7fca8f5de8db
[1:1:0712/145232.251353:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1325 0x7fca8cc99070 0x2b6f4d49c9e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145232.251534:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1325 0x7fca8cc99070 0x2b6f4d49c9e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145232.251777:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1540
[1:1:0712/145232.251879:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1540 0x7fca8cc99070 0x2b6f4d4b62e0 , 5:3_http://www.hebnews.cn/, 0, , 1411 0x7fca8cc99070 0x2b6f4dfb5fe0 
[1:1:0712/145232.252041:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145232.252299:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/145232.252386:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145232.253229:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hebnews.cn/, 1414, 7fca8f5de881
[1:1:0712/145232.279586:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"144296482860","ptid":"1326 0x7fca8cc99070 0x2b6f4dd42ae0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145232.279810:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hebnews.cn/","ptid":"1326 0x7fca8cc99070 0x2b6f4dd42ae0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145232.280063:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145232.280367:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , (){qn=t}
[1:1:0712/145232.280477:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145232.305900:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1413, 7fca8f5de8db
[1:1:0712/145232.330433:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1326 0x7fca8cc99070 0x2b6f4dd42ae0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145232.330628:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1326 0x7fca8cc99070 0x2b6f4dd42ae0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145232.330888:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1544
[1:1:0712/145232.331029:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1544 0x7fca8cc99070 0x2b6f4de32a60 , 5:3_http://www.hebnews.cn/, 0, , 1413 0x7fca8cc99070 0x2b6f4c8ce560 
[1:1:0712/145232.331233:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145232.331567:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , ab, (a){if(!A||M!=p||a||R){if(R?p>=1?p=1:0>=p&&(p=0):(O=p,p>=k?p=0:0>p&&(p=k-1)),S(),null!=n&&_(l.childr
[1:1:0712/145232.331691:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145232.345144:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3c17ca4629c8, 0x2b6f4c06d950
[1:1:0712/145232.345338:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hebnews.cn/", 0
[1:1:0712/145232.345525:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hebnews.cn/, 1545
[1:1:0712/145232.345638:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1545 0x7fca8cc99070 0x2b6f4e491260 , 5:3_http://www.hebnews.cn/, 1, -5:3_http://www.hebnews.cn/, 1413 0x7fca8cc99070 0x2b6f4c8ce560 
[1:1:0712/145232.573004:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , document.readyState
[1:1:0712/145232.573212:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145232.977482:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1439, 7fca8f5de8db
[1:1:0712/145233.001757:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1351 0x7fca8cc99070 0x2b6f4d800e60 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145233.001914:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1351 0x7fca8cc99070 0x2b6f4d800e60 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145233.002138:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1570
[1:1:0712/145233.002267:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1570 0x7fca8cc99070 0x2b6f4df54c60 , 5:3_http://www.hebnews.cn/, 0, , 1439 0x7fca8cc99070 0x2b6f4df58fe0 
[1:1:0712/145233.002440:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145233.002730:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/145233.002822:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145233.327936:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1455, 7fca8f5de8db
[1:1:0712/145233.353537:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"144296482860","ptid":"1239 0x7fca8cc99070 0x2b6f4d6b02e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145233.353752:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hebnews.cn/","ptid":"1239 0x7fca8cc99070 0x2b6f4d6b02e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145233.353990:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1580
[1:1:0712/145233.354101:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1580 0x7fca8cc99070 0x2b6f4bef7f60 , 5:3_http://www.hebnews.cn/, 0, , 1455 0x7fca8cc99070 0x2b6f4dcae960 
[1:1:0712/145233.354277:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145233.354557:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , v.fx.tick, (){var e,n=v.timers,r=0;qn=v.now();for(;r<n.length;r++)e=n[r],!e()&&n[r]===e&&n.splice(r--,1);n.leng
[1:1:0712/145233.354673:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145233.466567:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1321, 7fca8f5de8db
[1:1:0712/145233.491046:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"991 0x7fca8cc99070 0x2b6f4d425a60 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145233.491209:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"991 0x7fca8cc99070 0x2b6f4d425a60 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145233.491439:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1581
[1:1:0712/145233.491549:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1581 0x7fca8cc99070 0x2b6f4d45cc60 , 5:3_http://www.hebnews.cn/, 0, , 1321 0x7fca8cc99070 0x2b6f4c8e11e0 
[1:1:0712/145233.491730:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145233.492006:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:6_http://www.hebnews.cn/, 1442965796c0, , , () { roll(); }
[1:1:0712/145233.492134:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 6, 1, http://www.hebnews.cn, www.hebnews.cn, 3
[1:1:0712/145234.853684:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1536, "http://www.hebnews.cn/"
[1:1:0712/145234.854386:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , ___adblockplus({"queryid" : "c299abcde1d7cb6b","tuid" : "3229899_0","placement" : {"basic" : {"sspId
[1:1:0712/145234.854519:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145234.864262:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[8383:8383:0712/145234.865659:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/145234.866556:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 9, 0x2b6f4dcb4e20
[1:1:0712/145234.866702:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 9
[8383:8383:0712/145234.867897:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: iframe3229899_0, 9, 9, 
[8383:8383:0712/145234.883258:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:9_http://www.hebnews.cn/, http://www.hebnews.cn/, 9
[8383:8383:0712/145234.883340:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 9, 9, http://www.hebnews.cn/, http://www.hebnews.cn
[1:1:0712/145234.886320:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.hebnews.cn/"
[1:1:0712/145234.901136:INFO:switcher_impl.cc(1369)] 			updated frame chain. [WARN] subject_frame does not exist in protected memory. [subject_frame, principals, url] = 14429653e6f8, 5:3_http://www.hebnews.cn/, 5:9_http://www.hebnews.cn/, about:blank
[1:1:0712/145234.901335:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:3_http://www.hebnews.cn/-5:9_http://www.hebnews.cn/, 14429653e6f8, 144296482860, open, 
[1:1:0712/145234.901526:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "www.hebnews.cn", 9, 2, http://www.hebnews.cn, www.hebnews.cn, 3
[1:1:0712/145234.902431:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.renderFrame (http://dup.baidustatic.com/js/ds.js:1:1)
	http://dup.baidustatic.com/js/ds.js:1:1
	HTMLIFrameElement.onload (http://www.hebnews.cn/:741:10)
	Object.render (http://dup.baidustatic.com/js/ds.js:1:1)
	Object.painterLoadedCallback (http://dup.baidustatic.com/js/ds.js:1:1)
	Object.callback (http://dup.baidustatic.com/js/ds.js:1:1)
	http://dup.baidustatic.com/js/ds.js:1:1
	http://pos.baidu.com/dctm?psi=44d19a27fc5a70d4026dd3c3226e0505&di=3229899&dri=0&dis=0&dai=0&ps=1878x930&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562914334076&ti=%E6%B2%B3%E5%8C%97%E6%96%B0%E9%97%BB%E7%BD%91_%E6%B2%B3%E5%8C%97%E6%9C%80%E5%A4%A7%E7%9A%84%E7%BD%91%E7%BB%9C%E5%AA%92%E4%BD%93_%E6%B2%B3%E5%8C%97%E7%AC%AC%E4%B8%80%E6%96%B0%E9%97%BB%E9%97%A8%E6%88%B7%E7%BD%91%E7%AB%99_%E6%B2%B3%E5%8C%97%E6%97%A5%E6%8A%A5%E6%8A%A5%E4%B8%9A%E9%9B%86%E5%9B%A2%E4%B8%BB%E5%8A%9E&ari=2&dbv=2&drs=1&pcs=887x666&pss=1215x1983&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562914352&rw=681&ltu=http%3A%2F%2Fwww.hebnews.cn%2F&ecd=1&uc=1855x1056&pis=-1x-1&sr=1920x1080&tcn=1562914352&exps=110011:1:1

[1:1:0712/145234.908164:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:3_http://www.hebnews.cn/-5:9_http://www.hebnews.cn/-5:3_http://www.hebnews.cn/, 144296482860, 14429653e6f8, regisetViewWatch, (t){this.isEventInited||(this.initializeEvent(),this.isEventInited=!0),this.watchingList=this.watchi
[1:1:0712/145234.908352:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 3, , , 0
[1:1:0712/145234.908740:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.render (http://dup.baidustatic.com/js/ds.js:1:1)
	Object.painterLoadedCallback (http://dup.baidustatic.com/js/ds.js:1:1)
	Object.callback (http://dup.baidustatic.com/js/ds.js:1:1)
	http://dup.baidustatic.com/js/ds.js:1:1
	http://pos.baidu.com/dctm?psi=44d19a27fc5a70d4026dd3c3226e0505&di=3229899&dri=0&dis=0&dai=0&ps=1878x930&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562914334076&ti=%E6%B2%B3%E5%8C%97%E6%96%B0%E9%97%BB%E7%BD%91_%E6%B2%B3%E5%8C%97%E6%9C%80%E5%A4%A7%E7%9A%84%E7%BD%91%E7%BB%9C%E5%AA%92%E4%BD%93_%E6%B2%B3%E5%8C%97%E7%AC%AC%E4%B8%80%E6%96%B0%E9%97%BB%E9%97%A8%E6%88%B7%E7%BD%91%E7%AB%99_%E6%B2%B3%E5%8C%97%E6%97%A5%E6%8A%A5%E6%8A%A5%E4%B8%9A%E9%9B%86%E5%9B%A2%E4%B8%BB%E5%8A%9E&ari=2&dbv=2&drs=1&pcs=887x666&pss=1215x1983&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562914352&rw=681&ltu=http%3A%2F%2Fwww.hebnews.cn%2F&ecd=1&uc=1855x1056&pis=-1x-1&sr=1920x1080&tcn=1562914352&exps=110011:1:1

[1:1:0712/145234.932627:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.00825095, 117, 1
[1:1:0712/145234.932794:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/145235.072243:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1454, 7fca8f5de8db
[1:1:0712/145235.098412:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1239 0x7fca8cc99070 0x2b6f4d6b02e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145235.098576:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1239 0x7fca8cc99070 0x2b6f4d6b02e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145235.098788:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1648
[1:1:0712/145235.098895:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1648 0x7fca8cc99070 0x2b6f4da63fe0 , 5:3_http://www.hebnews.cn/, 0, , 1454 0x7fca8cc99070 0x2b6f4dd1d860 
[1:1:0712/145235.099054:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145235.099284:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , () {
                    $btn.last().click()
                }
[1:1:0712/145235.099357:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145235.116832:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3c17ca4629c8, 0x2b6f4c06d950
[1:1:0712/145235.117007:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hebnews.cn/", 0
[1:1:0712/145235.117276:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hebnews.cn/, 1649
[1:1:0712/145235.117440:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1649 0x7fca8cc99070 0x2b6f4d4b76e0 , 5:3_http://www.hebnews.cn/, 1, -5:3_http://www.hebnews.cn/, 1454 0x7fca8cc99070 0x2b6f4dd1d860 
[1:1:0712/145235.136765:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hebnews.cn/", 13
[1:1:0712/145235.137015:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1650
[1:1:0712/145235.137172:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1650 0x7fca8cc99070 0x2b6f4e7f33e0 , 5:3_http://www.hebnews.cn/, 1, -5:3_http://www.hebnews.cn/, 1454 0x7fca8cc99070 0x2b6f4dd1d860 
[1:1:0712/145235.224532:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "click", "http://www.hebnews.cn/"
[1:1:0712/145235.225953:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1540, 7fca8f5de8db
[1:1:0712/145235.253291:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1411 0x7fca8cc99070 0x2b6f4dfb5fe0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145235.253487:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1411 0x7fca8cc99070 0x2b6f4dfb5fe0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145235.253760:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1657
[1:1:0712/145235.253916:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1657 0x7fca8cc99070 0x2b6f4daaeb60 , 5:3_http://www.hebnews.cn/, 0, , 1540 0x7fca8cc99070 0x2b6f4d4b62e0 
[1:1:0712/145235.254087:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145235.254394:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/145235.254531:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145235.308969:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1544, 7fca8f5de8db
[1:1:0712/145235.335581:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1413 0x7fca8cc99070 0x2b6f4c8ce560 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145235.335761:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1413 0x7fca8cc99070 0x2b6f4c8ce560 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145235.336011:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1661
[1:1:0712/145235.336133:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1661 0x7fca8cc99070 0x2b6f4d7fb260 , 5:3_http://www.hebnews.cn/, 0, , 1544 0x7fca8cc99070 0x2b6f4de32a60 
[1:1:0712/145235.336333:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145235.336630:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , ab, (a){if(!A||M!=p||a||R){if(R?p>=1?p=1:0>=p&&(p=0):(O=p,p>=k?p=0:0>p&&(p=k-1)),S(),null!=n&&_(l.childr
[1:1:0712/145235.336711:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145235.453557:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hebnews.cn/, 1545, 7fca8f5de881
[1:1:0712/145235.480587:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"144296482860","ptid":"1413 0x7fca8cc99070 0x2b6f4c8ce560 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145235.480761:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hebnews.cn/","ptid":"1413 0x7fca8cc99070 0x2b6f4c8ce560 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145235.480971:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145235.481286:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , (){qn=t}
[1:1:0712/145235.481401:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145235.690693:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , document.readyState
[1:1:0712/145235.690872:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145235.747739:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1307, 7fca8f5de8db
[1:1:0712/145235.774256:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"144296482860","ptid":"1245 0x7fca8cc99070 0x2b6f4cd129e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145235.774413:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hebnews.cn/","ptid":"1245 0x7fca8cc99070 0x2b6f4cd129e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145235.774635:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1675
[1:1:0712/145235.774741:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1675 0x7fca8cc99070 0x2b6f4e89b0e0 , 5:3_http://www.hebnews.cn/, 0, , 1307 0x7fca8cc99070 0x2b6f4cfe5960 
[1:1:0712/145235.774907:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145235.775150:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , (){w?p--:p++,ab()}
[1:1:0712/145235.775247:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145235.794078:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3c17ca4629c8, 0x2b6f4c06d950
[1:1:0712/145235.794219:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hebnews.cn/", 0
[1:1:0712/145235.794466:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hebnews.cn/, 1676
[1:1:0712/145235.794594:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1676 0x7fca8cc99070 0x2b6f4e5633e0 , 5:3_http://www.hebnews.cn/, 1, -5:3_http://www.hebnews.cn/, 1307 0x7fca8cc99070 0x2b6f4cfe5960 
[1:1:0712/145235.915110:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1402, 7fca8f5de8db
[1:1:0712/145235.939246:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1098 0x7fca8cc99070 0x2b6f4cfde2e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145235.939405:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1098 0x7fca8cc99070 0x2b6f4cfde2e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145235.939628:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1682
[1:1:0712/145235.939735:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1682 0x7fca8cc99070 0x2b6f4e9403e0 , 5:3_http://www.hebnews.cn/, 0, , 1402 0x7fca8cc99070 0x2b6f4de2dbe0 
[1:1:0712/145235.939904:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145235.940138:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:7_http://www.hebnews.cn/, 14429654c330, , , () { roll(); }
[1:1:0712/145235.940265:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 7, 1, http://www.hebnews.cn, www.hebnews.cn, 3
[1:1:0712/145236.164029:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1570, 7fca8f5de8db
[1:1:0712/145236.191082:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1439 0x7fca8cc99070 0x2b6f4df58fe0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145236.191274:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1439 0x7fca8cc99070 0x2b6f4df58fe0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145236.191563:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1688
[1:1:0712/145236.191726:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1688 0x7fca8cc99070 0x2b6f4e8a39e0 , 5:3_http://www.hebnews.cn/, 0, , 1570 0x7fca8cc99070 0x2b6f4df54c60 
[1:1:0712/145236.191930:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145236.192230:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/145236.192356:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145237.931897:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/145237.932126:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.hebnews.cn/"
[1:1:0712/145237.932738:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1641 0x7fca8cc99070 0x2b6f4d4a1ae0 , "http://www.hebnews.cn/"
[1:1:0712/145237.933788:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , 
(function() {
    var s = "_" + Math.random().toString(36).slice(2);
    document.write('<div id="'
[1:1:0712/145237.933908:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[8383:8383:0712/145237.971329:INFO:CONSOLE(3)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://pos.baidu.com/dctm?psi=44d19a27fc5a70d4026dd3c3226e0505&di=3229977&dri=0&dis=0&dai=0&ps=2318x0&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562914334076&ti=%E6%B2%B3%E5%8C%97%E6%96%B0%E9%97%BB%E7%BD%91_%E6%B2%B3%E5%8C%97%E6%9C%80%E5%A4%A7%E7%9A%84%E7%BD%91%E7%BB%9C%E5%AA%92%E4%BD%93_%E6%B2%B3%E5%8C%97%E7%AC%AC%E4%B8%80%E6%96%B0%E9%97%BB%E9%97%A8%E6%88%B7%E7%BD%91%E7%AB%99_%E6%B2%B3%E5%8C%97%E6%97%A5%E6%8A%A5%E6%8A%A5%E4%B8%9A%E9%9B%86%E5%9B%A2%E4%B8%BB%E5%8A%9E&ari=2&dbv=2&drs=1&pcs=887x666&pss=1215x2424&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562914357&rw=681&ltu=http%3A%2F%2Fwww.hebnews.cn%2F&ecd=1&uc=1855x1056&pis=-1x-1&sr=1920x1080&tcn=1562914358&exps=110011, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://dup.baidustatic.com/js/ds.js (3)
[8383:8383:0712/145237.976279:INFO:CONSOLE(3)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://pos.baidu.com/dctm?psi=44d19a27fc5a70d4026dd3c3226e0505&di=3229977&dri=0&dis=0&dai=0&ps=2318x0&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562914334076&ti=%E6%B2%B3%E5%8C%97%E6%96%B0%E9%97%BB%E7%BD%91_%E6%B2%B3%E5%8C%97%E6%9C%80%E5%A4%A7%E7%9A%84%E7%BD%91%E7%BB%9C%E5%AA%92%E4%BD%93_%E6%B2%B3%E5%8C%97%E7%AC%AC%E4%B8%80%E6%96%B0%E9%97%BB%E9%97%A8%E6%88%B7%E7%BD%91%E7%AB%99_%E6%B2%B3%E5%8C%97%E6%97%A5%E6%8A%A5%E6%8A%A5%E4%B8%9A%E9%9B%86%E5%9B%A2%E4%B8%BB%E5%8A%9E&ari=2&dbv=2&drs=1&pcs=887x666&pss=1215x2424&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562914357&rw=681&ltu=http%3A%2F%2Fwww.hebnews.cn%2F&ecd=1&uc=1855x1056&pis=-1x-1&sr=1920x1080&tcn=1562914358&exps=110011, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://dup.baidustatic.com/js/ds.js (3)
[1:1:0712/145238.227248:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hebnews.cn/, 1649, 7fca8f5de881
[1:1:0712/145238.254132:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"144296482860","ptid":"1454 0x7fca8cc99070 0x2b6f4dd1d860 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145238.254367:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hebnews.cn/","ptid":"1454 0x7fca8cc99070 0x2b6f4dd1d860 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145238.254660:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145238.255026:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , (){qn=t}
[1:1:0712/145238.255140:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145238.287792:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1650, 7fca8f5de8db
[1:1:0712/145238.318543:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"144296482860","ptid":"1454 0x7fca8cc99070 0x2b6f4dd1d860 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145238.318851:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hebnews.cn/","ptid":"1454 0x7fca8cc99070 0x2b6f4dd1d860 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145238.319132:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1750
[1:1:0712/145238.319287:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1750 0x7fca8cc99070 0x2b6f4e995ee0 , 5:3_http://www.hebnews.cn/, 0, , 1650 0x7fca8cc99070 0x2b6f4e7f33e0 
[1:1:0712/145238.319516:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145238.319795:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , v.fx.tick, (){var e,n=v.timers,r=0;qn=v.now();for(;r<n.length;r++)e=n[r],!e()&&n[r]===e&&n.splice(r--,1);n.leng
[1:1:0712/145238.319890:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145238.367587:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1648, 7fca8f5de8db
[1:1:0712/145238.397373:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1454 0x7fca8cc99070 0x2b6f4dd1d860 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145238.397538:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1454 0x7fca8cc99070 0x2b6f4dd1d860 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145238.397760:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1753
[1:1:0712/145238.397871:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1753 0x7fca8cc99070 0x2b6f4e7f0d60 , 5:3_http://www.hebnews.cn/, 0, , 1648 0x7fca8cc99070 0x2b6f4da63fe0 
[1:1:0712/145238.398038:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145238.398330:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , () {
                    $btn.last().click()
                }
[1:1:0712/145238.398429:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145238.415411:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3c17ca4629c8, 0x2b6f4c06d950
[1:1:0712/145238.415595:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hebnews.cn/", 0
[1:1:0712/145238.415796:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hebnews.cn/, 1754
[1:1:0712/145238.415900:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1754 0x7fca8cc99070 0x2b6f4e4f5060 , 5:3_http://www.hebnews.cn/, 1, -5:3_http://www.hebnews.cn/, 1648 0x7fca8cc99070 0x2b6f4da63fe0 
[1:1:0712/145238.424995:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hebnews.cn/", 13
[1:1:0712/145238.425240:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1755
[1:1:0712/145238.425350:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1755 0x7fca8cc99070 0x2b6f4e9f1360 , 5:3_http://www.hebnews.cn/, 1, -5:3_http://www.hebnews.cn/, 1648 0x7fca8cc99070 0x2b6f4da63fe0 
[1:1:0712/145238.514120:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "click", "http://www.hebnews.cn/"
[1:1:0712/145238.515026:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1657, 7fca8f5de8db
[1:1:0712/145238.541715:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1540 0x7fca8cc99070 0x2b6f4d4b62e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145238.541896:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1540 0x7fca8cc99070 0x2b6f4d4b62e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145238.542132:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1760
[1:1:0712/145238.542264:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1760 0x7fca8cc99070 0x2b6f4e4665e0 , 5:3_http://www.hebnews.cn/, 0, , 1657 0x7fca8cc99070 0x2b6f4daaeb60 
[1:1:0712/145238.542448:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145238.542718:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/145238.542866:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145238.573508:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1661, 7fca8f5de8db
[1:1:0712/145238.602152:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1544 0x7fca8cc99070 0x2b6f4de32a60 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145238.602342:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1544 0x7fca8cc99070 0x2b6f4de32a60 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145238.602605:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1763
[1:1:0712/145238.602721:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1763 0x7fca8cc99070 0x2b6f4df562e0 , 5:3_http://www.hebnews.cn/, 0, , 1661 0x7fca8cc99070 0x2b6f4d7fb260 
[1:1:0712/145238.602887:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145238.603166:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , ab, (a){if(!A||M!=p||a||R){if(R?p>=1?p=1:0>=p&&(p=0):(O=p,p>=k?p=0:0>p&&(p=k-1)),S(),null!=n&&_(l.childr
[1:1:0712/145238.603266:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145238.991066:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , document.readyState
[1:1:0712/145238.991233:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145239.050968:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hebnews.cn/, 1676, 7fca8f5de881
[1:1:0712/145239.077698:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"144296482860","ptid":"1307 0x7fca8cc99070 0x2b6f4cfe5960 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145239.077905:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hebnews.cn/","ptid":"1307 0x7fca8cc99070 0x2b6f4cfe5960 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145239.078150:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145239.078489:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , (){qn=t}
[1:1:0712/145239.078614:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145239.341245:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1581, 7fca8f5de8db
[1:1:0712/145239.369552:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1321 0x7fca8cc99070 0x2b6f4c8e11e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145239.369717:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1321 0x7fca8cc99070 0x2b6f4c8e11e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145239.369943:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1798
[1:1:0712/145239.370053:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1798 0x7fca8cc99070 0x2b6f4ea187e0 , 5:3_http://www.hebnews.cn/, 0, , 1581 0x7fca8cc99070 0x2b6f4d45cc60 
[1:1:0712/145239.370229:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145239.370477:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:6_http://www.hebnews.cn/, 1442965796c0, , , () { roll(); }
[1:1:0712/145239.370599:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 6, 1, http://www.hebnews.cn, www.hebnews.cn, 3
[1:1:0712/145239.399193:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1688, 7fca8f5de8db
[1:1:0712/145239.426321:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1570 0x7fca8cc99070 0x2b6f4df54c60 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145239.426552:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1570 0x7fca8cc99070 0x2b6f4df54c60 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145239.426817:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1799
[1:1:0712/145239.426929:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1799 0x7fca8cc99070 0x2b6f4e96aa60 , 5:3_http://www.hebnews.cn/, 0, , 1688 0x7fca8cc99070 0x2b6f4e8a39e0 
[1:1:0712/145239.427131:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145239.427419:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/145239.427533:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145239.743861:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1517, 7fca8f5de8db
[1:1:0712/145239.771899:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"144296482860144296532210","ptid":"1403","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145239.772083:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hebnews.cn/-5:8_http://www.hebnews.cn/","ptid":"1403","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145239.772301:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1810
[1:1:0712/145239.772411:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1810 0x7fca8cc99070 0x2b6f4e96a3e0 , 5:3_http://www.hebnews.cn/, 0, , 1517 0x7fca8cc99070 0x2b6f4d5339e0 
[1:1:0712/145239.772572:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145239.772809:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:8_http://www.hebnews.cn/, 144296532210, , , () { roll(); }
[1:1:0712/145239.772918:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 8, 1, http://www.hebnews.cn, www.hebnews.cn, 3
[1:1:0712/145240.368896:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1675, 7fca8f5de8db
[1:1:0712/145240.397337:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1307 0x7fca8cc99070 0x2b6f4cfe5960 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145240.397534:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1307 0x7fca8cc99070 0x2b6f4cfe5960 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145240.397819:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1823
[1:1:0712/145240.397968:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1823 0x7fca8cc99070 0x2b6f4e915de0 , 5:3_http://www.hebnews.cn/, 0, , 1675 0x7fca8cc99070 0x2b6f4e89b0e0 
[1:1:0712/145240.398213:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145240.398541:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , (){w?p--:p++,ab()}
[1:1:0712/145240.398724:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145240.416326:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3c17ca4629c8, 0x2b6f4c06d950
[1:1:0712/145240.416476:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hebnews.cn/", 0
[1:1:0712/145240.416662:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hebnews.cn/, 1824
[1:1:0712/145240.416823:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1824 0x7fca8cc99070 0x2b6f4d8006e0 , 5:3_http://www.hebnews.cn/, 1, -5:3_http://www.hebnews.cn/, 1675 0x7fca8cc99070 0x2b6f4e89b0e0 
[1:1:0712/145240.429399:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1682, 7fca8f5de8db
[1:1:0712/145240.458361:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1402 0x7fca8cc99070 0x2b6f4de2dbe0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145240.458609:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1402 0x7fca8cc99070 0x2b6f4de2dbe0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145240.458884:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1828
[1:1:0712/145240.459006:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1828 0x7fca8cc99070 0x2b6f4c871ce0 , 5:3_http://www.hebnews.cn/, 0, , 1682 0x7fca8cc99070 0x2b6f4e9403e0 
[1:1:0712/145240.459194:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145240.459485:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:7_http://www.hebnews.cn/, 14429654c330, , , () { roll(); }
[1:1:0712/145240.459628:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 7, 1, http://www.hebnews.cn, www.hebnews.cn, 3
[1:1:0712/145241.027900:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1752, "http://www.hebnews.cn/"
[1:1:0712/145241.028686:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , ___adblockplus({"queryid" : "0a6d55ace2aac5db","tuid" : "3229977_0","placement" : {"basic" : {"sspId
[1:1:0712/145241.028824:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145241.039406:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[8383:8383:0712/145241.040706:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/145241.042215:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 10, 0x2b6f4e8ade20
[1:1:0712/145241.042632:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 10
[8383:8383:0712/145241.043208:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: iframe3229977_0, 10, 10, 
[1:1:0712/145241.061664:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.hebnews.cn/"
[8383:8383:0712/145241.063298:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:10_http://www.hebnews.cn/, http://www.hebnews.cn/, 10
[8383:8383:0712/145241.063372:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 10, 10, http://www.hebnews.cn/, http://www.hebnews.cn
[1:1:0712/145241.079702:INFO:switcher_impl.cc(1369)] 			updated frame chain. [WARN] subject_frame does not exist in protected memory. [subject_frame, principals, url] = 14429650e548, 5:3_http://www.hebnews.cn/, 5:10_http://www.hebnews.cn/, about:blank
[1:1:0712/145241.079901:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:3_http://www.hebnews.cn/-5:10_http://www.hebnews.cn/, 14429650e548, 144296482860, open, 
[1:1:0712/145241.080066:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "www.hebnews.cn", 10, 2, http://www.hebnews.cn, www.hebnews.cn, 3
[1:1:0712/145241.080936:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.renderFrame (http://dup.baidustatic.com/js/ds.js:1:1)
	http://dup.baidustatic.com/js/ds.js:1:1
	HTMLIFrameElement.onload (http://www.hebnews.cn/:793:10)
	Object.render (http://dup.baidustatic.com/js/ds.js:1:1)
	Object.painterLoadedCallback (http://dup.baidustatic.com/js/ds.js:1:1)
	Object.callback (http://dup.baidustatic.com/js/ds.js:1:1)
	http://dup.baidustatic.com/js/ds.js:1:1
	http://pos.baidu.com/dctm?psi=44d19a27fc5a70d4026dd3c3226e0505&di=3229977&dri=0&dis=0&dai=0&ps=2318x0&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562914334076&ti=%E6%B2%B3%E5%8C%97%E6%96%B0%E9%97%BB%E7%BD%91_%E6%B2%B3%E5%8C%97%E6%9C%80%E5%A4%A7%E7%9A%84%E7%BD%91%E7%BB%9C%E5%AA%92%E4%BD%93_%E6%B2%B3%E5%8C%97%E7%AC%AC%E4%B8%80%E6%96%B0%E9%97%BB%E9%97%A8%E6%88%B7%E7%BD%91%E7%AB%99_%E6%B2%B3%E5%8C%97%E6%97%A5%E6%8A%A5%E6%8A%A5%E4%B8%9A%E9%9B%86%E5%9B%A2%E4%B8%BB%E5%8A%9E&ari=2&dbv=2&drs=1&pcs=887x666&pss=1215x2424&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562914357&rw=681&ltu=http%3A%2F%2Fwww.hebnews.cn%2F&ecd=1&uc=1855x1056&pis=-1x-1&sr=1920x1080&tcn=1562914358&exps=110011:1:1

[1:1:0712/145241.087053:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:3_http://www.hebnews.cn/-5:10_http://www.hebnews.cn/-5:3_http://www.hebnews.cn/, 144296482860, 14429650e548, regisetViewWatch, (t){this.isEventInited||(this.initializeEvent(),this.isEventInited=!0),this.watchingList=this.watchi
[1:1:0712/145241.087258:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 3, , , 0
[1:1:0712/145241.087601:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.render (http://dup.baidustatic.com/js/ds.js:1:1)
	Object.painterLoadedCallback (http://dup.baidustatic.com/js/ds.js:1:1)
	Object.callback (http://dup.baidustatic.com/js/ds.js:1:1)
	http://dup.baidustatic.com/js/ds.js:1:1
	http://pos.baidu.com/dctm?psi=44d19a27fc5a70d4026dd3c3226e0505&di=3229977&dri=0&dis=0&dai=0&ps=2318x0&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562914334076&ti=%E6%B2%B3%E5%8C%97%E6%96%B0%E9%97%BB%E7%BD%91_%E6%B2%B3%E5%8C%97%E6%9C%80%E5%A4%A7%E7%9A%84%E7%BD%91%E7%BB%9C%E5%AA%92%E4%BD%93_%E6%B2%B3%E5%8C%97%E7%AC%AC%E4%B8%80%E6%96%B0%E9%97%BB%E9%97%A8%E6%88%B7%E7%BD%91%E7%AB%99_%E6%B2%B3%E5%8C%97%E6%97%A5%E6%8A%A5%E6%8A%A5%E4%B8%9A%E9%9B%86%E5%9B%A2%E4%B8%BB%E5%8A%9E&ari=2&dbv=2&drs=1&pcs=887x666&pss=1215x2424&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562914357&rw=681&ltu=http%3A%2F%2Fwww.hebnews.cn%2F&ecd=1&uc=1855x1056&pis=-1x-1&sr=1920x1080&tcn=1562914358&exps=110011:1:1

[1:1:0712/145241.104457:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1752, "http://www.hebnews.cn/"
[8383:8383:0712/145241.143004:INFO:CONSOLE(3)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://pos.baidu.com/dctm?psi=44d19a27fc5a70d4026dd3c3226e0505&di=3229982&dri=0&dis=0&dai=0&ps=2318x310&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562914334076&ti=%E6%B2%B3%E5%8C%97%E6%96%B0%E9%97%BB%E7%BD%91_%E6%B2%B3%E5%8C%97%E6%9C%80%E5%A4%A7%E7%9A%84%E7%BD%91%E7%BB%9C%E5%AA%92%E4%BD%93_%E6%B2%B3%E5%8C%97%E7%AC%AC%E4%B8%80%E6%96%B0%E9%97%BB%E9%97%A8%E6%88%B7%E7%BD%91%E7%AB%99_%E6%B2%B3%E5%8C%97%E6%97%A5%E6%8A%A5%E6%8A%A5%E4%B8%9A%E9%9B%86%E5%9B%A2%E4%B8%BB%E5%8A%9E&ari=2&dbv=2&drs=1&pcs=887x666&pss=1215x2424&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562914361&rw=681&ltu=http%3A%2F%2Fwww.hebnews.cn%2F&ecd=1&uc=1855x1056&pis=-1x-1&sr=1920x1080&tcn=1562914361&exps=110011, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://dup.baidustatic.com/js/ds.js (3)
[1:1:0712/145241.147364:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hebnews.cn/, 1754, 7fca8f5de881
[8383:8383:0712/145241.148365:INFO:CONSOLE(3)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://pos.baidu.com/dctm?psi=44d19a27fc5a70d4026dd3c3226e0505&di=3229982&dri=0&dis=0&dai=0&ps=2318x310&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562914334076&ti=%E6%B2%B3%E5%8C%97%E6%96%B0%E9%97%BB%E7%BD%91_%E6%B2%B3%E5%8C%97%E6%9C%80%E5%A4%A7%E7%9A%84%E7%BD%91%E7%BB%9C%E5%AA%92%E4%BD%93_%E6%B2%B3%E5%8C%97%E7%AC%AC%E4%B8%80%E6%96%B0%E9%97%BB%E9%97%A8%E6%88%B7%E7%BD%91%E7%AB%99_%E6%B2%B3%E5%8C%97%E6%97%A5%E6%8A%A5%E6%8A%A5%E4%B8%9A%E9%9B%86%E5%9B%A2%E4%B8%BB%E5%8A%9E&ari=2&dbv=2&drs=1&pcs=887x666&pss=1215x2424&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562914361&rw=681&ltu=http%3A%2F%2Fwww.hebnews.cn%2F&ecd=1&uc=1855x1056&pis=-1x-1&sr=1920x1080&tcn=1562914361&exps=110011, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://dup.baidustatic.com/js/ds.js (3)
[1:1:0712/145241.183111:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"144296482860","ptid":"1648 0x7fca8cc99070 0x2b6f4da63fe0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145241.183313:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hebnews.cn/","ptid":"1648 0x7fca8cc99070 0x2b6f4da63fe0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145241.183527:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145241.183789:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , (){qn=t}
[1:1:0712/145241.183893:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145241.184401:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1755, 7fca8f5de8db
[1:1:0712/145241.213343:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"144296482860","ptid":"1648 0x7fca8cc99070 0x2b6f4da63fe0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145241.213538:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hebnews.cn/","ptid":"1648 0x7fca8cc99070 0x2b6f4da63fe0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145241.213872:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1909
[1:1:0712/145241.214029:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1909 0x7fca8cc99070 0x2b6f4e5beae0 , 5:3_http://www.hebnews.cn/, 0, , 1755 0x7fca8cc99070 0x2b6f4e9f1360 
[1:1:0712/145241.214191:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145241.214439:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , v.fx.tick, (){var e,n=v.timers,r=0;qn=v.now();for(;r<n.length;r++)e=n[r],!e()&&n[r]===e&&n.splice(r--,1);n.leng
[1:1:0712/145241.214536:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145241.327329:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1760, 7fca8f5de8db
[1:1:0712/145241.357452:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1657 0x7fca8cc99070 0x2b6f4daaeb60 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145241.357677:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1657 0x7fca8cc99070 0x2b6f4daaeb60 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145241.357974:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1917
[1:1:0712/145241.358137:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1917 0x7fca8cc99070 0x2b6f4d499860 , 5:3_http://www.hebnews.cn/, 0, , 1760 0x7fca8cc99070 0x2b6f4e4665e0 
[1:1:0712/145241.358332:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145241.358605:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/145241.358714:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145241.359712:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1763, 7fca8f5de8db
[1:1:0712/145241.390096:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1661 0x7fca8cc99070 0x2b6f4d7fb260 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145241.390265:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1661 0x7fca8cc99070 0x2b6f4d7fb260 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145241.390500:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1918
[1:1:0712/145241.390612:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1918 0x7fca8cc99070 0x2b6f4dc45f60 , 5:3_http://www.hebnews.cn/, 0, , 1763 0x7fca8cc99070 0x2b6f4df562e0 
[1:1:0712/145241.390783:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145241.391057:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , ab, (a){if(!A||M!=p||a||R){if(R?p>=1?p=1:0>=p&&(p=0):(O=p,p>=k?p=0:0>p&&(p=k-1)),S(),null!=n&&_(l.childr
[1:1:0712/145241.391180:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145241.407575:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3c17ca4629c8, 0x2b6f4c06d950
[1:1:0712/145241.407753:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hebnews.cn/", 0
[1:1:0712/145241.407957:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hebnews.cn/, 1919
[1:1:0712/145241.408102:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1919 0x7fca8cc99070 0x2b6f4db6d0e0 , 5:3_http://www.hebnews.cn/, 1, -5:3_http://www.hebnews.cn/, 1763 0x7fca8cc99070 0x2b6f4df562e0 
[1:1:0712/145241.909175:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , document.readyState
[1:1:0712/145241.909376:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145242.339344:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1799, 7fca8f5de8db
[1:1:0712/145242.369703:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1688 0x7fca8cc99070 0x2b6f4e8a39e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145242.369890:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1688 0x7fca8cc99070 0x2b6f4e8a39e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145242.370145:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1948
[1:1:0712/145242.370289:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1948 0x7fca8cc99070 0x2b6f4e5637e0 , 5:3_http://www.hebnews.cn/, 0, , 1799 0x7fca8cc99070 0x2b6f4e96aa60 
[1:1:0712/145242.370480:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145242.370755:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/145242.370866:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145242.797477:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hebnews.cn/, 1824, 7fca8f5de881
[1:1:0712/145242.827692:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"144296482860","ptid":"1675 0x7fca8cc99070 0x2b6f4e89b0e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145242.827868:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hebnews.cn/","ptid":"1675 0x7fca8cc99070 0x2b6f4e89b0e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145242.828086:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145242.828399:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , (){qn=t}
[1:1:0712/145242.828523:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145245.386887:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1798, 7fca8f5de8db
[1:1:0712/145245.418738:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1581 0x7fca8cc99070 0x2b6f4d45cc60 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145245.418935:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1581 0x7fca8cc99070 0x2b6f4d45cc60 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145245.419243:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2015
[1:1:0712/145245.419422:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2015 0x7fca8cc99070 0x2b6f4ee9fce0 , 5:3_http://www.hebnews.cn/, 0, , 1798 0x7fca8cc99070 0x2b6f4ea187e0 
[1:1:0712/145245.419592:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145245.419871:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:6_http://www.hebnews.cn/, 1442965796c0, , , () { roll(); }
[1:1:0712/145245.420022:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 6, 1, http://www.hebnews.cn, www.hebnews.cn, 3
[1:1:0712/145245.420860:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1909, 7fca8f5de8db
[1:1:0712/145245.451764:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1755 0x7fca8cc99070 0x2b6f4e9f1360 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145245.451930:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1755 0x7fca8cc99070 0x2b6f4e9f1360 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145245.452164:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2016
[1:1:0712/145245.452272:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2016 0x7fca8cc99070 0x2b6f4c8d88e0 , 5:3_http://www.hebnews.cn/, 0, , 1909 0x7fca8cc99070 0x2b6f4e5beae0 
[1:1:0712/145245.452445:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145245.452705:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , v.fx.tick, (){var e,n=v.timers,r=0;qn=v.now();for(;r<n.length;r++)e=n[r],!e()&&n[r]===e&&n.splice(r--,1);n.leng
[1:1:0712/145245.452794:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145245.521831:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1912, "http://www.hebnews.cn/"
[1:1:0712/145245.522519:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , ___adblockplus({"queryid" : "5332c8306e83afce","tuid" : "3229982_0","placement" : {"basic" : {"sspId
[1:1:0712/145245.522680:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145245.532469:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[8383:8383:0712/145245.533654:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/145245.534901:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 11, 0x2b6f4dcb4420
[1:1:0712/145245.535027:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 11
[8383:8383:0712/145245.536074:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: iframe3229982_0, 11, 11, 
[8383:8383:0712/145245.551380:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:11_http://www.hebnews.cn/, http://www.hebnews.cn/, 11
[8383:8383:0712/145245.551464:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 11, 11, http://www.hebnews.cn/, http://www.hebnews.cn
[1:1:0712/145245.554475:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.hebnews.cn/"
[1:1:0712/145245.569843:INFO:switcher_impl.cc(1369)] 			updated frame chain. [WARN] subject_frame does not exist in protected memory. [subject_frame, principals, url] = 144296519748, 5:3_http://www.hebnews.cn/, 5:11_http://www.hebnews.cn/, about:blank
[1:1:0712/145245.570038:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:3_http://www.hebnews.cn/-5:11_http://www.hebnews.cn/, 144296519748, 144296482860, open, 
[1:1:0712/145245.570233:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "www.hebnews.cn", 11, 2, http://www.hebnews.cn, www.hebnews.cn, 3
[1:1:0712/145245.571185:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.renderFrame (http://dup.baidustatic.com/js/ds.js:1:1)
	http://dup.baidustatic.com/js/ds.js:1:1
	HTMLIFrameElement.onload (http://www.hebnews.cn/:807:10)
	Object.render (http://dup.baidustatic.com/js/ds.js:1:1)
	Object.painterLoadedCallback (http://dup.baidustatic.com/js/ds.js:1:1)
	Object.callback (http://dup.baidustatic.com/js/ds.js:1:1)
	http://dup.baidustatic.com/js/ds.js:1:1
	http://pos.baidu.com/dctm?psi=44d19a27fc5a70d4026dd3c3226e0505&di=3229982&dri=0&dis=0&dai=0&ps=2318x310&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562914334076&ti=%E6%B2%B3%E5%8C%97%E6%96%B0%E9%97%BB%E7%BD%91_%E6%B2%B3%E5%8C%97%E6%9C%80%E5%A4%A7%E7%9A%84%E7%BD%91%E7%BB%9C%E5%AA%92%E4%BD%93_%E6%B2%B3%E5%8C%97%E7%AC%AC%E4%B8%80%E6%96%B0%E9%97%BB%E9%97%A8%E6%88%B7%E7%BD%91%E7%AB%99_%E6%B2%B3%E5%8C%97%E6%97%A5%E6%8A%A5%E6%8A%A5%E4%B8%9A%E9%9B%86%E5%9B%A2%E4%B8%BB%E5%8A%9E&ari=2&dbv=2&drs=1&pcs=887x666&pss=1215x2424&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562914361&rw=681&ltu=http%3A%2F%2Fwww.hebnews.cn%2F&ecd=1&uc=1855x1056&pis=-1x-1&sr=1920x1080&tcn=1562914361&exps=110011:1:1

[1:1:0712/145245.573509:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1912, "http://www.hebnews.cn/"
[1:1:0712/145245.576995:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hebnews.cn/", 5000
[1:1:0712/145245.577348:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2037
[1:1:0712/145245.577477:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2037 0x7fca8cc99070 0x2b6f4ed792e0 , 5:3_http://www.hebnews.cn/, 2, -5:3_http://www.hebnews.cn/-5:11_http://www.hebnews.cn/, 1912
[1:1:0712/145245.579959:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:3_http://www.hebnews.cn/-5:11_http://www.hebnews.cn/-5:3_http://www.hebnews.cn/, 144296482860, 144296519748, regisetViewWatch, (t){this.isEventInited||(this.initializeEvent(),this.isEventInited=!0),this.watchingList=this.watchi
[1:1:0712/145245.580132:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 3, , , 0
[1:1:0712/145245.580499:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.render (http://dup.baidustatic.com/js/ds.js:1:1)
	Object.painterLoadedCallback (http://dup.baidustatic.com/js/ds.js:1:1)
	Object.callback (http://dup.baidustatic.com/js/ds.js:1:1)
	http://dup.baidustatic.com/js/ds.js:1:1
	http://pos.baidu.com/dctm?psi=44d19a27fc5a70d4026dd3c3226e0505&di=3229982&dri=0&dis=0&dai=0&ps=2318x310&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562914334076&ti=%E6%B2%B3%E5%8C%97%E6%96%B0%E9%97%BB%E7%BD%91_%E6%B2%B3%E5%8C%97%E6%9C%80%E5%A4%A7%E7%9A%84%E7%BD%91%E7%BB%9C%E5%AA%92%E4%BD%93_%E6%B2%B3%E5%8C%97%E7%AC%AC%E4%B8%80%E6%96%B0%E9%97%BB%E9%97%A8%E6%88%B7%E7%BD%91%E7%AB%99_%E6%B2%B3%E5%8C%97%E6%97%A5%E6%8A%A5%E6%8A%A5%E4%B8%9A%E9%9B%86%E5%9B%A2%E4%B8%BB%E5%8A%9E&ari=2&dbv=2&drs=1&pcs=887x666&pss=1215x2424&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562914361&rw=681&ltu=http%3A%2F%2Fwww.hebnews.cn%2F&ecd=1&uc=1855x1056&pis=-1x-1&sr=1920x1080&tcn=1562914361&exps=110011:1:1

[1:1:0712/145245.599118:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1912, "http://www.hebnews.cn/"
[8383:8383:0712/145245.636761:INFO:CONSOLE(3)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://pos.baidu.com/dctm?psi=44d19a27fc5a70d4026dd3c3226e0505&di=3229984&dri=0&dis=0&dai=0&ps=2318x620&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562914334076&ti=%E6%B2%B3%E5%8C%97%E6%96%B0%E9%97%BB%E7%BD%91_%E6%B2%B3%E5%8C%97%E6%9C%80%E5%A4%A7%E7%9A%84%E7%BD%91%E7%BB%9C%E5%AA%92%E4%BD%93_%E6%B2%B3%E5%8C%97%E7%AC%AC%E4%B8%80%E6%96%B0%E9%97%BB%E9%97%A8%E6%88%B7%E7%BD%91%E7%AB%99_%E6%B2%B3%E5%8C%97%E6%97%A5%E6%8A%A5%E6%8A%A5%E4%B8%9A%E9%9B%86%E5%9B%A2%E4%B8%BB%E5%8A%9E&ari=2&dbv=2&drs=1&pcs=887x666&pss=1215x2424&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562914365&rw=681&ltu=http%3A%2F%2Fwww.hebnews.cn%2F&ecd=1&uc=1855x1056&pis=-1x-1&sr=1920x1080&tcn=1562914366&exps=110011, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://dup.baidustatic.com/js/ds.js (3)
[8383:8383:0712/145245.642068:INFO:CONSOLE(3)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://pos.baidu.com/dctm?psi=44d19a27fc5a70d4026dd3c3226e0505&di=3229984&dri=0&dis=0&dai=0&ps=2318x620&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562914334076&ti=%E6%B2%B3%E5%8C%97%E6%96%B0%E9%97%BB%E7%BD%91_%E6%B2%B3%E5%8C%97%E6%9C%80%E5%A4%A7%E7%9A%84%E7%BD%91%E7%BB%9C%E5%AA%92%E4%BD%93_%E6%B2%B3%E5%8C%97%E7%AC%AC%E4%B8%80%E6%96%B0%E9%97%BB%E9%97%A8%E6%88%B7%E7%BD%91%E7%AB%99_%E6%B2%B3%E5%8C%97%E6%97%A5%E6%8A%A5%E6%8A%A5%E4%B8%9A%E9%9B%86%E5%9B%A2%E4%B8%BB%E5%8A%9E&ari=2&dbv=2&drs=1&pcs=887x666&pss=1215x2424&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562914365&rw=681&ltu=http%3A%2F%2Fwww.hebnews.cn%2F&ecd=1&uc=1855x1056&pis=-1x-1&sr=1920x1080&tcn=1562914366&exps=110011, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://dup.baidustatic.com/js/ds.js (3)
[1:1:0712/145245.708680:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1753, 7fca8f5de8db
[1:1:0712/145245.741050:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1648 0x7fca8cc99070 0x2b6f4da63fe0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145245.741245:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1648 0x7fca8cc99070 0x2b6f4da63fe0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145245.741485:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2053
[1:1:0712/145245.741610:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2053 0x7fca8cc99070 0x2b6f4ef12c60 , 5:3_http://www.hebnews.cn/, 0, , 1753 0x7fca8cc99070 0x2b6f4e7f0d60 
[1:1:0712/145245.741843:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145245.742131:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , () {
                    $btn.last().click()
                }
[1:1:0712/145245.742235:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145245.757916:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3c17ca4629c8, 0x2b6f4c06d950
[1:1:0712/145245.758084:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hebnews.cn/", 0
[1:1:0712/145245.758289:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hebnews.cn/, 2054
[1:1:0712/145245.758433:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2054 0x7fca8cc99070 0x2b6f4d997760 , 5:3_http://www.hebnews.cn/, 1, -5:3_http://www.hebnews.cn/, 1753 0x7fca8cc99070 0x2b6f4e7f0d60 
[1:1:0712/145245.767509:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hebnews.cn/", 13
[1:1:0712/145245.767759:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2055
[1:1:0712/145245.767879:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2055 0x7fca8cc99070 0x2b6f4c5ca7e0 , 5:3_http://www.hebnews.cn/, 1, -5:3_http://www.hebnews.cn/, 1753 0x7fca8cc99070 0x2b6f4e7f0d60 
[1:1:0712/145245.855601:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "click", "http://www.hebnews.cn/"
[1:1:0712/145245.921939:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1917, 7fca8f5de8db
[1:1:0712/145245.954649:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1760 0x7fca8cc99070 0x2b6f4e4665e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145245.954832:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1760 0x7fca8cc99070 0x2b6f4e4665e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145245.955097:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2060
[1:1:0712/145245.955224:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2060 0x7fca8cc99070 0x2b6f4d997160 , 5:3_http://www.hebnews.cn/, 0, , 1917 0x7fca8cc99070 0x2b6f4d499860 
[1:1:0712/145245.955459:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145245.955759:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/145245.955893:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145245.956837:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1918, 7fca8f5de8db
[1:1:0712/145245.991982:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1763 0x7fca8cc99070 0x2b6f4df562e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145245.992175:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1763 0x7fca8cc99070 0x2b6f4df562e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145245.992456:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2062
[1:1:0712/145245.992582:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2062 0x7fca8cc99070 0x2b6f4e5bb260 , 5:3_http://www.hebnews.cn/, 0, , 1918 0x7fca8cc99070 0x2b6f4dc45f60 
[1:1:0712/145245.992771:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145245.993269:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , ab, (a){if(!A||M!=p||a||R){if(R?p>=1?p=1:0>=p&&(p=0):(O=p,p>=k?p=0:0>p&&(p=k-1)),S(),null!=n&&_(l.childr
[1:1:0712/145245.993355:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145246.030978:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hebnews.cn/, 1919, 7fca8f5de881
[1:1:0712/145246.064469:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"144296482860","ptid":"1763 0x7fca8cc99070 0x2b6f4df562e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145246.064688:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hebnews.cn/","ptid":"1763 0x7fca8cc99070 0x2b6f4df562e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145246.064957:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145246.065274:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , (){qn=t}
[1:1:0712/145246.065412:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145246.503590:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , document.readyState
[1:1:0712/145246.503750:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145246.640204:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1810, 7fca8f5de8db
[1:1:0712/145246.674835:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1517 0x7fca8cc99070 0x2b6f4d5339e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145246.675071:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1517 0x7fca8cc99070 0x2b6f4d5339e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145246.675383:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2082
[1:1:0712/145246.675549:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2082 0x7fca8cc99070 0x2b6f4d6985e0 , 5:3_http://www.hebnews.cn/, 0, , 1810 0x7fca8cc99070 0x2b6f4e96a3e0 
[1:1:0712/145246.675769:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145246.676075:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:8_http://www.hebnews.cn/, 144296532210, , , () { roll(); }
[1:1:0712/145246.676207:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 8, 1, http://www.hebnews.cn, www.hebnews.cn, 3
[8383:8394:0712/145246.734972:ERROR:ssl_client_socket_impl.cc(1046)] handshake failed; returned -1, SSL error code 1, net_error -101
[1:1:0712/145247.049188:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1948, 7fca8f5de8db
[1:1:0712/145247.083954:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1799 0x7fca8cc99070 0x2b6f4e96aa60 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145247.084135:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1799 0x7fca8cc99070 0x2b6f4e96aa60 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145247.084372:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2096
[1:1:0712/145247.084488:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2096 0x7fca8cc99070 0x2b6f4ee5aae0 , 5:3_http://www.hebnews.cn/, 0, , 1948 0x7fca8cc99070 0x2b6f4e5637e0 
[1:1:0712/145247.084655:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145247.084905:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/145247.084995:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145247.197472:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1823, 7fca8f5de8db
[1:1:0712/145247.230012:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1675 0x7fca8cc99070 0x2b6f4e89b0e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145247.230219:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1675 0x7fca8cc99070 0x2b6f4e89b0e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145247.230499:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2099
[1:1:0712/145247.230646:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2099 0x7fca8cc99070 0x2b6f4ed64ce0 , 5:3_http://www.hebnews.cn/, 0, , 1823 0x7fca8cc99070 0x2b6f4e915de0 
[1:1:0712/145247.230835:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145247.231157:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , (){w?p--:p++,ab()}
[1:1:0712/145247.231276:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145247.249706:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3c17ca4629c8, 0x2b6f4c06d950
[1:1:0712/145247.249869:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hebnews.cn/", 0
[1:1:0712/145247.250067:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hebnews.cn/, 2100
[1:1:0712/145247.250203:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2100 0x7fca8cc99070 0x2b6f4d6aa460 , 5:3_http://www.hebnews.cn/, 1, -5:3_http://www.hebnews.cn/, 1823 0x7fca8cc99070 0x2b6f4e915de0 
[1:1:0712/145247.263876:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1828, 7fca8f5de8db
[1:1:0712/145247.298267:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1682 0x7fca8cc99070 0x2b6f4e9403e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145247.298431:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1682 0x7fca8cc99070 0x2b6f4e9403e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145247.298664:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2105
[1:1:0712/145247.298774:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2105 0x7fca8cc99070 0x2b6f4ed7bd60 , 5:3_http://www.hebnews.cn/, 0, , 1828 0x7fca8cc99070 0x2b6f4c871ce0 
[1:1:0712/145247.298947:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145247.299195:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:7_http://www.hebnews.cn/, 14429654c330, , , () { roll(); }
[1:1:0712/145247.299330:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 7, 1, http://www.hebnews.cn, www.hebnews.cn, 3
[1:1:0712/145249.956144:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 2052, "http://www.hebnews.cn/"
[1:1:0712/145249.956908:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , ___adblockplus({"queryid" : "cd1604495474598c","tuid" : "3229984_0","placement" : {"basic" : {"sspId
[1:1:0712/145249.957083:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145249.967252:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[8383:8383:0712/145249.968553:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/145249.970122:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 12, 0x2b6f4dcb5820
[1:1:0712/145249.970271:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 12
[8383:8383:0712/145249.971108:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: iframe3229984_0, 12, 12, 
[8383:8383:0712/145249.985355:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:12_http://www.hebnews.cn/, http://www.hebnews.cn/, 12
[8383:8383:0712/145249.985437:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 12, 12, http://www.hebnews.cn/, http://www.hebnews.cn
[1:1:0712/145249.988089:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.hebnews.cn/"
[1:1:0712/145250.002617:INFO:switcher_impl.cc(1369)] 			updated frame chain. [WARN] subject_frame does not exist in protected memory. [subject_frame, principals, url] = 1442964e7e28, 5:3_http://www.hebnews.cn/, 5:12_http://www.hebnews.cn/, about:blank
[1:1:0712/145250.002813:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:3_http://www.hebnews.cn/-5:12_http://www.hebnews.cn/, 1442964e7e28, 144296482860, open, 
[1:1:0712/145250.003011:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "www.hebnews.cn", 12, 2, http://www.hebnews.cn, www.hebnews.cn, 3
[1:1:0712/145250.003885:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.renderFrame (http://dup.baidustatic.com/js/ds.js:1:1)
	http://dup.baidustatic.com/js/ds.js:1:1
	HTMLIFrameElement.onload (http://www.hebnews.cn/:821:10)
	Object.render (http://dup.baidustatic.com/js/ds.js:1:1)
	Object.painterLoadedCallback (http://dup.baidustatic.com/js/ds.js:1:1)
	Object.callback (http://dup.baidustatic.com/js/ds.js:1:1)
	http://dup.baidustatic.com/js/ds.js:1:1
	http://pos.baidu.com/dctm?psi=44d19a27fc5a70d4026dd3c3226e0505&di=3229984&dri=0&dis=0&dai=0&ps=2318x620&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562914334076&ti=%E6%B2%B3%E5%8C%97%E6%96%B0%E9%97%BB%E7%BD%91_%E6%B2%B3%E5%8C%97%E6%9C%80%E5%A4%A7%E7%9A%84%E7%BD%91%E7%BB%9C%E5%AA%92%E4%BD%93_%E6%B2%B3%E5%8C%97%E7%AC%AC%E4%B8%80%E6%96%B0%E9%97%BB%E9%97%A8%E6%88%B7%E7%BD%91%E7%AB%99_%E6%B2%B3%E5%8C%97%E6%97%A5%E6%8A%A5%E6%8A%A5%E4%B8%9A%E9%9B%86%E5%9B%A2%E4%B8%BB%E5%8A%9E&ari=2&dbv=2&drs=1&pcs=887x666&pss=1215x2424&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562914365&rw=681&ltu=http%3A%2F%2Fwww.hebnews.cn%2F&ecd=1&uc=1855x1056&pis=-1x-1&sr=1920x1080&tcn=1562914366&exps=110011:1:1

[1:1:0712/145250.012615:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:3_http://www.hebnews.cn/-5:12_http://www.hebnews.cn/-5:3_http://www.hebnews.cn/, 144296482860, 1442964e7e28, regisetViewWatch, (t){this.isEventInited||(this.initializeEvent(),this.isEventInited=!0),this.watchingList=this.watchi
[1:1:0712/145250.013561:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 3, , , 0
[1:1:0712/145250.014001:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.render (http://dup.baidustatic.com/js/ds.js:1:1)
	Object.painterLoadedCallback (http://dup.baidustatic.com/js/ds.js:1:1)
	Object.callback (http://dup.baidustatic.com/js/ds.js:1:1)
	http://dup.baidustatic.com/js/ds.js:1:1
	http://pos.baidu.com/dctm?psi=44d19a27fc5a70d4026dd3c3226e0505&di=3229984&dri=0&dis=0&dai=0&ps=2318x620&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562914334076&ti=%E6%B2%B3%E5%8C%97%E6%96%B0%E9%97%BB%E7%BD%91_%E6%B2%B3%E5%8C%97%E6%9C%80%E5%A4%A7%E7%9A%84%E7%BD%91%E7%BB%9C%E5%AA%92%E4%BD%93_%E6%B2%B3%E5%8C%97%E7%AC%AC%E4%B8%80%E6%96%B0%E9%97%BB%E9%97%A8%E6%88%B7%E7%BD%91%E7%AB%99_%E6%B2%B3%E5%8C%97%E6%97%A5%E6%8A%A5%E6%8A%A5%E4%B8%9A%E9%9B%86%E5%9B%A2%E4%B8%BB%E5%8A%9E&ari=2&dbv=2&drs=1&pcs=887x666&pss=1215x2424&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562914365&rw=681&ltu=http%3A%2F%2Fwww.hebnews.cn%2F&ecd=1&uc=1855x1056&pis=-1x-1&sr=1920x1080&tcn=1562914366&exps=110011:1:1

[1:1:0712/145250.031694:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 2052, "http://www.hebnews.cn/"
[8383:8383:0712/145250.069720:INFO:CONSOLE(3)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://pos.baidu.com/dctm?psi=44d19a27fc5a70d4026dd3c3226e0505&di=3229987&dri=0&dis=0&dai=0&ps=2318x930&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562914334076&ti=%E6%B2%B3%E5%8C%97%E6%96%B0%E9%97%BB%E7%BD%91_%E6%B2%B3%E5%8C%97%E6%9C%80%E5%A4%A7%E7%9A%84%E7%BD%91%E7%BB%9C%E5%AA%92%E4%BD%93_%E6%B2%B3%E5%8C%97%E7%AC%AC%E4%B8%80%E6%96%B0%E9%97%BB%E9%97%A8%E6%88%B7%E7%BD%91%E7%AB%99_%E6%B2%B3%E5%8C%97%E6%97%A5%E6%8A%A5%E6%8A%A5%E4%B8%9A%E9%9B%86%E5%9B%A2%E4%B8%BB%E5%8A%9E&ari=2&dbv=2&drs=1&pcs=887x666&pss=1215x2424&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562914370&rw=681&ltu=http%3A%2F%2Fwww.hebnews.cn%2F&ecd=1&uc=1855x1056&pis=-1x-1&sr=1920x1080&tcn=1562914370&exps=110011, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://dup.baidustatic.com/js/ds.js (3)
[8383:8383:0712/145250.075084:INFO:CONSOLE(3)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://pos.baidu.com/dctm?psi=44d19a27fc5a70d4026dd3c3226e0505&di=3229987&dri=0&dis=0&dai=0&ps=2318x930&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562914334076&ti=%E6%B2%B3%E5%8C%97%E6%96%B0%E9%97%BB%E7%BD%91_%E6%B2%B3%E5%8C%97%E6%9C%80%E5%A4%A7%E7%9A%84%E7%BD%91%E7%BB%9C%E5%AA%92%E4%BD%93_%E6%B2%B3%E5%8C%97%E7%AC%AC%E4%B8%80%E6%96%B0%E9%97%BB%E9%97%A8%E6%88%B7%E7%BD%91%E7%AB%99_%E6%B2%B3%E5%8C%97%E6%97%A5%E6%8A%A5%E6%8A%A5%E4%B8%9A%E9%9B%86%E5%9B%A2%E4%B8%BB%E5%8A%9E&ari=2&dbv=2&drs=1&pcs=887x666&pss=1215x2424&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562914370&rw=681&ltu=http%3A%2F%2Fwww.hebnews.cn%2F&ecd=1&uc=1855x1056&pis=-1x-1&sr=1920x1080&tcn=1562914370&exps=110011, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://dup.baidustatic.com/js/ds.js (3)
[1:1:0712/145250.110774:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hebnews.cn/, 2054, 7fca8f5de881
[1:1:0712/145250.146218:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"144296482860","ptid":"1753 0x7fca8cc99070 0x2b6f4e7f0d60 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145250.146432:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hebnews.cn/","ptid":"1753 0x7fca8cc99070 0x2b6f4e7f0d60 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145250.146637:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145250.146889:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , (){qn=t}
[1:1:0712/145250.147012:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145250.147712:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2055, 7fca8f5de8db
[1:1:0712/145250.181920:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"144296482860","ptid":"1753 0x7fca8cc99070 0x2b6f4e7f0d60 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145250.182109:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hebnews.cn/","ptid":"1753 0x7fca8cc99070 0x2b6f4e7f0d60 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145250.182345:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2174
[1:1:0712/145250.182453:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2174 0x7fca8cc99070 0x2b6f4dfde2e0 , 5:3_http://www.hebnews.cn/, 0, , 2055 0x7fca8cc99070 0x2b6f4c5ca7e0 
[1:1:0712/145250.182628:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145250.182888:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , v.fx.tick, (){var e,n=v.timers,r=0;qn=v.now();for(;r<n.length;r++)e=n[r],!e()&&n[r]===e&&n.splice(r--,1);n.leng
[1:1:0712/145250.182994:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145250.265154:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2060, 7fca8f5de8db
[1:1:0712/145250.300052:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1917 0x7fca8cc99070 0x2b6f4d499860 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145250.300215:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1917 0x7fca8cc99070 0x2b6f4d499860 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145250.300441:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2176
[1:1:0712/145250.300540:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2176 0x7fca8cc99070 0x2b6f4ef28560 , 5:3_http://www.hebnews.cn/, 0, , 2060 0x7fca8cc99070 0x2b6f4d997160 
[1:1:0712/145250.300705:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145250.300946:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/145250.301054:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145250.337220:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2062, 7fca8f5de8db
[1:1:0712/145250.370910:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1918 0x7fca8cc99070 0x2b6f4dc45f60 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145250.371082:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1918 0x7fca8cc99070 0x2b6f4dc45f60 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145250.371308:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2178
[1:1:0712/145250.371414:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2178 0x7fca8cc99070 0x2b6f4ef241e0 , 5:3_http://www.hebnews.cn/, 0, , 2062 0x7fca8cc99070 0x2b6f4e5bb260 
[1:1:0712/145250.371590:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145250.371851:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , ab, (a){if(!A||M!=p||a||R){if(R?p>=1?p=1:0>=p&&(p=0):(O=p,p>=k?p=0:0>p&&(p=k-1)),S(),null!=n&&_(l.childr
[1:1:0712/145250.371937:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145250.388372:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3c17ca4629c8, 0x2b6f4c06d950
[1:1:0712/145250.388516:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hebnews.cn/", 0
[1:1:0712/145250.388678:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hebnews.cn/, 2179
[1:1:0712/145250.388772:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2179 0x7fca8cc99070 0x2b6f4ea1fb60 , 5:3_http://www.hebnews.cn/, 1, -5:3_http://www.hebnews.cn/, 2062 0x7fca8cc99070 0x2b6f4e5bb260 
[1:1:0712/145250.543951:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2015, 7fca8f5de8db
[1:1:0712/145250.577742:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1798 0x7fca8cc99070 0x2b6f4ea187e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145250.577926:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1798 0x7fca8cc99070 0x2b6f4ea187e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145250.578297:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2183
[1:1:0712/145250.578451:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2183 0x7fca8cc99070 0x2b6f4f414e60 , 5:3_http://www.hebnews.cn/, 0, , 2015 0x7fca8cc99070 0x2b6f4ee9fce0 
[1:1:0712/145250.578669:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145250.578977:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:6_http://www.hebnews.cn/, 1442965796c0, , , () { roll(); }
[1:1:0712/145250.579118:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 6, 1, http://www.hebnews.cn, www.hebnews.cn, 3
[1:1:0712/145250.817513:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , document.readyState
[1:1:0712/145250.817691:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145251.465520:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2082, 7fca8f5de8db
[1:1:0712/145251.498742:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1810 0x7fca8cc99070 0x2b6f4e96a3e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145251.498924:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1810 0x7fca8cc99070 0x2b6f4e96a3e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145251.499164:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2204
[1:1:0712/145251.499292:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2204 0x7fca8cc99070 0x2b6f4bb93d60 , 5:3_http://www.hebnews.cn/, 0, , 2082 0x7fca8cc99070 0x2b6f4d6985e0 
[1:1:0712/145251.499483:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145251.499755:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:8_http://www.hebnews.cn/, 144296532210, , , () { roll(); }
[1:1:0712/145251.499884:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 8, 1, http://www.hebnews.cn, www.hebnews.cn, 3
[1:1:0712/145251.668582:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2096, 7fca8f5de8db
[1:1:0712/145251.702299:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1948 0x7fca8cc99070 0x2b6f4e5637e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145251.702480:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1948 0x7fca8cc99070 0x2b6f4e5637e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145251.702714:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2206
[1:1:0712/145251.702836:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2206 0x7fca8cc99070 0x2b6f4c49d060 , 5:3_http://www.hebnews.cn/, 0, , 2096 0x7fca8cc99070 0x2b6f4ee5aae0 
[1:1:0712/145251.703029:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145251.703310:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/145251.703417:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145251.790578:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hebnews.cn/, 2100, 7fca8f5de881
[1:1:0712/145251.825617:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"144296482860","ptid":"1823 0x7fca8cc99070 0x2b6f4e915de0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145251.825870:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hebnews.cn/","ptid":"1823 0x7fca8cc99070 0x2b6f4e915de0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145251.826157:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145251.826483:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , (){qn=t}
[1:1:0712/145251.826599:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145251.827166:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2053, 7fca8f5de8db
[1:1:0712/145251.860976:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1753 0x7fca8cc99070 0x2b6f4e7f0d60 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145251.861227:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1753 0x7fca8cc99070 0x2b6f4e7f0d60 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145251.861597:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2210
[1:1:0712/145251.861796:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2210 0x7fca8cc99070 0x2b6f4f417060 , 5:3_http://www.hebnews.cn/, 0, , 2053 0x7fca8cc99070 0x2b6f4ef12c60 
[1:1:0712/145251.862067:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145251.862413:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , () {
                    $btn.last().click()
                }
[1:1:0712/145251.862771:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145251.877904:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3c17ca4629c8, 0x2b6f4c06d950
[1:1:0712/145251.878122:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hebnews.cn/", 0
[1:1:0712/145251.878336:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hebnews.cn/, 2211
[1:1:0712/145251.878454:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2211 0x7fca8cc99070 0x2b6f4ee556e0 , 5:3_http://www.hebnews.cn/, 1, -5:3_http://www.hebnews.cn/, 2053 0x7fca8cc99070 0x2b6f4ef12c60 
[1:1:0712/145251.887577:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hebnews.cn/", 13
[1:1:0712/145251.887841:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2212
[1:1:0712/145251.887953:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2212 0x7fca8cc99070 0x2b6f4f45f960 , 5:3_http://www.hebnews.cn/, 1, -5:3_http://www.hebnews.cn/, 2053 0x7fca8cc99070 0x2b6f4ef12c60 
[1:1:0712/145251.972370:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "click", "http://www.hebnews.cn/"
[1:1:0712/145252.282480:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2099, 7fca8f5de8db
[1:1:0712/145252.315571:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1823 0x7fca8cc99070 0x2b6f4e915de0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145252.315801:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1823 0x7fca8cc99070 0x2b6f4e915de0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145252.316110:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2222
[1:1:0712/145252.316272:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2222 0x7fca8cc99070 0x2b6f4ee55460 , 5:3_http://www.hebnews.cn/, 0, , 2099 0x7fca8cc99070 0x2b6f4ed64ce0 
[1:1:0712/145252.316520:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145252.316829:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , (){w?p--:p++,ab()}
[1:1:0712/145252.316930:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145252.422531:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2105, 7fca8f5de8db
[1:1:0712/145252.456493:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1828 0x7fca8cc99070 0x2b6f4c871ce0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145252.456683:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1828 0x7fca8cc99070 0x2b6f4c871ce0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145252.456925:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2225
[1:1:0712/145252.457062:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2225 0x7fca8cc99070 0x2b6f4ee5a260 , 5:3_http://www.hebnews.cn/, 0, , 2105 0x7fca8cc99070 0x2b6f4ed7bd60 
[1:1:0712/145252.457288:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145252.457608:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:7_http://www.hebnews.cn/, 14429654c330, , , () { roll(); }
[1:1:0712/145252.457777:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 7, 1, http://www.hebnews.cn, www.hebnews.cn, 3
[1:1:0712/145254.420017:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2176, 7fca8f5de8db
[1:1:0712/145254.454822:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"2060 0x7fca8cc99070 0x2b6f4d997160 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145254.454992:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"2060 0x7fca8cc99070 0x2b6f4d997160 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145254.455222:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2293
[1:1:0712/145254.455324:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2293 0x7fca8cc99070 0x2b6f4c965460 , 5:3_http://www.hebnews.cn/, 0, , 2176 0x7fca8cc99070 0x2b6f4ef28560 
[1:1:0712/145254.455488:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145254.455732:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/145254.455832:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145254.456626:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hebnews.cn/, 2179, 7fca8f5de881
[1:1:0712/145254.491459:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"144296482860","ptid":"2062 0x7fca8cc99070 0x2b6f4e5bb260 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145254.491635:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hebnews.cn/","ptid":"2062 0x7fca8cc99070 0x2b6f4e5bb260 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145254.491849:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145254.492107:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , (){qn=t}
[1:1:0712/145254.492208:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145254.563909:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2178, 7fca8f5de8db
[1:1:0712/145254.599524:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"2062 0x7fca8cc99070 0x2b6f4e5bb260 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145254.599706:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"2062 0x7fca8cc99070 0x2b6f4e5bb260 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145254.599951:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2296
[1:1:0712/145254.600069:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2296 0x7fca8cc99070 0x2b6f4cc5f760 , 5:3_http://www.hebnews.cn/, 0, , 2178 0x7fca8cc99070 0x2b6f4ef241e0 
[1:1:0712/145254.600260:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145254.600546:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , ab, (a){if(!A||M!=p||a||R){if(R?p>=1?p=1:0>=p&&(p=0):(O=p,p>=k?p=0:0>p&&(p=k-1)),S(),null!=n&&_(l.childr
[1:1:0712/145254.600651:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145254.611528:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3c17ca4629c8, 0x2b6f4c06d950
[1:1:0712/145254.611667:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hebnews.cn/", 0
[1:1:0712/145254.611878:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hebnews.cn/, 2297
[1:1:0712/145254.612028:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2297 0x7fca8cc99070 0x2b6f4f45c4e0 , 5:3_http://www.hebnews.cn/, 1, -5:3_http://www.hebnews.cn/, 2178 0x7fca8cc99070 0x2b6f4ef241e0 
[1:1:0712/145254.629625:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2037, 7fca8f5de8db
[1:1:0712/145254.665873:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"144296482860144296519748","ptid":"1912","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145254.666061:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hebnews.cn/-5:11_http://www.hebnews.cn/","ptid":"1912","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145254.666294:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2300
[1:1:0712/145254.666404:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2300 0x7fca8cc99070 0x2b6f4f6ca6e0 , 5:3_http://www.hebnews.cn/, 0, , 2037 0x7fca8cc99070 0x2b6f4ed792e0 
[1:1:0712/145254.666583:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145254.666844:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:11_http://www.hebnews.cn/, 144296519748, , , () { roll(); }
[1:1:0712/145254.666970:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 11, 1, http://www.hebnews.cn, www.hebnews.cn, 3
[1:1:0712/145254.847746:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , document.readyState
[1:1:0712/145254.847900:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145255.065962:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2183, 7fca8f5de8db
[1:1:0712/145255.101160:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"2015 0x7fca8cc99070 0x2b6f4ee9fce0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145255.101325:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"2015 0x7fca8cc99070 0x2b6f4ee9fce0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145255.101560:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2309
[1:1:0712/145255.101672:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2309 0x7fca8cc99070 0x2b6f4f7157e0 , 5:3_http://www.hebnews.cn/, 0, , 2183 0x7fca8cc99070 0x2b6f4f414e60 
[1:1:0712/145255.101844:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145255.102105:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:6_http://www.hebnews.cn/, 1442965796c0, , , () { roll(); }
[1:1:0712/145255.102241:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 6, 1, http://www.hebnews.cn, www.hebnews.cn, 3
[1:1:0712/145255.318425:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2206, 7fca8f5de8db
[1:1:0712/145255.353358:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"2096 0x7fca8cc99070 0x2b6f4ee5aae0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145255.353527:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"2096 0x7fca8cc99070 0x2b6f4ee5aae0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145255.353736:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2312
[1:1:0712/145255.353832:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2312 0x7fca8cc99070 0x2b6f4d4b7660 , 5:3_http://www.hebnews.cn/, 0, , 2206 0x7fca8cc99070 0x2b6f4c49d060 
[1:1:0712/145255.353974:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145255.354252:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/145255.354369:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145255.477867:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hebnews.cn/, 2211, 7fca8f5de881
[1:1:0712/145255.514032:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"144296482860","ptid":"2053 0x7fca8cc99070 0x2b6f4ef12c60 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145255.514294:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hebnews.cn/","ptid":"2053 0x7fca8cc99070 0x2b6f4ef12c60 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145255.514593:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145255.514977:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , (){qn=t}
[1:1:0712/145255.515111:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145255.587296:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2212, 7fca8f5de8db
[1:1:0712/145255.622453:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"144296482860","ptid":"2053 0x7fca8cc99070 0x2b6f4ef12c60 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145255.622672:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hebnews.cn/","ptid":"2053 0x7fca8cc99070 0x2b6f4ef12c60 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145255.622955:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2318
[1:1:0712/145255.623070:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2318 0x7fca8cc99070 0x2b6f4dfe0360 , 5:3_http://www.hebnews.cn/, 0, , 2212 0x7fca8cc99070 0x2b6f4f45f960 
[1:1:0712/145255.623256:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145255.623522:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , v.fx.tick, (){var e,n=v.timers,r=0;qn=v.now();for(;r<n.length;r++)e=n[r],!e()&&n[r]===e&&n.splice(r--,1);n.leng
[1:1:0712/145255.623622:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145255.675480:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2204, 7fca8f5de8db
[1:1:0712/145255.711672:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"2082 0x7fca8cc99070 0x2b6f4d6985e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145255.711918:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"2082 0x7fca8cc99070 0x2b6f4d6985e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145255.712184:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2320
[1:1:0712/145255.712318:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2320 0x7fca8cc99070 0x2b6f4f6ccce0 , 5:3_http://www.hebnews.cn/, 0, , 2204 0x7fca8cc99070 0x2b6f4bb93d60 
[1:1:0712/145255.712548:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145255.712829:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:8_http://www.hebnews.cn/, 144296532210, , , () { roll(); }
[1:1:0712/145255.712955:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 8, 1, http://www.hebnews.cn, www.hebnews.cn, 3
[1:1:0712/145255.972654:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2222, 7fca8f5de8db
[1:1:0712/145256.011657:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"2099 0x7fca8cc99070 0x2b6f4ed64ce0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145256.011844:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"2099 0x7fca8cc99070 0x2b6f4ed64ce0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145256.012126:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2327
[1:1:0712/145256.012259:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2327 0x7fca8cc99070 0x2b6f4f4a8260 , 5:3_http://www.hebnews.cn/, 0, , 2222 0x7fca8cc99070 0x2b6f4ee55460 
[1:1:0712/145256.012467:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145256.012746:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , (){w?p--:p++,ab()}
[1:1:0712/145256.012846:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145256.031665:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3c17ca4629c8, 0x2b6f4c06d950
[1:1:0712/145256.031829:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hebnews.cn/", 0
[1:1:0712/145256.032032:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hebnews.cn/, 2328
[1:1:0712/145256.032169:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2328 0x7fca8cc99070 0x2b6f4f6ed9e0 , 5:3_http://www.hebnews.cn/, 1, -5:3_http://www.hebnews.cn/, 2222 0x7fca8cc99070 0x2b6f4ee55460 
[1:1:0712/145256.043110:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hebnews.cn/", 13
[1:1:0712/145256.043326:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2329
[1:1:0712/145256.043447:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2329 0x7fca8cc99070 0x2b6f4dff02e0 , 5:3_http://www.hebnews.cn/, 1, -5:3_http://www.hebnews.cn/, 2222 0x7fca8cc99070 0x2b6f4ee55460 
[1:1:0712/145256.051352:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2225, 7fca8f5de8db
[1:1:0712/145256.091703:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"2105 0x7fca8cc99070 0x2b6f4ed7bd60 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145256.091895:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"2105 0x7fca8cc99070 0x2b6f4ed7bd60 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145256.092145:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2333
[1:1:0712/145256.092255:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2333 0x7fca8cc99070 0x2b6f4f6cc0e0 , 5:3_http://www.hebnews.cn/, 0, , 2225 0x7fca8cc99070 0x2b6f4ee5a260 
[1:1:0712/145256.092443:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145256.092686:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:7_http://www.hebnews.cn/, 14429654c330, , , () { roll(); }
[1:1:0712/145256.092807:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 7, 1, http://www.hebnews.cn, www.hebnews.cn, 3
[1:1:0712/145256.135712:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 2236 0x7fcaa3324080 0x2b6f4ea8fec0 1 0 0x2b6f4ea8fed8 , "http://tianqi.2345.com/plugin/widget/index.htm?s=3&z=3&t=0&v=0&d=2&bd=0&k=&f=&q=1&e=1&a=1&c=53698&w=180&h=36&align=left"
[1:1:0712/145256.139931:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://tianqi.2345.com/, 144296588e58, , , var country = [];
country['africa']="algeria-A 阿尔及利亚-algeria|angola-A 安哥拉-angola|egy
[1:1:0712/145256.140091:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tianqi.2345.com/plugin/widget/index.htm?s=3&z=3&t=0&v=0&d=2&bd=0&k=&f=&q=1&e=1&a=1&c=53698&w=180&h=36&align=left", "tianqi.2345.com", 4, 1, http://www.hebnews.cn, www.hebnews.cn, 3
[1:1:0712/145256.142200:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 2236 0x7fcaa3324080 0x2b6f4ea8fec0 1 0 0x2b6f4ea8fed8 , "http://tianqi.2345.com/plugin/widget/index.htm?s=3&z=3&t=0&v=0&d=2&bd=0&k=&f=&q=1&e=1&a=1&c=53698&w=180&h=36&align=left"
[1:1:0712/145256.147450:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 2236 0x7fcaa3324080 0x2b6f4ea8fec0 1 0 0x2b6f4ea8fed8 , "http://tianqi.2345.com/plugin/widget/index.htm?s=3&z=3&t=0&v=0&d=2&bd=0&k=&f=&q=1&e=1&a=1&c=53698&w=180&h=36&align=left"
[1:1:0712/145256.170721:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 2236 0x7fcaa3324080 0x2b6f4ea8fec0 1 0 0x2b6f4ea8fed8 , "http://tianqi.2345.com/plugin/widget/index.htm?s=3&z=3&t=0&v=0&d=2&bd=0&k=&f=&q=1&e=1&a=1&c=53698&w=180&h=36&align=left"
[1:1:0712/145256.175789:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://tianqi.2345.com/plugin/widget/index.htm?s=3&z=3&t=0&v=0&d=2&bd=0&k=&f=&q=1&e=1&a=1&c=53698&w=180&h=36&align=left"
[1:1:0712/145256.445205:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2210, 7fca8f5de8db
[1:1:0712/145256.483668:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"2053 0x7fca8cc99070 0x2b6f4ef12c60 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145256.483878:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"2053 0x7fca8cc99070 0x2b6f4ef12c60 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145256.484157:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2363
[1:1:0712/145256.484299:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2363 0x7fca8cc99070 0x2b6f4f6edc60 , 5:3_http://www.hebnews.cn/, 0, , 2210 0x7fca8cc99070 0x2b6f4f417060 
[1:1:0712/145256.484512:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145256.484828:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , () {
                    $btn.last().click()
                }
[1:1:0712/145256.484924:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145256.596739:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "click", "http://www.hebnews.cn/"
[1:1:0712/145259.129886:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2293, 7fca8f5de8db
[1:1:0712/145259.166215:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"2176 0x7fca8cc99070 0x2b6f4ef28560 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145259.166376:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"2176 0x7fca8cc99070 0x2b6f4ef28560 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145259.166607:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2437
[1:1:0712/145259.166706:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2437 0x7fca8cc99070 0x2b6f4f4a63e0 , 5:3_http://www.hebnews.cn/, 0, , 2293 0x7fca8cc99070 0x2b6f4c965460 
[1:1:0712/145259.166880:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145259.167125:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/145259.167212:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145259.207845:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hebnews.cn/, 2297, 7fca8f5de881
[1:1:0712/145259.246023:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"144296482860","ptid":"2178 0x7fca8cc99070 0x2b6f4ef241e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145259.246223:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hebnews.cn/","ptid":"2178 0x7fca8cc99070 0x2b6f4ef241e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145259.246494:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145259.246802:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , (){qn=t}
[1:1:0712/145259.246918:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145259.284866:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2296, 7fca8f5de8db
[1:1:0712/145259.321574:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"2178 0x7fca8cc99070 0x2b6f4ef241e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145259.321761:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"2178 0x7fca8cc99070 0x2b6f4ef241e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145259.321995:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2444
[1:1:0712/145259.322092:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2444 0x7fca8cc99070 0x2b6f4f628de0 , 5:3_http://www.hebnews.cn/, 0, , 2296 0x7fca8cc99070 0x2b6f4cc5f760 
[1:1:0712/145259.322259:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145259.322522:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , ab, (a){if(!A||M!=p||a||R){if(R?p>=1?p=1:0>=p&&(p=0):(O=p,p>=k?p=0:0>p&&(p=k-1)),S(),null!=n&&_(l.childr
[1:1:0712/145259.322634:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145259.333999:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3c17ca4629c8, 0x2b6f4c06d950
[1:1:0712/145259.334140:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hebnews.cn/", 0
[1:1:0712/145259.334297:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hebnews.cn/, 2445
[1:1:0712/145259.334394:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2445 0x7fca8cc99070 0x2b6f4f6341e0 , 5:3_http://www.hebnews.cn/, 1, -5:3_http://www.hebnews.cn/, 2296 0x7fca8cc99070 0x2b6f4cc5f760 
[1:1:0712/145259.539217:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , document.readyState
[1:1:0712/145259.539376:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145259.804560:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2300, 7fca8f5de8db
[1:1:0712/145259.841587:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"2037 0x7fca8cc99070 0x2b6f4ed792e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145259.841770:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"2037 0x7fca8cc99070 0x2b6f4ed792e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145259.842084:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2453
[1:1:0712/145259.842225:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2453 0x7fca8cc99070 0x2b6f4f45f060 , 5:3_http://www.hebnews.cn/, 0, , 2300 0x7fca8cc99070 0x2b6f4f6ca6e0 
[1:1:0712/145259.842464:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145259.842724:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:11_http://www.hebnews.cn/, 144296519748, , , () { roll(); }
[1:1:0712/145259.842849:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 11, 1, http://www.hebnews.cn, www.hebnews.cn, 3
[1:1:0712/145259.919104:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2312, 7fca8f5de8db
[1:1:0712/145259.956128:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"2206 0x7fca8cc99070 0x2b6f4c49d060 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145259.956297:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"2206 0x7fca8cc99070 0x2b6f4c49d060 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145259.956530:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2454
[1:1:0712/145259.956641:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2454 0x7fca8cc99070 0x2b6f4f9a13e0 , 5:3_http://www.hebnews.cn/, 0, , 2312 0x7fca8cc99070 0x2b6f4d4b7660 
[1:1:0712/145259.956807:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145259.957096:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/145259.957200:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145300.239229:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hebnews.cn/, 2328, 7fca8f5de881
[1:1:0712/145300.276605:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"144296482860","ptid":"2222 0x7fca8cc99070 0x2b6f4ee55460 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145300.276815:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hebnews.cn/","ptid":"2222 0x7fca8cc99070 0x2b6f4ee55460 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145300.277084:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145300.277392:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , (){qn=t}
[1:1:0712/145300.277520:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145300.353503:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2329, 7fca8f5de8db
[1:1:0712/145300.390653:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"144296482860","ptid":"2222 0x7fca8cc99070 0x2b6f4ee55460 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145300.390885:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hebnews.cn/","ptid":"2222 0x7fca8cc99070 0x2b6f4ee55460 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145300.391210:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2460
[1:1:0712/145300.391404:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2460 0x7fca8cc99070 0x2b6f4faa8260 , 5:3_http://www.hebnews.cn/, 0, , 2329 0x7fca8cc99070 0x2b6f4dff02e0 
[1:1:0712/145300.391648:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145300.391974:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , v.fx.tick, (){var e,n=v.timers,r=0;qn=v.now();for(;r<n.length;r++)e=n[r],!e()&&n[r]===e&&n.splice(r--,1);n.leng
[1:1:0712/145300.392105:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145300.744097:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2309, 7fca8f5de8db
[1:1:0712/145300.781265:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"2183 0x7fca8cc99070 0x2b6f4f414e60 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145300.781495:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"2183 0x7fca8cc99070 0x2b6f4f414e60 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145300.781778:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2463
[1:1:0712/145300.781942:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2463 0x7fca8cc99070 0x2b6f4f4173e0 , 5:3_http://www.hebnews.cn/, 0, , 2309 0x7fca8cc99070 0x2b6f4f7157e0 
[1:1:0712/145300.782168:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145300.782489:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:6_http://www.hebnews.cn/, 1442965796c0, , , () { roll(); }
[1:1:0712/145300.782622:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 6, 1, http://www.hebnews.cn, www.hebnews.cn, 3
[1:1:0712/145301.203906:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2320, 7fca8f5de8db
[1:1:0712/145301.242606:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"2204 0x7fca8cc99070 0x2b6f4bb93d60 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145301.242777:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"2204 0x7fca8cc99070 0x2b6f4bb93d60 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145301.242985:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2470
[1:1:0712/145301.243129:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2470 0x7fca8cc99070 0x2b6f4f999260 , 5:3_http://www.hebnews.cn/, 0, , 2320 0x7fca8cc99070 0x2b6f4f6ccce0 
[1:1:0712/145301.243377:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145301.243666:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:8_http://www.hebnews.cn/, 144296532210, , , () { roll(); }
[1:1:0712/145301.243813:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 8, 1, http://www.hebnews.cn, www.hebnews.cn, 3
[1:1:0712/145301.438220:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2327, 7fca8f5de8db
[1:1:0712/145301.475736:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"2222 0x7fca8cc99070 0x2b6f4ee55460 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145301.475950:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"2222 0x7fca8cc99070 0x2b6f4ee55460 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145301.476217:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2475
[1:1:0712/145301.476375:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2475 0x7fca8cc99070 0x2b6f4f9bec60 , 5:3_http://www.hebnews.cn/, 0, , 2327 0x7fca8cc99070 0x2b6f4f4a8260 
[1:1:0712/145301.476591:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145301.476846:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , (){w?p--:p++,ab()}
[1:1:0712/145301.476942:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145301.495106:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3c17ca4629c8, 0x2b6f4c06d950
[1:1:0712/145301.495335:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hebnews.cn/", 0
[1:1:0712/145301.495567:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hebnews.cn/, 2476
[1:1:0712/145301.495703:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2476 0x7fca8cc99070 0x2b6f4fac88e0 , 5:3_http://www.hebnews.cn/, 1, -5:3_http://www.hebnews.cn/, 2327 0x7fca8cc99070 0x2b6f4f4a8260 
[1:1:0712/145301.505818:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hebnews.cn/", 13
[1:1:0712/145301.506015:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2477
[1:1:0712/145301.506132:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2477 0x7fca8cc99070 0x2b6f4f997960 , 5:3_http://www.hebnews.cn/, 1, -5:3_http://www.hebnews.cn/, 2327 0x7fca8cc99070 0x2b6f4f4a8260 
[1:1:0712/145301.550213:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2333, 7fca8f5de8db
[1:1:0712/145301.585829:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"2225 0x7fca8cc99070 0x2b6f4ee5a260 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145301.585996:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"2225 0x7fca8cc99070 0x2b6f4ee5a260 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145301.586219:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2481
[1:1:0712/145301.586327:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2481 0x7fca8cc99070 0x2b6f4f993ee0 , 5:3_http://www.hebnews.cn/, 0, , 2333 0x7fca8cc99070 0x2b6f4f6cc0e0 
[1:1:0712/145301.586519:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145301.586797:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:7_http://www.hebnews.cn/, 14429654c330, , , () { roll(); }
[1:1:0712/145301.586922:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 7, 1, http://www.hebnews.cn, www.hebnews.cn, 3
[1:1:0712/145302.954274:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2437, 7fca8f5de8db
[1:1:0712/145302.996736:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"2293 0x7fca8cc99070 0x2b6f4c965460 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145302.996897:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"2293 0x7fca8cc99070 0x2b6f4c965460 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145302.997202:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2502
[1:1:0712/145302.997305:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2502 0x7fca8cc99070 0x2b6f4f9971e0 , 5:3_http://www.hebnews.cn/, 0, , 2437 0x7fca8cc99070 0x2b6f4f4a63e0 
[1:1:0712/145302.997466:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145302.997713:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/145302.997827:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145302.998695:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2363, 7fca8f5de8db
[1:1:0712/145303.040174:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"2210 0x7fca8cc99070 0x2b6f4f417060 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145303.040346:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"2210 0x7fca8cc99070 0x2b6f4f417060 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145303.040687:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2507
[1:1:0712/145303.040806:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2507 0x7fca8cc99070 0x2b6f4fb260e0 , 5:3_http://www.hebnews.cn/, 0, , 2363 0x7fca8cc99070 0x2b6f4f6edc60 
[1:1:0712/145303.041010:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145303.041324:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , () {
                    $btn.last().click()
                }
[1:1:0712/145303.041436:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145303.159000:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "click", "http://www.hebnews.cn/"
[1:1:0712/145303.160061:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hebnews.cn/, 2445, 7fca8f5de881
[1:1:0712/145303.200887:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"144296482860","ptid":"2296 0x7fca8cc99070 0x2b6f4cc5f760 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145303.201103:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hebnews.cn/","ptid":"2296 0x7fca8cc99070 0x2b6f4cc5f760 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145303.201338:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145303.201615:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , (){qn=t}
[1:1:0712/145303.201729:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145303.276180:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , document.readyState
[1:1:0712/145303.276370:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145303.277760:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2444, 7fca8f5de8db
[1:1:0712/145303.316483:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"2296 0x7fca8cc99070 0x2b6f4cc5f760 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145303.316643:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"2296 0x7fca8cc99070 0x2b6f4cc5f760 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145303.316857:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2522
[1:1:0712/145303.316955:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2522 0x7fca8cc99070 0x2b6f4fb38a60 , 5:3_http://www.hebnews.cn/, 0, , 2444 0x7fca8cc99070 0x2b6f4f628de0 
[1:1:0712/145303.317184:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145303.317518:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , ab, (a){if(!A||M!=p||a||R){if(R?p>=1?p=1:0>=p&&(p=0):(O=p,p>=k?p=0:0>p&&(p=k-1)),S(),null!=n&&_(l.childr
[1:1:0712/145303.317633:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145303.334748:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3c17ca4629c8, 0x2b6f4c06d950
[1:1:0712/145303.334884:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hebnews.cn/", 0
[1:1:0712/145303.335055:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hebnews.cn/, 2523
[1:1:0712/145303.335173:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2523 0x7fca8cc99070 0x2b6f4f755360 , 5:3_http://www.hebnews.cn/, 1, -5:3_http://www.hebnews.cn/, 2444 0x7fca8cc99070 0x2b6f4f628de0 
[1:1:0712/145303.673859:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2454, 7fca8f5de8db
[1:1:0712/145303.712344:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"2312 0x7fca8cc99070 0x2b6f4d4b7660 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145303.712536:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"2312 0x7fca8cc99070 0x2b6f4d4b7660 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145303.712782:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2535
[1:1:0712/145303.712908:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2535 0x7fca8cc99070 0x2b6f4f9a0960 , 5:3_http://www.hebnews.cn/, 0, , 2454 0x7fca8cc99070 0x2b6f4f9a13e0 
[1:1:0712/145303.713106:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145303.713408:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/145303.713526:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145303.800056:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2453, 7fca8f5de8db
[1:1:0712/145303.839716:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"2300 0x7fca8cc99070 0x2b6f4f6ca6e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145303.839884:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"2300 0x7fca8cc99070 0x2b6f4f6ca6e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145303.840118:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2539
[1:1:0712/145303.840238:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2539 0x7fca8cc99070 0x2b6f4fb22be0 , 5:3_http://www.hebnews.cn/, 0, , 2453 0x7fca8cc99070 0x2b6f4f45f060 
[1:1:0712/145303.840415:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145303.840655:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:11_http://www.hebnews.cn/, 144296519748, , , () { roll(); }
[1:1:0712/145303.840767:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 11, 1, http://www.hebnews.cn, www.hebnews.cn, 3
[1:1:0712/145303.919094:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 2465 0x7fca8ebc12e0 0x2b6f4f49ece0 , "http://tianqi.2345.com/plugin/widget/index.htm?s=3&z=3&t=0&v=0&d=2&bd=0&k=&f=&q=1&e=1&a=1&c=53698&w=180&h=36&align=left"
[1:1:0712/145303.919868:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://tianqi.2345.com/, 144296588e58, , , setDefaultDzWea('71144');var wea_ = {city:"海淀",dayType:"15",day1:["21～34℃","五","多云","�
[1:1:0712/145303.920025:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tianqi.2345.com/plugin/widget/index.htm?s=3&z=3&t=0&v=0&d=2&bd=0&k=&f=&q=1&e=1&a=1&c=53698&w=180&h=36&align=left", "tianqi.2345.com", 4, 1, http://www.hebnews.cn, www.hebnews.cn, 3
		remove user.f_e3a28417 -> 0
[1:1:0712/145303.942529:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://tianqi.2345.com/plugin/widget/index.htm?s=3&z=3&t=0&v=0&d=2&bd=0&k=&f=&q=1&e=1&a=1&c=53698&w=180&h=36&align=left"
[1:1:0712/145304.098468:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://tianqi.2345.com/plugin/widget/index.htm?s=3&z=3&t=0&v=0&d=2&bd=0&k=&f=&q=1&e=1&a=1&c=53698&w=180&h=36&align=left"
[1:1:0712/145304.098991:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://tianqi.2345.com/, 144296588e58, , ready, (e){if(e===!0?--v.readyWait:v.isReady)return;if(!i.body)return setTimeout(v.ready,1);v.isReady=!0;if
[1:1:0712/145304.099155:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tianqi.2345.com/plugin/widget/index.htm?s=3&z=3&t=0&v=0&d=2&bd=0&k=&f=&q=1&e=1&a=1&c=53698&w=180&h=36&align=left", "tianqi.2345.com", 4, 1, http://www.hebnews.cn, www.hebnews.cn, 3
[1:1:0712/145304.117875:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2463, 7fca8f5de8db
[1:1:0712/145304.157123:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"2309 0x7fca8cc99070 0x2b6f4f7157e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145304.157338:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"2309 0x7fca8cc99070 0x2b6f4f7157e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145304.157620:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2548
[1:1:0712/145304.157780:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2548 0x7fca8cc99070 0x2b6f4eaea2e0 , 5:3_http://www.hebnews.cn/, 0, , 2463 0x7fca8cc99070 0x2b6f4f4173e0 
[1:1:0712/145304.158021:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145304.158286:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:6_http://www.hebnews.cn/, 1442965796c0, , , () { roll(); }
[1:1:0712/145304.158402:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 6, 1, http://www.hebnews.cn, www.hebnews.cn, 3
[1:1:0712/145304.276577:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hebnews.cn/, 2476, 7fca8f5de881
[1:1:0712/145304.315136:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"144296482860","ptid":"2327 0x7fca8cc99070 0x2b6f4f4a8260 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145304.315351:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hebnews.cn/","ptid":"2327 0x7fca8cc99070 0x2b6f4f4a8260 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145304.315567:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145304.315819:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , (){qn=t}
[1:1:0712/145304.315914:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145304.316404:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2477, 7fca8f5de8db
[1:1:0712/145304.355419:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"144296482860","ptid":"2327 0x7fca8cc99070 0x2b6f4f4a8260 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145304.355595:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hebnews.cn/","ptid":"2327 0x7fca8cc99070 0x2b6f4f4a8260 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145304.355820:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2550
[1:1:0712/145304.355918:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2550 0x7fca8cc99070 0x2b6f4fb3d8e0 , 5:3_http://www.hebnews.cn/, 0, , 2477 0x7fca8cc99070 0x2b6f4f997960 
[1:1:0712/145304.356072:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145304.356357:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , v.fx.tick, (){var e,n=v.timers,r=0;qn=v.now();for(;r<n.length;r++)e=n[r],!e()&&n[r]===e&&n.splice(r--,1);n.leng
[1:1:0712/145304.356459:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145304.488744:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2470, 7fca8f5de8db
[1:1:0712/145304.527135:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"2320 0x7fca8cc99070 0x2b6f4f6ccce0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145304.527344:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"2320 0x7fca8cc99070 0x2b6f4f6ccce0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145304.527634:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2553
[1:1:0712/145304.527821:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2553 0x7fca8cc99070 0x2b6f4fb2f760 , 5:3_http://www.hebnews.cn/, 0, , 2470 0x7fca8cc99070 0x2b6f4f999260 
[1:1:0712/145304.528047:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145304.528359:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:8_http://www.hebnews.cn/, 144296532210, , , () { roll(); }
[1:1:0712/145304.528504:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 8, 1, http://www.hebnews.cn, www.hebnews.cn, 3
[1:1:0712/145304.609988:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2475, 7fca8f5de8db
[1:1:0712/145304.649265:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"2327 0x7fca8cc99070 0x2b6f4f4a8260 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145304.649471:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"2327 0x7fca8cc99070 0x2b6f4f4a8260 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145304.649795:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2559
[1:1:0712/145304.649957:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2559 0x7fca8cc99070 0x2b6f4fb2e5e0 , 5:3_http://www.hebnews.cn/, 0, , 2475 0x7fca8cc99070 0x2b6f4f9bec60 
[1:1:0712/145304.650156:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145304.650434:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , (){w?p--:p++,ab()}
[1:1:0712/145304.650547:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145304.668780:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3c17ca4629c8, 0x2b6f4c06d950
[1:1:0712/145304.668924:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hebnews.cn/", 0
[1:1:0712/145304.669222:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hebnews.cn/, 2560
[1:1:0712/145304.669341:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2560 0x7fca8cc99070 0x2b6f4f99d8e0 , 5:3_http://www.hebnews.cn/, 1, -5:3_http://www.hebnews.cn/, 2475 0x7fca8cc99070 0x2b6f4f9bec60 
[1:1:0712/145304.679399:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hebnews.cn/", 13
[1:1:0712/145304.679653:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2561
[1:1:0712/145304.679800:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2561 0x7fca8cc99070 0x2b6f4fb2f360 , 5:3_http://www.hebnews.cn/, 1, -5:3_http://www.hebnews.cn/, 2475 0x7fca8cc99070 0x2b6f4f9bec60 
[1:1:0712/145304.728600:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2481, 7fca8f5de8db
[1:1:0712/145304.767866:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"2333 0x7fca8cc99070 0x2b6f4f6cc0e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145304.768079:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"2333 0x7fca8cc99070 0x2b6f4f6cc0e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145304.768357:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2567
[1:1:0712/145304.768521:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2567 0x7fca8cc99070 0x2b6f4e6dc360 , 5:3_http://www.hebnews.cn/, 0, , 2481 0x7fca8cc99070 0x2b6f4f993ee0 
[1:1:0712/145304.768725:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145304.769012:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:7_http://www.hebnews.cn/, 14429654c330, , , () { roll(); }
[1:1:0712/145304.769238:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 7, 1, http://www.hebnews.cn, www.hebnews.cn, 3
[1:1:0712/145305.364337:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2502, 7fca8f5de8db
[1:1:0712/145305.402499:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"2437 0x7fca8cc99070 0x2b6f4f4a63e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145305.402720:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"2437 0x7fca8cc99070 0x2b6f4f4a63e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145305.403010:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2578
[1:1:0712/145305.403172:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2578 0x7fca8cc99070 0x2b6f4fc494e0 , 5:3_http://www.hebnews.cn/, 0, , 2502 0x7fca8cc99070 0x2b6f4f9971e0 
[1:1:0712/145305.403413:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145305.403729:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/145305.403876:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145305.638825:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , document.readyState
[1:1:0712/145305.639005:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145305.678420:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hebnews.cn/, 2523, 7fca8f5de881
[1:1:0712/145305.715967:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"144296482860","ptid":"2444 0x7fca8cc99070 0x2b6f4f628de0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145305.716159:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hebnews.cn/","ptid":"2444 0x7fca8cc99070 0x2b6f4f628de0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145305.716389:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145305.716661:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , (){qn=t}
[1:1:0712/145305.716764:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145305.717312:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2522, 7fca8f5de8db
[1:1:0712/145305.755780:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"2444 0x7fca8cc99070 0x2b6f4f628de0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145305.755976:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"2444 0x7fca8cc99070 0x2b6f4f628de0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145305.756232:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2586
[1:1:0712/145305.756363:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2586 0x7fca8cc99070 0x2b6f4fb26d60 , 5:3_http://www.hebnews.cn/, 0, , 2522 0x7fca8cc99070 0x2b6f4fb38a60 
[1:1:0712/145305.756564:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145305.756849:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , ab, (a){if(!A||M!=p||a||R){if(R?p>=1?p=1:0>=p&&(p=0):(O=p,p>=k?p=0:0>p&&(p=k-1)),S(),null!=n&&_(l.childr
[1:1:0712/145305.756946:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145305.767877:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3c17ca4629c8, 0x2b6f4c06d950
[1:1:0712/145305.768017:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hebnews.cn/", 0
[1:1:0712/145305.768174:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hebnews.cn/, 2587
[1:1:0712/145305.768284:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2587 0x7fca8cc99070 0x2b6f4fb39de0 , 5:3_http://www.hebnews.cn/, 1, -5:3_http://www.hebnews.cn/, 2522 0x7fca8cc99070 0x2b6f4fb38a60 
[1:1:0712/145306.139711:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2535, 7fca8f5de8db
[1:1:0712/145306.178686:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"2454 0x7fca8cc99070 0x2b6f4f9a13e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145306.178928:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"2454 0x7fca8cc99070 0x2b6f4f9a13e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145306.179314:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2594
[1:1:0712/145306.179486:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2594 0x7fca8cc99070 0x2b6f4f6ccee0 , 5:3_http://www.hebnews.cn/, 0, , 2535 0x7fca8cc99070 0x2b6f4f9a0960 
[1:1:0712/145306.179689:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145306.179992:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/145306.180107:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145306.787503:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hebnews.cn/, 2560, 7fca8f5de881
[1:1:0712/145306.826922:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"144296482860","ptid":"2475 0x7fca8cc99070 0x2b6f4f9bec60 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145306.827120:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hebnews.cn/","ptid":"2475 0x7fca8cc99070 0x2b6f4f9bec60 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145306.827382:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145306.827734:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , (){qn=t}
[1:1:0712/145306.827871:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145306.828615:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2561, 7fca8f5de8db
[1:1:0712/145306.868497:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"144296482860","ptid":"2475 0x7fca8cc99070 0x2b6f4f9bec60 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145306.868692:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hebnews.cn/","ptid":"2475 0x7fca8cc99070 0x2b6f4f9bec60 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145306.868936:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2605
[1:1:0712/145306.869082:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2605 0x7fca8cc99070 0x2b6f4fadeae0 , 5:3_http://www.hebnews.cn/, 0, , 2561 0x7fca8cc99070 0x2b6f4fb2f360 
[1:1:0712/145306.869299:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145306.869581:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , v.fx.tick, (){var e,n=v.timers,r=0;qn=v.now();for(;r<n.length;r++)e=n[r],!e()&&n[r]===e&&n.splice(r--,1);n.leng
[1:1:0712/145306.869704:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145307.111708:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2507, 7fca8f5de8db
[1:1:0712/145307.151309:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"2363 0x7fca8cc99070 0x2b6f4f6edc60 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145307.151478:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"2363 0x7fca8cc99070 0x2b6f4f6edc60 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145307.151701:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2608
[1:1:0712/145307.151798:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2608 0x7fca8cc99070 0x2b6f4fad89e0 , 5:3_http://www.hebnews.cn/, 0, , 2507 0x7fca8cc99070 0x2b6f4fb260e0 
[1:1:0712/145307.151944:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145307.152200:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , () {
                    $btn.last().click()
                }
[1:1:0712/145307.152301:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145307.168347:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3c17ca4629c8, 0x2b6f4c06d950
[1:1:0712/145307.168493:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hebnews.cn/", 0
[1:1:0712/145307.168650:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hebnews.cn/, 2609
[1:1:0712/145307.168747:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2609 0x7fca8cc99070 0x2b6f4fda8ce0 , 5:3_http://www.hebnews.cn/, 1, -5:3_http://www.hebnews.cn/, 2507 0x7fca8cc99070 0x2b6f4fb260e0 
[1:1:0712/145307.177710:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hebnews.cn/", 13
[1:1:0712/145307.177919:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2610
[1:1:0712/145307.178055:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2610 0x7fca8cc99070 0x2b6f4ed673e0 , 5:3_http://www.hebnews.cn/, 1, -5:3_http://www.hebnews.cn/, 2507 0x7fca8cc99070 0x2b6f4fb260e0 
[1:1:0712/145307.263358:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "click", "http://www.hebnews.cn/"
[1:1:0712/145307.380675:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2578, 7fca8f5de8db
[1:1:0712/145307.420503:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"2502 0x7fca8cc99070 0x2b6f4f9971e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145307.420671:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"2502 0x7fca8cc99070 0x2b6f4f9971e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145307.420881:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2621
[1:1:0712/145307.420976:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2621 0x7fca8cc99070 0x2b6f4fdcb0e0 , 5:3_http://www.hebnews.cn/, 0, , 2578 0x7fca8cc99070 0x2b6f4fc494e0 
[1:1:0712/145307.421173:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145307.421428:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/145307.421528:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145307.741554:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2539, 7fca8f5de8db
[1:1:0712/145307.781662:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"2453 0x7fca8cc99070 0x2b6f4f45f060 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145307.781826:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"2453 0x7fca8cc99070 0x2b6f4f45f060 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145307.782050:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2632
[1:1:0712/145307.782160:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2632 0x7fca8cc99070 0x2b6f4f99ca60 , 5:3_http://www.hebnews.cn/, 0, , 2539 0x7fca8cc99070 0x2b6f4fb22be0 
[1:1:0712/145307.782345:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145307.782610:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:11_http://www.hebnews.cn/, 144296519748, , , () { roll(); }
[1:1:0712/145307.782736:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 11, 1, http://www.hebnews.cn, www.hebnews.cn, 3
[1:1:0712/145307.864699:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hebnews.cn/, 2587, 7fca8f5de881
[1:1:0712/145307.908982:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"144296482860","ptid":"2522 0x7fca8cc99070 0x2b6f4fb38a60 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145307.909196:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hebnews.cn/","ptid":"2522 0x7fca8cc99070 0x2b6f4fb38a60 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145307.909443:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145307.909736:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , (){qn=t}
[1:1:0712/145307.909860:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145307.951230:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2586, 7fca8f5de8db
[1:1:0712/145307.991310:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"2522 0x7fca8cc99070 0x2b6f4fb38a60 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145307.991476:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"2522 0x7fca8cc99070 0x2b6f4fb38a60 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145307.991720:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2643
[1:1:0712/145307.991832:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2643 0x7fca8cc99070 0x2b6f4f9988e0 , 5:3_http://www.hebnews.cn/, 0, , 2586 0x7fca8cc99070 0x2b6f4fb26d60 
[1:1:0712/145307.992011:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145307.992344:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , ab, (a){if(!A||M!=p||a||R){if(R?p>=1?p=1:0>=p&&(p=0):(O=p,p>=k?p=0:0>p&&(p=k-1)),S(),null!=n&&_(l.childr
[1:1:0712/145307.992449:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145308.003006:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3c17ca4629c8, 0x2b6f4c06d950
[1:1:0712/145308.003109:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hebnews.cn/", 0
[1:1:0712/145308.003264:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hebnews.cn/, 2644
[1:1:0712/145308.003367:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2644 0x7fca8cc99070 0x2b6f4fc3e4e0 , 5:3_http://www.hebnews.cn/, 1, -5:3_http://www.hebnews.cn/, 2586 0x7fca8cc99070 0x2b6f4fb26d60 
[1:1:0712/145308.101796:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2548, 7fca8f5de8db
[1:1:0712/145308.142668:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"2463 0x7fca8cc99070 0x2b6f4f4173e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145308.142895:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"2463 0x7fca8cc99070 0x2b6f4f4173e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145308.143153:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2651
[1:1:0712/145308.143300:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2651 0x7fca8cc99070 0x2b6f4fc3a0e0 , 5:3_http://www.hebnews.cn/, 0, , 2548 0x7fca8cc99070 0x2b6f4eaea2e0 
[1:1:0712/145308.143505:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145308.143784:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:6_http://www.hebnews.cn/, 1442965796c0, , , () { roll(); }
[1:1:0712/145308.143921:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 6, 1, http://www.hebnews.cn, www.hebnews.cn, 3
[1:1:0712/145308.185671:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2594, 7fca8f5de8db
[1:1:0712/145308.225773:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"2535 0x7fca8cc99070 0x2b6f4f9a0960 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145308.225936:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"2535 0x7fca8cc99070 0x2b6f4f9a0960 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145308.226196:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2652
[1:1:0712/145308.226338:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2652 0x7fca8cc99070 0x2b6f4dfe7c60 , 5:3_http://www.hebnews.cn/, 0, , 2594 0x7fca8cc99070 0x2b6f4f6ccee0 
[1:1:0712/145308.226543:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145308.226838:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 144296482860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/145308.226949:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/145308.514875:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2553, 7fca8f5de8db
[1:1:0712/145308.556454:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"2470 0x7fca8cc99070 0x2b6f4f999260 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145308.556645:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"2470 0x7fca8cc99070 0x2b6f4f999260 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/145308.556893:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 2656
[1:1:0712/145308.557067:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2656 0x7fca8cc99070 0x2b6f4fc557e0 , 5:3_http://www.hebnews.cn/, 0, , 2553 0x7fca8cc99070 0x2b6f4fb2f760 
[1:1:0712/145308.557377:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/145308.557706:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:8_http://www.hebnews.cn/, 144296532210, , , () { roll(); }
[1:1:0712/145308.557902:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 8, 1, http://www.hebnews.cn, www.hebnews.cn, 3
[1:1:0712/145308.558923:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hebnews.cn/, 2609, 7fca8f5de881
