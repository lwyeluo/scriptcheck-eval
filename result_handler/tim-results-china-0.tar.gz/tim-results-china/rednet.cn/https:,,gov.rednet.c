[0712/150055.931793:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/150055.932047:INFO:switcher_clone.cc(787)] backtrace rip is 7ffb3a8e5891
[0712/150056.477660:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/150056.477893:INFO:switcher_clone.cc(787)] backtrace rip is 7f127311c891
[1:1:0712/150056.481690:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/150056.481853:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/150056.484748:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[10046:10046:0712/150057.242497:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/ba6f4015-8c32-42ce-b3da-48109f6003cc
[0712/150057.328638:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/150057.328930:INFO:switcher_clone.cc(787)] backtrace rip is 7fc58ffd9891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[10078:10078:0712/150057.484454:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=10078
[10091:10091:0712/150057.496287:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=10091
[10046:10046:0712/150057.497469:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[10046:10076:0712/150057.499677:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/150057.499792:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/150057.499947:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/150057.500265:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/150057.500396:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/150057.503415:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x3d9c1ba0, 1
[1:1:0712/150057.503693:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x265b4fc4, 0
[1:1:0712/150057.505440:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x261209c, 3
[1:1:0712/150057.505541:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x486ea4b, 2
[1:1:0712/150057.505639:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffc44f5b26 ffffffa01bffffff9c3d 4bffffffeaffffff8604 ffffff9c206102 , 10104, 4
[1:1:0712/150057.506356:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[10046:10076:0712/150057.510659:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�O[&��=K�� a�Fw
[10046:10076:0712/150057.510701:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �O[&��=K�� a�m�Fw
[10046:10076:0712/150057.510864:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[10046:10076:0712/150057.510897:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 10099, 4, c44f5b26 a01b9c3d 4bea8604 9c206102 
[1:1:0712/150057.511266:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f12713560a0, 3
[1:1:0712/150057.511384:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f12714e2080, 2
[1:1:0712/150057.511480:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f125b1a4d20, -2
[1:1:0712/150057.520035:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/150057.520462:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 486ea4b
[1:1:0712/150057.520912:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 486ea4b
[1:1:0712/150057.521729:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 486ea4b
[1:1:0712/150057.522410:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 486ea4b
[1:1:0712/150057.522507:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 486ea4b
[1:1:0712/150057.522585:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 486ea4b
[1:1:0712/150057.522655:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 486ea4b
[1:1:0712/150057.522880:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 486ea4b
[1:1:0712/150057.523006:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f127311c7ba
[1:1:0712/150057.523066:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f1273113def, 7f127311c77a, 7f127311e0cf
[1:1:0712/150057.524775:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 486ea4b
[1:1:0712/150057.524939:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 486ea4b
[1:1:0712/150057.525243:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 486ea4b
[1:1:0712/150057.526034:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 486ea4b
[1:1:0712/150057.526123:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 486ea4b
[1:1:0712/150057.526197:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 486ea4b
[1:1:0712/150057.526270:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 486ea4b
[1:1:0712/150057.526750:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 486ea4b
[1:1:0712/150057.526892:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f127311c7ba
[1:1:0712/150057.526944:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f1273113def, 7f127311c77a, 7f127311e0cf
[1:1:0712/150057.529601:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/150057.529793:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/150057.529876:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fffa66f6858, 0x7fffa66f67d8)
[1:1:0712/150057.541888:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/150057.544621:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[10046:10046:0712/150057.910618:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[10046:10046:0712/150057.911167:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[10046:10057:0712/150057.919680:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[10046:10057:0712/150057.919747:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[10046:10046:0712/150057.919768:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[10046:10046:0712/150057.919811:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[10046:10046:0712/150057.919879:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,10099, 4
[1:7:0712/150057.920782:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/150057.921952:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x2a917e223220
[1:1:0712/150057.922261:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[10046:10071:0712/150057.970178:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/150058.192664:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[10046:10046:0712/150058.808930:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[10046:10046:0712/150058.809006:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/150058.821977:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/150058.823763:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/150059.237992:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 03678a1a1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/150059.238191:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/150059.243726:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 03678a1a1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/150059.243864:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/150059.266595:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/150059.376974:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/150059.377158:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/150059.496766:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/150059.499271:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 03678a1a1f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/150059.499423:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/150059.511450:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 356, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/150059.514426:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 03678a1a1f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/150059.514564:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/150059.518427:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[10046:10046:0712/150059.519112:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/150059.520235:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x2a917e221e20
[1:1:0712/150059.521143:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[10046:10046:0712/150059.521651:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[10046:10046:0712/150059.533815:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[10046:10046:0712/150059.533894:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/150059.553810:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/150059.852714:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 415 0x7f125cd7f2e0 0x2a917e492de0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/150059.853433:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 03678a1a1f78, , , var configData = {"googleBaseUrl":"https://www.google.com.hk/","isAccessibleBrowser":false,"isGoogle
[1:1:0712/150059.853607:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/150059.854206:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[10046:10046:0712/150059.879354:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/150059.880478:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x2a917e222820
[1:1:0712/150059.880631:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[10046:10046:0712/150059.881910:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/150059.887856:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/150059.888026:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[10046:10046:0712/150059.889113:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[10046:10046:0712/150059.893006:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[10046:10046:0712/150059.893443:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[10046:10057:0712/150059.897859:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[10046:10057:0712/150059.897911:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[10046:10046:0712/150059.897933:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[10046:10046:0712/150059.897971:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[10046:10046:0712/150059.898031:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,10099, 4
[1:7:0712/150059.899399:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/150100.161245:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/150100.291069:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 465 0x7f125cd7f2e0 0x2a917e5c9460 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/150100.291669:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 03678a1a1f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/150100.291832:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/150100.292167:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[10046:10046:0712/150100.436705:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[10046:10046:0712/150100.436794:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/150100.448356:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/150100.562299:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/150100.770571:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/150100.770730:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[10046:10046:0712/150100.790957:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[10046:10076:0712/150100.791245:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/150100.791377:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/150100.791514:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/150100.791704:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/150100.791784:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/150100.805314:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x1d6ee212, 1
[1:1:0712/150100.805558:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x58c5ad7, 0
[1:1:0712/150100.805735:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x2b320102, 3
[1:1:0712/150100.805895:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0xd848e76, 2
[1:1:0712/150100.806045:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffd75affffff8c05 12ffffffe26e1d 76ffffff8effffff840d 0201322b , 10104, 5
[1:1:0712/150100.806815:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[10046:10076:0712/150100.807031:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�Z��nv��2+Gw
[10046:10076:0712/150100.807079:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �Z��nv��2+x�Gw
[1:1:0712/150100.807022:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f12713560a0, 3
[10046:10076:0712/150100.807224:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 10143, 5, d75a8c05 12e26e1d 768e840d 0201322b 
[1:1:0712/150100.807422:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f12714e2080, 2
[1:1:0712/150100.807536:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f125b1a4d20, -2
[1:1:0712/150100.817010:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/150100.817238:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal d848e76
[1:1:0712/150100.817475:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal d848e76
[1:1:0712/150100.817781:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal d848e76
[1:1:0712/150100.818358:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal d848e76
[1:1:0712/150100.818497:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal d848e76
[1:1:0712/150100.818602:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal d848e76
[1:1:0712/150100.818710:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal d848e76
[1:1:0712/150100.818969:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal d848e76
[1:1:0712/150100.819081:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f127311c7ba
[1:1:0712/150100.819172:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f1273113def, 7f127311c77a, 7f127311e0cf
[1:1:0712/150100.820928:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal d848e76
[1:1:0712/150100.821131:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal d848e76
[1:1:0712/150100.821438:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal d848e76
[1:1:0712/150100.822207:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal d848e76
[1:1:0712/150100.822341:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal d848e76
[1:1:0712/150100.822453:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal d848e76
[1:1:0712/150100.822552:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal d848e76
[1:1:0712/150100.823053:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal d848e76
[1:1:0712/150100.823220:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f127311c7ba
[1:1:0712/150100.823298:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f1273113def, 7f127311c77a, 7f127311e0cf
[1:1:0712/150100.825846:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/150100.826066:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/150100.826172:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fffa66f6858, 0x7fffa66f67d8)
[1:1:0712/150100.832292:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/150100.834281:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/150100.921178:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 530, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/150100.921846:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x2a917e1ec220
[1:1:0712/150100.922148:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/150100.922997:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 03678a2ce5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/150100.923228:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/150100.925697:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[10046:10046:0712/150106.360532:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[10046:10046:0712/150106.363708:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[10046:10057:0712/150106.381079:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[10046:10057:0712/150106.381148:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[10046:10046:0712/150106.381935:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://gov.rednet.cn/
[10046:10046:0712/150106.381994:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://gov.rednet.cn/, https://gov.rednet.cn/content/2019/06/17/5595635.html, 1
[10046:10046:0712/150106.382063:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_https://gov.rednet.cn/, HTTP/1.1 200 OK Server: nginx Date: Fri, 12 Jul 2019 07:01:06 GMT Content-Type: text/html Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Strict-Transport-Security: max-age=3600; includeSubdomains; preload Content-Encoding: gzip  ,10143, 5
[1:7:0712/150106.383601:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/150106.401629:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_https://gov.rednet.cn/
[10046:10046:0712/150106.453880:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://gov.rednet.cn/, https://gov.rednet.cn/, 1
[10046:10046:0712/150106.453939:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://gov.rednet.cn/, https://gov.rednet.cn
[1:1:0712/150106.472847:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/150106.517379:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/150106.554617:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/150106.554774:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://gov.rednet.cn/content/2019/06/17/5595635.html"
[1:1:0712/150106.671028:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/150106.865466:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 190 0x7f125ae57070 0x2a917e31dd60 , "https://gov.rednet.cn/content/2019/06/17/5595635.html"
[1:1:0712/150106.866404:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/150106.869356:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gov.rednet.cn/, 031616f22860, , , /*! jQuery v1.11.3 | (c) 2005, 2015 jQuery Foundation, Inc. | jquery.org/license */
!function(a,b){"
[1:1:0712/150106.869525:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gov.rednet.cn/content/2019/06/17/5595635.html", "gov.rednet.cn", 3, 1, , , 0
[1:1:0712/150106.970752:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 190 0x7f125ae57070 0x2a917e31dd60 , "https://gov.rednet.cn/content/2019/06/17/5595635.html"
[1:1:0712/150107.040645:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 204, "https://gov.rednet.cn/content/2019/06/17/5595635.html"
[1:1:0712/150107.042991:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gov.rednet.cn/, 031616f22860, , , /*! jPlayer 2.9.2 for jQuery ~ (c) 2009-2014 Happyworm Ltd ~ MIT License */
!function(a,b){"function
[1:1:0712/150107.043178:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gov.rednet.cn/content/2019/06/17/5595635.html", "gov.rednet.cn", 3, 1, , , 0
[1:1:0712/150107.113595:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/150107.138304:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/150107.138487:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://gov.rednet.cn/content/2019/06/17/5595635.html"
[1:1:0712/150107.146794:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 218 0x7f12714e2080 0x2a917e223ba0 1 0 0x2a917e223bb8 , "https://gov.rednet.cn/content/2019/06/17/5595635.html"
[1:1:0712/150107.150411:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gov.rednet.cn/, 031616f22860, , , "object"==typeof navigator&&function(e,t){"object"==typeof exports&&"undefined"!=typeof module?modul
[1:1:0712/150107.150590:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gov.rednet.cn/content/2019/06/17/5595635.html", "gov.rednet.cn", 3, 1, , , 0
[1:1:0712/150107.230695:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 218 0x7f12714e2080 0x2a917e223ba0 1 0 0x2a917e223bb8 , "https://gov.rednet.cn/content/2019/06/17/5595635.html"
[1:1:0712/150107.234806:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 218 0x7f12714e2080 0x2a917e223ba0 1 0 0x2a917e223bb8 , "https://gov.rednet.cn/content/2019/06/17/5595635.html"
[1:1:0712/150107.236542:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 218 0x7f12714e2080 0x2a917e223ba0 1 0 0x2a917e223bb8 , "https://gov.rednet.cn/content/2019/06/17/5595635.html"
[1:1:0712/150107.241905:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.013134, 63, 1
[1:1:0712/150107.242090:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/150107.298611:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/150107.298791:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://gov.rednet.cn/content/2019/06/17/5595635.html"
[1:1:0712/150107.300366:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 231 0x7f125ae57070 0x2a917e5407e0 , "https://gov.rednet.cn/content/2019/06/17/5595635.html"
[1:1:0712/150107.301013:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gov.rednet.cn/, 031616f22860, , , 	var intEgg_1483 = 0;
	var arrEgg_1483 = new Array();
	arrEgg_1483[0]='<a href="https://news.redne
[1:1:0712/150107.301210:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gov.rednet.cn/content/2019/06/17/5595635.html", "gov.rednet.cn", 3, 1, , , 0
[1:1:0712/150107.303246:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html", 6000
[1:1:0712/150107.303487:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://gov.rednet.cn/, 237
[1:1:0712/150107.303613:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 237 0x7f125ae57070 0x2a917e2249e0 , 5:3_https://gov.rednet.cn/, 1, -5:3_https://gov.rednet.cn/, 231 0x7f125ae57070 0x2a917e5407e0 
[1:1:0712/150107.308986:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 231 0x7f125ae57070 0x2a917e5407e0 , "https://gov.rednet.cn/content/2019/06/17/5595635.html"
[1:1:0712/150113.465724:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 6.16687, 48, 0
[1:1:0712/150113.465907:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/150113.534219:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/150113.534384:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://gov.rednet.cn/content/2019/06/17/5595635.html"
[1:1:0712/150113.556825:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.022326, 647, 1
[1:1:0712/150113.556950:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/150113.594227:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://gov.rednet.cn/, 237, 7f125d79c8db
[1:1:0712/150113.597618:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"031616f22860","ptid":"231 0x7f125ae57070 0x2a917e5407e0 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150113.597763:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://gov.rednet.cn/","ptid":"231 0x7f125ae57070 0x2a917e5407e0 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150113.597933:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://gov.rednet.cn/, 266
[1:1:0712/150113.598048:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 266 0x7f125ae57070 0x2a917e48dc60 , 5:3_https://gov.rednet.cn/, 0, , 237 0x7f125ae57070 0x2a917e2249e0 
[1:1:0712/150113.598206:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html"
[1:1:0712/150113.598649:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gov.rednet.cn/, 031616f22860, , , ChangeEGG_1483()
[1:1:0712/150113.598763:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gov.rednet.cn/content/2019/06/17/5595635.html", "gov.rednet.cn", 3, 1, , , 0
[1:1:0712/150113.629070:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/150113.629209:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://gov.rednet.cn/content/2019/06/17/5595635.html"
[1:1:0712/150113.630375:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 262 0x7f125ae57070 0x2a9182c68360 , "https://gov.rednet.cn/content/2019/06/17/5595635.html"
[1:1:0712/150113.630840:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gov.rednet.cn/, 031616f22860, , , (function(){
document.getElementById('overcontent').innerHTML='<div class="mb5"><a href="https://mo
[1:1:0712/150113.630957:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gov.rednet.cn/content/2019/06/17/5595635.html", "gov.rednet.cn", 3, 1, , , 0
[1:1:0712/150113.641693:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 262 0x7f125ae57070 0x2a9182c68360 , "https://gov.rednet.cn/content/2019/06/17/5595635.html"
[1:1:0712/150113.648812:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 262 0x7f125ae57070 0x2a9182c68360 , "https://gov.rednet.cn/content/2019/06/17/5595635.html"
[1:1:0712/150113.653998:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 262 0x7f125ae57070 0x2a9182c68360 , "https://gov.rednet.cn/content/2019/06/17/5595635.html"
[1:1:0712/150113.657383:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 262 0x7f125ae57070 0x2a9182c68360 , "https://gov.rednet.cn/content/2019/06/17/5595635.html"
[1:1:0712/150113.658624:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 262 0x7f125ae57070 0x2a9182c68360 , "https://gov.rednet.cn/content/2019/06/17/5595635.html"
[1:1:0712/150113.701577:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://gov.rednet.cn/content/2019/06/17/5595635.html"
[1:1:0712/150114.191676:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/150114.550866:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://gov.rednet.cn/content/2019/06/17/5595635.html"
[1:1:0712/150114.551367:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gov.rednet.cn/, 031616f22860, , b.src.e.onload, () {
                        d.drawImage(e, (b.width - b.imgWidth) / 2, (b.height - b.imgHeight) / 
[1:1:0712/150114.551540:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gov.rednet.cn/content/2019/06/17/5595635.html", "gov.rednet.cn", 3, 1, , , 0
[1:1:0712/150114.742077:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://gov.rednet.cn/content/2019/06/17/5595635.html"
[1:1:0712/150114.742529:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gov.rednet.cn/, 031616f22860, , b, (c,e){var h,i,j;if(b&&(e||4===f.readyState))if(delete Xb[g],b=void 0,f.onreadystatechange=m.noop,e)4
[1:1:0712/150114.742694:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gov.rednet.cn/content/2019/06/17/5595635.html", "gov.rednet.cn", 3, 1, , , 0
[1:1:0712/150114.743261:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://gov.rednet.cn/content/2019/06/17/5595635.html"
[1:1:0712/150114.744481:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://gov.rednet.cn/content/2019/06/17/5595635.html"
[1:1:0712/150114.744822:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x3b147e4301b8
[1:1:0712/150114.844080:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 323 0x7f125cd7f2e0 0x2a9182e86f60 , "https://gov.rednet.cn/content/2019/06/17/5595635.html"
[1:1:0712/150114.844763:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gov.rednet.cn/, 031616f22860, , , !function(){var e=/([http|https]:\/\/[a-zA-Z0-9\_\.]+\.baidu\.com)/gi,r=window.location.href,t=docum
[1:1:0712/150114.844891:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gov.rednet.cn/content/2019/06/17/5595635.html", "gov.rednet.cn", 3, 1, , , 0
[1:1:0712/150114.853534:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 324 0x7f125cd7f2e0 0x2a917e31fa60 , "https://gov.rednet.cn/content/2019/06/17/5595635.html"
[1:1:0712/150114.854352:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gov.rednet.cn/, 031616f22860, , , var ROOTDM=[".hebtv.com",".jstv.com",".chinawater.com.cn",".cwec.org.cn",".nsbd.gov.cn",".zgzx.org.c
[1:1:0712/150114.854476:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gov.rednet.cn/content/2019/06/17/5595635.html", "gov.rednet.cn", 3, 1, , , 0
[1:1:0712/150114.977990:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/150115.047012:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 327 0x7f125cd7f2e0 0x2a9182d85460 , "https://gov.rednet.cn/content/2019/06/17/5595635.html"
[1:1:0712/150115.047565:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gov.rednet.cn/, 031616f22860, , , var ROOTDM=[".hebtv.com",".jstv.com",".chinawater.com.cn",".cwec.org.cn",".nsbd.gov.cn",".zgzx.org.c
[1:1:0712/150115.047708:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gov.rednet.cn/content/2019/06/17/5595635.html", "gov.rednet.cn", 3, 1, , , 0
[1:1:0712/150115.172518:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x3b147e430c68
[1:1:0712/150115.208416:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 328 0x7f125cd7f2e0 0x2a9182b875e0 , "https://gov.rednet.cn/content/2019/06/17/5595635.html"
[1:1:0712/150115.209886:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gov.rednet.cn/, 031616f22860, , , (function(){var h={},mt={},c={id:"aaecf8414f59c3fb0127932014cf53c7",dm:["rednet.cn"],js:"tongji.baid
[1:1:0712/150115.210061:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gov.rednet.cn/content/2019/06/17/5595635.html", "gov.rednet.cn", 3, 1, , , 0
[1:1:0712/150115.220487:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x39a119e629c8, 0x2a917e075190
[1:1:0712/150115.220667:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html", 100
[1:1:0712/150115.220897:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 385
[1:1:0712/150115.220986:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 385 0x7f125ae57070 0x2a917e31fa60 , 5:3_https://gov.rednet.cn/, 1, -5:3_https://gov.rednet.cn/, 328 0x7f125cd7f2e0 0x2a9182b875e0 
[10046:10046:0712/150116.953010:INFO:CONSOLE(71)] "Mixed Content: The page at 'https://gov.rednet.cn/content/2019/06/17/5595635.html' was loaded over a secure connection, but contains a form that targets an insecure endpoint 'http://s.rednet.cn/'. This endpoint should be made available over a secure connection.", source: https://gov.rednet.cn/content/2019/06/17/5595635.html (71)
[1:1:0712/150117.199684:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://gov.rednet.cn/content/2019/06/17/5595635.html"
[1:1:0712/150117.200152:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gov.rednet.cn/, 031616f22860, , b, (c,e){var h,i,j;if(b&&(e||4===f.readyState))if(delete Xb[g],b=void 0,f.onreadystatechange=m.noop,e)4
[1:1:0712/150117.200279:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gov.rednet.cn/content/2019/06/17/5595635.html", "gov.rednet.cn", 3, 1, , , 0
[1:1:0712/150117.200557:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://gov.rednet.cn/content/2019/06/17/5595635.html"
[1:1:0712/150117.200910:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x3b147e4301b8
[3:3:0712/150117.524071:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/150117.525339:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gov.rednet.cn/, 031616f22860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/150117.525477:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gov.rednet.cn/content/2019/06/17/5595635.html", "gov.rednet.cn", 3, 1, , , 0
[1:1:0712/150117.789276:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 385, 7f125d79c881
[1:1:0712/150117.796561:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"031616f22860","ptid":"328 0x7f125cd7f2e0 0x2a9182b875e0 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150117.796714:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://gov.rednet.cn/","ptid":"328 0x7f125cd7f2e0 0x2a9182b875e0 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150117.796865:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html"
[1:1:0712/150117.797169:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gov.rednet.cn/, 031616f22860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/150117.797265:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gov.rednet.cn/content/2019/06/17/5595635.html", "gov.rednet.cn", 3, 1, , , 0
[1:1:0712/150117.797626:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x39a119e629c8, 0x2a917e075150
[1:1:0712/150117.797715:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html", 100
[1:1:0712/150117.797891:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 450
[1:1:0712/150117.797991:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 450 0x7f125ae57070 0x2a917e4874e0 , 5:3_https://gov.rednet.cn/, 1, -5:3_https://gov.rednet.cn/, 385 0x7f125ae57070 0x2a917e31fa60 
[1:1:0712/150117.907565:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://gov.rednet.cn/content/2019/06/17/5595635.html"
[1:1:0712/150117.907964:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gov.rednet.cn/, 031616f22860, , _wdEC, (){}
[1:1:0712/150117.908059:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gov.rednet.cn/content/2019/06/17/5595635.html", "gov.rednet.cn", 3, 1, , , 0
[1:1:0712/150117.929870:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://gov.rednet.cn/content/2019/06/17/5595635.html"
[1:1:0712/150117.930241:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gov.rednet.cn/, 031616f22860, , _wdEC, (){}
[1:1:0712/150117.930337:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gov.rednet.cn/content/2019/06/17/5595635.html", "gov.rednet.cn", 3, 1, , , 0
[1:1:0712/150117.945571:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://gov.rednet.cn/content/2019/06/17/5595635.html"
[1:1:0712/150117.945961:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gov.rednet.cn/, 031616f22860, , _wdEC, (){}
[1:1:0712/150117.946077:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gov.rednet.cn/content/2019/06/17/5595635.html", "gov.rednet.cn", 3, 1, , , 0
[1:1:0712/150117.967347:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://gov.rednet.cn/content/2019/06/17/5595635.html"
[1:1:0712/150117.967745:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gov.rednet.cn/, 031616f22860, , _wdEC, (){}
[1:1:0712/150117.967856:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gov.rednet.cn/content/2019/06/17/5595635.html", "gov.rednet.cn", 3, 1, , , 0
[1:1:0712/150118.093127:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gov.rednet.cn/, 031616f22860, , , document.readyState
[1:1:0712/150118.093313:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gov.rednet.cn/content/2019/06/17/5595635.html", "gov.rednet.cn", 3, 1, , , 0
[1:1:0712/150118.138703:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://gov.rednet.cn/content/2019/06/17/5595635.html"
[1:1:0712/150118.139092:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gov.rednet.cn/, 031616f22860, , f.onload, (){f.onload=u;f=window[d]=u;a&&a(b)}
[1:1:0712/150118.139176:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gov.rednet.cn/content/2019/06/17/5595635.html", "gov.rednet.cn", 3, 1, , , 0
[1:1:0712/150118.179814:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 450, 7f125d79c881
[1:1:0712/150118.188940:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"031616f22860","ptid":"385 0x7f125ae57070 0x2a917e31fa60 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150118.189456:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://gov.rednet.cn/","ptid":"385 0x7f125ae57070 0x2a917e31fa60 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150118.190525:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html"
[1:1:0712/150118.191031:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gov.rednet.cn/, 031616f22860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/150118.191147:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gov.rednet.cn/content/2019/06/17/5595635.html", "gov.rednet.cn", 3, 1, , , 0
[1:1:0712/150118.191479:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x39a119e629c8, 0x2a917e075150
[1:1:0712/150118.191587:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html", 100
[1:1:0712/150118.192750:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 494
[1:1:0712/150118.192855:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 494 0x7f125ae57070 0x2a917fae79e0 , 5:3_https://gov.rednet.cn/, 1, -5:3_https://gov.rednet.cn/, 450 0x7f125ae57070 0x2a917e4874e0 
[1:1:0712/150118.347520:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gov.rednet.cn/, 031616f22860, , , document.readyState
[1:1:0712/150118.347714:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gov.rednet.cn/content/2019/06/17/5595635.html", "gov.rednet.cn", 3, 1, , , 0
[1:1:0712/150118.430615:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://gov.rednet.cn/content/2019/06/17/5595635.html"
[1:1:0712/150118.431073:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gov.rednet.cn/, 031616f22860, , a, (){if(!a.U){a.U=t;for(var d=0,b=g.length;d<b;d++)g[d]()}}
[1:1:0712/150118.431220:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gov.rednet.cn/content/2019/06/17/5595635.html", "gov.rednet.cn", 3, 1, , , 0
[1:1:0712/150118.432155:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "pageshow", "https://gov.rednet.cn/content/2019/06/17/5595635.html"
[1:1:0712/150118.432837:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x39a119e629c8, 0x2a917e0752f0
[1:1:0712/150118.432956:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html", 100
[1:1:0712/150118.433157:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 500
[1:1:0712/150118.433278:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 500 0x7f125ae57070 0x2a917de815e0 , 5:3_https://gov.rednet.cn/, 1, -5:3_https://gov.rednet.cn/, 484 0x7f125ae57070 0x2a917dedf060 
[1:1:0712/150118.545222:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gov.rednet.cn/, 031616f22860, , , document.readyState
[1:1:0712/150118.545397:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gov.rednet.cn/content/2019/06/17/5595635.html", "gov.rednet.cn", 3, 1, , , 0
[1:1:0712/150118.622256:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 500, 7f125d79c881
[1:1:0712/150118.628605:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"031616f22860","ptid":"484 0x7f125ae57070 0x2a917dedf060 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150118.628736:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://gov.rednet.cn/","ptid":"484 0x7f125ae57070 0x2a917dedf060 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150118.628877:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html"
[1:1:0712/150118.629178:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gov.rednet.cn/, 031616f22860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/150118.629287:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gov.rednet.cn/content/2019/06/17/5595635.html", "gov.rednet.cn", 3, 1, , , 0
[1:1:0712/150118.629586:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x39a119e629c8, 0x2a917e075150
[1:1:0712/150118.629686:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html", 100
[1:1:0712/150118.629863:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 516
[1:1:0712/150118.629982:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 516 0x7f125ae57070 0x2a917fae8e60 , 5:3_https://gov.rednet.cn/, 1, -5:3_https://gov.rednet.cn/, 500 0x7f125ae57070 0x2a917de815e0 
[1:1:0712/150118.734059:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: the server responded with a status of 404 (Not Found)","https://gov.rednet.cn/content/2019/06/17/favicon.ico"
[1:1:0712/150118.795372:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 516, 7f125d79c881
[1:1:0712/150118.802145:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"031616f22860","ptid":"500 0x7f125ae57070 0x2a917de815e0 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150118.802279:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://gov.rednet.cn/","ptid":"500 0x7f125ae57070 0x2a917de815e0 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150118.802422:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html"
[1:1:0712/150118.802680:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gov.rednet.cn/, 031616f22860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/150118.802797:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gov.rednet.cn/content/2019/06/17/5595635.html", "gov.rednet.cn", 3, 1, , , 0
[1:1:0712/150118.803129:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x39a119e629c8, 0x2a917e075150
[1:1:0712/150118.803247:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html", 100
[1:1:0712/150118.803430:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 534
[1:1:0712/150118.803534:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 534 0x7f125ae57070 0x2a917dee1fe0 , 5:3_https://gov.rednet.cn/, 1, -5:3_https://gov.rednet.cn/, 516 0x7f125ae57070 0x2a917fae8e60 
[1:1:0712/150118.913149:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 534, 7f125d79c881
[1:1:0712/150118.921508:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"031616f22860","ptid":"516 0x7f125ae57070 0x2a917fae8e60 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150118.921706:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://gov.rednet.cn/","ptid":"516 0x7f125ae57070 0x2a917fae8e60 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150118.921915:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html"
[1:1:0712/150118.922248:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gov.rednet.cn/, 031616f22860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/150118.922394:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gov.rednet.cn/content/2019/06/17/5595635.html", "gov.rednet.cn", 3, 1, , , 0
[1:1:0712/150118.922744:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x39a119e629c8, 0x2a917e075150
[1:1:0712/150118.922844:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html", 100
[1:1:0712/150118.923020:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 541
[1:1:0712/150118.923130:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 541 0x7f125ae57070 0x2a917faeaa60 , 5:3_https://gov.rednet.cn/, 1, -5:3_https://gov.rednet.cn/, 534 0x7f125ae57070 0x2a917dee1fe0 
[1:1:0712/150119.031807:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 541, 7f125d79c881
[1:1:0712/150119.038960:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"031616f22860","ptid":"534 0x7f125ae57070 0x2a917dee1fe0 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150119.039131:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://gov.rednet.cn/","ptid":"534 0x7f125ae57070 0x2a917dee1fe0 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150119.039331:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html"
[1:1:0712/150119.039657:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gov.rednet.cn/, 031616f22860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/150119.039802:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gov.rednet.cn/content/2019/06/17/5595635.html", "gov.rednet.cn", 3, 1, , , 0
[1:1:0712/150119.040160:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x39a119e629c8, 0x2a917e075150
[1:1:0712/150119.040293:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html", 100
[1:1:0712/150119.040466:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 543
[1:1:0712/150119.040561:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 543 0x7f125ae57070 0x2a917e27c1e0 , 5:3_https://gov.rednet.cn/, 1, -5:3_https://gov.rednet.cn/, 541 0x7f125ae57070 0x2a917faeaa60 
[1:1:0712/150119.148921:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 543, 7f125d79c881
[1:1:0712/150119.155744:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"031616f22860","ptid":"541 0x7f125ae57070 0x2a917faeaa60 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150119.155914:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://gov.rednet.cn/","ptid":"541 0x7f125ae57070 0x2a917faeaa60 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150119.156114:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html"
[1:1:0712/150119.156431:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gov.rednet.cn/, 031616f22860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/150119.156529:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gov.rednet.cn/content/2019/06/17/5595635.html", "gov.rednet.cn", 3, 1, , , 0
[1:1:0712/150119.156816:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x39a119e629c8, 0x2a917e075150
[1:1:0712/150119.156902:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html", 100
[1:1:0712/150119.157079:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 547
[1:1:0712/150119.157179:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 547 0x7f125ae57070 0x2a917e2b8de0 , 5:3_https://gov.rednet.cn/, 1, -5:3_https://gov.rednet.cn/, 543 0x7f125ae57070 0x2a917e27c1e0 
[1:1:0712/150119.265192:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 547, 7f125d79c881
[1:1:0712/150119.272016:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"031616f22860","ptid":"543 0x7f125ae57070 0x2a917e27c1e0 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150119.272175:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://gov.rednet.cn/","ptid":"543 0x7f125ae57070 0x2a917e27c1e0 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150119.272352:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html"
[1:1:0712/150119.272618:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gov.rednet.cn/, 031616f22860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/150119.272713:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gov.rednet.cn/content/2019/06/17/5595635.html", "gov.rednet.cn", 3, 1, , , 0
[1:1:0712/150119.272996:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x39a119e629c8, 0x2a917e075150
[1:1:0712/150119.273093:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html", 100
[1:1:0712/150119.273264:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 550
[1:1:0712/150119.273365:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 550 0x7f125ae57070 0x2a917e298760 , 5:3_https://gov.rednet.cn/, 1, -5:3_https://gov.rednet.cn/, 547 0x7f125ae57070 0x2a917e2b8de0 
[1:1:0712/150119.312243:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://gov.rednet.cn/, 266, 7f125d79c8db
[1:1:0712/150119.319328:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"237 0x7f125ae57070 0x2a917e2249e0 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150119.319485:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"237 0x7f125ae57070 0x2a917e2249e0 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150119.319695:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://gov.rednet.cn/, 552
[1:1:0712/150119.319844:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 552 0x7f125ae57070 0x2a917e299060 , 5:3_https://gov.rednet.cn/, 0, , 266 0x7f125ae57070 0x2a917e48dc60 
[1:1:0712/150119.320029:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html"
[1:1:0712/150119.320342:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gov.rednet.cn/, 031616f22860, , , ChangeEGG_1483()
[1:1:0712/150119.320446:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gov.rednet.cn/content/2019/06/17/5595635.html", "gov.rednet.cn", 3, 1, , , 0
[1:1:0712/150119.390981:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 550, 7f125d79c881
[1:1:0712/150119.398124:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"031616f22860","ptid":"547 0x7f125ae57070 0x2a917e2b8de0 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150119.398307:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://gov.rednet.cn/","ptid":"547 0x7f125ae57070 0x2a917e2b8de0 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150119.398508:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html"
[1:1:0712/150119.398833:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gov.rednet.cn/, 031616f22860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/150119.398969:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gov.rednet.cn/content/2019/06/17/5595635.html", "gov.rednet.cn", 3, 1, , , 0
[1:1:0712/150119.399293:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x39a119e629c8, 0x2a917e075150
[1:1:0712/150119.399395:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html", 100
[1:1:0712/150119.399597:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 558
[1:1:0712/150119.399711:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 558 0x7f125ae57070 0x2a917e23a860 , 5:3_https://gov.rednet.cn/, 1, -5:3_https://gov.rednet.cn/, 550 0x7f125ae57070 0x2a917e298760 
[1:1:0712/150119.508751:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 558, 7f125d79c881
[1:1:0712/150119.516155:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"031616f22860","ptid":"550 0x7f125ae57070 0x2a917e298760 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150119.516313:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://gov.rednet.cn/","ptid":"550 0x7f125ae57070 0x2a917e298760 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150119.516495:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html"
[1:1:0712/150119.516767:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gov.rednet.cn/, 031616f22860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/150119.516862:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gov.rednet.cn/content/2019/06/17/5595635.html", "gov.rednet.cn", 3, 1, , , 0
[1:1:0712/150119.517184:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x39a119e629c8, 0x2a917e075150
[1:1:0712/150119.517285:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html", 100
[1:1:0712/150119.517465:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 561
[1:1:0712/150119.517594:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 561 0x7f125ae57070 0x2a917e216be0 , 5:3_https://gov.rednet.cn/, 1, -5:3_https://gov.rednet.cn/, 558 0x7f125ae57070 0x2a917e23a860 
[1:1:0712/150119.626706:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 561, 7f125d79c881
[1:1:0712/150119.634349:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"031616f22860","ptid":"558 0x7f125ae57070 0x2a917e23a860 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150119.634536:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://gov.rednet.cn/","ptid":"558 0x7f125ae57070 0x2a917e23a860 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150119.634757:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html"
[1:1:0712/150119.635085:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gov.rednet.cn/, 031616f22860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/150119.635230:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gov.rednet.cn/content/2019/06/17/5595635.html", "gov.rednet.cn", 3, 1, , , 0
[1:1:0712/150119.635578:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x39a119e629c8, 0x2a917e075150
[1:1:0712/150119.635669:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html", 100
[1:1:0712/150119.635853:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 563
[1:1:0712/150119.635944:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 563 0x7f125ae57070 0x2a917de806e0 , 5:3_https://gov.rednet.cn/, 1, -5:3_https://gov.rednet.cn/, 561 0x7f125ae57070 0x2a917e216be0 
[1:1:0712/150119.744952:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 563, 7f125d79c881
[1:1:0712/150119.752366:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"031616f22860","ptid":"561 0x7f125ae57070 0x2a917e216be0 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150119.752527:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://gov.rednet.cn/","ptid":"561 0x7f125ae57070 0x2a917e216be0 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150119.752672:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html"
[1:1:0712/150119.752942:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gov.rednet.cn/, 031616f22860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/150119.753048:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gov.rednet.cn/content/2019/06/17/5595635.html", "gov.rednet.cn", 3, 1, , , 0
[1:1:0712/150119.753372:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x39a119e629c8, 0x2a917e075150
[1:1:0712/150119.753472:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html", 100
[1:1:0712/150119.753652:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 565
[1:1:0712/150119.753773:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 565 0x7f125ae57070 0x2a9182e4bbe0 , 5:3_https://gov.rednet.cn/, 1, -5:3_https://gov.rednet.cn/, 563 0x7f125ae57070 0x2a917de806e0 
[1:1:0712/150119.862695:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 565, 7f125d79c881
[1:1:0712/150119.870075:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"031616f22860","ptid":"563 0x7f125ae57070 0x2a917de806e0 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150119.870258:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://gov.rednet.cn/","ptid":"563 0x7f125ae57070 0x2a917de806e0 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150119.870459:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html"
[1:1:0712/150119.870790:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gov.rednet.cn/, 031616f22860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/150119.870934:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gov.rednet.cn/content/2019/06/17/5595635.html", "gov.rednet.cn", 3, 1, , , 0
[1:1:0712/150119.871284:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x39a119e629c8, 0x2a917e075150
[1:1:0712/150119.871376:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html", 100
[1:1:0712/150119.871550:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 567
[1:1:0712/150119.871658:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 567 0x7f125ae57070 0x2a91835aade0 , 5:3_https://gov.rednet.cn/, 1, -5:3_https://gov.rednet.cn/, 565 0x7f125ae57070 0x2a9182e4bbe0 
[1:1:0712/150119.980697:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 567, 7f125d79c881
[1:1:0712/150119.987951:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"031616f22860","ptid":"565 0x7f125ae57070 0x2a9182e4bbe0 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150119.988121:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://gov.rednet.cn/","ptid":"565 0x7f125ae57070 0x2a9182e4bbe0 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150119.988308:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html"
[1:1:0712/150119.988619:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gov.rednet.cn/, 031616f22860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/150119.988776:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gov.rednet.cn/content/2019/06/17/5595635.html", "gov.rednet.cn", 3, 1, , , 0
[1:1:0712/150119.989101:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x39a119e629c8, 0x2a917e075150
[1:1:0712/150119.989198:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html", 100
[1:1:0712/150119.989388:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 569
[1:1:0712/150119.989503:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 569 0x7f125ae57070 0x2a91835b2860 , 5:3_https://gov.rednet.cn/, 1, -5:3_https://gov.rednet.cn/, 567 0x7f125ae57070 0x2a91835aade0 
[1:1:0712/150120.098292:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 569, 7f125d79c881
[1:1:0712/150120.105451:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"031616f22860","ptid":"567 0x7f125ae57070 0x2a91835aade0 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150120.105632:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://gov.rednet.cn/","ptid":"567 0x7f125ae57070 0x2a91835aade0 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150120.105832:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html"
[1:1:0712/150120.106157:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gov.rednet.cn/, 031616f22860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/150120.106303:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gov.rednet.cn/content/2019/06/17/5595635.html", "gov.rednet.cn", 3, 1, , , 0
[1:1:0712/150120.106648:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x39a119e629c8, 0x2a917e075150
[1:1:0712/150120.106752:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html", 100
[1:1:0712/150120.106926:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 572
[1:1:0712/150120.107026:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 572 0x7f125ae57070 0x2a917dee2be0 , 5:3_https://gov.rednet.cn/, 1, -5:3_https://gov.rednet.cn/, 569 0x7f125ae57070 0x2a91835b2860 
[1:1:0712/150120.215830:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 572, 7f125d79c881
[1:1:0712/150120.222989:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"031616f22860","ptid":"569 0x7f125ae57070 0x2a91835b2860 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150120.223161:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://gov.rednet.cn/","ptid":"569 0x7f125ae57070 0x2a91835b2860 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150120.223364:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html"
[1:1:0712/150120.223692:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gov.rednet.cn/, 031616f22860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/150120.223829:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gov.rednet.cn/content/2019/06/17/5595635.html", "gov.rednet.cn", 3, 1, , , 0
[1:1:0712/150120.224189:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x39a119e629c8, 0x2a917e075150
[1:1:0712/150120.224323:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html", 100
[1:1:0712/150120.224511:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 576
[1:1:0712/150120.224617:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 576 0x7f125ae57070 0x2a917fae8ce0 , 5:3_https://gov.rednet.cn/, 1, -5:3_https://gov.rednet.cn/, 572 0x7f125ae57070 0x2a917dee2be0 
[1:1:0712/150120.332179:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 576, 7f125d79c881
[1:1:0712/150120.339322:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"031616f22860","ptid":"572 0x7f125ae57070 0x2a917dee2be0 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150120.339490:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://gov.rednet.cn/","ptid":"572 0x7f125ae57070 0x2a917dee2be0 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150120.339679:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html"
[1:1:0712/150120.339963:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gov.rednet.cn/, 031616f22860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/150120.340098:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gov.rednet.cn/content/2019/06/17/5595635.html", "gov.rednet.cn", 3, 1, , , 0
[1:1:0712/150120.340409:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x39a119e629c8, 0x2a917e075150
[1:1:0712/150120.340508:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html", 100
[1:1:0712/150120.340669:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 578
[1:1:0712/150120.340767:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 578 0x7f125ae57070 0x2a917e299c60 , 5:3_https://gov.rednet.cn/, 1, -5:3_https://gov.rednet.cn/, 576 0x7f125ae57070 0x2a917fae8ce0 
[1:1:0712/150120.450208:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 578, 7f125d79c881
[1:1:0712/150120.458940:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"031616f22860","ptid":"576 0x7f125ae57070 0x2a917fae8ce0 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150120.459169:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://gov.rednet.cn/","ptid":"576 0x7f125ae57070 0x2a917fae8ce0 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150120.459393:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html"
[1:1:0712/150120.459740:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gov.rednet.cn/, 031616f22860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/150120.459915:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gov.rednet.cn/content/2019/06/17/5595635.html", "gov.rednet.cn", 3, 1, , , 0
[1:1:0712/150120.460270:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x39a119e629c8, 0x2a917e075150
[1:1:0712/150120.460378:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html", 100
[1:1:0712/150120.460584:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 580
[1:1:0712/150120.460706:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 580 0x7f125ae57070 0x2a917de802e0 , 5:3_https://gov.rednet.cn/, 1, -5:3_https://gov.rednet.cn/, 578 0x7f125ae57070 0x2a917e299c60 
[1:1:0712/150120.569571:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 580, 7f125d79c881
[1:1:0712/150120.576747:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"031616f22860","ptid":"578 0x7f125ae57070 0x2a917e299c60 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150120.576881:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://gov.rednet.cn/","ptid":"578 0x7f125ae57070 0x2a917e299c60 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150120.577021:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html"
[1:1:0712/150120.577340:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gov.rednet.cn/, 031616f22860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/150120.577485:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gov.rednet.cn/content/2019/06/17/5595635.html", "gov.rednet.cn", 3, 1, , , 0
[1:1:0712/150120.577851:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x39a119e629c8, 0x2a917e075150
[1:1:0712/150120.577992:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html", 100
[1:1:0712/150120.578175:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 582
[1:1:0712/150120.578276:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 582 0x7f125ae57070 0x2a9182b7dee0 , 5:3_https://gov.rednet.cn/, 1, -5:3_https://gov.rednet.cn/, 580 0x7f125ae57070 0x2a917de802e0 
[1:1:0712/150120.687280:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 582, 7f125d79c881
[1:1:0712/150120.694674:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"031616f22860","ptid":"580 0x7f125ae57070 0x2a917de802e0 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150120.694844:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://gov.rednet.cn/","ptid":"580 0x7f125ae57070 0x2a917de802e0 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150120.695044:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html"
[1:1:0712/150120.695370:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gov.rednet.cn/, 031616f22860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/150120.695508:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gov.rednet.cn/content/2019/06/17/5595635.html", "gov.rednet.cn", 3, 1, , , 0
[1:1:0712/150120.695855:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x39a119e629c8, 0x2a917e075150
[1:1:0712/150120.695947:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html", 100
[1:1:0712/150120.696124:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 584
[1:1:0712/150120.696212:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 584 0x7f125ae57070 0x2a917de80560 , 5:3_https://gov.rednet.cn/, 1, -5:3_https://gov.rednet.cn/, 582 0x7f125ae57070 0x2a9182b7dee0 
[1:1:0712/150120.805270:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 584, 7f125d79c881
[1:1:0712/150120.812545:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"031616f22860","ptid":"582 0x7f125ae57070 0x2a9182b7dee0 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150120.812706:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://gov.rednet.cn/","ptid":"582 0x7f125ae57070 0x2a9182b7dee0 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150120.812881:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html"
[1:1:0712/150120.813160:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gov.rednet.cn/, 031616f22860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/150120.813314:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gov.rednet.cn/content/2019/06/17/5595635.html", "gov.rednet.cn", 3, 1, , , 0
[1:1:0712/150120.813663:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x39a119e629c8, 0x2a917e075150
[1:1:0712/150120.813801:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html", 100
[1:1:0712/150120.814029:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 586
[1:1:0712/150120.814113:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 586 0x7f125ae57070 0x2a91835fbde0 , 5:3_https://gov.rednet.cn/, 1, -5:3_https://gov.rednet.cn/, 584 0x7f125ae57070 0x2a917de80560 
[1:1:0712/150120.923231:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 586, 7f125d79c881
[1:1:0712/150120.932895:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"031616f22860","ptid":"584 0x7f125ae57070 0x2a917de80560 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150120.933025:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://gov.rednet.cn/","ptid":"584 0x7f125ae57070 0x2a917de80560 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150120.933253:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html"
[1:1:0712/150120.933582:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gov.rednet.cn/, 031616f22860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/150120.933728:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gov.rednet.cn/content/2019/06/17/5595635.html", "gov.rednet.cn", 3, 1, , , 0
[1:1:0712/150120.934075:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x39a119e629c8, 0x2a917e075150
[1:1:0712/150120.934179:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html", 100
[1:1:0712/150120.934414:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 588
[1:1:0712/150120.934518:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 588 0x7f125ae57070 0x2a917decffe0 , 5:3_https://gov.rednet.cn/, 1, -5:3_https://gov.rednet.cn/, 586 0x7f125ae57070 0x2a91835fbde0 
[1:1:0712/150121.044069:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 588, 7f125d79c881
[1:1:0712/150121.054102:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"031616f22860","ptid":"586 0x7f125ae57070 0x2a91835fbde0 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150121.054271:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://gov.rednet.cn/","ptid":"586 0x7f125ae57070 0x2a91835fbde0 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150121.054474:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html"
[1:1:0712/150121.054801:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gov.rednet.cn/, 031616f22860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/150121.054947:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gov.rednet.cn/content/2019/06/17/5595635.html", "gov.rednet.cn", 3, 1, , , 0
[1:1:0712/150121.055292:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x39a119e629c8, 0x2a917e075150
[1:1:0712/150121.055396:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html", 100
[1:1:0712/150121.055584:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 590
[1:1:0712/150121.055687:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 590 0x7f125ae57070 0x2a917debcae0 , 5:3_https://gov.rednet.cn/, 1, -5:3_https://gov.rednet.cn/, 588 0x7f125ae57070 0x2a917decffe0 
[1:1:0712/150121.164645:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 590, 7f125d79c881
[1:1:0712/150121.172063:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"031616f22860","ptid":"588 0x7f125ae57070 0x2a917decffe0 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150121.172221:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://gov.rednet.cn/","ptid":"588 0x7f125ae57070 0x2a917decffe0 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150121.172404:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html"
[1:1:0712/150121.172714:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gov.rednet.cn/, 031616f22860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/150121.172811:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gov.rednet.cn/content/2019/06/17/5595635.html", "gov.rednet.cn", 3, 1, , , 0
[1:1:0712/150121.173145:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x39a119e629c8, 0x2a917e075150
[1:1:0712/150121.173247:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html", 100
[1:1:0712/150121.173444:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 594
[1:1:0712/150121.173547:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 594 0x7f125ae57070 0x2a917de78ee0 , 5:3_https://gov.rednet.cn/, 1, -5:3_https://gov.rednet.cn/, 590 0x7f125ae57070 0x2a917debcae0 
[1:1:0712/150121.282535:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 594, 7f125d79c881
[1:1:0712/150121.289887:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"031616f22860","ptid":"590 0x7f125ae57070 0x2a917debcae0 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150121.290058:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://gov.rednet.cn/","ptid":"590 0x7f125ae57070 0x2a917debcae0 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150121.290259:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html"
[1:1:0712/150121.290585:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gov.rednet.cn/, 031616f22860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/150121.290749:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gov.rednet.cn/content/2019/06/17/5595635.html", "gov.rednet.cn", 3, 1, , , 0
[1:1:0712/150121.291095:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x39a119e629c8, 0x2a917e075150
[1:1:0712/150121.291200:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html", 100
[1:1:0712/150121.291389:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 596
[1:1:0712/150121.291491:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 596 0x7f125ae57070 0x2a918364a060 , 5:3_https://gov.rednet.cn/, 1, -5:3_https://gov.rednet.cn/, 594 0x7f125ae57070 0x2a917de78ee0 
[1:1:0712/150121.402377:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 596, 7f125d79c881
[1:1:0712/150121.409818:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"031616f22860","ptid":"594 0x7f125ae57070 0x2a917de78ee0 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150121.409988:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://gov.rednet.cn/","ptid":"594 0x7f125ae57070 0x2a917de78ee0 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150121.410188:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html"
[1:1:0712/150121.410515:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gov.rednet.cn/, 031616f22860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/150121.410662:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gov.rednet.cn/content/2019/06/17/5595635.html", "gov.rednet.cn", 3, 1, , , 0
[1:1:0712/150121.411034:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x39a119e629c8, 0x2a917e075150
[1:1:0712/150121.411133:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html", 100
[1:1:0712/150121.411321:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 598
[1:1:0712/150121.411428:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 598 0x7f125ae57070 0x2a91824ae8e0 , 5:3_https://gov.rednet.cn/, 1, -5:3_https://gov.rednet.cn/, 596 0x7f125ae57070 0x2a918364a060 
[1:1:0712/150121.523608:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 598, 7f125d79c881
[1:1:0712/150121.532417:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"031616f22860","ptid":"596 0x7f125ae57070 0x2a918364a060 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150121.532577:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://gov.rednet.cn/","ptid":"596 0x7f125ae57070 0x2a918364a060 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150121.532724:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html"
[1:1:0712/150121.532992:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gov.rednet.cn/, 031616f22860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/150121.533123:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gov.rednet.cn/content/2019/06/17/5595635.html", "gov.rednet.cn", 3, 1, , , 0
[1:1:0712/150121.533467:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x39a119e629c8, 0x2a917e075150
[1:1:0712/150121.533572:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html", 100
[1:1:0712/150121.533754:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 600
[1:1:0712/150121.533866:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 600 0x7f125ae57070 0x2a917de7fae0 , 5:3_https://gov.rednet.cn/, 1, -5:3_https://gov.rednet.cn/, 598 0x7f125ae57070 0x2a91824ae8e0 
[1:1:0712/150121.643340:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 600, 7f125d79c881
[1:1:0712/150121.650789:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"031616f22860","ptid":"598 0x7f125ae57070 0x2a91824ae8e0 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150121.650963:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://gov.rednet.cn/","ptid":"598 0x7f125ae57070 0x2a91824ae8e0 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150121.651162:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html"
[1:1:0712/150121.651489:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gov.rednet.cn/, 031616f22860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/150121.651634:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gov.rednet.cn/content/2019/06/17/5595635.html", "gov.rednet.cn", 3, 1, , , 0
[1:1:0712/150121.651979:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x39a119e629c8, 0x2a917e075150
[1:1:0712/150121.652089:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html", 100
[1:1:0712/150121.652266:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 602
[1:1:0712/150121.652370:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 602 0x7f125ae57070 0x2a917de03c60 , 5:3_https://gov.rednet.cn/, 1, -5:3_https://gov.rednet.cn/, 600 0x7f125ae57070 0x2a917de7fae0 
[1:1:0712/150121.761791:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 602, 7f125d79c881
[1:1:0712/150121.769412:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"031616f22860","ptid":"600 0x7f125ae57070 0x2a917de7fae0 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150121.769587:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://gov.rednet.cn/","ptid":"600 0x7f125ae57070 0x2a917de7fae0 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150121.769787:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html"
[1:1:0712/150121.770113:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gov.rednet.cn/, 031616f22860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/150121.770259:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gov.rednet.cn/content/2019/06/17/5595635.html", "gov.rednet.cn", 3, 1, , , 0
[1:1:0712/150121.770605:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x39a119e629c8, 0x2a917e075150
[1:1:0712/150121.770710:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html", 100
[1:1:0712/150121.770901:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 604
[1:1:0712/150121.770999:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 604 0x7f125ae57070 0x2a917faeb360 , 5:3_https://gov.rednet.cn/, 1, -5:3_https://gov.rednet.cn/, 602 0x7f125ae57070 0x2a917de03c60 
[1:1:0712/150121.885578:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 604, 7f125d79c881
[1:1:0712/150121.893371:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"031616f22860","ptid":"602 0x7f125ae57070 0x2a917de03c60 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150121.893551:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://gov.rednet.cn/","ptid":"602 0x7f125ae57070 0x2a917de03c60 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150121.893753:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html"
[1:1:0712/150121.894090:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gov.rednet.cn/, 031616f22860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/150121.894237:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gov.rednet.cn/content/2019/06/17/5595635.html", "gov.rednet.cn", 3, 1, , , 0
[1:1:0712/150121.894582:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x39a119e629c8, 0x2a917e075150
[1:1:0712/150121.894691:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html", 100
[1:1:0712/150121.894878:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 606
[1:1:0712/150121.894983:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 606 0x7f125ae57070 0x2a918364ade0 , 5:3_https://gov.rednet.cn/, 1, -5:3_https://gov.rednet.cn/, 604 0x7f125ae57070 0x2a917faeb360 
[1:1:0712/150122.004164:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 606, 7f125d79c881
[1:1:0712/150122.014145:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"031616f22860","ptid":"604 0x7f125ae57070 0x2a917faeb360 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150122.014317:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://gov.rednet.cn/","ptid":"604 0x7f125ae57070 0x2a917faeb360 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150122.014517:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html"
[1:1:0712/150122.014844:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gov.rednet.cn/, 031616f22860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/150122.014999:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gov.rednet.cn/content/2019/06/17/5595635.html", "gov.rednet.cn", 3, 1, , , 0
[1:1:0712/150122.015357:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x39a119e629c8, 0x2a917e075150
[1:1:0712/150122.015452:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html", 100
[1:1:0712/150122.015629:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 608
[1:1:0712/150122.015731:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 608 0x7f125ae57070 0x2a91835f36e0 , 5:3_https://gov.rednet.cn/, 1, -5:3_https://gov.rednet.cn/, 606 0x7f125ae57070 0x2a918364ade0 
[1:1:0712/150122.132712:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 608, 7f125d79c881
[1:1:0712/150122.141829:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"031616f22860","ptid":"606 0x7f125ae57070 0x2a918364ade0 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150122.142022:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://gov.rednet.cn/","ptid":"606 0x7f125ae57070 0x2a918364ade0 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150122.142246:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html"
[1:1:0712/150122.142615:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gov.rednet.cn/, 031616f22860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/150122.142778:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gov.rednet.cn/content/2019/06/17/5595635.html", "gov.rednet.cn", 3, 1, , , 0
[1:1:0712/150122.143179:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x39a119e629c8, 0x2a917e075150
[1:1:0712/150122.143294:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html", 100
[1:1:0712/150122.143495:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 611
[1:1:0712/150122.143611:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 611 0x7f125ae57070 0x2a917e27fae0 , 5:3_https://gov.rednet.cn/, 1, -5:3_https://gov.rednet.cn/, 608 0x7f125ae57070 0x2a91835f36e0 
[1:1:0712/150122.253530:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 611, 7f125d79c881
[1:1:0712/150122.261396:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"031616f22860","ptid":"608 0x7f125ae57070 0x2a91835f36e0 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150122.261570:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://gov.rednet.cn/","ptid":"608 0x7f125ae57070 0x2a91835f36e0 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150122.261773:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html"
[1:1:0712/150122.262101:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gov.rednet.cn/, 031616f22860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/150122.262250:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gov.rednet.cn/content/2019/06/17/5595635.html", "gov.rednet.cn", 3, 1, , , 0
[1:1:0712/150122.262585:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x39a119e629c8, 0x2a917e075150
[1:1:0712/150122.262667:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html", 100
[1:1:0712/150122.262870:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 613
[1:1:0712/150122.262983:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 613 0x7f125ae57070 0x2a9183575be0 , 5:3_https://gov.rednet.cn/, 1, -5:3_https://gov.rednet.cn/, 611 0x7f125ae57070 0x2a917e27fae0 
[1:1:0712/150122.372545:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 613, 7f125d79c881
[1:1:0712/150122.380312:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"031616f22860","ptid":"611 0x7f125ae57070 0x2a917e27fae0 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150122.380472:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://gov.rednet.cn/","ptid":"611 0x7f125ae57070 0x2a917e27fae0 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150122.380655:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html"
[1:1:0712/150122.380926:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gov.rednet.cn/, 031616f22860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/150122.381013:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gov.rednet.cn/content/2019/06/17/5595635.html", "gov.rednet.cn", 3, 1, , , 0
[1:1:0712/150122.381319:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x39a119e629c8, 0x2a917e075150
[1:1:0712/150122.381421:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html", 100
[1:1:0712/150122.381602:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 615
[1:1:0712/150122.381713:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 615 0x7f125ae57070 0x2a917de04060 , 5:3_https://gov.rednet.cn/, 1, -5:3_https://gov.rednet.cn/, 613 0x7f125ae57070 0x2a9183575be0 
[1:1:0712/150122.491006:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 615, 7f125d79c881
[1:1:0712/150122.498586:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"031616f22860","ptid":"613 0x7f125ae57070 0x2a9183575be0 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150122.498759:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://gov.rednet.cn/","ptid":"613 0x7f125ae57070 0x2a9183575be0 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150122.498958:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html"
[1:1:0712/150122.499283:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gov.rednet.cn/, 031616f22860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/150122.499430:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gov.rednet.cn/content/2019/06/17/5595635.html", "gov.rednet.cn", 3, 1, , , 0
[1:1:0712/150122.499789:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x39a119e629c8, 0x2a917e075150
[1:1:0712/150122.499883:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html", 100
[1:1:0712/150122.500058:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 617
[1:1:0712/150122.500148:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 617 0x7f125ae57070 0x2a918364af60 , 5:3_https://gov.rednet.cn/, 1, -5:3_https://gov.rednet.cn/, 615 0x7f125ae57070 0x2a917de04060 
[1:1:0712/150122.610134:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 617, 7f125d79c881
[1:1:0712/150122.618013:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"031616f22860","ptid":"615 0x7f125ae57070 0x2a917de04060 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150122.618187:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://gov.rednet.cn/","ptid":"615 0x7f125ae57070 0x2a917de04060 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150122.618406:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html"
[1:1:0712/150122.618731:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gov.rednet.cn/, 031616f22860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/150122.618877:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gov.rednet.cn/content/2019/06/17/5595635.html", "gov.rednet.cn", 3, 1, , , 0
[1:1:0712/150122.619240:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x39a119e629c8, 0x2a917e075150
[1:1:0712/150122.619345:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html", 100
[1:1:0712/150122.619527:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 619
[1:1:0712/150122.619640:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 619 0x7f125ae57070 0x2a917de78360 , 5:3_https://gov.rednet.cn/, 1, -5:3_https://gov.rednet.cn/, 617 0x7f125ae57070 0x2a918364af60 
[1:1:0712/150122.729313:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 619, 7f125d79c881
[1:1:0712/150122.737105:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"031616f22860","ptid":"617 0x7f125ae57070 0x2a918364af60 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150122.737278:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://gov.rednet.cn/","ptid":"617 0x7f125ae57070 0x2a918364af60 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150122.737478:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html"
[1:1:0712/150122.737815:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gov.rednet.cn/, 031616f22860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/150122.737983:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gov.rednet.cn/content/2019/06/17/5595635.html", "gov.rednet.cn", 3, 1, , , 0
[1:1:0712/150122.738332:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x39a119e629c8, 0x2a917e075150
[1:1:0712/150122.738424:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html", 100
[1:1:0712/150122.738583:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 621
[1:1:0712/150122.738682:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 621 0x7f125ae57070 0x2a91833333e0 , 5:3_https://gov.rednet.cn/, 1, -5:3_https://gov.rednet.cn/, 619 0x7f125ae57070 0x2a917de78360 
[1:1:0712/150122.848053:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 621, 7f125d79c881
[1:1:0712/150122.857985:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"031616f22860","ptid":"619 0x7f125ae57070 0x2a917de78360 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150122.858154:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://gov.rednet.cn/","ptid":"619 0x7f125ae57070 0x2a917de78360 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150122.858354:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html"
[1:1:0712/150122.858682:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gov.rednet.cn/, 031616f22860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/150122.858828:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gov.rednet.cn/content/2019/06/17/5595635.html", "gov.rednet.cn", 3, 1, , , 0
[1:1:0712/150122.859179:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x39a119e629c8, 0x2a917e075150
[1:1:0712/150122.859283:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html", 100
[1:1:0712/150122.859466:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 623
[1:1:0712/150122.859600:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 623 0x7f125ae57070 0x2a917e284460 , 5:3_https://gov.rednet.cn/, 1, -5:3_https://gov.rednet.cn/, 621 0x7f125ae57070 0x2a91833333e0 
[1:1:0712/150122.969171:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 623, 7f125d79c881
[1:1:0712/150122.976982:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"031616f22860","ptid":"621 0x7f125ae57070 0x2a91833333e0 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150122.977186:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://gov.rednet.cn/","ptid":"621 0x7f125ae57070 0x2a91833333e0 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150122.977389:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html"
[1:1:0712/150122.977717:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gov.rednet.cn/, 031616f22860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/150122.977865:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gov.rednet.cn/content/2019/06/17/5595635.html", "gov.rednet.cn", 3, 1, , , 0
[1:1:0712/150122.978212:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x39a119e629c8, 0x2a917e075150
[1:1:0712/150122.978325:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html", 100
[1:1:0712/150122.978489:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 625
[1:1:0712/150122.978579:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 625 0x7f125ae57070 0x2a917e1f5c60 , 5:3_https://gov.rednet.cn/, 1, -5:3_https://gov.rednet.cn/, 623 0x7f125ae57070 0x2a917e284460 
[1:1:0712/150123.090426:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 625, 7f125d79c881
[1:1:0712/150123.101766:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"031616f22860","ptid":"623 0x7f125ae57070 0x2a917e284460 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150123.101982:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://gov.rednet.cn/","ptid":"623 0x7f125ae57070 0x2a917e284460 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150123.102232:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html"
[1:1:0712/150123.102648:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gov.rednet.cn/, 031616f22860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/150123.102832:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gov.rednet.cn/content/2019/06/17/5595635.html", "gov.rednet.cn", 3, 1, , , 0
[1:1:0712/150123.103256:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x39a119e629c8, 0x2a917e075150
[1:1:0712/150123.103365:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html", 100
[1:1:0712/150123.103629:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 627
[1:1:0712/150123.103805:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 627 0x7f125ae57070 0x2a917de7fbe0 , 5:3_https://gov.rednet.cn/, 1, -5:3_https://gov.rednet.cn/, 625 0x7f125ae57070 0x2a917e1f5c60 
[1:1:0712/150123.213007:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 627, 7f125d79c881
[1:1:0712/150123.220759:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"031616f22860","ptid":"625 0x7f125ae57070 0x2a917e1f5c60 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150123.220894:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://gov.rednet.cn/","ptid":"625 0x7f125ae57070 0x2a917e1f5c60 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150123.221042:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html"
[1:1:0712/150123.221396:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gov.rednet.cn/, 031616f22860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/150123.221542:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gov.rednet.cn/content/2019/06/17/5595635.html", "gov.rednet.cn", 3, 1, , , 0
[1:1:0712/150123.221890:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x39a119e629c8, 0x2a917e075150
[1:1:0712/150123.222030:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html", 100
[1:1:0712/150123.222271:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 631
[1:1:0712/150123.222378:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 631 0x7f125ae57070 0x2a917e299660 , 5:3_https://gov.rednet.cn/, 1, -5:3_https://gov.rednet.cn/, 627 0x7f125ae57070 0x2a917de7fbe0 
[1:1:0712/150123.331808:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 631, 7f125d79c881
[1:1:0712/150123.339585:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"031616f22860","ptid":"627 0x7f125ae57070 0x2a917de7fbe0 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150123.339757:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://gov.rednet.cn/","ptid":"627 0x7f125ae57070 0x2a917de7fbe0 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150123.339957:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html"
[1:1:0712/150123.340277:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gov.rednet.cn/, 031616f22860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/150123.340410:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gov.rednet.cn/content/2019/06/17/5595635.html", "gov.rednet.cn", 3, 1, , , 0
[1:1:0712/150123.340742:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x39a119e629c8, 0x2a917e075150
[1:1:0712/150123.340832:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html", 100
[1:1:0712/150123.340993:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 633
[1:1:0712/150123.341127:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 633 0x7f125ae57070 0x2a917fae72e0 , 5:3_https://gov.rednet.cn/, 1, -5:3_https://gov.rednet.cn/, 631 0x7f125ae57070 0x2a917e299660 
[1:1:0712/150123.450798:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 633, 7f125d79c881
[1:1:0712/150123.459176:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"031616f22860","ptid":"631 0x7f125ae57070 0x2a917e299660 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150123.459373:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://gov.rednet.cn/","ptid":"631 0x7f125ae57070 0x2a917e299660 ","rf":"5:3_https://gov.rednet.cn/"}
[1:1:0712/150123.459586:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html"
[1:1:0712/150123.459933:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gov.rednet.cn/, 031616f22860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/150123.460077:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gov.rednet.cn/content/2019/06/17/5595635.html", "gov.rednet.cn", 3, 1, , , 0
[1:1:0712/150123.460425:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x39a119e629c8, 0x2a917e075150
[1:1:0712/150123.460555:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://gov.rednet.cn/content/2019/06/17/5595635.html", 100
[1:1:0712/150123.460727:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 635
[1:1:0712/150123.460820:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 635 0x7f125ae57070 0x2a917de040e0 , 5:3_https://gov.rednet.cn/, 1, -5:3_https://gov.rednet.cn/, 633 0x7f125ae57070 0x2a917fae72e0 
[1:1:0100/000000.577279:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gov.rednet.cn/, 635, 7f125d79c881
