[0711/213541.164138:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/213541.164416:INFO:switcher_clone.cc(787)] backtrace rip is 7f6b6eefe891
[0711/213541.700227:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/213541.700491:INFO:switcher_clone.cc(787)] backtrace rip is 7fb71b123891
[1:1:0711/213541.704328:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0711/213541.704509:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0711/213541.707475:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[7491:7491:0711/213542.357257:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/c7a43f10-2aa7-4400-864a-542de7f68add
[0711/213542.546621:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/213542.546902:INFO:switcher_clone.cc(787)] backtrace rip is 7f44c6b11891
[7491:7491:0711/213542.611210:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[7491:7520:0711/213542.611634:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0711/213542.611777:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0711/213542.611962:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0711/213542.612279:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0711/213542.612420:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0711/213542.614350:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x3e20401e, 1
[1:1:0711/213542.614566:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x17a8a151, 0
[1:1:0711/213542.614694:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x39be2259, 3
[1:1:0711/213542.614794:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x88564e8, 2
[1:1:0711/213542.614882:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 51ffffffa1ffffffa817 1e40203e ffffffe864ffffff8508 5922ffffffbe39 , 10104, 4
[1:1:0711/213542.615587:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[7491:7520:0711/213542.615684:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGQ��@ >�d�Y"�9w��:
[7491:7520:0711/213542.615731:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is Q��@ >�d�Y"�9��w��:
[1:1:0711/213542.615685:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fb71935d0a0, 3
[7491:7520:0711/213542.615861:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[7491:7520:0711/213542.615899:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 7536, 4, 51a1a817 1e40203e e8648508 5922be39 
[1:1:0711/213542.616141:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fb7194e9080, 2
[1:1:0711/213542.616234:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fb7031abd20, -2
[1:1:0711/213542.623974:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0711/213542.624380:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 88564e8
[1:1:0711/213542.624824:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 88564e8
[1:1:0711/213542.625592:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 88564e8
[1:1:0711/213542.626153:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 88564e8
[1:1:0711/213542.626271:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 88564e8
[1:1:0711/213542.626394:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 88564e8
[1:1:0711/213542.626472:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 88564e8
[1:1:0711/213542.626694:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 88564e8
[1:1:0711/213542.626847:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fb71b1237ba
[1:1:0711/213542.626911:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fb71b11adef, 7fb71b12377a, 7fb71b1250cf
[1:1:0711/213542.628582:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 88564e8
[1:1:0711/213542.628753:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 88564e8
[1:1:0711/213542.629072:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 88564e8
[1:1:0711/213542.629843:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 88564e8
[1:1:0711/213542.630035:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 88564e8
[1:1:0711/213542.630152:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 88564e8
[1:1:0711/213542.630255:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 88564e8
[1:1:0711/213542.630755:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 88564e8
[1:1:0711/213542.630907:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fb71b1237ba
[1:1:0711/213542.631003:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fb71b11adef, 7fb71b12377a, 7fb71b1250cf
[1:1:0711/213542.633649:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0711/213542.633867:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0711/213542.633960:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffc40994608, 0x7ffc40994588)
[1:1:0711/213542.640643:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0711/213542.643520:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[7522:7522:0711/213542.706882:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=7522
[7548:7548:0711/213542.707544:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=7548
[7491:7491:0711/213542.902238:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[7491:7491:0711/213542.902739:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[7491:7491:0711/213542.911400:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[7491:7491:0711/213542.911470:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[7491:7491:0711/213542.911564:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,7536, 4
[7491:7502:0711/213542.982393:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[7491:7502:0711/213542.982462:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[1:7:0711/213542.986315:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/213543.056807:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x3113459f3220
[1:1:0711/213543.057027:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[7491:7515:0711/213543.097076:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0711/213543.240837:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[7491:7491:0711/213543.931545:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[7491:7491:0711/213543.931654:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0711/213543.945933:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/213543.947619:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/213544.346224:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0ac0d5d61f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0711/213544.346415:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/213544.351737:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0ac0d5d61f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0711/213544.351877:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/213544.397524:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/213544.513609:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/213544.513764:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/213544.642172:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 354, "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/213544.644643:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0ac0d5d61f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0711/213544.644794:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/213544.656872:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355, "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/213544.659831:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0ac0d5d61f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0711/213544.659979:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/213544.663841:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[7491:7491:0711/213544.664514:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0711/213544.665783:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x3113459f1e20
[1:1:0711/213544.665888:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[7491:7491:0711/213544.667095:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[7491:7491:0711/213544.678601:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[7491:7491:0711/213544.678718:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0711/213544.698450:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/213544.995690:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 414 0x7fb704d862e0 0x311345c3a7e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/213544.996375:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0ac0d5d61f78, , , var configData = {"googleBaseUrl":"https://www.google.com.hk/","isAccessibleBrowser":false,"isGoogle
[1:1:0711/213544.996524:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/213544.997142:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[7491:7491:0711/213545.023563:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0711/213545.024661:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x3113459f2820
[1:1:0711/213545.024827:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[7491:7491:0711/213545.026019:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0711/213545.032087:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0711/213545.032691:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[7491:7491:0711/213545.033848:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[7491:7491:0711/213545.038095:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[7491:7491:0711/213545.038547:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[7491:7502:0711/213545.043294:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[7491:7502:0711/213545.043367:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[7491:7491:0711/213545.043398:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[7491:7491:0711/213545.043452:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[7491:7491:0711/213545.043544:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,7536, 4
[1:7:0711/213545.045220:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/213545.294775:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0711/213545.475787:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 469 0x7fb704d862e0 0x311345d68460 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/213545.476413:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0ac0d5d61f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0711/213545.476580:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/213545.476992:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[7491:7491:0711/213545.528397:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[7491:7491:0711/213545.528473:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0711/213545.540040:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/213545.673306:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/213545.842418:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/213545.842603:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/213545.995309:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 526, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/213545.996933:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0ac0d5e8e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0711/213545.997114:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/213545.999386:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[7491:7491:0711/213546.022316:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[7491:7520:0711/213546.022606:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0711/213546.022756:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0711/213546.022896:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0711/213546.023095:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0711/213546.023181:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0711/213546.025469:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x2cc0d502, 1
[1:1:0711/213546.025766:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x127791cc, 0
[1:1:0711/213546.025872:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0xc283424, 3
[1:1:0711/213546.025966:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x3979e21f, 2
[1:1:0711/213546.026050:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffccffffff917712 02ffffffd5ffffffc02c 1fffffffe27939 2434280c , 10104, 5
[1:1:0711/213546.026793:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[7491:7520:0711/213546.027039:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING̑w��,�y9$4(-��:
[7491:7520:0711/213546.027104:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ̑w��,�y9$4(��-��:
[7491:7520:0711/213546.027287:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 7584, 5, cc917712 02d5c02c 1fe27939 2434280c 
[1:1:0711/213546.027034:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fb71935d0a0, 3
[1:1:0711/213546.027371:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fb7194e9080, 2
[1:1:0711/213546.027478:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fb7031abd20, -2
[1:1:0711/213546.037161:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0711/213546.037376:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3979e21f
[1:1:0711/213546.037572:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3979e21f
[1:1:0711/213546.037850:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3979e21f
[1:1:0711/213546.038387:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3979e21f
[1:1:0711/213546.038497:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3979e21f
[1:1:0711/213546.038605:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3979e21f
[1:1:0711/213546.038704:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3979e21f
[1:1:0711/213546.038966:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3979e21f
[1:1:0711/213546.039104:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fb71b1237ba
[1:1:0711/213546.039187:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fb71b11adef, 7fb71b12377a, 7fb71b1250cf
[1:1:0711/213546.040890:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3979e21f
[1:1:0711/213546.041085:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3979e21f
[1:1:0711/213546.041405:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3979e21f
[1:1:0711/213546.042206:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3979e21f
[1:1:0711/213546.042324:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3979e21f
[1:1:0711/213546.042428:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3979e21f
[1:1:0711/213546.042531:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3979e21f
[1:1:0711/213546.043049:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3979e21f
[1:1:0711/213546.043290:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fb71b1237ba
[1:1:0711/213546.043388:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fb71b11adef, 7fb71b12377a, 7fb71b1250cf
[1:1:0711/213546.046096:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0711/213546.046361:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0711/213546.046481:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffc40994608, 0x7ffc40994588)
[1:1:0711/213546.052698:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0711/213546.054737:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0711/213546.064278:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/213546.064686:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0ac0d5d61f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0711/213546.064820:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/213546.147703:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x311345999220
[1:1:0711/213546.147920:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0711/213546.165616:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/213546.166413:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0711/213546.166560:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0ac0d5e8e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0711/213546.166712:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/213546.230817:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/213546.231284:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0711/213546.231435:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0ac0d5e8e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0711/213546.231590:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/213546.379280:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.qq.com/"
[1:1:0711/213546.571726:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://amazon.com/"
[1:1:0711/213546.597695:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://taobao.com/"
[1:1:0711/213546.632983:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://tmall.com/"
[1:1:0711/213546.689196:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://vk.com/"
[1:1:0711/213546.715662:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.jd.com/"
[1:1:0711/213546.751203:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://yahoo.com/"
[1:1:0711/213546.777578:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://sohu.com/"
[1:1:0711/213546.809084:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/213546.809516:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0ac0d5e8e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0711/213546.809665:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/213546.830309:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/213546.830733:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0ac0d5e8e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0711/213546.830874:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/213546.862006:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/213546.862427:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0ac0d5e8e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0711/213546.862572:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/213546.883352:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/213546.883815:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0ac0d5e8e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0711/213546.883996:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/213546.915035:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/213546.915512:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0ac0d5e8e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0711/213546.915698:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/213546.936487:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/213546.936995:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0ac0d5e8e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0711/213546.937195:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/213546.968295:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/213546.968798:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0ac0d5e8e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0711/213546.968967:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/213546.989529:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/213546.989926:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0ac0d5e8e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0711/213546.990057:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/213547.027145:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/213547.027606:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0ac0d5e8e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0711/213547.027780:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/213547.076459:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/213547.076866:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0ac0d5e8e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0711/213547.076978:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/213547.097176:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/213547.097623:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0ac0d5e8e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0711/213547.097793:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/213547.125944:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/213547.126391:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0ac0d5e8e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0711/213547.126552:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/213547.174508:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/213547.174902:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0ac0d5e8e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0711/213547.175025:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/213547.194490:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/213547.194896:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0ac0d5e8e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0711/213547.195010:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/213547.223587:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/213547.224025:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0ac0d5e8e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0711/213547.224185:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/213547.242884:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/213547.243401:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0ac0d5e8e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0711/213547.243574:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/213547.446003:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/213547.446677:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:1_chrome-search://local-ntp/, 4:4_chrome-search://most-visited/
[1:1:0711/213547.446784:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0ac0d5d61f78, , handlePostMessage, (event) {
  var cmd = event.data.cmd;
  var args = event.data;
  if (cmd === 'loaded') {
    tilesAr
[1:1:0711/213547.446893:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[7491:7491:0711/213549.849534:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[7491:7491:0711/213549.852305:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[7491:7502:0711/213549.865585:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[7491:7502:0711/213549.865695:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[7491:7491:0711/213549.865791:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://www.im286.net/
[7491:7491:0711/213549.865850:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://www.im286.net/, https://www.im286.net/forum.php, 1
[7491:7491:0711/213549.865923:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_https://www.im286.net/, HTTP/1.1 200 OK Server: Microsoft IIS 600.00 1110 Date: Thu, 11 Jul 2019 13:35:45 GMT Content-Type: text/html; charset=gbk Transfer-Encoding: chunked Connection: keep-alive X-Powered-By: PHP/5.6.22 Set-Cookie: j2us_2132_saltkey=a00Xh806; expires=Sat, 10-Aug-2019 13:35:45 GMT; Max-Age=2592000; path=/; secure; httponly Set-Cookie: j2us_2132_lastvisit=1562848545; expires=Sat, 10-Aug-2019 13:35:45 GMT; Max-Age=2592000; path=/; secure Set-Cookie: j2us_2132_sid=Fx9Adv; expires=Fri, 12-Jul-2019 13:35:45 GMT; Max-Age=86400; path=/; secure Set-Cookie: j2us_2132_lastact=1562852145%09forum.php%09; expires=Fri, 12-Jul-2019 13:35:45 GMT; Max-Age=86400; path=/; secure Set-Cookie: j2us_2132_sid=Fx9Adv; expires=Fri, 12-Jul-2019 13:35:45 GMT; Max-Age=86400; path=/; secure Content-Encoding: gzip Vary: Accept-Encoding  ,7584, 5
[1:7:0711/213549.868806:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/213549.882957:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_https://www.im286.net/
[7491:7491:0711/213549.942540:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://www.im286.net/, https://www.im286.net/, 1
[7491:7491:0711/213549.942600:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://www.im286.net/, https://www.im286.net
[1:1:0711/213549.950466:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/213549.999844:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/213550.041716:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/213550.042054:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.im286.net/forum.php"
[1:1:0711/213551.224835:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/213552.029850:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 265 0x7fb702e5e070 0x311345bc8160 , "https://www.im286.net/forum.php"
[1:1:0711/213552.030820:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.im286.net/, 2087f75c2860, , , var STYLEID = '2', STATICURL = 'static/', IMGDIR = 'static/image/common', VERHASH = 'Y5U', charset =
[1:1:0711/213552.030993:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.im286.net/forum.php", "www.im286.net", 3, 1, , , 0
[1:1:0711/213552.034722:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 265 0x7fb702e5e070 0x311345bc8160 , "https://www.im286.net/forum.php"
[1:1:0711/213552.044093:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/213552.058467:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 265 0x7fb702e5e070 0x311345bc8160 , "https://www.im286.net/forum.php"
[1:1:0711/213552.086394:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0546112, 313, 1
[1:1:0711/213552.086582:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/213552.231620:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/213552.231794:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.im286.net/forum.php"
[1:1:0711/213552.232216:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 291 0x7fb702e5e070 0x311345bdf260 , "https://www.im286.net/forum.php"
[1:1:0711/213552.232672:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.im286.net/, 2087f75c2860, , , 
runslideshow();

[1:1:0711/213552.232808:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.im286.net/forum.php", "www.im286.net", 3, 1, , , 0
[1:1:0711/213552.244628:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 50, 0x3e79c85c29c8, 0x3113457601a0
[1:1:0711/213552.244792:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.im286.net/forum.php", 50
[1:1:0711/213552.244979:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.im286.net/, 299
[1:1:0711/213552.245107:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 299 0x7fb702e5e070 0x3113459b4360 , 5:3_https://www.im286.net/, 1, -5:3_https://www.im286.net/, 291 0x7fb702e5e070 0x311345bdf260 
[1:1:0711/213552.300959:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0692041, 1207, 1
[1:1:0711/213552.301202:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/213552.615285:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/213552.615496:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.im286.net/forum.php"
[1:1:0711/213552.616028:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 343 0x7fb702e5e070 0x311345c05660 , "https://www.im286.net/forum.php"
[1:1:0711/213552.616565:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.im286.net/, 2087f75c2860, , , var cookieLogin = Ajax("TEXT");cookieLogin.get("connect.php?mod=check&op=cookie", function() {});
[1:1:0711/213552.616735:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.im286.net/forum.php", "www.im286.net", 3, 1, , , 0
[1:1:0711/213552.620463:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 250, 0x3e79c85c29c8, 0x3113457601a8
[1:1:0711/213552.620606:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.im286.net/forum.php", 250
[1:1:0711/213552.620808:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.im286.net/, 353
[1:1:0711/213552.620925:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 353 0x7fb702e5e070 0x3113456cabe0 , 5:3_https://www.im286.net/, 1, -5:3_https://www.im286.net/, 343 0x7fb702e5e070 0x311345c05660 
[1:1:0711/213552.621390:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.im286.net/forum.php"
[1:1:0711/213552.624817:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 343 0x7fb702e5e070 0x311345c05660 , "https://www.im286.net/forum.php"
[1:1:0711/213552.632323:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.016737, 69, 1
[1:1:0711/213552.632498:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/213552.633576:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.im286.net/, 299, 7fb7057a3881
[1:1:0711/213552.639460:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2087f75c2860","ptid":"291 0x7fb702e5e070 0x311345bdf260 ","rf":"5:3_https://www.im286.net/"}
[1:1:0711/213552.639621:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.im286.net/","ptid":"291 0x7fb702e5e070 0x311345bdf260 ","rf":"5:3_https://www.im286.net/"}
[1:1:0711/213552.639821:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.im286.net/forum.php"
[1:1:0711/213552.640094:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.im286.net/, 2087f75c2860, , , () {checkrun();}
[1:1:0711/213552.640218:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.im286.net/forum.php", "www.im286.net", 3, 1, , , 0
[1:1:0711/213552.640658:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 50, 0x3e79c85c29c8, 0x311345760150
[1:1:0711/213552.640776:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.im286.net/forum.php", 50
[1:1:0711/213552.640959:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.im286.net/, 362
[1:1:0711/213552.641092:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 362 0x7fb702e5e070 0x311345c01460 , 5:3_https://www.im286.net/, 1, -5:3_https://www.im286.net/, 299 0x7fb702e5e070 0x3113459b4360 
[1:1:0711/213552.736972:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/213552.737166:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.im286.net/forum.php"
[1:1:0711/213552.738274:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 361 0x7fb702e5e070 0x311345be03e0 , "https://www.im286.net/forum.php"
[1:1:0711/213552.738694:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.im286.net/, 2087f75c2860, , , 
[1:1:0711/213552.738826:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.im286.net/forum.php", "www.im286.net", 3, 1, , , 0
[1:1:0711/213552.739731:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 361 0x7fb702e5e070 0x311345be03e0 , "https://www.im286.net/forum.php"
[1:1:0711/213552.741072:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 361 0x7fb702e5e070 0x311345be03e0 , "https://www.im286.net/forum.php"
[1:1:0711/213552.949421:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 364 0x7fb704d862e0 0x311345c04ae0 , "https://www.im286.net/forum.php"
[1:1:0711/213552.953552:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.im286.net/, 2087f75c2860, , , /*
	[Discuz!] (C)2001-2099 Comsenz Inc.
	This is NOT a freeware, use is subject to license terms

[1:1:0711/213552.953724:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.im286.net/forum.php", "www.im286.net", 3, 1, , , 0
[1:1:0711/213552.954422:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.im286.net/forum.php"
[1:1:0711/213552.979372:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.im286.net/, 362, 7fb7057a3881
[1:1:0711/213552.984630:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2087f75c2860","ptid":"299 0x7fb702e5e070 0x3113459b4360 ","rf":"5:3_https://www.im286.net/"}
[1:1:0711/213552.984789:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.im286.net/","ptid":"299 0x7fb702e5e070 0x3113459b4360 ","rf":"5:3_https://www.im286.net/"}
[1:1:0711/213552.984926:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.im286.net/forum.php"
[1:1:0711/213552.985184:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.im286.net/, 2087f75c2860, , , () {checkrun();}
[1:1:0711/213552.985283:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.im286.net/forum.php", "www.im286.net", 3, 1, , , 0
[1:1:0711/213553.518273:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 2500, 0x3e79c85c29c8, 0x311345760150
[1:1:0711/213553.518488:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.im286.net/forum.php", 2500
[1:1:0711/213553.518711:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.im286.net/, 407
[1:1:0711/213553.518845:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 407 0x7fb702e5e070 0x311345d225e0 , 5:3_https://www.im286.net/, 1, -5:3_https://www.im286.net/, 362 0x7fb702e5e070 0x311345c01460 
[1:1:0711/213553.613789:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.im286.net/, 353, 7fb7057a3881
[1:1:0711/213553.619440:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2087f75c2860","ptid":"343 0x7fb702e5e070 0x311345c05660 ","rf":"5:3_https://www.im286.net/"}
[1:1:0711/213553.619605:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.im286.net/","ptid":"343 0x7fb702e5e070 0x311345c05660 ","rf":"5:3_https://www.im286.net/"}
[1:1:0711/213553.619786:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.im286.net/forum.php"
[1:1:0711/213553.620058:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.im286.net/, 2087f75c2860, , , (){aj.showLoading()}
[1:1:0711/213553.620182:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.im286.net/forum.php", "www.im286.net", 3, 1, , , 0
[1:1:0711/213553.787133:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.im286.net/forum.php"
[1:1:0711/213553.787528:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.im286.net/, 2087f75c2860, , Ajax.aj.processHandle, () {
		if(aj.XMLHttpRequest.readyState == 4 && aj.XMLHttpRequest.status == 200) {
			if(aj.waitId)
[1:1:0711/213553.787658:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.im286.net/forum.php", "www.im286.net", 3, 1, , , 0
[1:1:0711/213553.788005:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.im286.net/forum.php"
[1:1:0711/213553.789219:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.im286.net/forum.php"
[1:1:0711/213554.055535:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.im286.net/forum.php"
[1:1:0711/213554.055962:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.im286.net/, 2087f75c2860, , cardInit, () {
	var cardShow = function (obj) {
		if(BROWSER.ie && BROWSER.ie < 7 && obj.href.indexOf('usern
[1:1:0711/213554.056133:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.im286.net/forum.php", "www.im286.net", 3, 1, , , 0
[1:1:0711/213555.459091:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.im286.net/, 2087f75c2860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0711/213555.459314:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.im286.net/forum.php", "www.im286.net", 3, 1, , , 0
[7491:7491:0711/213555.610784:INFO:CONSOLE(80)] "Mixed Content: The page at 'https://www.im286.net/forum.php' was loaded over HTTPS, but requested an insecure image 'http://www.im286.net/286/qy3.gif'. This content should also be served over HTTPS.", source: https://www.im286.net/forum.php (80)
[3:3:0711/213555.652260:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0711/213556.027211:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.im286.net/, 407, 7fb7057a3881
[1:1:0711/213556.035069:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2087f75c2860","ptid":"362 0x7fb702e5e070 0x311345c01460 ","rf":"5:3_https://www.im286.net/"}
[1:1:0711/213556.035266:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.im286.net/","ptid":"362 0x7fb702e5e070 0x311345c01460 ","rf":"5:3_https://www.im286.net/"}
[1:1:0711/213556.035468:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.im286.net/forum.php"
[1:1:0711/213556.035754:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.im286.net/, 2087f75c2860, , , (){
			ss.run();
		}
[1:1:0711/213556.035844:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.im286.net/forum.php", "www.im286.net", 3, 1, , , 0
[1:1:0711/213556.036773:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 2500, 0x3e79c85c29c8, 0x311345760150
[1:1:0711/213556.036868:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.im286.net/forum.php", 2500
[1:1:0711/213556.037012:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.im286.net/, 469
[1:1:0711/213556.037131:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 469 0x7fb702e5e070 0x311345a76ae0 , 5:3_https://www.im286.net/, 1, -5:3_https://www.im286.net/, 407 0x7fb702e5e070 0x311345d225e0 
[1:1:0711/213558.546009:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.im286.net/, 469, 7fb7057a3881
[1:1:0711/213558.553711:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2087f75c2860","ptid":"407 0x7fb702e5e070 0x311345d225e0 ","rf":"5:3_https://www.im286.net/"}
[1:1:0711/213558.553906:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.im286.net/","ptid":"407 0x7fb702e5e070 0x311345d225e0 ","rf":"5:3_https://www.im286.net/"}
[1:1:0711/213558.554126:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.im286.net/forum.php"
[1:1:0711/213558.554451:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.im286.net/, 2087f75c2860, , , (){
			ss.run();
		}
[1:1:0711/213558.554610:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.im286.net/forum.php", "www.im286.net", 3, 1, , , 0
[1:1:0711/213558.555290:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 2500, 0x3e79c85c29c8, 0x311345760150
[1:1:0711/213558.555424:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.im286.net/forum.php", 2500
[1:1:0711/213558.555648:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.im286.net/, 548
[1:1:0711/213558.555791:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 548 0x7fb702e5e070 0x31134642e760 , 5:3_https://www.im286.net/, 1, -5:3_https://www.im286.net/, 469 0x7fb702e5e070 0x311345a76ae0 
