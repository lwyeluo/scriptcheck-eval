[0713/002402.907868:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/002402.908131:INFO:switcher_clone.cc(787)] backtrace rip is 7feec08ae891
[0713/002403.456280:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/002403.456530:INFO:switcher_clone.cc(787)] backtrace rip is 7ff3eeed3891
[1:1:0713/002403.460372:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0713/002403.460538:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0713/002403.463422:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[0713/002404.305832:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/002404.306094:INFO:switcher_clone.cc(787)] backtrace rip is 7fe0a0040891
[30714:30714:0713/002404.332616:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/03198e62-ef44-44ac-b542-2c8338c7e969
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[30745:30745:0713/002404.453659:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=30745
[30758:30758:0713/002404.453952:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=30758
[30714:30714:0713/002404.572806:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[30714:30743:0713/002404.573271:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0713/002404.573411:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0713/002404.573597:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0713/002404.573927:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0713/002404.574085:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0713/002404.575811:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x34420c53, 1
[1:1:0713/002404.576009:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0xaffa4c4, 0
[1:1:0713/002404.576113:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x3d1afb21, 3
[1:1:0713/002404.576206:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x287ff5c8, 2
[1:1:0713/002404.576299:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffc4ffffffa4ffffffff0a 530c4234 ffffffc8fffffff57f28 21fffffffb1a3d , 10104, 4
[1:1:0713/002404.576938:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[30714:30743:0713/002404.577085:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGĤ�
SB4��(!�=E�\+
[1:1:0713/002404.577066:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7ff3ed10d0a0, 3
[30714:30743:0713/002404.577152:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is Ĥ�
SB4��(!�=زE�\+
[1:1:0713/002404.577193:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7ff3ed299080, 2
[1:1:0713/002404.577293:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7ff3d6f5bd20, -2
[30714:30743:0713/002404.577389:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[30714:30743:0713/002404.577427:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 30766, 4, c4a4ff0a 530c4234 c8f57f28 21fb1a3d 
[1:1:0713/002404.584951:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0713/002404.585386:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 287ff5c8
[1:1:0713/002404.585820:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 287ff5c8
[1:1:0713/002404.586536:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 287ff5c8
[1:1:0713/002404.587058:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 287ff5c8
[1:1:0713/002404.587170:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 287ff5c8
[1:1:0713/002404.587284:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 287ff5c8
[1:1:0713/002404.587410:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 287ff5c8
[1:1:0713/002404.587670:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 287ff5c8
[1:1:0713/002404.587815:INFO:switcher_clone.cc(775)] clone wrapper rip is 7ff3eeed37ba
[1:1:0713/002404.587895:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7ff3eeecadef, 7ff3eeed377a, 7ff3eeed50cf
[1:1:0713/002404.589506:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 287ff5c8
[1:1:0713/002404.589688:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 287ff5c8
[1:1:0713/002404.590042:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 287ff5c8
[1:1:0713/002404.590844:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 287ff5c8
[1:1:0713/002404.590962:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 287ff5c8
[1:1:0713/002404.591061:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 287ff5c8
[1:1:0713/002404.591183:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 287ff5c8
[1:1:0713/002404.591738:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 287ff5c8
[1:1:0713/002404.591917:INFO:switcher_clone.cc(775)] clone wrapper rip is 7ff3eeed37ba
[1:1:0713/002404.591974:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7ff3eeecadef, 7ff3eeed377a, 7ff3eeed50cf
[1:1:0713/002404.594555:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0713/002404.594742:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0713/002404.594855:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffc12195ee8, 0x7ffc12195e68)
[1:1:0713/002404.601624:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0713/002404.604232:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[30714:30714:0713/002404.995119:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[30714:30714:0713/002404.995601:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[30714:30725:0713/002405.004121:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[30714:30725:0713/002405.004187:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[30714:30714:0713/002405.004203:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[30714:30714:0713/002405.004249:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[30714:30714:0713/002405.004321:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,30766, 4
[1:7:0713/002405.006140:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/002405.047074:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x27e5a4ad1220
[1:1:0713/002405.047235:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0713/002405.237746:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[30714:30738:0713/002405.283186:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0713/002405.984115:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/002405.985672:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[30714:30714:0713/002406.355801:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[30714:30714:0713/002406.355913:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0713/002406.460881:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/002406.587982:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 10d70e341f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0713/002406.588178:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/002406.598451:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 10d70e341f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0713/002406.598633:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/002406.626424:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/002406.626574:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/002406.772194:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 359, "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/002406.774714:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 10d70e341f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0713/002406.774863:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/002406.786931:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 360, "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/002406.789913:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 10d70e341f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0713/002406.790052:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/002406.793840:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[30714:30714:0713/002406.794507:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0713/002406.795592:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x27e5a4acfe20
[1:1:0713/002406.795698:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[30714:30714:0713/002406.797022:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[30714:30714:0713/002406.808336:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[30714:30714:0713/002406.808428:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0713/002406.827692:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/002407.129233:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 419 0x7ff3d8b362e0 0x27e5a4ca7160 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/002407.129937:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 10d70e341f78, , , var configData = {"googleBaseUrl":"https://www.google.com.hk/","isAccessibleBrowser":false,"isGoogle
[1:1:0713/002407.130105:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/002407.130648:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[30714:30714:0713/002407.156718:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0713/002407.157815:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x27e5a4ad0820
[1:1:0713/002407.157966:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[30714:30714:0713/002407.159104:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0713/002407.164850:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0713/002407.164984:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[30714:30714:0713/002407.165974:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[30714:30714:0713/002407.170092:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[30714:30714:0713/002407.170531:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[30714:30725:0713/002407.175361:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[30714:30725:0713/002407.175424:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[30714:30714:0713/002407.175446:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[30714:30714:0713/002407.175485:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[30714:30714:0713/002407.175549:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,30766, 4
[1:7:0713/002407.177209:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/002407.457113:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0713/002407.581894:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 466 0x7ff3d8b362e0 0x27e5a4da64e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/002407.582468:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 10d70e341f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0713/002407.582580:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/002407.582953:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[30714:30714:0713/002407.743535:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[30714:30714:0713/002407.743616:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0713/002407.755506:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[30714:30714:0713/002407.873922:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[30714:30743:0713/002407.874261:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0713/002407.874396:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0713/002407.874546:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0713/002407.874743:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0713/002407.874854:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0713/002407.877178:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x2af7b818, 1
[1:1:0713/002407.877422:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x18d309ac, 0
[1:1:0713/002407.877593:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x9148d13, 3
[1:1:0713/002407.877751:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x220c24df, 2
[1:1:0713/002407.877901:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffac09ffffffd318 18ffffffb8fffffff72a ffffffdf240c22 13ffffff8d1409 , 10104, 5
[1:1:0713/002407.878667:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[30714:30743:0713/002407.878873:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�	���*�$"�	��\+
[30714:30743:0713/002407.878927:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �	���*�$"�	�Ǜ�\+
[1:1:0713/002407.878865:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7ff3ed10d0a0, 3
[30714:30743:0713/002407.879067:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 30808, 5, ac09d318 18b8f72a df240c22 138d1409 
[1:1:0713/002407.879649:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7ff3ed299080, 2
[1:1:0713/002407.879756:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7ff3d6f5bd20, -2
[1:1:0713/002407.889338:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0713/002407.889541:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 220c24df
[1:1:0713/002407.889714:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 220c24df
[1:1:0713/002407.889975:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 220c24df
[1:1:0713/002407.890475:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 220c24df
[1:1:0713/002407.890574:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 220c24df
[1:1:0713/002407.890667:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 220c24df
[1:1:0713/002407.890758:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 220c24df
[1:1:0713/002407.891008:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 220c24df
[1:1:0713/002407.891134:INFO:switcher_clone.cc(775)] clone wrapper rip is 7ff3eeed37ba
[1:1:0713/002407.891211:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7ff3eeecadef, 7ff3eeed377a, 7ff3eeed50cf
[1:1:0713/002407.892937:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 220c24df
[1:1:0713/002407.893108:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 220c24df
[1:1:0713/002407.893455:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 220c24df
[1:1:0713/002407.894288:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 220c24df
[1:1:0713/002407.894418:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 220c24df
[1:1:0713/002407.894543:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 220c24df
[1:1:0713/002407.894650:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 220c24df
[1:1:0713/002407.895165:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 220c24df
[1:1:0713/002407.895338:INFO:switcher_clone.cc(775)] clone wrapper rip is 7ff3eeed37ba
[1:1:0713/002407.895421:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7ff3eeecadef, 7ff3eeed377a, 7ff3eeed50cf
[1:1:0713/002407.898031:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0713/002407.898280:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0713/002407.898399:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffc12195ee8, 0x7ffc12195e68)
[1:1:0713/002407.904545:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0713/002407.905383:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/002407.906505:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0713/002407.993331:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x27e5a4a9d220
[1:1:0713/002407.993534:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0713/002408.184633:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/002408.184815:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[30714:30714:0713/002408.318422:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[30714:30714:0713/002408.320336:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0713/002408.329605:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 541, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/002408.331210:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 10d70e46e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0713/002408.331403:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/002408.333678:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[30714:30714:0713/002408.341283:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://www.liangle.com/
[30714:30714:0713/002408.341339:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://www.liangle.com/, http://www.liangle.com/, 1
[30714:30714:0713/002408.341403:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://www.liangle.com/, HTTP/1.1 200 OK Server: nginx Date: Fri, 12 Jul 2019 16:24:08 GMT Content-Type: text/html; charset=UTF-8 Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding X-Powered-By: PHP/7.1.2 X-Server: liangle-web-2-10-prd.vpc Content-Encoding: gzip X-Server: zhangjiaozhu-lb-1-106-prd.vpc  ,30808, 5
[30714:30725:0713/002408.341901:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[30714:30725:0713/002408.341957:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[1:7:0713/002408.342661:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/002408.357276:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://www.liangle.com/
[1:1:0713/002408.384341:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/002408.384760:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 10d70e341f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0713/002408.384901:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[30714:30714:0713/002408.413973:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://www.liangle.com/, http://www.liangle.com/, 1
[30714:30714:0713/002408.414036:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://www.liangle.com/, http://www.liangle.com
[1:1:0713/002408.427463:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/002408.472632:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/002408.507642:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/002408.507846:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.liangle.com/"
[1:1:0713/002408.510856:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/002408.511743:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0713/002408.511869:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 10d70e46e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0713/002408.511987:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/002408.560986:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 122 0x7ff3d6c0e070 0x27e5a4b6fe60 , "http://www.liangle.com/"
[1:1:0713/002408.562048:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.liangle.com/, 35e977ba2860, , , 
        var __dacePageName = 'list';

        !function(win){
            var HTV = win.HTV = {};
 
[1:1:0713/002408.562183:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.liangle.com/", "www.liangle.com", 3, 1, , , 0
[1:1:0713/002408.563419:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 122 0x7ff3d6c0e070 0x27e5a4b6fe60 , "http://www.liangle.com/"
[1:1:0713/002408.564512:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/002408.568705:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/002408.577441:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0713/002408.577583:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 10d70e46e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0713/002408.577712:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/002408.708510:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 159, "http://www.liangle.com/"
[1:1:0713/002408.711713:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.liangle.com/, 35e977ba2860, , , var __dace=function(){var ms=0,c={channel:[[1,"opahnet","Web_MV_v"],[2,"kaluli","web_biz_cal"],[3,"t
[1:1:0713/002408.711883:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.liangle.com/", "www.liangle.com", 3, 1, , , 0
[1:1:0713/002408.820674:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/002409.055686:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 221 0x7ff3d6f76bd0 0x27e5a4b455d8 , "http://www.liangle.com/"
[1:1:0713/002409.063301:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.liangle.com/, 35e977ba2860, , , try{!function(){window.___baidu_union_||(window.___baidu_union_={}),window.___baidu_union_dup_||(win
[1:1:0713/002409.063518:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.liangle.com/", "www.liangle.com", 3, 1, , , 0
		remove user.e_cf27770 -> 0
[1:1:0713/002409.729362:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 221 0x7ff3d6f76bd0 0x27e5a4b455d8 , "http://www.liangle.com/"
[1:1:0713/002409.826762:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0981002, 114, 1
[1:1:0713/002409.827045:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/002410.219259:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/002410.219461:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.liangle.com/"
[1:1:0713/002410.227627:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.00809407, 188, 1
[1:1:0713/002410.227771:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/002410.615034:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "loadstart", "http://www.liangle.com/"
[1:1:0713/002410.644165:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/002410.644295:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.liangle.com/"
[1:1:0713/002410.649700:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.00542307, 58, 1
[1:1:0713/002410.649874:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/002410.980408:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 378 0x7ff3d8b362e0 0x27e5a54b9ce0 , "http://www.liangle.com/"
[1:1:0713/002410.980975:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.liangle.com/, 35e977ba2860, , , _DACE_GetVid("0x51cabce88113f55d",1);
[1:1:0713/002410.981108:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.liangle.com/", "www.liangle.com", 3, 1, , , 0
[1:1:0713/002411.215507:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/002411.215714:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.liangle.com/"
[1:1:0713/002411.229321:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.013566, 141, 1
[1:1:0713/002411.229499:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/002412.030508:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/002412.030682:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.liangle.com/"
[1:1:0713/002412.031895:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 499 0x7ff3d6c0e070 0x27e5a5594260 , "http://www.liangle.com/"
[1:1:0713/002412.032390:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.liangle.com/, 35e977ba2860, , , document.write('<script type="text/javascript" src="https://goto.hupu.com/?pid=105" charset="utf-8">
[1:1:0713/002412.032530:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.liangle.com/", "www.liangle.com", 3, 1, , , 0
[1:1:0713/002412.056096:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 503 0x7ff3d8b362e0 0x27e5a5474e60 , "http://www.liangle.com/"
[1:1:0713/002412.059150:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.liangle.com/, 35e977ba2860, , , (function(){var h={},mt={},c={id:"b55ae6a6cd9b8ca6596073078419d698",dm:["liangle.com"],js:"tongji.ba
[1:1:0713/002412.059324:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.liangle.com/", "www.liangle.com", 3, 1, , , 0
[1:1:0713/002412.072093:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2d20a4a29c8, 0x27e5a46b5948
[1:1:0713/002412.072265:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.liangle.com/", 100
[1:1:0713/002412.072456:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.liangle.com/, 569
[1:1:0713/002412.072588:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 569 0x7ff3d6c0e070 0x27e5a558ede0 , 5:3_http://www.liangle.com/, 1, -5:3_http://www.liangle.com/, 503 0x7ff3d8b362e0 0x27e5a5474e60 
[1:1:0713/002413.214538:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[30714:30725:0713/002420.874009:ERROR:ssl_client_socket_impl.cc(1046)] handshake failed; returned -1, SSL error code 1, net_error -101
[30714:30714:0713/002428.051904:INFO:CONSOLE(1)] "A parser-blocking, cross site (i.e. different eTLD+1) script, https://goto.hupu.com/?pid=105, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: https://goto.hupu.com/js/c/105.js (1)
[30714:30714:0713/002428.052804:INFO:CONSOLE(1)] "A parser-blocking, cross site (i.e. different eTLD+1) script, https://goto.hupu.com/?pid=105, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: https://goto.hupu.com/js/c/105.js (1)
[3:3:0713/002428.614467:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0713/002429.473622:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.liangle.com/"
[1:1:0713/002429.474576:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.liangle.com/, 35e977ba2860, , , (){He(d,"")}
[1:1:0713/002429.474761:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.liangle.com/", "www.liangle.com", 3, 1, , , 0
[1:1:0713/002429.507682:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.liangle.com/"
[1:1:0713/002429.508130:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.liangle.com/, 35e977ba2860, , , (){He(d,"")}
[1:1:0713/002429.508291:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.liangle.com/", "www.liangle.com", 3, 1, , , 0
[1:1:0713/002429.630061:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 573, "http://www.liangle.com/"
[1:1:0713/002429.630610:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.liangle.com/, 35e977ba2860, , , 
[1:1:0713/002429.630800:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.liangle.com/", "www.liangle.com", 3, 1, , , 0
[1:1:0713/002429.635228:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.00394392, 56, 1
[1:1:0713/002429.635372:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/002429.651614:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.liangle.com/, 35e977ba2860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0713/002429.651790:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.liangle.com/", "www.liangle.com", 3, 1, , , 0
[1:1:0713/002430.594715:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.liangle.com/, 569, 7ff3d9553881
[1:1:0713/002430.606689:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"35e977ba2860","ptid":"503 0x7ff3d8b362e0 0x27e5a5474e60 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002430.606911:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.liangle.com/","ptid":"503 0x7ff3d8b362e0 0x27e5a5474e60 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002430.607186:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.liangle.com/"
[1:1:0713/002430.607514:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.liangle.com/, 35e977ba2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/002430.607661:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.liangle.com/", "www.liangle.com", 3, 1, , , 0
[1:1:0713/002430.608112:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2d20a4a29c8, 0x27e5a46b5950
[1:1:0713/002430.608218:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.liangle.com/", 100
[1:1:0713/002430.608411:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.liangle.com/, 697
[1:1:0713/002430.608542:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 697 0x7ff3d6c0e070 0x27e5a5487760 , 5:3_http://www.liangle.com/, 1, -5:3_http://www.liangle.com/, 569 0x7ff3d6c0e070 0x27e5a558ede0 
[1:1:0713/002430.830900:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/002430.831097:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.liangle.com/"
[1:1:0713/002430.834102:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 668 0x7ff3d6c0e070 0x27e5a5474660 , "http://www.liangle.com/"
[1:1:0713/002430.852567:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.liangle.com/, 35e977ba2860, , , ;var require,define;!function(e){function r(e,r){function t(){clearTimeout(a)}if(!(e in s)){s[e]=!0;
[1:1:0713/002430.852776:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.liangle.com/", "www.liangle.com", 3, 1, , , 0
[1:1:0713/002430.978881:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 668 0x7ff3d6c0e070 0x27e5a5474660 , "http://www.liangle.com/"
[1:1:0713/002430.987476:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 668 0x7ff3d6c0e070 0x27e5a5474660 , "http://www.liangle.com/"
[1:1:0713/002430.990239:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 668 0x7ff3d6c0e070 0x27e5a5474660 , "http://www.liangle.com/"
[1:1:0713/002430.994020:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 668 0x7ff3d6c0e070 0x27e5a5474660 , "http://www.liangle.com/"
[1:1:0713/002431.121279:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.liangle.com/, 35e977ba2860, , , document.readyState
[1:1:0713/002431.121470:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.liangle.com/", "www.liangle.com", 3, 1, , , 0
[1:1:0713/002431.831813:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.liangle.com/, 697, 7ff3d9553881
[1:1:0713/002431.850455:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"35e977ba2860","ptid":"569 0x7ff3d6c0e070 0x27e5a558ede0 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002431.850705:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.liangle.com/","ptid":"569 0x7ff3d6c0e070 0x27e5a558ede0 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002431.850993:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.liangle.com/"
[1:1:0713/002431.851344:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.liangle.com/, 35e977ba2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/002431.851513:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.liangle.com/", "www.liangle.com", 3, 1, , , 0
[1:1:0713/002431.851876:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2d20a4a29c8, 0x27e5a46b5950
[1:1:0713/002431.852015:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.liangle.com/", 100
[1:1:0713/002431.852178:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.liangle.com/, 764
[1:1:0713/002431.852305:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 764 0x7ff3d6c0e070 0x27e5a5b7ca60 , 5:3_http://www.liangle.com/, 1, -5:3_http://www.liangle.com/, 697 0x7ff3d6c0e070 0x27e5a5487760 
[1:1:0713/002432.075736:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.liangle.com/, 35e977ba2860, , , document.readyState
[1:1:0713/002432.075906:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.liangle.com/", "www.liangle.com", 3, 1, , , 0
[1:1:0713/002432.616388:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.liangle.com/"
[1:1:0713/002432.616810:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.liangle.com/, 35e977ba2860, , f.onload, (){f.onload=u;f=window[d]=u;a&&a(b)}
[1:1:0713/002432.616932:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.liangle.com/", "www.liangle.com", 3, 1, , , 0
[1:1:0713/002432.707787:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 765 0x7ff3d6f76bd0 0x27e5a54bb058 , "http://www.liangle.com/"
[1:1:0713/002432.715678:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.liangle.com/, 35e977ba2860, , , ;"undefined"==typeof window.HTMLVideoElement&&(document.createElement("video"),document.createElemen
[1:1:0713/002432.715863:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.liangle.com/", "www.liangle.com", 3, 1, , , 0
[30714:30714:0713/002432.772645:INFO:CONSOLE(1)] "Application Cache is deprecated in non-secure contexts, and will be restricted to secure contexts in M69, around September 2018. Please consider migrating your application to HTTPS, and eventually shifting over to Service Workers. See https://goo.gl/rStTGz for more details.", source: http://assets.liangle.com/tv/static/common/pkg/videojs_cd31032.js (1)
[1:1:0713/002433.035307:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/002433.061231:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x2d20a4a29c8, 0x27e5a46b5960
[1:1:0713/002433.061488:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.liangle.com/", 1
[1:1:0713/002433.061737:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.liangle.com/, 795
[1:1:0713/002433.061882:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 795 0x7ff3d6c0e070 0x27e5a48b1b60 , 5:3_http://www.liangle.com/, 1, -5:3_http://www.liangle.com/, 765 0x7ff3d6f76bd0 0x27e5a54bb058 
[1:1:0713/002433.085100:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 765 0x7ff3d6f76bd0 0x27e5a54bb058 , "http://www.liangle.com/"
[1:1:0713/002433.087131:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 765 0x7ff3d6f76bd0 0x27e5a54bb058 , "http://www.liangle.com/"
[1:1:0713/002433.089163:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 765 0x7ff3d6f76bd0 0x27e5a54bb058 , "http://www.liangle.com/"
[1:1:0713/002433.235559:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2d20a4a29c8, 0x27e5a46b59b8
[1:1:0713/002433.235742:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.liangle.com/", 0
[1:1:0713/002433.235974:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.liangle.com/, 810
[1:1:0713/002433.236098:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 810 0x7ff3d6c0e070 0x27e5a55948e0 , 5:3_http://www.liangle.com/, 1, -5:3_http://www.liangle.com/, 765 0x7ff3d6f76bd0 0x27e5a54bb058 
[1:1:0713/002433.237505:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x2d20a4a29c8, 0x27e5a46b59b8
[1:1:0713/002433.237626:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.liangle.com/", 1
[1:1:0713/002433.237792:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.liangle.com/, 811
[1:1:0713/002433.237909:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 811 0x7ff3d6c0e070 0x27e5a5482760 , 5:3_http://www.liangle.com/, 1, -5:3_http://www.liangle.com/, 765 0x7ff3d6f76bd0 0x27e5a54bb058 
[1:1:0713/002433.299905:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x2d20a4a29c8, 0x27e5a46b59b8
[1:1:0713/002433.300103:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.liangle.com/", 1
[1:1:0713/002433.300312:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.liangle.com/, 812
[1:1:0713/002433.300458:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 812 0x7ff3d6c0e070 0x27e5a5669fe0 , 5:3_http://www.liangle.com/, 1, -5:3_http://www.liangle.com/, 765 0x7ff3d6f76bd0 0x27e5a54bb058 
[1:1:0713/002433.525249:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x2d20a4a29c8, 0x27e5a46b59b8
[1:1:0713/002433.525467:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.liangle.com/", 1
[1:1:0713/002433.525873:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.liangle.com/, 813
[1:1:0713/002433.526083:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 813 0x7ff3d6c0e070 0x27e5a7065160 , 5:3_http://www.liangle.com/, 1, -5:3_http://www.liangle.com/, 765 0x7ff3d6f76bd0 0x27e5a54bb058 
[1:1:0713/002433.774448:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x2d20a4a29c8, 0x27e5a46b59b8
[1:1:0713/002433.774678:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.liangle.com/", 1
[1:1:0713/002433.775244:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.liangle.com/, 814
[1:1:0713/002433.775397:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 814 0x7ff3d6c0e070 0x27e5a70db3e0 , 5:3_http://www.liangle.com/, 1, -5:3_http://www.liangle.com/, 765 0x7ff3d6f76bd0 0x27e5a54bb058 
[1:1:0713/002433.785168:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x2d20a4a29c8, 0x27e5a46b59b8
[1:1:0713/002433.785351:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.liangle.com/", 1
[1:1:0713/002433.785559:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.liangle.com/, 815
[1:1:0713/002433.785741:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 815 0x7ff3d6c0e070 0x27e5a73dd360 , 5:3_http://www.liangle.com/, 1, -5:3_http://www.liangle.com/, 765 0x7ff3d6f76bd0 0x27e5a54bb058 
[1:1:0713/002434.299833:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.liangle.com/", 250
[1:1:0713/002434.300166:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.liangle.com/, 816
[1:1:0713/002434.300335:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 816 0x7ff3d6c0e070 0x27e5a7962360 , 5:3_http://www.liangle.com/, 1, -5:3_http://www.liangle.com/, 765 0x7ff3d6f76bd0 0x27e5a54bb058 
[1:1:0713/002434.425572:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 1.34183, 0, 0
[1:1:0713/002434.425822:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/002434.508184:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.liangle.com/, 764, 7ff3d9553881
[1:1:0713/002434.521537:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"35e977ba2860","ptid":"697 0x7ff3d6c0e070 0x27e5a5487760 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002434.521811:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.liangle.com/","ptid":"697 0x7ff3d6c0e070 0x27e5a5487760 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002434.522099:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.liangle.com/"
[1:1:0713/002434.522420:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.liangle.com/, 35e977ba2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/002434.522524:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.liangle.com/", "www.liangle.com", 3, 1, , , 0
[1:1:0713/002434.522975:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2d20a4a29c8, 0x27e5a46b5950
[1:1:0713/002434.523079:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.liangle.com/", 100
[1:1:0713/002434.523244:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.liangle.com/, 833
[1:1:0713/002434.523389:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 833 0x7ff3d6c0e070 0x27e5a7a44ce0 , 5:3_http://www.liangle.com/, 1, -5:3_http://www.liangle.com/, 764 0x7ff3d6c0e070 0x27e5a5b7ca60 
[1:1:0713/002434.537306:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.liangle.com/, 35e977ba2860, , , document.readyState
[1:1:0713/002434.537464:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.liangle.com/", "www.liangle.com", 3, 1, , , 0
[1:1:0713/002435.113763:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/002435.113942:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.liangle.com/"
[1:1:0713/002435.114654:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://www.liangle.com/"
[1:1:0713/002435.115027:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.liangle.com/, 35e977ba2860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0713/002435.115189:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.liangle.com/", "www.liangle.com", 3, 1, , , 0
[1:1:0713/002435.119266:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://www.liangle.com/"
[1:1:0713/002435.120111:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://www.liangle.com/"
[1:1:0713/002435.264938:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://www.liangle.com/"
[1:1:0713/002435.266027:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 25, 0x2d20a4a29c8, 0x27e5a46b59f0
[1:1:0713/002435.266200:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.liangle.com/", 25
[1:1:0713/002435.266451:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.liangle.com/, 853
[1:1:0713/002435.266618:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 853 0x7ff3d6c0e070 0x27e5a4b504e0 , 5:3_http://www.liangle.com/, 1, -5:3_http://www.liangle.com/, 818 0x7ff3d6c0e070 0x27e5a79642e0 
[1:1:0713/002435.295534:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.liangle.com/, 795, 7ff3d9553881
[1:1:0713/002435.308894:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"35e977ba2860","ptid":"765 0x7ff3d6f76bd0 0x27e5a54bb058 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002435.309124:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.liangle.com/","ptid":"765 0x7ff3d6f76bd0 0x27e5a54bb058 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002435.309346:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.liangle.com/"
[1:1:0713/002435.309643:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.liangle.com/, 35e977ba2860, , f, (){var t=l["default"].getElementsByTagName("video"),e=l["default"].getElementsByTagName("audio"),n=[
[1:1:0713/002435.309773:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.liangle.com/", "www.liangle.com", 3, 1, , , 0
[1:1:0713/002435.311643:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.liangle.com/, 810, 7ff3d9553881
[1:1:0713/002435.325011:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"35e977ba2860","ptid":"765 0x7ff3d6f76bd0 0x27e5a54bb058 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002435.325241:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.liangle.com/","ptid":"765 0x7ff3d6f76bd0 0x27e5a54bb058 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002435.325442:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.liangle.com/"
[1:1:0713/002435.325690:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.liangle.com/, 35e977ba2860, , r, (){return e.apply(t,arguments)}
[1:1:0713/002435.325812:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.liangle.com/", "www.liangle.com", 3, 1, , , 0
[1:1:0713/002435.372534:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.liangle.com/, 811, 7ff3d9553881
[1:1:0713/002435.385833:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"35e977ba2860","ptid":"765 0x7ff3d6f76bd0 0x27e5a54bb058 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002435.386008:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.liangle.com/","ptid":"765 0x7ff3d6f76bd0 0x27e5a54bb058 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002435.386208:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.liangle.com/"
[1:1:0713/002435.386455:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.liangle.com/, 35e977ba2860, , r, (){return e.apply(t,arguments)}
[1:1:0713/002435.386528:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.liangle.com/", "www.liangle.com", 3, 1, , , 0
[1:1:0713/002435.391112:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.liangle.com/, 812, 7ff3d9553881
[1:1:0713/002435.405499:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"35e977ba2860","ptid":"765 0x7ff3d6f76bd0 0x27e5a54bb058 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002435.405716:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.liangle.com/","ptid":"765 0x7ff3d6f76bd0 0x27e5a54bb058 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002435.406002:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.liangle.com/"
[1:1:0713/002435.406311:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.liangle.com/, 35e977ba2860, , r, (){return e.apply(t,arguments)}
[1:1:0713/002435.406443:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.liangle.com/", "www.liangle.com", 3, 1, , , 0
[1:1:0713/002435.407836:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.liangle.com/, 813, 7ff3d9553881
[1:1:0713/002435.421363:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"35e977ba2860","ptid":"765 0x7ff3d6f76bd0 0x27e5a54bb058 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002435.421534:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.liangle.com/","ptid":"765 0x7ff3d6f76bd0 0x27e5a54bb058 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002435.421735:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.liangle.com/"
[1:1:0713/002435.422045:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.liangle.com/, 35e977ba2860, , r, (){return e.apply(t,arguments)}
[1:1:0713/002435.422144:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.liangle.com/", "www.liangle.com", 3, 1, , , 0
[1:1:0713/002435.451413:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.liangle.com/, 814, 7ff3d9553881
[1:1:0713/002435.464972:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"35e977ba2860","ptid":"765 0x7ff3d6f76bd0 0x27e5a54bb058 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002435.465202:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.liangle.com/","ptid":"765 0x7ff3d6f76bd0 0x27e5a54bb058 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002435.465424:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.liangle.com/"
[1:1:0713/002435.465741:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.liangle.com/, 35e977ba2860, , r, (){return e.apply(t,arguments)}
[1:1:0713/002435.465859:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.liangle.com/", "www.liangle.com", 3, 1, , , 0
[1:1:0713/002435.467272:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.liangle.com/, 815, 7ff3d9553881
[1:1:0713/002435.480945:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"35e977ba2860","ptid":"765 0x7ff3d6f76bd0 0x27e5a54bb058 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002435.481158:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.liangle.com/","ptid":"765 0x7ff3d6f76bd0 0x27e5a54bb058 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002435.481368:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.liangle.com/"
[1:1:0713/002435.481618:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.liangle.com/, 35e977ba2860, , r, (){return e.apply(t,arguments)}
[1:1:0713/002435.481716:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.liangle.com/", "www.liangle.com", 3, 1, , , 0
[1:1:0713/002435.524393:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.liangle.com/, 35e977ba2860, , , document.readyState
[1:1:0713/002435.524570:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.liangle.com/", "www.liangle.com", 3, 1, , , 0
[1:1:0713/002435.553445:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.liangle.com/, 816, 7ff3d95538db
[1:1:0713/002435.569499:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"35e977ba2860","ptid":"765 0x7ff3d6f76bd0 0x27e5a54bb058 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002435.569666:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.liangle.com/","ptid":"765 0x7ff3d6f76bd0 0x27e5a54bb058 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002435.569869:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.liangle.com/, 864
[1:1:0713/002435.569973:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 864 0x7ff3d6c0e070 0x27e5a612cfe0 , 5:3_http://www.liangle.com/, 0, , 816 0x7ff3d6c0e070 0x27e5a7962360 
[1:1:0713/002435.570102:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.liangle.com/"
[1:1:0713/002435.570369:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.liangle.com/, 35e977ba2860, , r, (){return e.apply(t,arguments)}
[1:1:0713/002435.570488:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.liangle.com/", "www.liangle.com", 3, 1, , , 0
[1:1:0713/002435.572910:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 2000, 0x2d20a4a29c8, 0x27e5a46b5950
[1:1:0713/002435.573106:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.liangle.com/", 2000
[1:1:0713/002435.573349:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.liangle.com/, 865
[1:1:0713/002435.573481:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 865 0x7ff3d6c0e070 0x27e5a7a4d460 , 5:3_http://www.liangle.com/, 1, -5:3_http://www.liangle.com/, 816 0x7ff3d6c0e070 0x27e5a7962360 
[1:1:0713/002435.604337:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.liangle.com/, 833, 7ff3d9553881
[1:1:0713/002435.619577:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"35e977ba2860","ptid":"764 0x7ff3d6c0e070 0x27e5a5b7ca60 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002435.619817:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.liangle.com/","ptid":"764 0x7ff3d6c0e070 0x27e5a5b7ca60 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002435.620106:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.liangle.com/"
[1:1:0713/002435.620430:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.liangle.com/, 35e977ba2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/002435.620575:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.liangle.com/", "www.liangle.com", 3, 1, , , 0
[1:1:0713/002435.620901:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2d20a4a29c8, 0x27e5a46b5950
[1:1:0713/002435.620989:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.liangle.com/", 100
[1:1:0713/002435.621174:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.liangle.com/, 868
[1:1:0713/002435.621297:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 868 0x7ff3d6c0e070 0x27e5a60397e0 , 5:3_http://www.liangle.com/, 1, -5:3_http://www.liangle.com/, 833 0x7ff3d6c0e070 0x27e5a7a44ce0 
[1:1:0713/002435.783579:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "loadstart", "http://www.liangle.com/"
[1:1:0713/002435.877808:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.liangle.com/, 853, 7ff3d9553881
[1:1:0713/002435.893283:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"35e977ba2860","ptid":"818 0x7ff3d6c0e070 0x27e5a79642e0 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002435.893551:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.liangle.com/","ptid":"818 0x7ff3d6c0e070 0x27e5a79642e0 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002435.893859:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.liangle.com/"
[1:1:0713/002435.894219:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.liangle.com/, 35e977ba2860, , , (){var list=document.body,target=null;EventUtil.addHandler(list,"mousedown",function(event){var e=Ev
[1:1:0713/002435.894372:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.liangle.com/", "www.liangle.com", 3, 1, , , 0
[1:1:0713/002435.910841:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://www.liangle.com/"
[1:1:0713/002435.911241:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.liangle.com/, 35e977ba2860, , n, (e,r){var o,u,l;if(n&&(r||4===a.readyState))if(delete ur[s],n=void 0,a.onreadystatechange=pt.noop,r)
[1:1:0713/002435.911355:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.liangle.com/", "www.liangle.com", 3, 1, , , 0
[1:1:0713/002435.912362:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://www.liangle.com/"
[1:1:0713/002435.914223:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://www.liangle.com/"
[1:1:0713/002435.914624:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x13d4c1507c10
[1:1:0713/002436.258530:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.liangle.com/, 35e977ba2860, , , document.readyState
[1:1:0713/002436.258729:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.liangle.com/", "www.liangle.com", 3, 1, , , 0
[1:1:0713/002436.339263:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.liangle.com/, 868, 7ff3d9553881
[1:1:0713/002436.355322:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"35e977ba2860","ptid":"833 0x7ff3d6c0e070 0x27e5a7a44ce0 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002436.355550:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.liangle.com/","ptid":"833 0x7ff3d6c0e070 0x27e5a7a44ce0 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002436.355779:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.liangle.com/"
[1:1:0713/002436.356083:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.liangle.com/, 35e977ba2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/002436.356186:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.liangle.com/", "www.liangle.com", 3, 1, , , 0
[1:1:0713/002436.356485:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2d20a4a29c8, 0x27e5a46b5950
[1:1:0713/002436.356586:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.liangle.com/", 100
[1:1:0713/002436.356757:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.liangle.com/, 929
[1:1:0713/002436.356860:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 929 0x7ff3d6c0e070 0x27e5a61a4460 , 5:3_http://www.liangle.com/, 1, -5:3_http://www.liangle.com/, 868 0x7ff3d6c0e070 0x27e5a60397e0 
[1:1:0713/002436.453266:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.liangle.com/, 864, 7ff3d95538db
[1:1:0713/002436.469636:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"816 0x7ff3d6c0e070 0x27e5a7962360 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002436.469794:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"816 0x7ff3d6c0e070 0x27e5a7962360 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002436.470012:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.liangle.com/, 933
[1:1:0713/002436.470122:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 933 0x7ff3d6c0e070 0x27e5a7a4d060 , 5:3_http://www.liangle.com/, 0, , 864 0x7ff3d6c0e070 0x27e5a612cfe0 
[1:1:0713/002436.470258:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.liangle.com/"
[1:1:0713/002436.470512:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.liangle.com/, 35e977ba2860, , r, (){return e.apply(t,arguments)}
[1:1:0713/002436.470613:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.liangle.com/", "www.liangle.com", 3, 1, , , 0
[1:1:0713/002436.521483:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 880 0x7ff3d8b362e0 0x27e5a7a4cf60 , "http://www.liangle.com/"
[1:1:0713/002436.522086:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.liangle.com/, 35e977ba2860, , , ___baidu_union_callback_("auto","4f77e82d6cd02a33e3acd3c047fdd068",[])
[1:1:0713/002436.522631:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.liangle.com/", "www.liangle.com", 3, 1, , , 0
[1:1:0713/002438.082389:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.liangle.com/, 35e977ba2860, , , document.readyState
[1:1:0713/002438.082598:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.liangle.com/", "www.liangle.com", 3, 1, , , 0
[1:1:0713/002438.174936:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.liangle.com/, 929, 7ff3d9553881
[1:1:0713/002438.191474:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"35e977ba2860","ptid":"868 0x7ff3d6c0e070 0x27e5a60397e0 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002438.191702:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.liangle.com/","ptid":"868 0x7ff3d6c0e070 0x27e5a60397e0 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002438.191972:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.liangle.com/"
[1:1:0713/002438.192285:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.liangle.com/, 35e977ba2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/002438.192413:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.liangle.com/", "www.liangle.com", 3, 1, , , 0
[1:1:0713/002438.192709:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2d20a4a29c8, 0x27e5a46b5950
[1:1:0713/002438.192798:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.liangle.com/", 100
[1:1:0713/002438.192957:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.liangle.com/, 1004
[1:1:0713/002438.193062:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1004 0x7ff3d6c0e070 0x27e5a54f4e60 , 5:3_http://www.liangle.com/, 1, -5:3_http://www.liangle.com/, 929 0x7ff3d6c0e070 0x27e5a61a4460 
[1:1:0713/002438.273257:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.liangle.com/, 933, 7ff3d95538db
[1:1:0713/002438.290131:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"864 0x7ff3d6c0e070 0x27e5a612cfe0 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002438.290325:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"864 0x7ff3d6c0e070 0x27e5a612cfe0 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002438.290557:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.liangle.com/, 1011
[1:1:0713/002438.290661:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1011 0x7ff3d6c0e070 0x27e5a65e08e0 , 5:3_http://www.liangle.com/, 0, , 933 0x7ff3d6c0e070 0x27e5a7a4d060 
[1:1:0713/002438.290848:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.liangle.com/"
[1:1:0713/002438.291096:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.liangle.com/, 35e977ba2860, , r, (){return e.apply(t,arguments)}
[1:1:0713/002438.291211:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.liangle.com/", "www.liangle.com", 3, 1, , , 0
[1:1:0713/002439.056551:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.liangle.com/, 865, 7ff3d9553881
[1:1:0713/002439.074332:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"35e977ba2860","ptid":"816 0x7ff3d6c0e070 0x27e5a7962360 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002439.074630:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.liangle.com/","ptid":"816 0x7ff3d6c0e070 0x27e5a7962360 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002439.074885:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.liangle.com/"
[1:1:0713/002439.075209:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.liangle.com/, 35e977ba2860, , r, (){return e.apply(t,arguments)}
[1:1:0713/002439.075340:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.liangle.com/", "www.liangle.com", 3, 1, , , 0
[1:1:0713/002439.448853:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.liangle.com/, 35e977ba2860, , , document.readyState
[1:1:0713/002439.449016:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.liangle.com/", "www.liangle.com", 3, 1, , , 0
[1:1:0713/002439.744458:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.liangle.com/, 1004, 7ff3d9553881
[1:1:0713/002439.761439:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"35e977ba2860","ptid":"929 0x7ff3d6c0e070 0x27e5a61a4460 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002439.761685:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.liangle.com/","ptid":"929 0x7ff3d6c0e070 0x27e5a61a4460 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002439.762054:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.liangle.com/"
[1:1:0713/002439.762389:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.liangle.com/, 35e977ba2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/002439.762484:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.liangle.com/", "www.liangle.com", 3, 1, , , 0
[1:1:0713/002439.762785:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2d20a4a29c8, 0x27e5a46b5950
[1:1:0713/002439.762920:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.liangle.com/", 100
[1:1:0713/002439.763120:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.liangle.com/, 1085
[1:1:0713/002439.763224:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1085 0x7ff3d6c0e070 0x27e5a66fbb60 , 5:3_http://www.liangle.com/, 1, -5:3_http://www.liangle.com/, 1004 0x7ff3d6c0e070 0x27e5a54f4e60 
[1:1:0713/002439.780003:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.liangle.com/, 1011, 7ff3d95538db
[1:1:0713/002439.798038:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"933 0x7ff3d6c0e070 0x27e5a7a4d060 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002439.798272:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"933 0x7ff3d6c0e070 0x27e5a7a4d060 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002439.798562:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.liangle.com/, 1086
[1:1:0713/002439.798729:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1086 0x7ff3d6c0e070 0x27e5a6557ae0 , 5:3_http://www.liangle.com/, 0, , 1011 0x7ff3d6c0e070 0x27e5a65e08e0 
[1:1:0713/002439.798936:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.liangle.com/"
[1:1:0713/002439.799204:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.liangle.com/, 35e977ba2860, , r, (){return e.apply(t,arguments)}
[1:1:0713/002439.799339:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.liangle.com/", "www.liangle.com", 3, 1, , , 0
[1:1:0713/002440.853788:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.liangle.com/, 35e977ba2860, , , document.readyState
[1:1:0713/002440.854010:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.liangle.com/", "www.liangle.com", 3, 1, , , 0
[1:1:0713/002441.043060:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.liangle.com/, 1086, 7ff3d95538db
[1:1:0713/002441.061915:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1011 0x7ff3d6c0e070 0x27e5a65e08e0 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002441.062087:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1011 0x7ff3d6c0e070 0x27e5a65e08e0 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002441.062324:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.liangle.com/, 1102
[1:1:0713/002441.062437:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1102 0x7ff3d6c0e070 0x27e5a6535e60 , 5:3_http://www.liangle.com/, 0, , 1086 0x7ff3d6c0e070 0x27e5a6557ae0 
[1:1:0713/002441.062625:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.liangle.com/"
[1:1:0713/002441.062881:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.liangle.com/, 35e977ba2860, , r, (){return e.apply(t,arguments)}
[1:1:0713/002441.062972:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.liangle.com/", "www.liangle.com", 3, 1, , , 0
[1:1:0713/002441.063522:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.liangle.com/, 1085, 7ff3d9553881
[1:1:0713/002441.081513:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"35e977ba2860","ptid":"1004 0x7ff3d6c0e070 0x27e5a54f4e60 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002441.081720:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.liangle.com/","ptid":"1004 0x7ff3d6c0e070 0x27e5a54f4e60 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002441.081952:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.liangle.com/"
[1:1:0713/002441.082248:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.liangle.com/, 35e977ba2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/002441.082369:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.liangle.com/", "www.liangle.com", 3, 1, , , 0
[1:1:0713/002441.082686:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2d20a4a29c8, 0x27e5a46b5950
[1:1:0713/002441.082796:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.liangle.com/", 100
[1:1:0713/002441.082980:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.liangle.com/, 1103
[1:1:0713/002441.083092:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1103 0x7ff3d6c0e070 0x27e5a651c660 , 5:3_http://www.liangle.com/, 1, -5:3_http://www.liangle.com/, 1085 0x7ff3d6c0e070 0x27e5a66fbb60 
[1:1:0713/002441.257801:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.liangle.com/, 35e977ba2860, , , document.readyState
[1:1:0713/002441.258040:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.liangle.com/", "www.liangle.com", 3, 1, , , 0
[1:1:0713/002441.459535:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.liangle.com/, 1103, 7ff3d9553881
[1:1:0713/002441.476304:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"35e977ba2860","ptid":"1085 0x7ff3d6c0e070 0x27e5a66fbb60 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002441.476505:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.liangle.com/","ptid":"1085 0x7ff3d6c0e070 0x27e5a66fbb60 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002441.476767:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.liangle.com/"
[1:1:0713/002441.477148:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.liangle.com/, 35e977ba2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/002441.477310:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.liangle.com/", "www.liangle.com", 3, 1, , , 0
[1:1:0713/002441.477660:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2d20a4a29c8, 0x27e5a46b5950
[1:1:0713/002441.477772:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.liangle.com/", 100
[1:1:0713/002441.478003:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.liangle.com/, 1122
[1:1:0713/002441.478104:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1122 0x7ff3d6c0e070 0x27e5a654a4e0 , 5:3_http://www.liangle.com/, 1, -5:3_http://www.liangle.com/, 1103 0x7ff3d6c0e070 0x27e5a651c660 
[1:1:0713/002441.533710:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.liangle.com/, 35e977ba2860, , , document.readyState
[1:1:0713/002441.533902:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.liangle.com/", "www.liangle.com", 3, 1, , , 0
[1:1:0713/002441.535165:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.liangle.com/, 1102, 7ff3d95538db
[1:1:0713/002441.552573:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1086 0x7ff3d6c0e070 0x27e5a6557ae0 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002441.552854:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1086 0x7ff3d6c0e070 0x27e5a6557ae0 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002441.553113:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.liangle.com/, 1129
[1:1:0713/002441.553249:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1129 0x7ff3d6c0e070 0x27e5a6516a60 , 5:3_http://www.liangle.com/, 0, , 1102 0x7ff3d6c0e070 0x27e5a6535e60 
[1:1:0713/002441.553451:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.liangle.com/"
[1:1:0713/002441.553724:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.liangle.com/, 35e977ba2860, , r, (){return e.apply(t,arguments)}
[1:1:0713/002441.553834:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.liangle.com/", "www.liangle.com", 3, 1, , , 0
[1:1:0713/002441.714035:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://www.liangle.com/"
[1:1:0713/002441.714438:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.liangle.com/, 35e977ba2860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0713/002441.714543:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.liangle.com/", "www.liangle.com", 3, 1, , , 0
[1:1:0713/002441.715480:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.liangle.com/"
[1:1:0713/002441.716564:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.liangle.com/"
[30714:30714:0713/002441.720591:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0713/002441.721749:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x27e5a59e2420
[1:1:0713/002441.721906:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[30714:30714:0713/002441.722870:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 4, 4, 
[1:1:0713/002441.729776:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0713/002441.729946:INFO:render_frame_impl.cc(7019)] 	 [url] = http://www.liangle.com
[30714:30714:0713/002441.730741:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://www.liangle.com/
[1:1:0713/002441.730852:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.liangle.com/"
[1:1:0713/002441.731173:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.liangle.com/"
[1:1:0713/002441.735822:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.liangle.com/"
[1:1:0713/002441.749381:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x2d20a4a29c8, 0x27e5a46b59f0
[1:1:0713/002441.749536:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.liangle.com/", 3000
[1:1:0713/002441.749684:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.liangle.com/, 1147
[1:1:0713/002441.749818:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1147 0x7ff3d6c0e070 0x27e5a79ce660 , 5:3_http://www.liangle.com/, 1, -5:3_http://www.liangle.com/, 1125 0x7ff3d6c0e070 0x27e5a6542ce0 
[1:1:0713/002441.751434:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "pageshow", "http://www.liangle.com/"
[1:1:0713/002441.752084:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2d20a4a29c8, 0x27e5a46b5af0
[1:1:0713/002441.752185:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.liangle.com/", 100
[1:1:0713/002441.752357:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.liangle.com/, 1148
[1:1:0713/002441.752471:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1148 0x7ff3d6c0e070 0x27e5a65df8e0 , 5:3_http://www.liangle.com/, 1, -5:3_http://www.liangle.com/, 1125 0x7ff3d6c0e070 0x27e5a6542ce0 
[30714:30714:0713/002441.792850:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[30714:30714:0713/002441.795430:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[30714:30725:0713/002441.814153:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 4
[30714:30725:0713/002441.814225:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 4, HandleIncomingMessage, HandleIncomingMessage
[30714:30714:0713/002441.814245:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://pos.baidu.com/
[30714:30714:0713/002441.814284:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_https://pos.baidu.com/, https://pos.baidu.com/wh/o.htm?ltr=, 4
[30714:30714:0713/002441.814352:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:4_https://pos.baidu.com/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 16:24:41 GMT Last-Modified: Fri, 12 Jul 2019 03:18:19 GMT P3p: CP=" OTI DSP COR IVA OUR IND COM " Server: nginx Accept-Ranges: bytes Content-Length: 553 Content-Type: text/html Etag: "5d27fbfb-229"  ,30808, 5
[1:7:0713/002441.816346:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/002441.907898:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.liangle.com/, 35e977ba2860, , , document.readyState
[1:1:0713/002441.908075:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.liangle.com/", "www.liangle.com", 3, 1, , , 0
[1:1:0713/002442.206177:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:4_https://pos.baidu.com/
[1:1:0713/002442.229814:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.liangle.com/, 1129, 7ff3d95538db
[1:1:0713/002442.247498:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1102 0x7ff3d6c0e070 0x27e5a6535e60 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002442.247680:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1102 0x7ff3d6c0e070 0x27e5a6535e60 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002442.247924:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.liangle.com/, 1176
[1:1:0713/002442.248036:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1176 0x7ff3d6c0e070 0x27e5a66fbee0 , 5:3_http://www.liangle.com/, 0, , 1129 0x7ff3d6c0e070 0x27e5a6516a60 
[1:1:0713/002442.248227:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.liangle.com/"
[1:1:0713/002442.248499:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.liangle.com/, 35e977ba2860, , r, (){return e.apply(t,arguments)}
[1:1:0713/002442.248588:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.liangle.com/", "www.liangle.com", 3, 1, , , 0
[1:1:0713/002442.249202:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.liangle.com/, 1148, 7ff3d9553881
[1:1:0713/002442.267046:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"35e977ba2860","ptid":"1125 0x7ff3d6c0e070 0x27e5a6542ce0 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002442.267260:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.liangle.com/","ptid":"1125 0x7ff3d6c0e070 0x27e5a6542ce0 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002442.267483:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.liangle.com/"
[1:1:0713/002442.267766:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.liangle.com/, 35e977ba2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/002442.267891:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.liangle.com/", "www.liangle.com", 3, 1, , , 0
[1:1:0713/002442.268186:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2d20a4a29c8, 0x27e5a46b5950
[1:1:0713/002442.268286:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.liangle.com/", 100
[1:1:0713/002442.268453:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.liangle.com/, 1177
[1:1:0713/002442.268562:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1177 0x7ff3d6c0e070 0x27e5a6ade960 , 5:3_http://www.liangle.com/, 1, -5:3_http://www.liangle.com/, 1148 0x7ff3d6c0e070 0x27e5a65df8e0 
[1:1:0713/002442.655526:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[30714:30714:0713/002442.655900:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_https://pos.baidu.com/, https://pos.baidu.com/, 4
[30714:30714:0713/002442.655944:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, https://pos.baidu.com/, https://pos.baidu.com
[1:1:0713/002442.657635:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.liangle.com/, 1176, 7ff3d95538db
[1:1:0713/002442.677097:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1129 0x7ff3d6c0e070 0x27e5a6516a60 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002442.677282:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1129 0x7ff3d6c0e070 0x27e5a6516a60 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002442.677543:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.liangle.com/, 1195
[1:1:0713/002442.677688:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1195 0x7ff3d6c0e070 0x27e5a651afe0 , 5:3_http://www.liangle.com/, 0, , 1176 0x7ff3d6c0e070 0x27e5a66fbee0 
[1:1:0713/002442.677916:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.liangle.com/"
[1:1:0713/002442.678382:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.liangle.com/, 35e977ba2860, , r, (){return e.apply(t,arguments)}
[1:1:0713/002442.678492:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.liangle.com/", "www.liangle.com", 3, 1, , , 0
[1:1:0713/002442.699630:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.liangle.com/, 1177, 7ff3d9553881
[1:1:0713/002442.718498:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"35e977ba2860","ptid":"1148 0x7ff3d6c0e070 0x27e5a65df8e0 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002442.718676:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.liangle.com/","ptid":"1148 0x7ff3d6c0e070 0x27e5a65df8e0 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002442.718881:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.liangle.com/"
[1:1:0713/002442.719165:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.liangle.com/, 35e977ba2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/002442.719273:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.liangle.com/", "www.liangle.com", 3, 1, , , 0
[1:1:0713/002442.719578:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2d20a4a29c8, 0x27e5a46b5950
[1:1:0713/002442.719675:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.liangle.com/", 100
[1:1:0713/002442.719826:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.liangle.com/, 1198
[1:1:0713/002442.719920:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1198 0x7ff3d6c0e070 0x27e5a65df9e0 , 5:3_http://www.liangle.com/, 1, -5:3_http://www.liangle.com/, 1177 0x7ff3d6c0e070 0x27e5a6ade960 
[1:1:0713/002442.855020:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/002443.119157:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.liangle.com/, 1195, 7ff3d95538db
[1:1:0713/002443.137432:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1176 0x7ff3d6c0e070 0x27e5a66fbee0 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002443.137608:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1176 0x7ff3d6c0e070 0x27e5a66fbee0 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002443.137824:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.liangle.com/, 1214
[1:1:0713/002443.137931:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1214 0x7ff3d6c0e070 0x27e5a6545ee0 , 5:3_http://www.liangle.com/, 0, , 1195 0x7ff3d6c0e070 0x27e5a651afe0 
[1:1:0713/002443.138118:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.liangle.com/"
[1:1:0713/002443.138378:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.liangle.com/, 35e977ba2860, , r, (){return e.apply(t,arguments)}
[1:1:0713/002443.138480:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.liangle.com/", "www.liangle.com", 3, 1, , , 0
[1:1:0713/002443.139024:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.liangle.com/, 1198, 7ff3d9553881
[1:1:0713/002443.157749:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"35e977ba2860","ptid":"1177 0x7ff3d6c0e070 0x27e5a6ade960 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002443.157958:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.liangle.com/","ptid":"1177 0x7ff3d6c0e070 0x27e5a6ade960 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002443.158185:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.liangle.com/"
[1:1:0713/002443.158510:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.liangle.com/, 35e977ba2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/002443.158628:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.liangle.com/", "www.liangle.com", 3, 1, , , 0
[1:1:0713/002443.158958:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2d20a4a29c8, 0x27e5a46b5950
[1:1:0713/002443.159076:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.liangle.com/", 100
[1:1:0713/002443.159262:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.liangle.com/, 1215
[1:1:0713/002443.159371:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1215 0x7ff3d6c0e070 0x27e5a573b160 , 5:3_http://www.liangle.com/, 1, -5:3_http://www.liangle.com/, 1198 0x7ff3d6c0e070 0x27e5a65df9e0 
[1:1:0713/002443.215721:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/002443.215895:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://pos.baidu.com/wh/o.htm?ltr="
[1:1:0713/002443.628387:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.liangle.com/, 1215, 7ff3d9553881
[1:1:0713/002443.648725:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"35e977ba2860","ptid":"1198 0x7ff3d6c0e070 0x27e5a65df9e0 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002443.648921:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.liangle.com/","ptid":"1198 0x7ff3d6c0e070 0x27e5a65df9e0 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002443.649156:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.liangle.com/"
[1:1:0713/002443.649431:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.liangle.com/, 35e977ba2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/002443.649521:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.liangle.com/", "www.liangle.com", 3, 1, , , 0
[1:1:0713/002443.649849:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2d20a4a29c8, 0x27e5a46b5950
[1:1:0713/002443.649993:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.liangle.com/", 100
[1:1:0713/002443.650216:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.liangle.com/, 1251
[1:1:0713/002443.650352:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1251 0x7ff3d6c0e070 0x27e5a65572e0 , 5:3_http://www.liangle.com/, 1, -5:3_http://www.liangle.com/, 1215 0x7ff3d6c0e070 0x27e5a573b160 
[1:1:0713/002443.650919:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.liangle.com/, 1214, 7ff3d95538db
[1:1:0713/002443.670041:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1195 0x7ff3d6c0e070 0x27e5a651afe0 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002443.670274:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1195 0x7ff3d6c0e070 0x27e5a651afe0 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002443.670519:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.liangle.com/, 1252
[1:1:0713/002443.670644:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1252 0x7ff3d6c0e070 0x27e5a4731360 , 5:3_http://www.liangle.com/, 0, , 1214 0x7ff3d6c0e070 0x27e5a6545ee0 
[1:1:0713/002443.670855:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.liangle.com/"
[1:1:0713/002443.671128:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.liangle.com/, 35e977ba2860, , r, (){return e.apply(t,arguments)}
[1:1:0713/002443.671241:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.liangle.com/", "www.liangle.com", 3, 1, , , 0
[1:1:0713/002443.883329:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.liangle.com/, 1251, 7ff3d9553881
[1:1:0713/002443.902187:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"35e977ba2860","ptid":"1215 0x7ff3d6c0e070 0x27e5a573b160 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002443.902366:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.liangle.com/","ptid":"1215 0x7ff3d6c0e070 0x27e5a573b160 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002443.902561:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.liangle.com/"
[1:1:0713/002443.902823:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.liangle.com/, 35e977ba2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/002443.902921:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.liangle.com/", "www.liangle.com", 3, 1, , , 0
[1:1:0713/002443.903204:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2d20a4a29c8, 0x27e5a46b5950
[1:1:0713/002443.903304:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.liangle.com/", 100
[1:1:0713/002443.903470:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.liangle.com/, 1262
[1:1:0713/002443.903576:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1262 0x7ff3d6c0e070 0x27e5a7a4d360 , 5:3_http://www.liangle.com/, 1, -5:3_http://www.liangle.com/, 1251 0x7ff3d6c0e070 0x27e5a65572e0 
[1:1:0713/002443.904132:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.liangle.com/, 1252, 7ff3d95538db
[1:1:0713/002443.924070:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1214 0x7ff3d6c0e070 0x27e5a6545ee0 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002443.924243:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1214 0x7ff3d6c0e070 0x27e5a6545ee0 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002443.924467:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.liangle.com/, 1264
[1:1:0713/002443.924574:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1264 0x7ff3d6c0e070 0x27e5a78dd8e0 , 5:3_http://www.liangle.com/, 0, , 1252 0x7ff3d6c0e070 0x27e5a4731360 
[1:1:0713/002443.924742:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.liangle.com/"
[1:1:0713/002443.924983:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.liangle.com/, 35e977ba2860, , r, (){return e.apply(t,arguments)}
[1:1:0713/002443.925107:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.liangle.com/", "www.liangle.com", 3, 1, , , 0
[1:1:0713/002443.965230:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1261 0x7ff3d6f76bd0 0x27e5a469d258 , "https://pos.baidu.com/wh/o.htm?ltr="
[1:1:0713/002443.967684:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://pos.baidu.com/, 35e977c31e18, , , (function(){if(!PluginDetect)var PluginDetect={getNum:function(b,c){if(!this.num(b))return null;var 
[1:1:0713/002443.967852:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pos.baidu.com/wh/o.htm?ltr=", "pos.baidu.com", 4, 1, http://www.liangle.com, www.liangle.com, 3
[1:1:0713/002443.986797:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 2000, 0x2d20a567b68, 0x27e5a46b5960
[1:1:0713/002443.986983:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://pos.baidu.com/wh/o.htm?ltr=", 2000
[1:1:0713/002443.987221:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://pos.baidu.com/, 1267
[1:1:0713/002443.987405:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1267 0x7ff3d6c0e070 0x27e5a61a7ce0 , 5:4_https://pos.baidu.com/, 1, -5:4_https://pos.baidu.com/, 1261 0x7ff3d6f76bd0 0x27e5a469d258 
[1:1:0713/002443.988610:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 250, 0x2d20a567b68, 0x27e5a46b5960
[1:1:0713/002443.988711:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://pos.baidu.com/wh/o.htm?ltr=", 250
[1:1:0713/002443.988850:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://pos.baidu.com/, 1268
[1:1:0713/002443.988944:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1268 0x7ff3d6c0e070 0x27e5a654dee0 , 5:4_https://pos.baidu.com/, 1, -5:4_https://pos.baidu.com/, 1261 0x7ff3d6f76bd0 0x27e5a469d258 
[1:1:0713/002443.991004:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1261 0x7ff3d6f76bd0 0x27e5a469d258 , "https://pos.baidu.com/wh/o.htm?ltr="
[1:1:0713/002443.995417:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pos.baidu.com/wh/o.htm?ltr="
[1:1:0713/002444.182523:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.liangle.com/, 1262, 7ff3d9553881
[1:1:0713/002444.199549:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"35e977ba2860","ptid":"1251 0x7ff3d6c0e070 0x27e5a65572e0 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002444.199719:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.liangle.com/","ptid":"1251 0x7ff3d6c0e070 0x27e5a65572e0 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002444.199916:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.liangle.com/"
[1:1:0713/002444.200198:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.liangle.com/, 35e977ba2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/002444.200311:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.liangle.com/", "www.liangle.com", 3, 1, , , 0
[1:1:0713/002444.200598:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2d20a4a29c8, 0x27e5a46b5950
[1:1:0713/002444.200688:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.liangle.com/", 100
[1:1:0713/002444.200835:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.liangle.com/, 1291
[1:1:0713/002444.200912:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1291 0x7ff3d6c0e070 0x27e5a64f57e0 , 5:3_http://www.liangle.com/, 1, -5:3_http://www.liangle.com/, 1262 0x7ff3d6c0e070 0x27e5a7a4d360 
[1:1:0713/002444.235015:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.liangle.com/, 1264, 7ff3d95538db
[1:1:0713/002444.251246:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1252 0x7ff3d6c0e070 0x27e5a4731360 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002444.251392:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1252 0x7ff3d6c0e070 0x27e5a4731360 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002444.251591:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.liangle.com/, 1294
[1:1:0713/002444.251698:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1294 0x7ff3d6c0e070 0x27e5a65385e0 , 5:3_http://www.liangle.com/, 0, , 1264 0x7ff3d6c0e070 0x27e5a78dd8e0 
[1:1:0713/002444.251875:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.liangle.com/"
[1:1:0713/002444.252116:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.liangle.com/, 35e977ba2860, , r, (){return e.apply(t,arguments)}
[1:1:0713/002444.252229:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.liangle.com/", "www.liangle.com", 3, 1, , , 0
[1:1:0713/002444.335394:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://pos.baidu.com/, 1268, 7ff3d9553881
[1:1:0713/002444.354923:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"35e977c31e18","ptid":"1261 0x7ff3d6f76bd0 0x27e5a469d258 ","rf":"5:4_https://pos.baidu.com/"}
[1:1:0713/002444.355106:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_https://pos.baidu.com/","ptid":"1261 0x7ff3d6f76bd0 0x27e5a469d258 ","rf":"5:4_https://pos.baidu.com/"}
[1:1:0713/002444.355309:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://pos.baidu.com/wh/o.htm?ltr="
[1:1:0713/002444.355562:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://pos.baidu.com/, 35e977c31e18, , F, (){if(!detectFlash(fname)&&
!isSend)return setTimeout(F,250)}
[1:1:0713/002444.355669:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pos.baidu.com/wh/o.htm?ltr=", "pos.baidu.com", 4, 1, http://www.liangle.com, www.liangle.com, 3
[1:1:0713/002444.356379:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 250, 0x2d20a567b68, 0x27e5a46b5950
[1:1:0713/002444.356482:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://pos.baidu.com/wh/o.htm?ltr=", 250
[1:1:0713/002444.356658:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://pos.baidu.com/, 1303
[1:1:0713/002444.356759:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1303 0x7ff3d6c0e070 0x27e5a55ae560 , 5:4_https://pos.baidu.com/, 1, -5:4_https://pos.baidu.com/, 1268 0x7ff3d6c0e070 0x27e5a654dee0 
[1:1:0713/002444.392952:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.liangle.com/, 1294, 7ff3d95538db
[1:1:0713/002444.409442:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1264 0x7ff3d6c0e070 0x27e5a78dd8e0 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002444.409587:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1264 0x7ff3d6c0e070 0x27e5a78dd8e0 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002444.409800:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.liangle.com/, 1305
[1:1:0713/002444.409907:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1305 0x7ff3d6c0e070 0x27e5a4b36de0 , 5:3_http://www.liangle.com/, 0, , 1294 0x7ff3d6c0e070 0x27e5a65385e0 
[1:1:0713/002444.410089:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.liangle.com/"
[1:1:0713/002444.410328:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.liangle.com/, 35e977ba2860, , r, (){return e.apply(t,arguments)}
[1:1:0713/002444.410428:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.liangle.com/", "www.liangle.com", 3, 1, , , 0
[1:1:0713/002444.410942:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.liangle.com/, 1291, 7ff3d9553881
[1:1:0713/002444.427497:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"35e977ba2860","ptid":"1262 0x7ff3d6c0e070 0x27e5a7a4d360 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002444.427648:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.liangle.com/","ptid":"1262 0x7ff3d6c0e070 0x27e5a7a4d360 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002444.427839:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.liangle.com/"
[1:1:0713/002444.428080:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.liangle.com/, 35e977ba2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/002444.428193:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.liangle.com/", "www.liangle.com", 3, 1, , , 0
[1:1:0713/002444.428478:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2d20a4a29c8, 0x27e5a46b5950
[1:1:0713/002444.428592:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.liangle.com/", 100
[1:1:0713/002444.428747:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.liangle.com/, 1306
[1:1:0713/002444.428837:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1306 0x7ff3d6c0e070 0x27e5a61b44e0 , 5:3_http://www.liangle.com/, 1, -5:3_http://www.liangle.com/, 1291 0x7ff3d6c0e070 0x27e5a64f57e0 
[1:1:0713/002444.532298:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.liangle.com/, 1306, 7ff3d9553881
[1:1:0713/002444.548875:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"35e977ba2860","ptid":"1291 0x7ff3d6c0e070 0x27e5a64f57e0 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002444.549075:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.liangle.com/","ptid":"1291 0x7ff3d6c0e070 0x27e5a64f57e0 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002444.549289:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.liangle.com/"
[1:1:0713/002444.549558:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.liangle.com/, 35e977ba2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/002444.549679:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.liangle.com/", "www.liangle.com", 3, 1, , , 0
[1:1:0713/002444.549982:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2d20a4a29c8, 0x27e5a46b5950
[1:1:0713/002444.550088:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.liangle.com/", 100
[1:1:0713/002444.550257:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.liangle.com/, 1314
[1:1:0713/002444.550339:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1314 0x7ff3d6c0e070 0x27e5a4baa2e0 , 5:3_http://www.liangle.com/, 1, -5:3_http://www.liangle.com/, 1306 0x7ff3d6c0e070 0x27e5a61b44e0 
[1:1:0713/002444.600705:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.liangle.com/, 1305, 7ff3d95538db
[1:1:0713/002444.617306:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1294 0x7ff3d6c0e070 0x27e5a65385e0 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002444.617463:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1294 0x7ff3d6c0e070 0x27e5a65385e0 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002444.617672:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.liangle.com/, 1319
[1:1:0713/002444.617792:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1319 0x7ff3d6c0e070 0x27e5a5f8c1e0 , 5:3_http://www.liangle.com/, 0, , 1305 0x7ff3d6c0e070 0x27e5a4b36de0 
[1:1:0713/002444.617973:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.liangle.com/"
[1:1:0713/002444.618222:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.liangle.com/, 35e977ba2860, , r, (){return e.apply(t,arguments)}
[1:1:0713/002444.618334:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.liangle.com/", "www.liangle.com", 3, 1, , , 0
[1:1:0713/002444.619076:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://pos.baidu.com/, 1303, 7ff3d9553881
[1:1:0713/002444.635818:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"35e977c31e18","ptid":"1268 0x7ff3d6c0e070 0x27e5a654dee0 ","rf":"5:4_https://pos.baidu.com/"}
[1:1:0713/002444.635971:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_https://pos.baidu.com/","ptid":"1268 0x7ff3d6c0e070 0x27e5a654dee0 ","rf":"5:4_https://pos.baidu.com/"}
[1:1:0713/002444.636156:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://pos.baidu.com/wh/o.htm?ltr="
[1:1:0713/002444.636402:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://pos.baidu.com/, 35e977c31e18, , F, (){if(!detectFlash(fname)&&
!isSend)return setTimeout(F,250)}
[1:1:0713/002444.636542:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pos.baidu.com/wh/o.htm?ltr=", "pos.baidu.com", 4, 1, http://www.liangle.com, www.liangle.com, 3
[1:1:0713/002444.636905:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 250, 0x2d20a567b68, 0x27e5a46b5950
[1:1:0713/002444.636986:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://pos.baidu.com/wh/o.htm?ltr=", 250
[1:1:0713/002444.637141:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://pos.baidu.com/, 1322
[1:1:0713/002444.637248:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1322 0x7ff3d6c0e070 0x27e5a4af0ce0 , 5:4_https://pos.baidu.com/, 1, -5:4_https://pos.baidu.com/, 1303 0x7ff3d6c0e070 0x27e5a55ae560 
[1:1:0713/002444.671716:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.liangle.com/, 1314, 7ff3d9553881
[1:1:0713/002444.691779:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"35e977ba2860","ptid":"1306 0x7ff3d6c0e070 0x27e5a61b44e0 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002444.691982:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.liangle.com/","ptid":"1306 0x7ff3d6c0e070 0x27e5a61b44e0 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002444.692221:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.liangle.com/"
[1:1:0713/002444.692523:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.liangle.com/, 35e977ba2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/002444.692652:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.liangle.com/", "www.liangle.com", 3, 1, , , 0
[1:1:0713/002444.692980:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2d20a4a29c8, 0x27e5a46b5950
[1:1:0713/002444.693130:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.liangle.com/", 100
[1:1:0713/002444.693367:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.liangle.com/, 1327
[1:1:0713/002444.693526:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1327 0x7ff3d6c0e070 0x27e5a64ffe60 , 5:3_http://www.liangle.com/, 1, -5:3_http://www.liangle.com/, 1314 0x7ff3d6c0e070 0x27e5a4baa2e0 
[1:1:0713/002444.766153:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.liangle.com/, 1147, 7ff3d9553881
[1:1:0713/002444.782829:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"35e977ba2860","ptid":"1125 0x7ff3d6c0e070 0x27e5a6542ce0 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002444.783092:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.liangle.com/","ptid":"1125 0x7ff3d6c0e070 0x27e5a6542ce0 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002444.783301:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.liangle.com/"
[1:1:0713/002444.783585:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.liangle.com/, 35e977ba2860, , o, (){n.continuous?r(b+1):b<v.length-1&&r(b+1)}
[1:1:0713/002444.783698:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.liangle.com/", "www.liangle.com", 3, 1, , , 0
[1:1:0713/002444.792012:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2d20a4a29c8, 0x27e5a46b5950
[1:1:0713/002444.792167:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.liangle.com/", 0
[1:1:0713/002444.792347:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.liangle.com/, 1333
[1:1:0713/002444.792476:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1333 0x7ff3d6c0e070 0x27e5a6518ce0 , 5:3_http://www.liangle.com/, 1, -5:3_http://www.liangle.com/, 1147 0x7ff3d6c0e070 0x27e5a79ce660 
[1:1:0713/002444.869856:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.liangle.com/, 1333, 7ff3d9553881
[1:1:0713/002444.890825:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"35e977ba2860","ptid":"1147 0x7ff3d6c0e070 0x27e5a79ce660 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002444.891026:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.liangle.com/","ptid":"1147 0x7ff3d6c0e070 0x27e5a79ce660 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002444.891255:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.liangle.com/"
[1:1:0713/002444.891535:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.liangle.com/, 35e977ba2860, , m, (){}
[1:1:0713/002444.891653:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.liangle.com/", "www.liangle.com", 3, 1, , , 0
[1:1:0713/002444.892227:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.liangle.com/, 1327, 7ff3d9553881
[1:1:0713/002444.912151:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"35e977ba2860","ptid":"1314 0x7ff3d6c0e070 0x27e5a4baa2e0 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002444.912380:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.liangle.com/","ptid":"1314 0x7ff3d6c0e070 0x27e5a4baa2e0 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002444.912607:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.liangle.com/"
[1:1:0713/002444.912894:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.liangle.com/, 35e977ba2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/002444.913000:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.liangle.com/", "www.liangle.com", 3, 1, , , 0
[1:1:0713/002444.913297:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2d20a4a29c8, 0x27e5a46b5950
[1:1:0713/002444.913412:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.liangle.com/", 100
[1:1:0713/002444.913604:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.liangle.com/, 1350
[1:1:0713/002444.914371:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1350 0x7ff3d6c0e070 0x27e5a70dbc60 , 5:3_http://www.liangle.com/, 1, -5:3_http://www.liangle.com/, 1327 0x7ff3d6c0e070 0x27e5a64ffe60 
[1:1:0713/002444.914932:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.liangle.com/, 1319, 7ff3d95538db
[1:1:0713/002444.936392:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1305 0x7ff3d6c0e070 0x27e5a4b36de0 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002444.936674:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1305 0x7ff3d6c0e070 0x27e5a4b36de0 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002444.936952:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.liangle.com/, 1353
[1:1:0713/002444.937107:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1353 0x7ff3d6c0e070 0x27e5a654d3e0 , 5:3_http://www.liangle.com/, 0, , 1319 0x7ff3d6c0e070 0x27e5a5f8c1e0 
[1:1:0713/002444.937334:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.liangle.com/"
[1:1:0713/002444.937627:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.liangle.com/, 35e977ba2860, , r, (){return e.apply(t,arguments)}
[1:1:0713/002444.937747:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.liangle.com/", "www.liangle.com", 3, 1, , , 0
[1:1:0713/002445.161306:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://pos.baidu.com/, 1322, 7ff3d9553881
[1:1:0713/002445.182951:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"35e977c31e18","ptid":"1303 0x7ff3d6c0e070 0x27e5a55ae560 ","rf":"5:4_https://pos.baidu.com/"}
[1:1:0713/002445.183162:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_https://pos.baidu.com/","ptid":"1303 0x7ff3d6c0e070 0x27e5a55ae560 ","rf":"5:4_https://pos.baidu.com/"}
[1:1:0713/002445.183377:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://pos.baidu.com/wh/o.htm?ltr="
[1:1:0713/002445.183671:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://pos.baidu.com/, 35e977c31e18, , F, (){if(!detectFlash(fname)&&
!isSend)return setTimeout(F,250)}
[1:1:0713/002445.183802:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pos.baidu.com/wh/o.htm?ltr=", "pos.baidu.com", 4, 1, http://www.liangle.com, www.liangle.com, 3
[1:1:0713/002445.184142:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 250, 0x2d20a567b68, 0x27e5a46b5950
[1:1:0713/002445.184239:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://pos.baidu.com/wh/o.htm?ltr=", 250
[1:1:0713/002445.184453:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://pos.baidu.com/, 1374
[1:1:0713/002445.184569:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1374 0x7ff3d6c0e070 0x27e5a5a1f560 , 5:4_https://pos.baidu.com/, 1, -5:4_https://pos.baidu.com/, 1322 0x7ff3d6c0e070 0x27e5a4af0ce0 
[1:1:0713/002445.416628:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.liangle.com/, 1350, 7ff3d9553881
[1:1:0713/002445.437480:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"35e977ba2860","ptid":"1327 0x7ff3d6c0e070 0x27e5a64ffe60 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002445.437693:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.liangle.com/","ptid":"1327 0x7ff3d6c0e070 0x27e5a64ffe60 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002445.437956:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.liangle.com/"
[1:1:0713/002445.438284:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.liangle.com/, 35e977ba2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/002445.438436:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.liangle.com/", "www.liangle.com", 3, 1, , , 0
[1:1:0713/002445.438831:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2d20a4a29c8, 0x27e5a46b5950
[1:1:0713/002445.438937:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.liangle.com/", 100
[1:1:0713/002445.439115:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.liangle.com/, 1384
[1:1:0713/002445.439229:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1384 0x7ff3d6c0e070 0x27e5a565ba60 , 5:3_http://www.liangle.com/, 1, -5:3_http://www.liangle.com/, 1350 0x7ff3d6c0e070 0x27e5a70dbc60 
[1:1:0713/002445.512839:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.liangle.com/, 1353, 7ff3d95538db
[1:1:0713/002445.529962:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1319 0x7ff3d6c0e070 0x27e5a5f8c1e0 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002445.530101:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1319 0x7ff3d6c0e070 0x27e5a5f8c1e0 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002445.530300:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.liangle.com/, 1386
[1:1:0713/002445.530436:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1386 0x7ff3d6c0e070 0x27e5a6557060 , 5:3_http://www.liangle.com/, 0, , 1353 0x7ff3d6c0e070 0x27e5a654d3e0 
[1:1:0713/002445.530617:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.liangle.com/"
[1:1:0713/002445.530856:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.liangle.com/, 35e977ba2860, , r, (){return e.apply(t,arguments)}
[1:1:0713/002445.530967:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.liangle.com/", "www.liangle.com", 3, 1, , , 0
[1:1:0713/002445.862035:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://pos.baidu.com/, 1374, 7ff3d9553881
[1:1:0713/002445.880301:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"35e977c31e18","ptid":"1322 0x7ff3d6c0e070 0x27e5a4af0ce0 ","rf":"5:4_https://pos.baidu.com/"}
[1:1:0713/002445.880467:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_https://pos.baidu.com/","ptid":"1322 0x7ff3d6c0e070 0x27e5a4af0ce0 ","rf":"5:4_https://pos.baidu.com/"}
[1:1:0713/002445.880661:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://pos.baidu.com/wh/o.htm?ltr="
[1:1:0713/002445.880928:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://pos.baidu.com/, 35e977c31e18, , F, (){if(!detectFlash(fname)&&
!isSend)return setTimeout(F,250)}
[1:1:0713/002445.881090:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pos.baidu.com/wh/o.htm?ltr=", "pos.baidu.com", 4, 1, http://www.liangle.com, www.liangle.com, 3
[1:1:0713/002445.881439:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 250, 0x2d20a567b68, 0x27e5a46b5950
[1:1:0713/002445.881545:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://pos.baidu.com/wh/o.htm?ltr=", 250
[1:1:0713/002445.881719:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://pos.baidu.com/, 1393
[1:1:0713/002445.881847:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1393 0x7ff3d6c0e070 0x27e5a6518f60 , 5:4_https://pos.baidu.com/, 1, -5:4_https://pos.baidu.com/, 1374 0x7ff3d6c0e070 0x27e5a5a1f560 
[1:1:0713/002445.900928:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.liangle.com/, 1384, 7ff3d9553881
[1:1:0713/002445.919157:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"35e977ba2860","ptid":"1350 0x7ff3d6c0e070 0x27e5a70dbc60 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002445.919305:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.liangle.com/","ptid":"1350 0x7ff3d6c0e070 0x27e5a70dbc60 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002445.919495:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.liangle.com/"
[1:1:0713/002445.919750:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.liangle.com/, 35e977ba2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/002445.919862:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.liangle.com/", "www.liangle.com", 3, 1, , , 0
[1:1:0713/002445.920151:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2d20a4a29c8, 0x27e5a46b5950
[1:1:0713/002445.920255:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.liangle.com/", 100
[1:1:0713/002445.920415:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.liangle.com/, 1396
[1:1:0713/002445.920538:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1396 0x7ff3d6c0e070 0x27e5a5998860 , 5:3_http://www.liangle.com/, 1, -5:3_http://www.liangle.com/, 1384 0x7ff3d6c0e070 0x27e5a565ba60 
[1:1:0713/002445.939805:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.liangle.com/, 1386, 7ff3d95538db
[1:1:0713/002445.957980:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1353 0x7ff3d6c0e070 0x27e5a654d3e0 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002445.958117:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1353 0x7ff3d6c0e070 0x27e5a654d3e0 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002445.958319:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.liangle.com/, 1397
[1:1:0713/002445.958433:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1397 0x7ff3d6c0e070 0x27e5a62eda60 , 5:3_http://www.liangle.com/, 0, , 1386 0x7ff3d6c0e070 0x27e5a6557060 
[1:1:0713/002445.958610:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.liangle.com/"
[1:1:0713/002445.958855:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.liangle.com/, 35e977ba2860, , r, (){return e.apply(t,arguments)}
[1:1:0713/002445.958966:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.liangle.com/", "www.liangle.com", 3, 1, , , 0
[1:1:0713/002445.978690:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "transitionend", "http://www.liangle.com/"
[1:1:0713/002445.979229:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.liangle.com/, 35e977ba2860, , handleEvent, (t){switch(t.type){case"touchstart":this.start(t);break;case"touchmove":this.move(t);break;case"touc
[1:1:0713/002445.979354:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.liangle.com/", "www.liangle.com", 3, 1, , , 0
[1:1:0713/002445.980559:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x2d20a4a29c8, 0x27e5a46b5af8
[1:1:0713/002445.980672:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.liangle.com/", 3000
[1:1:0713/002445.980829:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.liangle.com/, 1399
[1:1:0713/002445.980927:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1399 0x7ff3d6c0e070 0x27e5a79cfbe0 , 5:3_http://www.liangle.com/, 1, -5:3_http://www.liangle.com/, 1389 0x7ff3e5f1f960 0x27e5a7b1cba0 0x27e5a7b1cbb0 
[1:1:0713/002445.981250:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2d20a4a29c8, 0x27e5a46b5af8
[1:1:0713/002445.981356:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.liangle.com/", 0
[1:1:0713/002445.981513:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.liangle.com/, 1400
[1:1:0713/002445.981591:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1400 0x7ff3d6c0e070 0x27e5a7bcfbe0 , 5:3_http://www.liangle.com/, 1, -5:3_http://www.liangle.com/, 1389 0x7ff3e5f1f960 0x27e5a7b1cba0 0x27e5a7b1cbb0 
[1:1:0713/002445.982075:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "transitionend", "http://www.liangle.com/"
[1:1:0713/002445.982993:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2d20a4a29c8, 0x27e5a46b5a08
[1:1:0713/002445.983055:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.liangle.com/", 0
[1:1:0713/002445.983172:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.liangle.com/, 1401
[1:1:0713/002445.983253:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1401 0x7ff3d6c0e070 0x27e5a5a1f960 , 5:3_http://www.liangle.com/, 1, -5:3_http://www.liangle.com/, 1389 0x7ff3e5f1f960 0x27e5a7b1cba0 0x27e5a7b1cbb0 
[1:1:0713/002446.055432:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.liangle.com/, 1400, 7ff3d9553881
[1:1:0713/002446.073887:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"35e977ba2860","ptid":"1389 0x7ff3e5f1f960 0x27e5a7b1cba0 0x27e5a7b1cbb0 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002446.074056:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.liangle.com/","ptid":"1389 0x7ff3e5f1f960 0x27e5a7b1cba0 0x27e5a7b1cbb0 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002446.074262:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.liangle.com/"
[1:1:0713/002446.074532:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.liangle.com/, 35e977ba2860, , m, (){}
[1:1:0713/002446.074646:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.liangle.com/", "www.liangle.com", 3, 1, , , 0
[1:1:0713/002446.075054:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.liangle.com/, 1401, 7ff3d9553881
[1:1:0713/002446.093438:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"35e977ba2860","ptid":"1389 0x7ff3e5f1f960 0x27e5a7b1cba0 0x27e5a7b1cbb0 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002446.093581:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.liangle.com/","ptid":"1389 0x7ff3e5f1f960 0x27e5a7b1cba0 0x27e5a7b1cbb0 ","rf":"5:3_http://www.liangle.com/"}
[1:1:0713/002446.093753:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.liangle.com/"
[1:1:0713/002446.094045:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.liangle.com/, 35e977ba2860, , m, (){}
[1:1:0713/002446.094167:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.liangle.com/", "www.liangle.com", 3, 1, , , 0
[1:1:0713/002446.114142:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://pos.baidu.com/, 1267, 7ff3d9553881
[1:1:0713/002446.133114:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"35e977c31e18","ptid":"1261 0x7ff3d6f76bd0 0x27e5a469d258 ","rf":"5:4_https://pos.baidu.com/"}
[1:1:0713/002446.133287:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_https://pos.baidu.com/","ptid":"1261 0x7ff3d6f76bd0 0x27e5a469d258 ","rf":"5:4_https://pos.baidu.com/"}
[1:1:0713/002446.133483:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://pos.baidu.com/wh/o.htm?ltr="
[1:1:0713/002446.133750:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://pos.baidu.com/, 35e977c31e18, , , (){if(!isSend)send()}
[1:1:0713/002446.133890:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pos.baidu.com/wh/o.htm?ltr=", "pos.baidu.com", 4, 1, http://www.liangle.com, www.liangle.com, 3
		remove user.f_64a5839c -> 0
