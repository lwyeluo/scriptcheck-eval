[0713/002629.664516:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/002629.664780:INFO:switcher_clone.cc(787)] backtrace rip is 7fdf068de891
[0713/002630.199512:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/002630.199760:INFO:switcher_clone.cc(787)] backtrace rip is 7f03c818e891
[1:1:0713/002630.203579:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0713/002630.203747:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0713/002630.206590:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[0713/002631.043233:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/002631.043495:INFO:switcher_clone.cc(787)] backtrace rip is 7f8bbac4e891
[31068:31068:0713/002631.084290:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/91f6a1f5-bb25-499a-a81b-793433dabaee
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[31101:31101:0713/002631.189654:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=31101
[31114:31114:0713/002631.190220:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=31114
[31068:31068:0713/002631.325152:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[31068:31099:0713/002631.325542:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0713/002631.325667:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0713/002631.325867:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0713/002631.326212:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0713/002631.326381:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0713/002631.328089:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x2a29be7f, 1
[1:1:0713/002631.328315:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x108f8e89, 0
[1:1:0713/002631.328416:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x3872fb3f, 3
[1:1:0713/002631.328477:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x1b16d661, 2
[1:1:0713/002631.328577:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffff89ffffff8effffff8f10 7fffffffbe292a 61ffffffd6161b 3ffffffffb7238 , 10104, 4
[1:1:0713/002631.329266:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[31068:31099:0713/002631.329421:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING����)*a�?�r8�g�
[31068:31099:0713/002631.329476:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ����)*a�?�r8u�g�
[1:1:0713/002631.329410:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f03c63c80a0, 3
[1:1:0713/002631.329516:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f03c6554080, 2
[31068:31099:0713/002631.329641:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0713/002631.329607:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f03b0216d20, -2
[31068:31099:0713/002631.329683:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 31122, 4, 898e8f10 7fbe292a 61d6161b 3ffb7238 
[1:1:0713/002631.337213:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0713/002631.337634:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1b16d661
[1:1:0713/002631.338067:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1b16d661
[1:1:0713/002631.338769:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1b16d661
[1:1:0713/002631.339321:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b16d661
[1:1:0713/002631.339439:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b16d661
[1:1:0713/002631.339560:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b16d661
[1:1:0713/002631.339672:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b16d661
[1:1:0713/002631.339924:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1b16d661
[1:1:0713/002631.340075:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f03c818e7ba
[1:1:0713/002631.340159:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f03c8185def, 7f03c818e77a, 7f03c81900cf
[1:1:0713/002631.341783:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1b16d661
[1:1:0713/002631.341960:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1b16d661
[1:1:0713/002631.342258:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1b16d661
[1:1:0713/002631.343058:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b16d661
[1:1:0713/002631.343168:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b16d661
[1:1:0713/002631.343267:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b16d661
[1:1:0713/002631.343363:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b16d661
[1:1:0713/002631.343851:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1b16d661
[1:1:0713/002631.343996:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f03c818e7ba
[1:1:0713/002631.344070:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f03c8185def, 7f03c818e77a, 7f03c81900cf
[1:1:0713/002631.346658:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0713/002631.346866:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0713/002631.346966:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe58315668, 0x7ffe583155e8)
[1:1:0713/002631.353672:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0713/002631.356196:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[31068:31068:0713/002631.774849:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[31068:31068:0713/002631.776016:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[31068:31068:0713/002631.784484:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[31068:31068:0713/002631.784544:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[31068:31068:0713/002631.784616:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,31122, 4
[31068:31081:0713/002631.785050:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[31068:31081:0713/002631.785109:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[1:7:0713/002631.785670:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/002631.831890:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0xa36bfab1220
[1:1:0713/002631.832257:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[31068:31092:0713/002631.868648:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0713/002632.036460:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0713/002632.794891:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/002632.796577:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[31068:31068:0713/002632.971100:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[31068:31068:0713/002632.971217:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0713/002633.271958:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/002633.367560:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 163b2cd61f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0713/002633.367754:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/002633.373000:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 163b2cd61f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0713/002633.373171:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/002633.411627:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/002633.411783:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/002633.553967:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 359, "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/002633.556491:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 163b2cd61f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0713/002633.556635:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/002633.568334:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 360, "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/002633.571341:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 163b2cd61f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0713/002633.571489:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/002633.575233:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[31068:31068:0713/002633.575857:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0713/002633.576973:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0xa36bfaafe20
[1:1:0713/002633.577778:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[31068:31068:0713/002633.578327:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[31068:31068:0713/002633.590321:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[31068:31068:0713/002633.590406:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0713/002633.611484:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/002633.899501:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 419 0x7f03b1df12e0 0xa36bfd409e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/002633.900174:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 163b2cd61f78, , , var configData = {"googleBaseUrl":"https://www.google.com.hk/","isAccessibleBrowser":false,"isGoogle
[1:1:0713/002633.900340:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/002633.900902:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[31068:31068:0713/002633.925715:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0713/002633.926840:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0xa36bfab0820
[1:1:0713/002633.926980:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[31068:31068:0713/002633.928139:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0713/002633.933837:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0713/002633.934031:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[31068:31068:0713/002633.935443:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[31068:31068:0713/002633.939545:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[31068:31068:0713/002633.939943:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[31068:31081:0713/002633.944280:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[31068:31081:0713/002633.944333:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[31068:31068:0713/002633.944353:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[31068:31068:0713/002633.944392:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[31068:31068:0713/002633.944453:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,31122, 4
[1:7:0713/002633.945869:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/002634.218123:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0713/002634.351407:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 466 0x7f03b1df12e0 0xa36bfd13e60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/002634.352039:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 163b2cd61f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0713/002634.352186:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/002634.352535:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[31068:31068:0713/002634.511693:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[31068:31068:0713/002634.511780:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0713/002634.523779:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[31068:31068:0713/002634.641733:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[31068:31099:0713/002634.642064:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0713/002634.642196:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0713/002634.642337:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0713/002634.642533:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0713/002634.642615:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0713/002634.644913:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x30775618, 1
[1:1:0713/002634.645125:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x38e0fbb3, 0
[1:1:0713/002634.645302:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x12674dfc, 3
[1:1:0713/002634.645446:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x127cbf52, 2
[1:1:0713/002634.645586:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffb3fffffffbffffffe038 18567730 52ffffffbf7c12 fffffffc4d6712 , 10104, 5
[1:1:0713/002634.646348:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[31068:31099:0713/002634.646579:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING���8Vw0R�|�Mg�l�
[31068:31099:0713/002634.646621:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ���8Vw0R�|�MgHc�l�
[1:1:0713/002634.646570:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f03c63c80a0, 3
[31068:31099:0713/002634.646760:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 31164, 5, b3fbe038 18567730 52bf7c12 fc4d6712 
[1:1:0713/002634.646811:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f03c6554080, 2
[1:1:0713/002634.647459:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f03b0216d20, -2
[1:1:0713/002634.657167:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0713/002634.657369:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 127cbf52
[1:1:0713/002634.657541:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 127cbf52
[1:1:0713/002634.657803:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 127cbf52
[1:1:0713/002634.658307:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 127cbf52
[1:1:0713/002634.658408:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 127cbf52
[1:1:0713/002634.658504:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 127cbf52
[1:1:0713/002634.658595:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 127cbf52
[1:1:0713/002634.658849:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 127cbf52
[1:1:0713/002634.658981:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f03c818e7ba
[1:1:0713/002634.659039:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f03c8185def, 7f03c818e77a, 7f03c81900cf
[1:1:0713/002634.660707:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 127cbf52
[1:1:0713/002634.660852:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 127cbf52
[1:1:0713/002634.661174:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 127cbf52
[1:1:0713/002634.661939:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 127cbf52
[1:1:0713/002634.662053:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 127cbf52
[1:1:0713/002634.662161:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 127cbf52
[1:1:0713/002634.662264:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 127cbf52
[1:1:0713/002634.662814:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 127cbf52
[1:1:0713/002634.663001:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f03c818e7ba
[1:1:0713/002634.663098:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f03c8185def, 7f03c818e77a, 7f03c81900cf
[1:1:0713/002634.665686:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0713/002634.665919:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0713/002634.666030:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe58315668, 0x7ffe583155e8)
[1:1:0713/002634.671983:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0713/002634.672361:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/002634.674321:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0713/002634.760999:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0xa36bfa8f220
[1:1:0713/002634.761165:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0713/002634.948506:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/002634.948730:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/002635.099241:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 541, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/002635.103612:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 163b2ce8e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0713/002635.103824:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/002635.106529:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/002635.176345:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/002635.176771:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 163b2cd61f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0713/002635.176899:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/002635.246530:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/002635.247296:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0713/002635.247421:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 163b2ce8e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0713/002635.247557:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/002635.320815:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/002635.325530:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0713/002635.325661:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 163b2ce8e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0713/002635.325801:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[31068:31068:0713/002635.477831:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[31068:31068:0713/002635.480451:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[31068:31081:0713/002635.494719:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[31068:31081:0713/002635.494782:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[31068:31068:0713/002635.494945:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://voice.hupu.com/
[31068:31068:0713/002635.494990:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://voice.hupu.com/, https://voice.hupu.com/soccer/2452432.html, 1
[31068:31068:0713/002635.495057:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_https://voice.hupu.com/, HTTP/1.1 200 status:200 server:nginx date:Fri, 12 Jul 2019 16:26:35 GMT content-type:text/html; charset=utf-8 vary:Accept-Encoding x-powered-by:PHP/5.4.41 keywords:尤文图斯-意甲-阿贾克斯-国际足球-马泰斯-德利赫特 x-cache:EXPIRED content-encoding:gzip x-server:zhangwuji-lb-20-238-prd.vm.jh  ,31164, 5
[1:7:0713/002635.499595:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/002635.514291:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_https://voice.hupu.com/
[31068:31068:0713/002635.569218:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://voice.hupu.com/, https://voice.hupu.com/, 1
[31068:31068:0713/002635.569282:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://voice.hupu.com/, https://voice.hupu.com
[1:1:0713/002635.567009:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://m.vk.com/"
[1:1:0713/002635.583962:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/002635.628672:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/002635.658613:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/002635.658803:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://voice.hupu.com/soccer/2452432.html"
[1:1:0713/002635.673588:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 134 0x7f03afec9070 0xa36bfb51e60 , "https://voice.hupu.com/soccer/2452432.html"
[1:1:0713/002635.674377:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://voice.hupu.com/, 0a6f00562860, , , 
var __daceDataNameOfChannel = 'soccer';

[1:1:0713/002635.674541:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://voice.hupu.com/soccer/2452432.html", "voice.hupu.com", 3, 1, , , 0
[1:1:0713/002635.743224:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.taobao.com/"
[1:1:0713/002635.774004:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/002635.783827:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.qq.com/"
[1:1:0713/002635.811029:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://amazon.com/"
[1:1:0713/002635.841150:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 170 0x7f03c6554080 0xa36bfbd7b00 1 0 0xa36bfbd7b18 , "https://voice.hupu.com/soccer/2452432.html"
[1:1:0713/002635.842008:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/002635.845134:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://voice.hupu.com/, 0a6f00562860, , , /*! jQuery v1.8.3 jquery.com | jquery.org/license */
(function(e,t){function _(e){var t=M[e]={};ret
[1:1:0713/002635.845292:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://voice.hupu.com/soccer/2452432.html", "voice.hupu.com", 3, 1, , , 0
[1:1:0713/002635.851468:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://tmall.com/"
		remove user.d_f1b45725 -> 0
[1:1:0713/002635.921559:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.jd.com/"
[1:1:0713/002635.948123:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 170 0x7f03c6554080 0xa36bfbd7b00 1 0 0xa36bfbd7b18 , "https://voice.hupu.com/soccer/2452432.html"
[1:1:0713/002635.973072:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://yahoo.com/"
[1:1:0713/002635.989037:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 170 0x7f03c6554080 0xa36bfbd7b00 1 0 0xa36bfbd7b18 , "https://voice.hupu.com/soccer/2452432.html"
[1:1:0713/002636.002099:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://sohu.com/"
[1:1:0713/002636.027160:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 170 0x7f03c6554080 0xa36bfbd7b00 1 0 0xa36bfbd7b18 , "https://voice.hupu.com/soccer/2452432.html"
[1:1:0713/002636.047002:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.100883, 269, 1
[1:1:0713/002636.047181:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/002636.077134:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/002636.077626:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 163b2ce8e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0713/002636.077802:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/002636.253346:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/002636.253526:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://voice.hupu.com/soccer/2452432.html"
[1:1:0713/002636.253990:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 217 0x7f03afec9070 0xa36bfd511e0 , "https://voice.hupu.com/soccer/2452432.html"
[1:1:0713/002636.254495:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://voice.hupu.com/, 0a6f00562860, , , 
        var qqShareContents = '虎扑的这篇文章已经引发热烈讨论，赶快来看看吧�
[1:1:0713/002636.254630:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://voice.hupu.com/soccer/2452432.html", "voice.hupu.com", 3, 1, , , 0
[1:1:0713/002636.259474:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.00588107, 72, 1
[1:1:0713/002636.259624:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/002636.329804:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/002636.329972:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://voice.hupu.com/soccer/2452432.html"
[1:1:0713/002636.330418:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 229 0x7f03afec9070 0xa36bfd42a60 , "https://voice.hupu.com/soccer/2452432.html"
[1:1:0713/002636.330865:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://voice.hupu.com/, 0a6f00562860, , , 
		 	    	 
[1:1:0713/002636.330995:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://voice.hupu.com/soccer/2452432.html", "voice.hupu.com", 3, 1, , , 0
[1:1:0713/002636.333788:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 229 0x7f03afec9070 0xa36bfd42a60 , "https://voice.hupu.com/soccer/2452432.html"
[1:1:0713/002636.337793:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 229 0x7f03afec9070 0xa36bfd42a60 , "https://voice.hupu.com/soccer/2452432.html"
[1:1:0713/002636.339964:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 229 0x7f03afec9070 0xa36bfd42a60 , "https://voice.hupu.com/soccer/2452432.html"
[1:1:0713/002636.375812:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 229 0x7f03afec9070 0xa36bfd42a60 , "https://voice.hupu.com/soccer/2452432.html"
[1:1:0713/002636.382490:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 229 0x7f03afec9070 0xa36bfd42a60 , "https://voice.hupu.com/soccer/2452432.html"
[1:1:0713/002636.415599:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://voice.hupu.com/soccer/2452432.html"
[1:1:0713/002636.419007:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://voice.hupu.com/, 0a6f00562860, , , (){He(d,"")}
[1:1:0713/002636.419216:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://voice.hupu.com/soccer/2452432.html", "voice.hupu.com", 3, 1, , , 0
[1:1:0713/002636.566188:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 265 0x7f03b1df12e0 0xa36bfbac6e0 , "https://voice.hupu.com/soccer/2452432.html"
[1:1:0713/002636.566908:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://voice.hupu.com/, 0a6f00562860, , , define("dist/modules/card/main",["//b3.hoopchina.com.cn/code/seajs/jquery/1.8.3/jquery","./support",
[1:1:0713/002636.567093:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://voice.hupu.com/soccer/2452432.html", "voice.hupu.com", 3, 1, , , 0
[1:1:0713/002636.573685:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://voice.hupu.com/soccer/2452432.html"
[1:1:0713/002636.612692:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 266 0x7f03b1df12e0 0xa36bfbac4e0 , "https://voice.hupu.com/soccer/2452432.html"
[1:1:0713/002636.613306:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://voice.hupu.com/, 0a6f00562860, , , var toolbarpic = "";

[1:1:0713/002636.613496:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://voice.hupu.com/soccer/2452432.html", "voice.hupu.com", 3, 1, , , 0
[1:1:0713/002636.613844:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://voice.hupu.com/soccer/2452432.html"
[1:1:0713/002636.707886:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 280 0x7f03b1df12e0 0xa36bfb9f960 , "https://voice.hupu.com/soccer/2452432.html"
[1:1:0713/002636.708458:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://voice.hupu.com/, 0a6f00562860, , , define("dist/modules/tips/warning",["//b3.hoopchina.com.cn/code/seajs/jquery/1.8.3/jquery"],function
[1:1:0713/002636.708635:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://voice.hupu.com/soccer/2452432.html", "voice.hupu.com", 3, 1, , , 0
[1:1:0713/002636.710399:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://voice.hupu.com/soccer/2452432.html"
[1:1:0713/002636.717743:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 281 0x7f03b1df12e0 0xa36bfbacbe0 , "https://voice.hupu.com/soccer/2452432.html"
[1:1:0713/002636.718225:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://voice.hupu.com/, 0a6f00562860, , , define("dist/modules/share/shareAPI",["//b3.hoopchina.com.cn/code/seajs/jquery/1.8.3/jquery"],functi
[1:1:0713/002636.718385:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://voice.hupu.com/soccer/2452432.html", "voice.hupu.com", 3, 1, , , 0
[1:1:0713/002636.720040:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://voice.hupu.com/soccer/2452432.html"
[1:1:0713/002636.772026:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 290 0x7f03b1df12e0 0xa36bfba1c60 , "https://voice.hupu.com/soccer/2452432.html"
[1:1:0713/002636.773553:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://voice.hupu.com/, 0a6f00562860, , , define(function(require, exports, module) {

	/*! jQuery v1.8.3 jquery.com | jquery.org/license */
	
[1:1:0713/002636.773705:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://voice.hupu.com/soccer/2452432.html", "voice.hupu.com", 3, 1, , , 0
[1:1:0713/002636.868726:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://voice.hupu.com/soccer/2452432.html"
[1:1:0713/002637.065990:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 300 0x7f03b0231bd0 0xa36bfbae3d8 , "https://voice.hupu.com/soccer/2452432.html"
[1:1:0713/002637.083420:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://voice.hupu.com/, 0a6f00562860, , , /*!

 handlebars v1.3.0

Copyright (C) 2011 by Yehuda Katz

Permission is hereby granted, free of ch
[1:1:0713/002637.083641:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://voice.hupu.com/soccer/2452432.html", "voice.hupu.com", 3, 1, , , 0
[1:1:0713/002637.122066:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3d936dea29c8, 0xa36bf85e960
[1:1:0713/002637.122288:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://voice.hupu.com/soccer/2452432.html", 0
[1:1:0713/002637.122512:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://voice.hupu.com/, 302
[1:1:0713/002637.122654:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 302 0x7f03afec9070 0xa36bffc7b60 , 5:3_https://voice.hupu.com/, 1, -5:3_https://voice.hupu.com/, 300 0x7f03b0231bd0 0xa36bfbae3d8 
[1:1:0713/002637.318930:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 300 0x7f03b0231bd0 0xa36bfbae3d8 , "https://voice.hupu.com/soccer/2452432.html"
[1:1:0713/002637.331723:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 300 0x7f03b0231bd0 0xa36bfbae3d8 , "https://voice.hupu.com/soccer/2452432.html"
[1:1:0713/002637.333432:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 300 0x7f03b0231bd0 0xa36bfbae3d8 , "https://voice.hupu.com/soccer/2452432.html"
[1:1:0713/002637.334835:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 300 0x7f03b0231bd0 0xa36bfbae3d8 , "https://voice.hupu.com/soccer/2452432.html"
[1:1:0713/002637.335993:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 300 0x7f03b0231bd0 0xa36bfbae3d8 , "https://voice.hupu.com/soccer/2452432.html"
[1:1:0713/002637.345113:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 300 0x7f03b0231bd0 0xa36bfbae3d8 , "https://voice.hupu.com/soccer/2452432.html"
[1:1:0713/002637.347195:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 300 0x7f03b0231bd0 0xa36bfbae3d8 , "https://voice.hupu.com/soccer/2452432.html"
[1:1:0713/002637.492065:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://voice.hupu.com/, 302, 7f03b280e881
[1:1:0713/002637.497114:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0a6f00562860","ptid":"300 0x7f03b0231bd0 0xa36bfbae3d8 ","rf":"5:3_https://voice.hupu.com/"}
[1:1:0713/002637.497286:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://voice.hupu.com/","ptid":"300 0x7f03b0231bd0 0xa36bfbae3d8 ","rf":"5:3_https://voice.hupu.com/"}
[1:1:0713/002637.497492:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://voice.hupu.com/soccer/2452432.html"
[1:1:0713/002637.497790:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://voice.hupu.com/, 0a6f00562860, , , (){if(J){return}if(!/loaded|complete/.test(j.readyState)){setTimeout(arguments.callee,0);return}f()}
[1:1:0713/002637.497915:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://voice.hupu.com/soccer/2452432.html", "voice.hupu.com", 3, 1, , , 0
[1:1:0713/002637.498307:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3d936dea29c8, 0xa36bf85e950
[1:1:0713/002637.498424:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://voice.hupu.com/soccer/2452432.html", 0
[1:1:0713/002637.498617:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://voice.hupu.com/, 332
[1:1:0713/002637.498743:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 332 0x7f03afec9070 0xa36bfc0f4e0 , 5:3_https://voice.hupu.com/, 1, -5:3_https://voice.hupu.com/, 302 0x7f03afec9070 0xa36bffc7b60 
[1:1:0713/002637.515164:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 326 0x7f03b1df12e0 0xa36bfd4c9e0 , "https://voice.hupu.com/soccer/2452432.html"
[1:1:0713/002637.515907:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://voice.hupu.com/, 0a6f00562860, , , define("dist/message/detail/main",["//b3.hoopchina.com.cn/code/seajs/jquery/1.8.3/jquery","./share",
[1:1:0713/002637.516053:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://voice.hupu.com/soccer/2452432.html", "voice.hupu.com", 3, 1, , , 0
[1:1:0713/002637.998205:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://voice.hupu.com/soccer/2452432.html"
[1:1:0713/002638.035711:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 327 0x7f03b1df12e0 0xa36bfdb43e0 , "https://voice.hupu.com/soccer/2452432.html"
[1:1:0713/002638.036289:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://voice.hupu.com/, 0a6f00562860, , , eval(function(p,a,c,k,e,d){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromChar
[1:1:0713/002638.036384:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://voice.hupu.com/soccer/2452432.html", "voice.hupu.com", 3, 1, , , 0
[1:1:0713/002638.126909:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 328, "https://voice.hupu.com/soccer/2452432.html"
[1:1:0713/002638.127431:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://voice.hupu.com/, 0a6f00562860, , , 
[1:1:0713/002638.127587:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://voice.hupu.com/soccer/2452432.html", "voice.hupu.com", 3, 1, , , 0
[1:1:0713/002638.128455:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 328, "https://voice.hupu.com/soccer/2452432.html"
[1:1:0713/002638.130367:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://voice.hupu.com/soccer/2452432.html"
[1:1:0713/002638.231459:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3d936dea29c8, 0xa36bf85ea10
[1:1:0713/002638.231683:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://voice.hupu.com/soccer/2452432.html", 100
[1:1:0713/002638.231932:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://voice.hupu.com/, 360
[1:1:0713/002638.232095:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 360 0x7f03afec9070 0xa36c01dcae0 , 5:3_https://voice.hupu.com/, 1, -5:3_https://voice.hupu.com/, 328
[1:1:0713/002638.250051:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://voice.hupu.com/soccer/2452432.html"
[1:1:0713/002638.335293:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://voice.hupu.com/soccer/2452432.html"
[1:1:0713/002638.337107:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://voice.hupu.com/soccer/2452432.html"
[1:1:0713/002638.338016:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 25, 0x3d936dea29c8, 0xa36bf85e9f0
[1:1:0713/002638.338131:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://voice.hupu.com/soccer/2452432.html", 25
[1:1:0713/002638.338323:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://voice.hupu.com/, 364
[1:1:0713/002638.338445:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 364 0x7f03afec9070 0xa36c0124d60 , 5:3_https://voice.hupu.com/, 1, -5:3_https://voice.hupu.com/, 328
[1:1:0713/002638.367491:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://voice.hupu.com/, 332, 7f03b280e881
[1:1:0713/002638.372231:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0a6f00562860","ptid":"302 0x7f03afec9070 0xa36bffc7b60 ","rf":"5:3_https://voice.hupu.com/"}
[1:1:0713/002638.372375:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://voice.hupu.com/","ptid":"302 0x7f03afec9070 0xa36bffc7b60 ","rf":"5:3_https://voice.hupu.com/"}
[1:1:0713/002638.372565:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://voice.hupu.com/soccer/2452432.html"
[1:1:0713/002638.372824:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://voice.hupu.com/, 0a6f00562860, , , (){if(J){return}if(!/loaded|complete/.test(j.readyState)){setTimeout(arguments.callee,0);return}f()}
[1:1:0713/002638.372920:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://voice.hupu.com/soccer/2452432.html", "voice.hupu.com", 3, 1, , , 0
[1:1:0713/002638.529161:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://voice.hupu.com/, 360, 7f03b280e881
[1:1:0713/002638.534574:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0a6f00562860","ptid":"328","rf":"5:3_https://voice.hupu.com/"}
[1:1:0713/002638.534718:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://voice.hupu.com/","ptid":"328","rf":"5:3_https://voice.hupu.com/"}
[1:1:0713/002638.534914:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://voice.hupu.com/soccer/2452432.html"
[1:1:0713/002638.535202:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://voice.hupu.com/, 0a6f00562860, , , (){
                scrollTop = $(win).scrollTop();
                
                if(scrollTop
[1:1:0713/002638.535318:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://voice.hupu.com/soccer/2452432.html", "voice.hupu.com", 3, 1, , , 0
[1:1:0713/002638.748316:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://voice.hupu.com/, 364, 7f03b280e881
[1:1:0713/002638.753583:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0a6f00562860","ptid":"328","rf":"5:3_https://voice.hupu.com/"}
[1:1:0713/002638.753726:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://voice.hupu.com/","ptid":"328","rf":"5:3_https://voice.hupu.com/"}
[1:1:0713/002638.753915:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://voice.hupu.com/soccer/2452432.html"
[1:1:0713/002638.754198:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://voice.hupu.com/, 0a6f00562860, , , (){var list=document.body,target=null;EventUtil.addHandlerCompatibility(list,"mousedown",function(ev
[1:1:0713/002638.754312:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://voice.hupu.com/soccer/2452432.html", "voice.hupu.com", 3, 1, , , 0
[1:1:0713/002638.791641:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 377 0x7f03b1df12e0 0xa36c0023160 , "https://voice.hupu.com/soccer/2452432.html"
[1:1:0713/002638.792133:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://voice.hupu.com/, 0a6f00562860, , , define("dist/modules/share/miniShare",["//b3.hoopchina.com.cn/code/seajs/jquery/1.8.3/jquery","modul
[1:1:0713/002638.792253:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://voice.hupu.com/soccer/2452432.html", "voice.hupu.com", 3, 1, , , 0
[1:1:0713/002638.794059:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://voice.hupu.com/soccer/2452432.html"
[1:1:0713/002638.803296:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 378 0x7f03b1df12e0 0xa36c01344e0 , "https://voice.hupu.com/soccer/2452432.html"
[1:1:0713/002638.803797:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://voice.hupu.com/, 0a6f00562860, , , define("dist/modules/follow/followObjectTip",["//b3.hoopchina.com.cn/code/seajs/jquery/1.8.3/jquery"
[1:1:0713/002638.803914:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://voice.hupu.com/soccer/2452432.html", "voice.hupu.com", 3, 1, , , 0
[1:1:0713/002638.805514:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://voice.hupu.com/soccer/2452432.html"
[1:1:0713/002638.830502:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 381 0x7f03b1df12e0 0xa36bfba44e0 , "https://voice.hupu.com/soccer/2452432.html"
[1:1:0713/002638.831225:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://voice.hupu.com/, 0a6f00562860, , , "use strict";!function(a){"function"==typeof define&&define.amd?define(["jquery"],a):a(jQuery)}(func
[1:1:0713/002638.831351:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://voice.hupu.com/soccer/2452432.html", "voice.hupu.com", 3, 1, , , 0
[1:1:0713/002638.861090:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3d936dea29c8, 0xa36bf85e998
[1:1:0713/002638.861305:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://voice.hupu.com/soccer/2452432.html", 0
[1:1:0713/002638.861591:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://voice.hupu.com/, 398
[1:1:0713/002638.861760:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 398 0x7f03afec9070 0xa36c01dc660 , 5:3_https://voice.hupu.com/, 1, -5:3_https://voice.hupu.com/, 381 0x7f03b1df12e0 0xa36bfba44e0 
[1:1:0713/002638.892388:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://voice.hupu.com/soccer/2452432.html", 13
[1:1:0713/002638.892671:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://voice.hupu.com/, 401
[1:1:0713/002638.892812:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 401 0x7f03afec9070 0xa36c09c7e60 , 5:3_https://voice.hupu.com/, 1, -5:3_https://voice.hupu.com/, 381 0x7f03b1df12e0 0xa36bfba44e0 
[1:1:0713/002638.898881:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://voice.hupu.com/soccer/2452432.html"
[1:1:0713/002638.995946:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://voice.hupu.com/, 398, 7f03b280e881
[1:1:0713/002639.002074:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0a6f00562860","ptid":"381 0x7f03b1df12e0 0xa36bfba44e0 ","rf":"5:3_https://voice.hupu.com/"}
[1:1:0713/002639.002271:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://voice.hupu.com/","ptid":"381 0x7f03b1df12e0 0xa36bfba44e0 ","rf":"5:3_https://voice.hupu.com/"}
[1:1:0713/002639.002509:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://voice.hupu.com/soccer/2452432.html"
[1:1:0713/002639.002839:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://voice.hupu.com/, 0a6f00562860, , , (){qn=t}
[1:1:0713/002639.002992:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://voice.hupu.com/soccer/2452432.html", "voice.hupu.com", 3, 1, , , 0
[1:1:0713/002639.009237:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://voice.hupu.com/, 401, 7f03b280e8db
[1:1:0713/002639.014541:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0a6f00562860","ptid":"381 0x7f03b1df12e0 0xa36bfba44e0 ","rf":"5:3_https://voice.hupu.com/"}
[1:1:0713/002639.014692:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://voice.hupu.com/","ptid":"381 0x7f03b1df12e0 0xa36bfba44e0 ","rf":"5:3_https://voice.hupu.com/"}
[1:1:0713/002639.014892:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://voice.hupu.com/, 411
[1:1:0713/002639.015012:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 411 0x7f03afec9070 0xa36c09ca8e0 , 5:3_https://voice.hupu.com/, 0, , 401 0x7f03afec9070 0xa36c09c7e60 
[1:1:0713/002639.015165:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://voice.hupu.com/soccer/2452432.html"
[1:1:0713/002639.015415:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://voice.hupu.com/, 0a6f00562860, , v.fx.tick, (){var e,n=v.timers,r=0;qn=v.now();for(;r<n.length;r++)e=n[r],!e()&&n[r]===e&&n.splice(r--,1);n.leng
[1:1:0713/002639.015531:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://voice.hupu.com/soccer/2452432.html", "voice.hupu.com", 3, 1, , , 0
[1:1:0713/002639.028769:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 406 0x7f03b1df12e0 0xa36c0125260 , "https://voice.hupu.com/soccer/2452432.html"
[1:1:0713/002639.029256:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://voice.hupu.com/, 0a6f00562860, , , define("dist/modules/follow/follow",["//b3.hoopchina.com.cn/code/seajs/jquery/1.8.3/jquery","modules
[1:1:0713/002639.029377:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://voice.hupu.com/soccer/2452432.html", "voice.hupu.com", 3, 1, , , 0
[1:1:0713/002639.030953:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://voice.hupu.com/soccer/2452432.html"
[1:1:0713/002639.136405:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://voice.hupu.com/, 411, 7f03b280e8db
[1:1:0713/002639.141931:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"401 0x7f03afec9070 0xa36c09c7e60 ","rf":"5:3_https://voice.hupu.com/"}
[1:1:0713/002639.142070:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"401 0x7f03afec9070 0xa36c09c7e60 ","rf":"5:3_https://voice.hupu.com/"}
[1:1:0713/002639.142266:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://voice.hupu.com/, 416
[1:1:0713/002639.142384:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 416 0x7f03afec9070 0xa36c0134560 , 5:3_https://voice.hupu.com/, 0, , 411 0x7f03afec9070 0xa36c09ca8e0 
[1:1:0713/002639.142541:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://voice.hupu.com/soccer/2452432.html"
[1:1:0713/002639.142805:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://voice.hupu.com/, 0a6f00562860, , v.fx.tick, (){var e,n=v.timers,r=0;qn=v.now();for(;r<n.length;r++)e=n[r],!e()&&n[r]===e&&n.splice(r--,1);n.leng
[1:1:0713/002639.142920:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://voice.hupu.com/soccer/2452432.html", "voice.hupu.com", 3, 1, , , 0
[1:1:0713/002639.161770:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://voice.hupu.com/soccer/2452432.html"
[1:1:0713/002639.162125:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://voice.hupu.com/, 0a6f00562860, , ready, (e){if(e===!0?--v.readyWait:v.isReady)return;if(!i.body)return setTimeout(v.ready,1);v.isReady=!0;if
[1:1:0713/002639.162246:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://voice.hupu.com/soccer/2452432.html", "voice.hupu.com", 3, 1, , , 0
[1:1:0713/002639.162444:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://voice.hupu.com/soccer/2452432.html"
[1:1:0713/002639.163054:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://voice.hupu.com/soccer/2452432.html"
[1:1:0713/002639.163321:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://voice.hupu.com/soccer/2452432.html"
[1:1:0713/002639.163642:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://voice.hupu.com/soccer/2452432.html"
[1:1:0713/002639.163897:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://voice.hupu.com/soccer/2452432.html"
[1:1:0713/002639.172766:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://voice.hupu.com/, 416, 7f03b280e8db
[1:1:0713/002639.179164:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"411 0x7f03afec9070 0xa36c09ca8e0 ","rf":"5:3_https://voice.hupu.com/"}
[1:1:0713/002639.179315:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"411 0x7f03afec9070 0xa36c09ca8e0 ","rf":"5:3_https://voice.hupu.com/"}
[1:1:0713/002639.179525:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://voice.hupu.com/, 419
[1:1:0713/002639.179646:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 419 0x7f03afec9070 0xa36c09cb160 , 5:3_https://voice.hupu.com/, 0, , 416 0x7f03afec9070 0xa36c0134560 
[1:1:0713/002639.179801:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://voice.hupu.com/soccer/2452432.html"
[1:1:0713/002639.180065:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://voice.hupu.com/, 0a6f00562860, , v.fx.tick, (){var e,n=v.timers,r=0;qn=v.now();for(;r<n.length;r++)e=n[r],!e()&&n[r]===e&&n.splice(r--,1);n.leng
[1:1:0713/002639.180167:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://voice.hupu.com/soccer/2452432.html", "voice.hupu.com", 3, 1, , , 0
[1:1:0713/002639.197325:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://voice.hupu.com/, 419, 7f03b280e8db
[1:1:0713/002639.202762:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"416 0x7f03afec9070 0xa36c0134560 ","rf":"5:3_https://voice.hupu.com/"}
[1:1:0713/002639.202895:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"416 0x7f03afec9070 0xa36c0134560 ","rf":"5:3_https://voice.hupu.com/"}
[1:1:0713/002639.203111:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://voice.hupu.com/, 421
[1:1:0713/002639.203228:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 421 0x7f03afec9070 0xa36c01285e0 , 5:3_https://voice.hupu.com/, 0, , 419 0x7f03afec9070 0xa36c09cb160 
[1:1:0713/002639.203377:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://voice.hupu.com/soccer/2452432.html"
[1:1:0713/002639.203635:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://voice.hupu.com/, 0a6f00562860, , v.fx.tick, (){var e,n=v.timers,r=0;qn=v.now();for(;r<n.length;r++)e=n[r],!e()&&n[r]===e&&n.splice(r--,1);n.leng
[1:1:0713/002639.203748:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://voice.hupu.com/soccer/2452432.html", "voice.hupu.com", 3, 1, , , 0
[1:1:0713/002639.205254:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://voice.hupu.com/, 421, 7f03b280e8db
[1:1:0713/002639.211188:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"419 0x7f03afec9070 0xa36c09cb160 ","rf":"5:3_https://voice.hupu.com/"}
[1:1:0713/002639.211320:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"419 0x7f03afec9070 0xa36c09cb160 ","rf":"5:3_https://voice.hupu.com/"}
[1:1:0713/002639.211520:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://voice.hupu.com/, 423
[1:1:0713/002639.211638:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 423 0x7f03afec9070 0xa36c09cd4e0 , 5:3_https://voice.hupu.com/, 0, , 421 0x7f03afec9070 0xa36c01285e0 
[1:1:0713/002639.211785:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://voice.hupu.com/soccer/2452432.html"
[1:1:0713/002639.212025:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://voice.hupu.com/, 0a6f00562860, , v.fx.tick, (){var e,n=v.timers,r=0;qn=v.now();for(;r<n.length;r++)e=n[r],!e()&&n[r]===e&&n.splice(r--,1);n.leng
[1:1:0713/002639.212125:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://voice.hupu.com/soccer/2452432.html", "voice.hupu.com", 3, 1, , , 0
[1:1:0713/002639.223619:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://voice.hupu.com/, 423, 7f03b280e8db
[1:1:0713/002639.229082:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"421 0x7f03afec9070 0xa36c01285e0 ","rf":"5:3_https://voice.hupu.com/"}
[1:1:0713/002639.229225:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"421 0x7f03afec9070 0xa36c01285e0 ","rf":"5:3_https://voice.hupu.com/"}
[1:1:0713/002639.229420:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://voice.hupu.com/, 425
[1:1:0713/002639.229539:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 425 0x7f03afec9070 0xa36c0127ee0 , 5:3_https://voice.hupu.com/, 0, , 423 0x7f03afec9070 0xa36c09cd4e0 
[1:1:0713/002639.229689:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://voice.hupu.com/soccer/2452432.html"
[1:1:0713/002639.229939:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://voice.hupu.com/, 0a6f00562860, , v.fx.tick, (){var e,n=v.timers,r=0;qn=v.now();for(;r<n.length;r++)e=n[r],!e()&&n[r]===e&&n.splice(r--,1);n.leng
[1:1:0713/002639.230053:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://voice.hupu.com/soccer/2452432.html", "voice.hupu.com", 3, 1, , , 0
[1:1:0713/002639.231468:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://voice.hupu.com/, 425, 7f03b280e8db
[1:1:0713/002639.237286:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"423 0x7f03afec9070 0xa36c09cd4e0 ","rf":"5:3_https://voice.hupu.com/"}
[1:1:0713/002639.237421:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"423 0x7f03afec9070 0xa36c09cd4e0 ","rf":"5:3_https://voice.hupu.com/"}
[1:1:0713/002639.237643:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://voice.hupu.com/, 427
[1:1:0713/002639.237767:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 427 0x7f03afec9070 0xa36c01236e0 , 5:3_https://voice.hupu.com/, 0, , 425 0x7f03afec9070 0xa36c0127ee0 
[1:1:0713/002639.237919:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://voice.hupu.com/soccer/2452432.html"
[1:1:0713/002639.238160:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://voice.hupu.com/, 0a6f00562860, , v.fx.tick, (){var e,n=v.timers,r=0;qn=v.now();for(;r<n.length;r++)e=n[r],!e()&&n[r]===e&&n.splice(r--,1);n.leng
[1:1:0713/002639.238273:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://voice.hupu.com/soccer/2452432.html", "voice.hupu.com", 3, 1, , , 0
[1:1:0713/002639.249820:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://voice.hupu.com/, 427, 7f03b280e8db
[1:1:0713/002639.255386:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"425 0x7f03afec9070 0xa36c0127ee0 ","rf":"5:3_https://voice.hupu.com/"}
[1:1:0713/002639.255519:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"425 0x7f03afec9070 0xa36c0127ee0 ","rf":"5:3_https://voice.hupu.com/"}
[1:1:0713/002639.255716:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://voice.hupu.com/, 429
[1:1:0713/002639.255834:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 429 0x7f03afec9070 0xa36bfeaa5e0 , 5:3_https://voice.hupu.com/, 0, , 427 0x7f03afec9070 0xa36c01236e0 
[1:1:0713/002639.255986:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://voice.hupu.com/soccer/2452432.html"
[1:1:0713/002639.256221:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://voice.hupu.com/, 0a6f00562860, , v.fx.tick, (){var e,n=v.timers,r=0;qn=v.now();for(;r<n.length;r++)e=n[r],!e()&&n[r]===e&&n.splice(r--,1);n.leng
[1:1:0713/002639.256334:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://voice.hupu.com/soccer/2452432.html", "voice.hupu.com", 3, 1, , , 0
[1:1:0713/002639.257745:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://voice.hupu.com/, 429, 7f03b280e8db
[1:1:0713/002639.263595:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"427 0x7f03afec9070 0xa36c01236e0 ","rf":"5:3_https://voice.hupu.com/"}
[1:1:0713/002639.263729:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"427 0x7f03afec9070 0xa36c01236e0 ","rf":"5:3_https://voice.hupu.com/"}
[1:1:0713/002639.263929:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://voice.hupu.com/, 431
[1:1:0713/002639.264046:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 431 0x7f03afec9070 0xa36c09c7a60 , 5:3_https://voice.hupu.com/, 0, , 429 0x7f03afec9070 0xa36bfeaa5e0 
[1:1:0713/002639.264191:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://voice.hupu.com/soccer/2452432.html"
[1:1:0713/002639.264451:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://voice.hupu.com/, 0a6f00562860, , v.fx.tick, (){var e,n=v.timers,r=0;qn=v.now();for(;r<n.length;r++)e=n[r],!e()&&n[r]===e&&n.splice(r--,1);n.leng
[1:1:0713/002639.264555:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://voice.hupu.com/soccer/2452432.html", "voice.hupu.com", 3, 1, , , 0
[1:1:0713/002640.008430:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/002654.506222:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://voice.hupu.com/, 0a6f00562860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0713/002654.506403:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://voice.hupu.com/soccer/2452432.html", "voice.hupu.com", 3, 1, , , 0
[3:3:0713/002655.225146:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[31068:31099:0713/002655.251871:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 6
[3:3:0713/002655.252239:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0713/002655.252355:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0713/002655.252464:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0713/002655.252541:INFO:zygote_linux.cc(633)] 		cid is 6
[1:1:0713/002655.255121:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0xe7da57a, 1
[1:1:0713/002655.255369:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x3f640266, 0
[1:1:0713/002655.255498:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0xbaa56e3, 3
[1:1:0713/002655.255609:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x32416eff, 2
[1:1:0713/002655.255717:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 6602643f 7affffffa57d0e ffffffff6e4132 ffffffe356ffffffaa0b , 10104, 6
[1:1:0713/002655.256484:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[31068:31099:0713/002655.256658:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGfd?z�}�nA2�V��m�
[1:1:0713/002655.256649:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f03c63c80a0, 3
[31068:31099:0713/002655.256706:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is fd?z�}�nA2�V���m�
[31068:31099:0713/002655.256818:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 31181, 6, 6602643f 7aa57d0e ff6e4132 e356aa0b 
[1:1:0713/002655.256737:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f03c6554080, 2
[1:1:0713/002655.256897:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f03b0216d20, -2
[1:1:0713/002655.262994:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0713/002655.263405:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 32416eff
[1:1:0713/002655.263856:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 32416eff
[1:1:0713/002655.264945:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 32416eff
[1:1:0713/002655.265780:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 32416eff
[1:1:0713/002655.265898:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 32416eff
[1:1:0713/002655.266002:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 32416eff
[1:1:0713/002655.266100:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 32416eff
[1:1:0713/002655.266321:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 32416eff
[1:1:0713/002655.266454:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f03c818e7ba
[1:1:0713/002655.266527:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f03c8185def, 7f03c818e77a, 7f03c81900cf
[1:1:0713/002655.268164:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 32416eff
[1:1:0713/002655.268351:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 32416eff
[1:1:0713/002655.268672:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 32416eff
[1:1:0713/002655.269560:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 32416eff
[1:1:0713/002655.269688:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 32416eff
[1:1:0713/002655.269804:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 32416eff
[1:1:0713/002655.269910:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 32416eff
[1:1:0713/002655.270320:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 32416eff
[1:1:0713/002655.270508:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f03c818e7ba
[1:1:0713/002655.270600:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f03c8185def, 7f03c818e77a, 7f03c81900cf
[1:1:0713/002655.273263:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0713/002655.273482:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0713/002655.273592:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe58315ef8, 0x7ffe58315e78)
[1:1:0713/002655.281907:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0713/002655.659153:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "https://voice.hupu.com/soccer/2452432.html"
[1:1:0713/002655.659550:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://voice.hupu.com/, 0a6f00562860, , u, (e){return typeof v=="undefined"||!!e&&v.event.triggered===e.type?t:v.event.dispatch.apply(u.elem,ar
[1:1:0713/002655.659653:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://voice.hupu.com/soccer/2452432.html", "voice.hupu.com", 3, 1, , , 0
[1:1:0713/002655.663604:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 50, 0x3d936dea29c8, 0xa36bf85ea20
[1:1:0713/002655.663764:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://voice.hupu.com/soccer/2452432.html", 50
[1:1:0713/002655.663950:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://voice.hupu.com/, 490
[1:1:0713/002655.664060:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 490 0x7f03afec9070 0xa36c09ced60 , 5:3_https://voice.hupu.com/, 1, -5:3_https://voice.hupu.com/, 485 0x7f03bf1da960 0xa36c1091920 0xa36c1091930 
[1:1:0713/002655.664812:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3d936dea29c8, 0xa36bf85ea20
[1:1:0713/002655.664923:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://voice.hupu.com/soccer/2452432.html", 100
[1:1:0713/002655.665093:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://voice.hupu.com/, 491
[1:1:0713/002655.665206:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 491 0x7f03afec9070 0xa36c01210e0 , 5:3_https://voice.hupu.com/, 1, -5:3_https://voice.hupu.com/, 485 0x7f03bf1da960 0xa36c1091920 0xa36c1091930 
[1:1:0713/002655.762246:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://voice.hupu.com/, 490, 7f03b280e881
[1:1:0713/002655.770045:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0a6f00562860","ptid":"485 0x7f03bf1da960 0xa36c1091920 0xa36c1091930 ","rf":"5:3_https://voice.hupu.com/"}
[1:1:0713/002655.770242:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://voice.hupu.com/","ptid":"485 0x7f03bf1da960 0xa36c1091920 0xa36c1091930 ","rf":"5:3_https://voice.hupu.com/"}
[1:1:0713/002655.770455:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://voice.hupu.com/soccer/2452432.html"
[1:1:0713/002655.770739:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://voice.hupu.com/, 0a6f00562860, , , (){

                    for( var key in FULLSCREENS ) {
                        FULLSCREENS[ key
[1:1:0713/002655.770862:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://voice.hupu.com/soccer/2452432.html", "voice.hupu.com", 3, 1, , , 0
[1:1:0713/002655.771556:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://voice.hupu.com/, 491, 7f03b280e881
[1:1:0713/002655.778351:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0a6f00562860","ptid":"485 0x7f03bf1da960 0xa36c1091920 0xa36c1091930 ","rf":"5:3_https://voice.hupu.com/"}
[1:1:0713/002655.778481:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://voice.hupu.com/","ptid":"485 0x7f03bf1da960 0xa36c1091920 0xa36c1091930 ","rf":"5:3_https://voice.hupu.com/"}
[1:1:0713/002655.778653:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://voice.hupu.com/soccer/2452432.html"
[1:1:0713/002655.778883:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://voice.hupu.com/, 0a6f00562860, , , (){
                scrollTop = $(win).scrollTop();
                
                if(scrollTop
[1:1:0713/002655.778993:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://voice.hupu.com/soccer/2452432.html", "voice.hupu.com", 3, 1, , , 0
[1:1:0713/002655.834440:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
